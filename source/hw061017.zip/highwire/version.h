#define _HIGHWIRE_MAJOR_     0
#define _HIGHWIRE_MINOR_     3
#define _HIGHWIRE_REVISION_  1
#define _HIGHWIRE_BETATAG_   "beta5"
#define _HIGHWIRE_VERSION_   "0.3.1"
