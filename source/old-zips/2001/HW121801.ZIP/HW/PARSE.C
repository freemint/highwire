#include <stdlib.h>
#include <string.h>

#ifdef LATTICE
#include <aes.h>
#endif

#ifdef __PUREC__
#include <aes.h>
#include "vdicol.h"
#endif /* end PUREC */

#ifdef __GNUC__
#include <gemx.h>
#else
# define wind_set_str(hdl, what, str) wind_set (hdl, what, str)
#endif

#include "global.h"

#ifndef LATTICE
#include "stptok.h"
#endif

/* just for printf for testing */
#include <stdio.h>

char window_title[80];

/* 01.10.2001 MJ */
typedef struct htmlcolor HTMLCOLOR;
#define MAX_COLOUR 85
struct htmlcolor {
    char name[20];
    char hexval[8];
    } level_1_boss, blue_one;

HTMLCOLOR colours[] = {
"black", "#000000", "silver", "#c0c0c0", "green", "#008000",
"gray", "#808080", "white", "#ffffff", "maroon", "#800000",
"red", "#ff0000", "purple", "#800080", "lime", "#00ff00",
"olive", "#808000", "yellow", "#ffff00", "navy", "#000080",
"blue", "#0000FF", "teal", "#008080", "aqua", "#00ffff",
"fuchsia", "#ff00ff", "chocolate", "#D2691E", "honeydew", "#F0FFF0",
"aliceblue", "#F0F8FF", "antiquewhite", "#FAEBD7", "aquamarine", "#7FFFD4",
"azure", "#F0FFFF", "beige", "#F5F5DC", "blueviolet", "#8A2BE2",
"brown", "#A52A2A", "burlywood", "#DEB887", "cadetblue", "#5F9EA0",
"chartreuse", "#7FFF00", "coral", "#FF7F50", "cornflowerblue", "#6495ED",
"cornsilk", "#FFF8DC", "crimson", "#DC143C", "darkblue", "#00008B",
"darkcyan", "#008B8B", "darkgoldenrod", "#B8860B", "darkgray", "#A9A9A9",
"darkgreen", "#006400", "darkkhaki", "#BDB76B", "darkmagenta", "#8B008B",
"darkolivegreen", "#556B2F", "darkorange", "#FF8C00", "darkorchid", "#9932CC", 
"darkred", "#8B0000", "darksalmon", "#E9967A", "darkseagreen", "#8FBC8F", 
"darkslateblue", "#483D8B", "darkslategray", "#2F4F4F", "darkturquoise", "#00CED1", 
"darkviolet", "#9400D3", "deeppink", "#FF1493", "deepskyblue", "#00BFFF", 
"dimgray", "#696969", "dodgerblue", "#1E90FF", "firebrick", "#B22222", 
"floralwhite", "#FFFAF0", "forestgreen", "#228B22", "gainsboro", "#DCDCDC", 
"ghostwhite", "#F8F8FF", "gold", "#FFD700", "goldenrod", "#DAA520", 
"greenyellow", "#ADFF2F", "hotpink","#FF69B4", "indianred", "#CD5C5C",
"indigo", "#4B0082", "ivory", "#FFFFF0", "khaki", "#F0E68C", 
"lavender", "#E6E6FA", "lavenderblush", "#FFF0F5", "lawngreen", "#7CFC00", 
"lemonchiffon", "#FFFACD", "lightblue", "#ADD8E6", "lightcoral","#F08080",
"lightcyan", "#E0FFFF", "lightgoldenrodyellow","#FAFAD2", "lightgreen", "#90EE90", 
"lightgrey", "#D3D3D3", "lightpink", "#FFB6C1", "lightsalmon", "#FFA07A", 
"lightseagreen", "#20B2AA", "lightskyblue", "#87CEFA", "lightslategray", "#778899", 
"lightsteelblue", "#B0C4DE", "lightyellow", "#FFFFE0", "limegreen", "#32CD32", 
"linen", "#FAF0E6" 
}; 

typedef struct htmlcharset HTMLCHARSET;
#define MAX_CHAR 114
struct htmlcharset {
    char name[10];
    int isoval;
    int atarival;
    };

HTMLCHARSET htmlchars[] = {
"aacute", 262, 160, "acirc", 258, 131, "acute", 129, 186,
"aelig", 118, 145, "agrave", 260, 133, "amp", 6, 38,
"aring", 117, 134, "atilde", 254, 176, "auml", 256, 132,
"frac14", 225, 172, "frac12", 226, 171, "frac34", 227, 127,
"raquo", 126, 175, "reg", 333, 190, "quot", 2, 34,
"sect", 110, 221, "shy", 111, 95, "sup1", 159, 39, 
"sup2", 160, 253, "sup3", 161, 254, "szlig", 121, 158,
"Aacute", 261, 160, "Acirc", 257, 131, "AElig", 114, 146,
"Agrave", 259, 182, "Aring", 113, 143, "Atilde", 253, 183,
"Auml", 255, 142, "brvbar", 277, 124, "ccedil", 149, 135,
"cedil", 141, 44, "cent", 98, 105, "copy", 332, 189,
"curren", 278, 127, "Ccedil", 148, 128, "deg", 146, 248,
"divide", 285, 246, "eacute", 252, 130, "ecirc", 248, 136,
"egrave", 250, 138, "eth", 273, 229, "euml", 246, 137,
"Eacute", 251, 144, "Ecirc", 247, 136, "ETH", 169, 229,
"Egrave", 249, 138, "Euml", 245, 137, "gt", 30, 62,
"iacute", 242, 161, "icirc", 238, 140, "iexcl", 128, 173,
"igrave", 240, 141, "iquest", 127, 168, "iuml", 236, 139,
"Iacute", 241, 161, "Icirc", 237, 140, "Igrave", 239, 141,
"Iuml", 235, 139, "laquo", 125, 174, "lt", 28, 60,
"macr", 230, 255, "micro", 325, 230, "middot", 102, 250,
"not", 309, 170, "ntilde", 195, 164, "Ntilde", 196, 165,
"oacute", 199, 162, "ocirc", 203, 147, "ograve", 201, 149,
"ordf", 538, 127, "ordm", 147, 248, "oslash", 119, 179,
"otilde", 207, 177, "ouml", 205, 148, "Oacute", 200, 162,
"Ocirc", 204, 147, "Ograve", 202, 149, "Oslash", 115, 178,
"Otilde", 208, 184, "Ouml", 206, 153, "para", 279, 188,
"plusmn", 286, 241, "pound", 97, 156, "thorn", 271, 127, 
"times", 284, 42, "THORN", 272, 127, "uacute", 209, 163,
"ucirc", 213, 150, "ugrave", 211, 151, "uml", 135, 185,

"uuml", 215, 154, "Uacute", 210, 163, "Ucirc", 214, 150,
"Ugrave", 212, 151, "Uuml", 216, 154, "yacute", 223, 121, 
"yen", 274, 157, "yuml", 221, 152, "Yacute", 224, 89,
"larr", 32, 4, "uarr", 32, 1, "rarr", 32, 3, 
"darr", 32, 3, "sum", 32, 228, "radic", 32, 251,
"infin", 32, 223, "isin", 32, 238, "cap", 32, 239,
"equiv", 32, 240, "le", 32, 243, "ge", 32, 242,
"trade", 32, 191, "ataril", 32, 14, "atarir", 32, 15
};

/* - */

/* variable
 *  find if a variable is set in a buffer
 *
 *  start_symbol is the pointer to the buffer
 *  search_string is the variable we are searching for
 *  out is the receiving buffer for the variable value
 *
 *  returns
 * '!' = variable not found
 * '*' = variable found no value
 * <some value> = variable found set to <some value>
 *
 * There is some funny stuff that has to go on, since HTML
 * is a very loose style.  Some people include alot of excess
 * spaces... Don't ask me why.  However we have to catch these
 * when they appear and seperate them out.
 *
 */

void
variable (char *start_symbol, char *search_string, char *out)
{
	char buffer[100], *symbol_position, *extract_position, *excess_position,
	*end_position;
	WORD search_string_length;
	WORD loop;
	
	/* I'm adding these to isolate a smaller part of the buffer
	 * we are scanning for variables in tags with this routine
	 * not scanning the entire document....
	 * at least that is what we should be doing.
	 * I'm certain there is more improvement that could be done
	 * baldrick July 13, 2001
	 */
	 
	long buffer_len, remain_len, diff_len;
	char test_buffer[500] = "\0"; /* This may need to be even larger in the real world*/

	search_string_length = strlen (search_string);

/*printf("search = %s              \r\n",search_string);
*/

	symbol_position = start_symbol;
	while (*symbol_position)
	{
		if (*symbol_position == ' ')
		{
			symbol_position++;
			break;
		}
		symbol_position++;
	}

	/* what I am doing here is finding the next tag end
	 * in the buffer.  I'm getting the various lengths
	 * and determining how much exists before the tag end.
	 * I then copy that to a new buffer
	 * and set my scanning symbol to the start of this smaller
	 * buffer.  Should save a bit of time on big documents.
	 * baldrick July 13, 2001
	 */

	buffer_len = strlen(start_symbol);
	
	excess_position = strchr(start_symbol,'>');
/*	excess_position = stptok (symbol_position, buffer, 100, ">");*/

	remain_len = strlen(excess_position); /* if we use strchr we don't need  + 1; */
	
	diff_len = buffer_len - remain_len;

	strncpy(test_buffer,start_symbol,diff_len);
	
	symbol_position = (char *)&test_buffer[0];

	/* ok now we have isolated the buffer, get rid of any
	 * spurious line endings that might have been included
	 */
	 
	for (loop = 0; loop < diff_len; loop++)
	{
		if (test_buffer[loop] == 10) /* line feed */
			test_buffer[loop] = 32;
		else if (test_buffer[loop] == 13) /* carriage return */
			test_buffer[loop] = 32;
	}
	
	*out = '!';
	*(out + 1) = '\0';
	for (;;)
	{
		/*	since the buffer we are searching should no longer
		 *  have a > contained within it.  We can now dump it from
		 * the stptok() call.  
		 * baldrick July 13, 2001
		 *
			symbol_position = stptok (symbol_position, buffer, 100, " >");
		 */
		 
		symbol_position = stptok (symbol_position, buffer, 100, " ");

		if (!symbol_position || !*symbol_position)
			return;

		/* if there is a space kill it, maybe this should be while? */
		if (*symbol_position == ' ')
			symbol_position++;

/*printf("symbol position = %s\r\n",symbol_position);
*/
		if (*symbol_position != '\0' && strnicmp (symbol_position, search_string, search_string_length) == 0)
		{
			extract_position = strchr (symbol_position, '=');

			if (extract_position != (char *)NULL)
			{				
/*printf("extract_position position = %s\r\n",extract_position);
*/
				/*advance past = */
				extract_position++;

				/* clear out useless spaces */
				if (*extract_position == ' ')
					while(*extract_position == ' ')
						extract_position++;
			}
			
			/* we now check if there is anything left and
			 * copy that to out[] for external use
			 */
			 
			if (extract_position == '\0')
				*out = '*';
			else
			{
				/* get rid of initial " */
				if (*extract_position == '"')
					extract_position++;
					
				buffer_len = strlen(extract_position);

				end_position = stptok (extract_position, buffer, 100, " ");

				remain_len = strlen(end_position);
				
				diff_len = buffer_len - remain_len;

				/* copy out the value we want and terminate it */				
				strncpy (out, extract_position,diff_len);
				out[diff_len] = '\0';

				/* get rid of junk trailing space */
				if(out[diff_len - 1] == ' ')
				{
					out[diff_len - 1] = '\0';
					diff_len -= 1;				
				}	

				/* get rid of trailing " */
				if(out[diff_len - 1] == '"')
					out[diff_len - 1] = '\0';
			}

/*			printf("out = %s            \r\n",out);
*/			
			return;
		}

		if (*symbol_position == '>')
			return;
		while (*symbol_position == ' ')
			symbol_position++;

		symbol_position++;
	}
}


/* kill_to_end()
 * 
 * purpose - speed up parsing by immediately advancing
 * data past already processed sections
 */
 
char *
kill_to_end(char *symbol)
{
/*
char shit[12];

strncpy(shit,symbol,12);
printf("%s                                                       \r\n",shit);
*/

	while (*(symbol) != '\0' && *(symbol) != '>')
		symbol++;

	return(symbol);
}

WORD
convert_to_number (const char *text)
{
	char *next;
	long value;

	if (*text == '"')
		text++;
		
	value = strtol (text, &next, 0);

	/* XXX */
	if (next && *next == '%')
		value = -value;

	return value;
}

void
word_store (struct frame_item *p_frame, WORD *active_word_buffer, WORD *active_word)
{
	WORD pts[8], string_length;

	*active_word = 0;
	for (string_length = 0; active_word_buffer[string_length] != 0; string_length++) ;
	string_length++;
	p_frame->current_word->item = malloc (string_length * 2);
	memcpy (p_frame->current_word->item, active_word_buffer, string_length * 2);

	vqt_f_extent16 (vdi_handle, p_frame->current_word->item, pts);

	p_frame->current_word->word_width += pts[2] - pts[0];
}

WORD
map (char symbol)
{
	if (symbol == ' ')
		return (Space_Code);
		
	return ((WORD) (symbol - 32));
}

WORD
list_indent (WORD type)
{
	switch (type)
	{
		case 0:
			return (POINT_SIZE * 2);
		case 1:
			return (POINT_SIZE * 3);
		case 2:
			return (POINT_SIZE * 4);
	}
	return (0);
}


/* set_pre_font()
 *
 * just a couple of lines that modify the current font to being 
 * the PRE font.
 * Used in numerous places
 *
 *  current_word is the current_word
 *  flag determines operation
 *     if 1 set to pre_font
 *     if not 1 turn off prefont
 */
 
void
set_pre_font(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
		current_word->styles.font = pre_font;
	else
		current_word->styles.font = normal_font;

	current_word->changed.font = true;

}

/* set_font_bold
 * 
 * changes the value of the BOLD status of a word
 *
 * current_word  = current word
 * flag determines operation
 *    if 1 add to bold
 *    if not 1 subtract from bold
 */

void
set_font_bold(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.bold++;
										
		if (current_word->styles.bold == 1)
			current_word->changed.font = true;
	}
	else
	{
		if (current_word->styles.bold > 0)
			current_word->styles.bold--;
				
		if(current_word->styles.bold == 0)
			current_word->changed.font = true;
	}
}

/* set_font_italic()
 * 
 * changes the value of the Italic status of a word
 *
 * current_word = current word
 * flag determines operation
 *    if 1 add to italic
 *    if not 1 subtract from italic
 */

void
set_font_italic(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.italic++;
	
		if (current_word->styles.italic == 1)
			current_word->changed.font = true;
	}
	else
	{
		if (current_word->styles.italic > 0)
			current_word->styles.italic--;
											
		if (current_word->styles.italic == 0)
			current_word->changed.font = true;
	}
}

/* set_font_strike()
 *
 * changes the value of the Strike status of a word
 * 
 * current_word = current word
 * flag determines operation
 *    if 1 add to strike
 *    if not 1 subtract from strike
 */
 
void
set_font_strike(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.strike++;
		current_word->changed.style = true;
	}
	else
	{
		if (current_word->styles.strike != 0)
			current_word->styles.strike--;

		current_word->changed.style = true;
	}
}

/* set_font_underline()
 *
 * changes the value of the underlined status of a word
 * 
 * current_word = current word
 * flag determines operation
 *    if 1 add to underline
 *    if not 1 subtract from underline
 */
 
void
set_font_underline(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.underlined++;
		current_word->changed.style = true;
	}
	else
	{
		if (current_word->styles.underlined != 0)
			current_word->styles.underlined--;

		current_word->changed.style = true;
	}
}

/* set_center_text()
 *
 * changes the value of paragraphs alignment
 * 
 * flag determines operation
 *    if 1  center text
 *    if not 1 left justify text
 */
 
void
set_center_text(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	if (flag == 1)
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	if (flag == 1)
		p_frame->current_paragraph->alignment = center;
	else
		p_frame->current_paragraph->alignment = 0;
}

/* set_blockquote_text()
 *
 * changes the value of paragraphs indentation
 * 
 * flag determines operation
 *    if 1  blockquote text
 *    if not 1  unindent text
 */
 
void
set_blockquote_text(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	add_paragraph(p_frame,active_word_buffer);

	p_frame->active_word = active_word_buffer;

	if (flag == 1)
	{
		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->eop_space = 0;
		p_frame->current_paragraph->left_border += list_indent (2);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
	else
	{
		p_frame->current_paragraph->left_border -= list_indent(2);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
}


/* parse_color()
 * takes a string and find the matching VDI color index
 * baldrick - august 20, 2001
 * mj - october 01, 2001: function now uses big color array
 */
 
WORD
parse_color(char *text)
{
	WORD new_color = 1;
	int i;
	char *scan_area;
	if (*text == '"')
		text++;

	switch(*(strupr(text)))
	{
		case '#': /* color index mapped */
			scan_area = (char *)(text + 1);

		break;
	}
	for (i = 0; i<MAX_COLOUR; i++)
	{
		if (stricmp(text, colours[i].name) == 0) {
			scan_area = (char *)(colours[i].hexval + 1);
			break;	
		}
	}

	new_color = parse_convert_colour(scan_area);
			
/*printf("returning from parse color %d       \r\n",new_color);
*/
	return(new_color);
}

/* parse anchor
 * ideally you drop the input on this routine
 * and it parses and processes the body tag information
 * baldrick - December 3, 2001
 * 
 * flag determines operation
 *    if 1  start d tag
 *    if not 1 end d tag
 * baldrick - December 17, 2001
 */

void
parse_anchor (char *symbol, struct frame_item *p_frame, WORD flag)
{
	char output[100];
	char out2[100];

	if (flag == 1)
	{
		variable (symbol, "href", output);

		if (*output != '!')
		{						
			p_frame->current_word->colour = p_frame->link_colour; /*link_colour;*/
			p_frame->current_word->changed.colour = true;

			variable (symbol, "target", out2);

			if (*out2 != '!')
			{
				p_frame->current_word->link = new_url_link (output, href, out2);
			}
			else
				p_frame->current_word->link = new_url_link (output, href, p_frame->frame_name);
		}
		else
		{
			variable (symbol, "name", output);

			if (*output != '!')
				p_frame->current_word->link = new_url_link(output, name,p_frame->frame_name);
		}	
	}
	else
	{
		p_frame->current_word->colour = p_frame->text_colour;
		p_frame->current_word->link = 0;
		p_frame->current_word->changed.colour = true;
	}
}

/* parse body tag
 * ideally you drop the input on this routine
 * and it parses and processes the body tag information
 *
 * baldrick - December 3, 2001
 */

void
parse_body (char *symbol, struct frame_item *p_frame)
{
	char output[100];
	WORD temp; /* just a junk variable for random use */

	variable (symbol, "text", output);

	if (*output != '!')
	{
		temp = parse_color(output);
																	
		p_frame->text_colour = temp;
	}

	variable (symbol, "bgcolor", output);

	if (*output != '!')
	{
		temp = parse_color(output);
																	
		p_frame->background_colour = temp;
	}

	variable (symbol, "link", output);

	if (*output != '!')
	{
		temp = parse_color(output);
																	
		p_frame->link_colour = temp;
	}
}

/* parse_d_tags()
 *
 * processes the d tags DL, DT, DD
 * 
 * type determines the type of d tag
 *    0 = DL tag
 *    1 = DT tag
 *    2 = DD tag
 *
 * flag determines operation
 *    if 1  start d tag
 *    if not 1 end d tag
 */
 
void
parse_d_tags(struct frame_item *p_frame, WORD *active_word_buffer,
			 WORD type, WORD flag)
{
	add_paragraph(p_frame,active_word_buffer);

	p_frame->current_paragraph->alignment = left;

	if (flag == 1)
	{
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->eop_space = 0;


		if (type == 0)       /* dl tag start */
			p_frame->current_paragraph->left_border += list_indent (2);
		else if (type == 1)  /* dt tag start */
			p_frame->current_paragraph->left_border -= list_indent (2);
		else if (type == 2)  /* dd tag start */
			p_frame->current_paragraph->left_border = list_indent (2);

		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
	else
	{
		if (type == 0) /* dl tag end */
		{
			p_frame->current_paragraph->eop_space = p_frame->current_font_size;

			p_frame->current_paragraph->left_border -= list_indent(2);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse DIV tag
 * ideally you drop the input on this routine
 * and it parses and processes the DIV tag information
 *
 * DIV is only partially implemented from my understanding
 * baldrick - December 14, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_div_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	
	if (flag == 1)
	{
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->active_word = active_word_buffer;

		variable (symbol,"align",output);

		switch (*output)
		{
			case 'r':
			case 'R':
				p_frame->current_paragraph->alignment = right;
				break;
			case 'c':
			case 'C':
				p_frame->current_paragraph->alignment = center;
				break;
			case 'l':
			case 'L':
				p_frame->current_paragraph->alignment = left;
				break;
		}
	}
	else
	{
		add_paragraph(p_frame, active_word_buffer);
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
	}
}

/* parse font tag
 * ideally you drop the input on this routine
 * and it parses and processes the font tag information
 *
 * baldrick - December 14, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_font_tag(struct frame_item *p_frame, char *symbol, WORD font_step, WORD flag)
{
	char output[100];
	WORD temp = 0;

	if (flag == 1)
	{
		variable (symbol, "size", output);

		if (*output != '!')
		{
			p_frame->current_font_step = add_step (p_frame->current_font_step);

			if (*output == '+' || *output == '-')
				p_frame->current_font_step->step += convert_to_number (output);
			else
				p_frame->current_font_step->step = convert_to_number (output);
									
			/* added +1 to font_step in next calculation
			 * this is not perfect, but does fix some of the problems
			 * with font size when there is a size variable
			 * Basically the smallest size fonts are way too small
			 * baldrick July 20, 2001
			 */
									
			p_frame->current_font_size = p_frame->current_font_step->step * font_step; /*(font_step + 1);*/
																	
			p_frame->current_word->styles.font_size = p_frame->current_font_size; 
			p_frame->current_word->changed.font = true;

	/*		printf("font size = %d\r\n",p_frame->current_word->styles.font_size);*/
		}
								
		variable (symbol, "color", output);

		if (*output != '!')
		{
			temp = parse_color(output);
																	
			p_frame->current_word->colour = temp;
			p_frame->current_word->changed.colour = true;
		}
	}
	else
	{
		p_frame->current_font_step = destroy_step(p_frame->current_font_step);
		p_frame->current_font_size = p_frame->current_font_step->step * font_step;
		p_frame->current_word->styles.font_size = p_frame->current_font_size;
		p_frame->current_word->colour = p_frame->text_colour;
		p_frame->current_word->changed.colour = true;
		p_frame->current_word->changed.font = true;
	}
}


/* parse header tag
 * ideally you drop the input on this routine
 * and it parses and processes the header tag information
 *
 * baldrick - August 20, 2001
 * mj - added strupr and 'j' - 10-01-01
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_header_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	WORD size = 0;

	if (flag == 1)
	{
	    /* This next line I'm not 100% certain of.  If Headings don't
	     * have enough space then remove this line - baldrick Dec 14, 01 
	     *
	     * Ok there is an error here somewhere. On MagicPC this runs and
	     * modifies the height of the space around header tags
	     * on my TT under Magic it crashes - baldrick Dec 14, 01 (evening)
	     */
	/*	p_frame->current_word = p_frame->current_paragraph->item;
	*/

		p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

		add_paragraph(p_frame, active_word_buffer);

		variable (symbol, "align", output);

		if (*output != '!')
		{
			switch (*(strupr(output)))
			{
				case 'R':
					p_frame->current_paragraph->alignment = right;
					break;
				case 'C':
					p_frame->current_paragraph->alignment = center;
					break;
				case 'J':
				case 'L':
					p_frame->current_paragraph->alignment = left;
			}
		}	
							
		p_frame->current_word->styles.font = header_font;
	
		switch (*(symbol + 1))
		{
			case '1':
				size = p_frame->current_font_size * 2;
				break;
			case '2':
				size = p_frame->current_font_size + (p_frame->current_font_size / 2);
				break;
			case '3':
				size = p_frame->current_font_size + (p_frame->current_font_size / 4);
				break;
			case '4':
				size = p_frame->current_font_size;
				break;
			case '5':
				size = p_frame->current_font_size - (p_frame->current_font_size / 5);
				break;
			case '6':
				size = p_frame->current_font_size - (p_frame->current_font_size / 3);
				break;
		}
		
		p_frame->current_word->styles.font_size = size;
		p_frame->current_word->styles.bold++;
		p_frame->current_word->changed.font = true;
	
		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		add_paragraph(p_frame,active_word_buffer);
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
		p_frame->current_word->styles.font = normal_font;
		p_frame->current_word->styles.font_size = p_frame->current_font_size;
		p_frame->current_word->styles.bold = 0;
		p_frame->current_word->changed.font = true;
	}
}

/* parse MENU tag
 * ideally you drop the input on this routine
 * and it parses and processes the MENU tag information
 *
 * I left symbol in this since we might need it, I'm not certain
 * it's also possible that we could map this onto parse_ul
 * baldrick - December 13, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_menu_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD flag)
{
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;
								
		add_paragraph(p_frame, active_word_buffer);
									
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent (0);
									
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
								
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item =	p_frame->current_list;

		if (p_frame->current_list != 0)
			temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;

		p_frame->current_list = temp_list_holder;
	}
	else
	{
		if (p_frame->current_list != 0)
		{
			if (p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space=-(p_frame->current_word->word_height);
												
			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);

			p_frame->active_word = active_word_buffer;
			p_frame->current_list = p_frame->current_list->next_stack_item;
			p_frame->current_paragraph->left_border -= list_indent(0);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse P tag
 * ideally you drop the input on this routine
 * and it parses and processes the P tag information
 *
 * baldrick - December 14, 2001
 */

void
parse_p_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer)
{
	char output[100];
	enum paragraph_alignment prev_alignment;

	prev_alignment = p_frame->current_paragraph->alignment;
	
	p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	variable (symbol, "align", output);

	if (*output != '!')
	{
		switch (*output)
		{
			case 'r':
			case 'R':
				p_frame->current_paragraph->alignment = right;
				break;
			case 'c':
			case 'C':
				p_frame->current_paragraph->alignment = center;
				break;
			case 'l':
			case 'L':
				p_frame->current_paragraph->alignment = left;
		}
	}
	else
		p_frame->current_paragraph->alignment = prev_alignment; /*left;*/
}

/* parse LI tag
 * ideally you drop the input on this routine
 * and it parses and processes the LI tag information
 *
 * baldrick - December 12, 2001
 */

void
parse_li_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD font_step)
{
	char output[100];
	
	p_frame->current_word->word_code = br;

	variable (symbol, "type", output);
	switch (*output)
	{
		case 'a':
			p_frame->current_list->bullet_style = alpha;
			break;
		case 'A':
			p_frame->current_list->bullet_style = Alpha;
			break;
		case 'i':
			p_frame->current_list->bullet_style = roman;
			break;
		case 'I':
			p_frame->current_list->bullet_style = Roman;
			break;
		case '1':
			p_frame->current_list->bullet_style = Number;
			break;
		case 'd':
		case 'D':
			p_frame->current_list->bullet_style = disc;
			break;
		case 'c':
		case 'C':
			p_frame->current_list->bullet_style = circle;
			break;
		case 's':
		case 'S':
			p_frame->current_list->bullet_style = square;
			break;
	}
								
	variable (symbol, "value", output);
	if (*output != '!')
			p_frame->current_list->current_list_count = convert_to_number(output);
										
	p_frame->current_word->styles.font_size = 2 * font_step;
	p_frame->current_word->changed.font = true;

	p_frame->current_word = list_marker(p_frame);
	p_frame->active_word = active_word_buffer;

	p_frame->current_word->styles.font_size = p_frame->current_font_step->step * font_step;
	p_frame->current_word->changed.font = true;
}

/* parse OL tag
 * ideally you drop the input on this routine
 * and it parses and processes the OL tag information
 *
 * baldrick - December 12, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_ol_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->active_word = active_word_buffer;

		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent(1);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = p_frame->current_list;
		p_frame->current_list = temp_list_holder;
								
		variable (symbol, "type", output);
		switch (*output)
		{
			case 'a':
				p_frame->current_list->bullet_style = alpha;
				break;
			case 'A':
				p_frame->current_list->bullet_style = Alpha;
				break;
			case 'i':
				p_frame->current_list->bullet_style = roman;
				break;
			case 'I':
				p_frame->current_list->bullet_style = Roman;
				break;
			default:
				p_frame->current_list->bullet_style = Number;
		}
							
		variable (symbol, "start", output);
								
		if (*output != '!')
			p_frame->current_list->current_list_count = convert_to_number(output);
		else
			p_frame->current_list->current_list_count = 1;

		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		if (p_frame->current_list != 0)
		{
			if(p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space = -(p_frame->current_word->word_height);

			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);
			p_frame->active_word = active_word_buffer;
			p_frame->current_list = remove_stack_item(p_frame->current_list);
			p_frame->current_paragraph->left_border -= list_indent(1);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}	
	}
}

/* parse UL tag
 * ideally you drop the input on this routine
 * and it parses and processes the UL tag information
 * baldrick - December 12, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_ul_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{	
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent (0);

		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	
		temp_list_holder = new_stack_list_item();
		temp_list_holder->next_stack_item = p_frame->current_list;

		variable (symbol, "type", output);
		switch (*output)
		{
			case 'S':
			case 's':
				temp_list_holder->bullet_style = square;
				break;
			case 'c':
			case 'C':
				temp_list_holder->bullet_style = circle;
				break;
			case 'd':
			case 'D':
				temp_list_holder->bullet_style = disc;
			default:
				if (p_frame->current_list != 0)
					temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;
		}
		p_frame->current_list = temp_list_holder;

		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		if (p_frame->current_list != 0)
		{
			if (p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space =- (p_frame->current_word->word_height);
			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);
			p_frame->active_word = active_word_buffer;
			p_frame->current_list = remove_stack_item(p_frame->current_list);
			p_frame->current_paragraph->left_border -= list_indent(0);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse table tag 
 * ideally you drop the input on this routine
 * and it parses and processes the table tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_table_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	WORD temp = 0;

	if (flag == 1)
	{
		add_paragraph(p_frame, active_word_buffer);

		/* link this paragraph into the list */
		p_frame->parent_table = add_table_step (p_frame->parent_table, p_frame->current_paragraph);

		p_frame->active_word = active_word_buffer;
								
		p_frame->current_paragraph->paragraph_code = table;

		p_frame->current_paragraph->table = new_table();
		p_frame->current_table = p_frame->current_paragraph->table;

		variable (symbol, "align", output);

		if (*output != '!')
		{
			switch (*output)
			{
				case 'r':
				case 'R':
					p_frame->current_table->alignment = right;
					break;
				case 'c':
				case 'C':
					p_frame->current_table->alignment = center;
					break;
				case 'l':
				case 'L':
					p_frame->current_table->alignment = left;
			}
		}
		else
			p_frame->current_table->alignment = left;

		variable (symbol, "width", output);

		if (*output != '!')
		{
			p_frame->current_table->forced_width = 1;
			p_frame->current_table->table_width = convert_to_number(output);
		}

		variable (symbol, "border", output);

		if (*output != '!')
			p_frame->current_table->border = 1;
		else
			p_frame->current_table->border = 0;

		variable (symbol, "bgcolor", output);

		if (*output != '!')
		{
			temp = parse_color(output);
																	
			p_frame->current_table->bgcolor = temp;
		}
		else
			p_frame->current_table->bgcolor = p_frame->background_colour;

		variable (symbol, "cellspacing", output);

		if (*output != '!')
			p_frame->current_table->cell_spacing = convert_to_number(output);
		else
			p_frame->current_table->cell_spacing = 5;
								
		variable (symbol, "cellpadding", output);
		if (*output != '!')
			p_frame->current_table->cell_padding = convert_to_number(output);
		else
			p_frame->current_table->cell_padding = 0;

		if (p_frame->current_table->table_width > p_frame->frame_page_width)
			p_frame->frame_page_width = p_frame->current_table->table_width;

		p_frame->current_child = p_frame->current_table->children;
	}
	else
	{
		/* set current paragraph to before the start of this table */
		
		p_frame->current_paragraph = p_frame->parent_table->table;
		
		/* walk back up list */
		
		p_frame->parent_table = destroy_table_step(p_frame->parent_table);
	}
}

/* parse th tag (table header cell )
 * ideally you drop the input on this routine
 * and it parses and processes the th tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_th_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	WORD temp = 0;

	if (flag == 1)
	{
		/* store any words floating around in the buffer */
								
		word_store (p_frame, active_word_buffer, p_frame->active_word);

		/* we need to create a new child */
								
		/* this first test will just supress the 
		 * creation of an extra child at the front of 
		 * the table's children list
		 */
			
		if (p_frame->current_table->num_children != 0)
		{
			p_frame->current_child->next_child = new_table_child();
			p_frame->current_child = p_frame->current_child->next_child;
		}
								
		p_frame->current_table->num_children += 1;
								
		/* My guess here is that if you are having headers
		 * then you are in the first row of a table.  This
		 * could be wrong.  It's just a guess.
		 */

		/*if (current_table->num_rows < 1)
		{*/
		p_frame->current_table->num_cols += 1;
		/*}*/
								
		variable (symbol, "bgcolor", output);

		if (*output != '!')
		{
			temp = parse_color(output);
																	
			p_frame->current_child->bgcolor = temp;
		}

		variable (symbol, "colspan", output);
		if (*output != '!')
		{
			temp = convert_to_number(output);
																	
			if (p_frame->current_table->num_rows <= 1)
				p_frame->current_table->num_cols += temp;
									
			p_frame->current_child->colspan = temp;
		}
		else
			p_frame->current_child->colspan = 1;
									
		variable (symbol, "rowspan", output);

		if (*output != '!')
		{
			temp = convert_to_number(output);
																	
			p_frame->current_child->rowspan = temp;
		}
		else
			p_frame->current_child->rowspan = 1;

		variable (symbol, "align", output);
		if (*output != '!')
		{
			switch (*output)
			{
				case 'r':
				case 'R':
					p_frame->current_child->alignment = right;
					break;
				case 'c':
				case 'C':
					p_frame->current_child->alignment = center;
					break;
				case 'l':
				case 'L':
					p_frame->current_child->alignment = left;
			}
		}
		else
			p_frame->current_child->alignment = left;

		p_frame->current_paragraph = p_frame->current_child->item;
		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
									
		set_font_bold(p_frame->current_word, 1);

		p_frame->current_paragraph->alignment = center;

	}
	else
	{
		/* Any special considerations for a closing th tag? */
		;
	}
}

/* parse td tag (table data cell )
 * ideally you drop the input on this routine
 * and it parses and processes the td tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

void
parse_td_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	WORD temp = 0;

	if (flag == 1)
	{
		/* store any words floating around in the buffer */
								
		word_store (p_frame, active_word_buffer, p_frame->active_word);

		/* we need to create a new child */
								
		/* this first test will just supress the 
		 * creation of an extra child at the front of 
		 * the table's children list
		 */
								
		if (p_frame->current_table->num_children != 0)
		{
			p_frame->current_child->next_child = new_table_child();
			p_frame->current_child = p_frame->current_child->next_child;
		}
								
		p_frame->current_table->num_children += 1;
								
		/* This might not be a good test
		 * we want to count the columns in the 
		 * first row. But if a Table has only
		 * one row it doesn't necessarily have a tr tag
		 *
		 * so we hope that we don't hit bad tables with
		 * multiple rows and no tr tag before first row
		 */
								 
		if (p_frame->current_table->num_rows < 1)
		{
			p_frame->current_table->num_cols += 1;
		}

		variable (symbol, "bgcolor", output);

		if (*output != '!')
		{
			temp = parse_color(output);
																	
			p_frame->current_child->bgcolor = temp;
		}

		variable (symbol, "colspan", output);

		if (*output != '!')
		{
			temp = convert_to_number(output);
																	
			if (p_frame->current_table->num_rows <= 1)
				p_frame->current_table->num_cols += temp;
									
			p_frame->current_child->colspan = temp;
		}
		else
			p_frame->current_child->colspan = 1;
									
		variable (symbol, "rowspan", output);

		if (*output != '!')
		{
			temp = convert_to_number(output);
																	
			p_frame->current_child->rowspan = temp;
		}
		else
			p_frame->current_child->rowspan = 1;

		variable (symbol, "align", output);

		if (*output != '!')
		{
			switch (*output)
			{
				case 'r':
				case 'R':
					p_frame->current_child->alignment = right;
					break;
				case 'c':
				case 'C':
					p_frame->current_child->alignment = center;
					break;
				case 'l':
				case 'L':
					p_frame->current_child->alignment = left;
			}
		}
		else
			p_frame->current_child->alignment = left;

		p_frame->current_paragraph = p_frame->current_child->item;
		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		/* Any special considerations for a closing td tag? */
		;
	}
}

/* parse hr tag
 * ideally you drop the input on this routine
 * and it parses and processes the hr tag information
 *
 * baldrick - December 5, 2001
 */

void
parse_hr_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer)
{
	char output[100];

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;
	p_frame->current_paragraph->paragraph_code = hr;

	variable (symbol, "align", output);

	if (*output != '!')
	{
		switch (*output)
		{
			case 'r':
			case 'R':
				p_frame->current_paragraph->eop_space = 2;
				break;
			case 'c':
			case 'C':
				p_frame->current_paragraph->eop_space = 1;
				break;
			default:
				p_frame->current_paragraph->eop_space = 0;
		}
	}

	variable (symbol, "width", output);
	
	if (*output != '!')
		p_frame->current_word->word_width = convert_to_number(output);
	else
		p_frame->current_word->word_width = -100;

	variable (symbol, "size", output);

	if (*output != '!')
		p_frame->current_word->word_height = convert_to_number(output);
	else
		p_frame->current_word->word_height = 2;

	variable (symbol, "noshade", output);

	if (*output != '!')
		p_frame->current_word->word_height = -p_frame->current_word->word_height;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;
	p_frame->current_word->changed.font = true;
}

/* parse img tag
 * ideally you drop the input on this routine
 * and it parses and processes the header tag information
 *
 * baldrick - Dec 4, 2001
 */

void
parse_img_tag(struct frame_item *p_frame, char *symbol, WORD *active_word_buffer)
{
	char output[100];
	char img_file[100];

	add_paragraph(p_frame, active_word_buffer);

	p_frame->current_paragraph->paragraph_code = img;

	variable (symbol, "align", output);

	if (*output != '!')
	{
		switch (*output)
		{
			case 'r':
			case 'R':
				p_frame->current_paragraph->eop_space = 2;
				break;
			case 'c':
			case 'C':
				p_frame->current_paragraph->eop_space = 1;
				break;
			default:
				p_frame->current_paragraph->eop_space = 0;
		}
	}
	else /* Assume center if not otherwise specifiec */
		p_frame->current_paragraph->eop_space = 1; /* should be left */

	variable (symbol, "width", output);

	if (*output != '!')
		p_frame->current_word->word_width = convert_to_number(output);
	else
		p_frame->current_word->word_width = 10;

	if (p_frame->current_word->word_width > p_frame->frame_page_width)
		p_frame->frame_page_width = p_frame->current_word->word_width;
								
	variable (symbol, "height", output);

	if (*output != '!')
		p_frame->current_word->word_height = convert_to_number(output);
	else
		p_frame->current_word->word_height = 10;

	p_frame->current_word->word_tail_drop = p_frame->current_word->word_height;

	variable (symbol, "src", output);

	if (*output != '!')
	{
		strncpy(img_file,output,strlen(output));
		img_file[strlen(output)] = '\0';

		/*  This next line just shows the parsed IMG SRC
		    if you were going to process the message you 
		    would dispatch this off with a load_to_do message
		    with a new type for IMG's.
		    
		    You would also need to add a bit more information
		    for the IMG handling, mainly a MFDB should do the 
		    job.  This could possibly be linked to an already
		    existing item.
		    
		    You would then need to work in a message retrieval
		    from the external application to get the notification
		    of image decompression.  
		    
		    Modify the height and width of the paragraph to match
		    the height and width of the returned img and issue
		    a redraw for it's parent frame.
		    
		printf("img file = %s   \r\n",img_file);
		*/
	}

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	p_frame->current_word->changed.font = true;
}

/* parse_title
 *
 * parses a title tag from a file 
 * and sets the window's title to this value
 * also watches for ISO Latin entities in the Title string
 *
 * Baldrick Dec. 6, 2001
 */
 
char *
parse_title(char *symbol, WORD *active_word)
{
	char output[100];
	char spec_char[1];

	strcpy(window_title,"\0");

	/* Get it past tag */
	while (*symbol != '>')
		symbol++;
									
	symbol++;

title_go_again:

	while (*symbol != '<' && *symbol != '\0')
	{
		switch(*symbol)
		{
			case '\r':
				symbol++;
				break;
			case '\n':
				symbol++;
				break;
			case '&':
				if (*(symbol + 1) == '#')
				{
					output[0] = *(symbol + 2);
					output[1] = *(symbol + 3);
					output[2] = *(symbol + 4);
					symbol += 4;
					output[3] = '\0';
						
					*active_word =	special_char_map (convert_to_number (output));
					active_word++;
				}
				else if (*(symbol + 1) == ' ')
				{
					strncat(output,symbol,1);
					symbol++;
					break;
				}
				else
				{
					strcpy(output,"\0");
											
					while (*(symbol + 1) != ';' && *(symbol + 1) != '\0')
					{
						strncat(output,symbol + 1,1);
						symbol++;
					}
					symbol++;
					symbol++;
													
					sprintf(spec_char,"%c",special_char_map_str(output,ATASCI));
					strncat(window_title,spec_char,1);
				}
				break;
			default:
				strncat(window_title,symbol,1);
				symbol++;
				break;
		}
	}									

	/* now check if there is a bad tag in the title line */
								
	if (((*(symbol + 2)) == 't') ||
		((*(symbol + 2)) == 'T'))
	{
		/* everything is really in the else section 
		 * was just easier to cast the test in this manner
		 */
									 
		;
	}
	else
	{
		strncat(window_title,symbol,1);

		symbol++;

		goto title_go_again;
	}

	/* Under Lattice the following line causing a crash baldrick July 13, 2001*/

	if (strlen(window_title) > 0)
		#ifdef LATTICE
			wind_set(window_handle, WF_NAME, ADDR(window_title));
		#else
			wind_set_str(window_handle, WF_NAME, window_title);
		#endif	

	return(symbol);
}

/* parse frameset
 * ideally you drop the input on this routine
 * and it parses and processes the frameset information
 * until done and then returns to the main parser with
 * a pointer to the end of the frameset
 * baldrick - August 8, 2001
 *
 * at the moment there is a hard coded limit of 10 frames.
 * Could or should be changed in the future.
 *
 * There are some printf's in this section that are rem'd out
 * they are useful checks on the frame parsing and I'm not
 * certain that it's 100% correct yet.  So I have left them
 * baldrick - August 14, 2001
 */
 
char *
parse_frameset(char *symbol)
{
	char output[100],frame_file[100],frame_name[100];
	int no_rows = 0, no_cols = 0, no_sets = 1, multiple = 0;
	int rows[10], cols[10],row = 0,col = 0;
	int rows_first = 0; /* tracks whether to parse rows first */
	char *raw_xy;
	struct frame_item *t_frame;
	
	int cur_xoffset = 0, cur_yoffset = 0;
	int border = 1;
	int start_frame = 0;
	int prev_parse = 0;		/* if 0 COLS if 1 ROWS */
	int i;
	
	/* preset frame_xy array */
	for (i = 0; i<10; i++)
	{
		rows[i] = 0;
		cols[i] = 0;
	}

new_frameset:
	
	/* ok the first thing we do is look for ROWS or COLS
	 * since when we are dumped here we are looking at a
	 * beginning of a FRAMESET tag
	 */

	variable (symbol, "COLS", output);
	
	if (*output != '!')
	{
		/* Ok we have found COLS so we need to parse it
		 * to discover how many columns there are in FRAMESET
		 */

		cols[no_cols] = convert_to_number(output);
		no_cols += 1;

		/* set rows_first to 0 */
		prev_parse = rows_first;
		rows_first = 0;

		/* set our pointer to start of output */
		raw_xy = output;
		
		while(1)
		{
			raw_xy = stptok (raw_xy, frame_file, 100, ",");

			if (!raw_xy || !*raw_xy)
				break;

			cols[no_cols] = convert_to_number(raw_xy);
			no_cols += 1;
		}
		
		/* we've found a COLS in this set so turn multiple on
		 * in case we have a ROWS as well
		 */
		 
		multiple = 1;
	}
	
	variable (symbol, "ROWS", output);

	if (*output != '!')
	{
		/* Ok we have found ROWS so we need to parse it
		 * to discover how many rows there are in FRAMESET
		 */
		 
		rows[no_rows] = convert_to_number(output);
		no_rows += 1;
		
		/* if no multiple set rows first to 1 */
		if (!multiple)
		{
			prev_parse = rows_first;
			rows_first = 1;
		}
		
		/* set our pointer to start of output */
		raw_xy = output;
		
		while(1)
		{
			raw_xy = stptok (raw_xy, frame_file, 100, ",");

			if (!raw_xy || !*raw_xy)
				break;

			rows[no_rows] = convert_to_number(raw_xy);

			/* increment the row counter */
			no_rows += 1;
		}
		
	}
	
	/* reset multiple if it hasn't been already */
	multiple = 0;
	
	/* check if they want Borders */
	
	variable (symbol, "FRAMEBORDER", output);

	if (*output != '!')
	{
		/* Ok we have found FRAMEBORDER so we need to parse it
		 */
		border = 1;
	}
	else
		border = 0;


parsef_again:

	while (*symbol != '>')
		symbol++;

	symbol++;

	/* get rid of any CR or LF or SPACE or any low char */
	
	while(1)
	{
		if (*symbol < 32)
			symbol++;
		else
			break;
	}
		
	/* We should now be past the FRAMSET command
	 * we now need to look for Framesrc or more framesets
	 */

	switch (*(symbol + 6))
	{
		case 's': /* frameset ? */
		case 'S':
		
			/* increment the number of sets so we know when to exit */
			no_sets += 1;
			
			goto new_frameset;
			break;
		case ' ': /*frame src*/
			variable (symbol, "src", output);

			if (*output != '!')
			{
/*				unsigned char c = *output;
				
				if (c == 186 || c == '"')
					output[strlen (output) - 1] = '\0';
				
				printf("output = %s\r\n",output);
*/				

				strncpy(frame_file,output,strlen(output));
				frame_file[strlen(output)] = '\0';

				/* check if the frame has a name */
	
				variable (symbol, "NAME", output);

				if (*output != '!')
				{
					strncpy(frame_name,output,strlen(output));
					frame_name[strlen(output)] = '\0';
				}
				else
					frame_name[0] = '\0';

				if (rows_first == 1)
				{
					if (start_frame == 0)
					{
						/*printf("rows y offset = %d x_offset = %d cols[col] = %d rows[row] = %d\r\n",cur_yoffset, cur_xoffset,cols[col],rows[row]);*/

						/* create temp frame */
						t_frame = temp_frame();
				
						/* set temp frame values to what we want for new frame*/
						t_frame->frame_left = 0;
						t_frame->frame_top = 0;
						t_frame->frame_width = cols[col];
						t_frame->frame_height = rows[row];
						t_frame->border = border;
						t_frame->frame_name = frame_name;
						
						add_load_item_to_to_do_list (0, frame_file, previous_frame, t_frame);

						start_frame = 1;

						cur_yoffset = rows[row];
					}
					else
					{
						/*printf("rows y offset = %d x_offset = %d cols[col] = %d rows[row] = %d\r\n",cur_yoffset, cur_xoffset,cols[col],rows[row]);*/

						/* create temp frame */
						t_frame = temp_frame();
				
						/* set temp frame values to what we want for new frame*/
						t_frame->frame_left = cur_xoffset;
						t_frame->frame_top = cur_yoffset;
						t_frame->frame_width = cols[col];
						t_frame->frame_height = rows[row];
						t_frame->border = border;
						t_frame->frame_name = frame_name;
				
						add_load_item_to_to_do_list (2, frame_file, previous_frame, t_frame);

						cur_yoffset += rows[row];
					}
					row += 1;

				}
				else							
				{
					if (start_frame == 0)
					{
						/*printf("cols y offset = %d x_offset = %d cols[col] = %d rows[row] = %d\r\n",cur_yoffset, cur_xoffset,cols[col],rows[row]);*/

						/* create temp frame */
						t_frame = temp_frame();
				
						/* set temp frame values to what we want for new frame*/
						t_frame->frame_left = 0;
						t_frame->frame_top = 0;
						t_frame->frame_width = cols[col];
						t_frame->frame_height = rows[row];
						t_frame->border = border;
						t_frame->frame_name = frame_name;
				
						add_load_item_to_to_do_list (0, frame_file, previous_frame, t_frame);
	
						start_frame = 1;

						cur_xoffset = cols[col];
					}
					else
					{
						/*printf("cols y offset = %d x_offset = %d cols[col] = %d rows[row] = %d\r\n",cur_yoffset, cur_xoffset,cols[col],rows[row]);*/

						/* create temp frame */
						t_frame = temp_frame();
				
						/* set temp frame values to what we want for new frame*/
						t_frame->frame_left = cur_xoffset;
						t_frame->frame_top = cur_yoffset;
						t_frame->frame_width = cols[col];
						t_frame->frame_height = rows[row];
						t_frame->border = border;
						t_frame->frame_name = frame_name;
				
						add_load_item_to_to_do_list (2, frame_file, previous_frame, t_frame);

						cur_xoffset += cols[col];
					}
					
					col += 1;
				}
			}

			break;
		case 'e': /* end of FRAMESET */
		case 'E':
			no_sets -= 1;
			
			if (no_sets == 0)
				return(symbol);

			rows_first = prev_parse;

			if (rows_first > 0)
				row += 1;
			else
				col += 1;

			if (rows_first == 1)
				cur_yoffset += rows[row - 1];
			else
				cur_xoffset += cols[col - 1];

			/* make certain it's not a stupid value
			 * for either x or y offset, something like
			 * 100% of area would be bad
			 */

			if(cur_xoffset == -100)
				cur_xoffset = 0;

			if(cur_yoffset == -100)
				cur_yoffset = 0;
										
			break;
	}

	goto parsef_again;

	return(symbol);
}

/* special_char_map_str()
 *
 * most of this routine is speculative and experimental
 * basically I just sat down with a list of what to find
 * and threw numbers at output til they matched on my machine
 * I hope this works for all machines and isn't just junk
 * SOME ARE NOT CORRECT.  I haven't finished them all
 * probably are some missing from list as well
 * baldrick July 16, 2001
 *
 * New parameter mapping - mapping determines how to map
 * the special char.  
 * ISO1 = ISO Latin 1
 * ATASCI = Atari System font
 *
 * The idea is eventually we can map to other sets by adding in
 * the mapping ex ISO 3 or 4 etc.
 *
 * One note on my ATASCI mappings.  Some of the capitals are mapped
 * to the lower case version as the Upper case does not appear to
 * exist in the Atari Ascii set.  Some of the other characters are
 * simply mapped to what I deemed closest at the time of coding
 * If I couldn't find anything I deemed close enough I gave it
 * a code of 127 (a triangle)
 * baldrick July 19, 2001
 * mj October 01, 2001: moved almost all characters to a big array (see
 *                      beginning of this file)
 * altF4 December 17, 2001: Modifications of test for space char
 */


WORD
special_char_map_str(char *str_symbol, int mapping)
{
	int i;
	WORD output = '\0'; 

	for (i = 0; i<MAX_CHAR; i++)
	{
		if (strcmp(str_symbol, htmlchars[i].name) == 0)
		{
			switch(mapping)
			{
				case ISO1:
					output = htmlchars[i].isoval;
					break;
				case ATASCI:
					output = htmlchars[i].atarival;
					break;
			}
			break;
		}
	}

	if (!output)
	{
		if (strcmp (str_symbol, "nbsp") == 0)
		{
			switch(mapping)
			{
				case ISO1:
					output = Space_Code;
					break;
				case ATASCI:
					output = 32;
					break;
			}
		}
		else /* no ISO entry found */
		{
			/* Only use the printf for tracking new ISO entities */
		/*	printf("ISO mapping didn't find str_symbol = %s\r\n",str_symbol);*/
			output = Space_Code;
		}
	}
	
	return (output);
}

WORD
special_char_map (WORD input)
{
	WORD output = 0;

	switch (input)
	{
		case 160:
			output = Space_Code;
			break;
		case 161:
			output = 388;
			break;
		case 162:
			output = 128;
			break;
		case 163:
			output = 97;
			break;
		case 164:
			output = 278;
			break;
		case 165:
			output = 274;
			break;
		case 166:
			output = 277;
			break;
		case 167:
			output = 110;
			break;
		case 168:
			output = 135;
			break;
		case 169:
			output = 332;
			break;
		case 170:
			output = 538;
			break;
		case 171:
			output = 125;
			break;
		case 172:
			output = 309;
			break;
		case 173:
			output = 111;
			break;
		case 174:
			output = 333;
			break;
		case 175:
			output = 230;
			break;
		case 176:
			output = 146;
			break;
		case 177:
			output = 286;
			break;
		case 178:
			output = 160;
			break;
		case 179:
			output = 161;
			break;
		case 180:
			output = 129;
			break;
		case 181:
			output = 325;
			break;
		case 182:
			output = 279;
			break;
		case 183:
			output = 102;
			break;
		case 184:
			output = 141;
			break;
		case 185:
			output = 159;
			break;
		case 186:
			output = 147;
			break;
		case 187:
			output = 126;
			break;
		case 188:
			output = 225;
			break;
		case 189:
			output = 226;
			break;
		case 190:
			output = 227;
			break;
		case 191:
			output = 127;
			break;
		case 192:
			output = 259;
			break;
		case 193:
			output = 261;
			break;
		case 194:
			output = 257;
			break;
		case 195:
			output = 253;
			break;
		case 196:
			output = 255;
			break;
		case 197:
			output = 113;
			break;
		case 198:
			output = 114;
			break;
		case 199:
			output = 199;
			break;
		case 200:
			output = 249;
			break;
		case 201:
			output = 251;
			break;
		case 202:
			output = 247;
			break;
		case 203:
			output = 245;
			break;
		case 204:
			output = 239;
			break;
		case 205:
			output = 241;
			break;
		case 206:
			output = 237;
			break;
		case 207:
			output = 235;
			break;
		case 208:
			output = 169;
			break;
		case 209:
			output = 196;
			break;
		case 210:
			output = 202;
			break;
		case 211:
			output = 200;
			break;
		case 212:
			output = 204;
			break;
		case 213:
			output = 208;
			break;
		case 214:
			output = 206;
			break;
		case 215:
			output = 284;
			break;
		case 216:
			output = 115;
			break;
		case 217:
			output = 212;
			break;
		case 218:
			output = 210;
			break;
		case 219:
			output = 214;
			break;
		case 220:
			output = 216;
			break;
		case 221:
			output = 224;
			break;
		case 222:
			output = 272;
			break;
		case 223:
			output = 121;
			break;
		case 224:
			output = 260;
			break;
		case 225:
			output = 262;
			break;
		case 226:
			output = 258;
			break;
		case 227:
			output = 254;
			break;
		case 228:
			output = 256;
			break;
		case 229:
			output = 117;
			break;
		case 230:
			output = 118;
			break;
		case 231:
			output = 149;
			break;
		case 232:
			output = 250;
			break;
		case 233:
			output = 252;
			break;
		case 234:
			output = 248;
			break;
		case 235:
			output = 246;
			break;
		case 236:
			output = 240;
			break;
		case 237:
			output = 242;
			break;
		case 238:
			output = 238;
			break;
		case 239:
			output = 236;
			break;
		case 240:
			output = 273;
			break;
		case 241:
			output = 195;
			break;
		case 242:
			output = 201;
			break;
		case 243:
			output = 199;
			break;
		case 244:
			output = 203;
			break;
		case 245:
			output = 207;
			break;
		case 246:
			output = 205;
			break;
		case 247:
			output = 285;
			break;
		case 248:
			output = 110;
			break;
		case 249:
			output = 211;
			break;
		case 250:
			output = 209;
			break;
		case 251:
			output = 213;
			break;
		case 252:
			output = 215;
			break;
		case 253:
			output = 223;
			break;
		case 254:
			output = 271;
			break;
		case 255:
			output = 221;
			break;
	}
	return (output);
}


struct word_item *
list_marker (struct frame_item *p_frame)
{
	WORD modulo = 0, count, word[5], *active_word, indent_type = 0;
	struct word_item *new_word;

	active_word = word;
	
	if (p_frame->current_list == 0)
		return (p_frame->current_word);

	count = p_frame->current_list->current_list_count;

	switch (p_frame->current_list->bullet_style)
	{
		case disc:
			*active_word = 342;
			active_word++;
			indent_type = 0;
			break;
		case square:
			*active_word = 507; /* baldrick - robert had 559;*/
			active_word++;
			indent_type = 0;
			break;
		case circle:
			*active_word = 353;
			active_word++;
			indent_type = 0;
			break;
		case Number:
			while (count > 9)
			{
				count -= 10;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 48);
				active_word++;
			}
			*active_word = map (count + 48);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case Alpha:
			while (count > 26)
			{
				count -= 26;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 64);
				active_word++;
			}
			*active_word = map (count + 64);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case alpha:
			while (count > 26)
			{
				count -= 26;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 96);
				active_word++;
			}
			*active_word = map (count + 96);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case roman:
		case Roman:
			break;
	}

 /* This might fail with new add_word routine */
 
	new_word = add_word (p_frame,p_frame->current_word, word, active_word);

	p_frame->current_word->word_width = list_indent (indent_type);

	if (p_frame->current_word->word_width + p_frame->current_indent_distance > p_frame->frame_page_width)
		p_frame->frame_page_width = p_frame->current_word->word_width + p_frame->current_indent_distance;

	return (new_word);
}

/* calculate_frame
 * this is the main parsing routine
 */
struct paragraph_item *
calculate_frame (char *symbol, struct frame_item *p_frame)
{
	struct paragraph_item *start;
	WORD u, font_step;
	WORD prev_sm_size, prev_su_size; /* one for before small and one for before sub/p */
	enum bool space_found = false, code_processed = false, in_pre = false;
	char output[1024]; /* baldrick - this should be done dynamically somehow */
	char *start_symbol;
	WORD active_word_buffer[300]; /* this can be too small for run on lines */

	WORD distances[5], effects[3];

	start_symbol = symbol;

	if (symbol == 0)
		return (new_paragraph ());

	start = p_frame->current_paragraph = new_paragraph ();
	p_frame->current_word = p_frame->current_paragraph->item;
	p_frame->active_word = active_word_buffer;
	p_frame->current_list = 0;
	wind_update (BEG_UPDATE);
	graf_mouse (2, 0);
	wind_update (END_UPDATE);

	current_highlighted_link_area = 0;

	vst_font (vdi_handle, fonts[0][0][0]);
	prev_su_size = prev_sm_size = p_frame->current_font_size = POINT_SIZE;
	p_frame->current_font_step = new_step(3);
	font_step = p_frame->current_font_size / p_frame->current_font_step->step;
	vst_arbpt (vdi_handle, p_frame->current_font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &p_frame->current_word->space_width, &u, &u, &u);

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	p_frame->current_word->word_height = distances[3];
	p_frame->current_word->word_tail_drop = distances[1];

	while (*symbol != '\0')
	{
		switch (*symbol)
		{
			case '<':
				code_processed = true;
				p_frame->current_word = add_word (p_frame,p_frame->current_word, active_word_buffer,p_frame->active_word);
				p_frame->active_word = active_word_buffer;
				symbol++;
				switch (*symbol)
				{
					case '\0':
						symbol--;
						break;
					case '!':
						while (*(symbol + 1) != '>' && *(symbol + 1) != '\0')
							symbol++;
						break;

					case 'a': /* A tag (anchor) */
					case 'A':
						parse_anchor (symbol, p_frame, 1);
						break;
					case 'b':
					case 'B':
						switch (*(symbol + 1))
						{
							/* we should also have BASE tag (base URI) */
							
							case 'a': /* BASEFONT tag (basefont size) */
							case 'A':
								variable (symbol, "size", output);
								if (*output != '!')
								{
									p_frame->current_font_step = add_step(p_frame->current_font_step);
									p_frame->current_font_step->step = convert_to_number(output);
									p_frame->current_font_size = p_frame->current_font_step->step * font_step;
									p_frame->current_word->styles.font_size = p_frame->current_font_size;
									p_frame->current_word->changed.font = true;
								}
								break;
							case 'i': /* big */
							case 'I':
								p_frame->current_word->styles.font_size = p_frame->current_font_size * 3 / 2;
								p_frame->current_word->changed.font = true;
								break;
							case 'r': /* br tag */
							case 'R':
								p_frame->current_word->word_code = br;
								/* maybe need this? current_word->changed.font = true; */
								break;
							case 'l': /* blockquote */
							case 'L':
								set_blockquote_text(p_frame, active_word_buffer, 1);
								break;

							case 'o': /* BODY tag */
							case 'O':
								parse_body (symbol, p_frame);
								break;

							case ' ': /* B tag (bold text) */
							case '>':
								set_font_bold(p_frame->current_word, 1);
								break;
						}
						break;
					case 'c':
					case 'C':
						switch (*(symbol + 1))
						{
							case ' ': /* C tag (centered text - deprecated) */
							case '>':
							case 'e': /* Center tag (centered text) */
							case 'E':
								set_center_text(p_frame, active_word_buffer, 1);
								break;
							case 'i': /* CITE tag (citation) */
							case 'I':
								set_font_italic(p_frame->current_word, 1);
								break;
	
	
							/* note CO should also have COL and COLGROUP */
	
							case 'o': /* CODE tag (computer code fragment) */
							case 'O':
								set_pre_font(p_frame->current_word,1);
								break;
						}
						break;
					case 'D':
					case 'd':
						switch (*(symbol + 1))
						{
							case 'f': /* DFN tag (instance definition) */
							case 'F':
								set_font_italic(p_frame->current_word, 1);
								break;
							case 'I': 
							case 'i':
								switch (*(symbol + 2))
								{
									case 'r': /* DIR tag (director list) */
									case 'R':
										parse_menu_tag(p_frame, symbol, active_word_buffer,1);
										break;
									case 'v': /* DIV tag (generic language style container) */
									case 'V':
										parse_div_tag(p_frame, symbol, active_word_buffer, 1);
										break;
								}
								break;
							case 'l': /* DL tag (definition list) */
							case 'L':
								parse_d_tags(p_frame, active_word_buffer, 0, 1);
								break;
							case 't': /* DT tag (definition term) */
							case 'T':
								parse_d_tags(p_frame, active_word_buffer, 1, 1);
								break;
							case 'd': /* DD tag (definition description) */
							case 'D':
								parse_d_tags(p_frame, active_word_buffer, 2, 1);
								break;
						}
						break;
					case 'e': /* EM tag (emphasis tag) */
					case 'E':
						set_font_italic(p_frame->current_word, 1);
						break;
					case 'f':
					case 'F':
						switch (*(symbol + 1))
						{
							case 'r': /* FR or fr -- frame processing */
							case 'R':
								symbol = parse_frameset(symbol);
								break;				
							case 'o': /* font or FONT */
							case 'O':
								parse_font_tag(p_frame, symbol, font_step, 1);
								break;
						}
						break;
					case 'h':
					case 'H':
						switch (*(symbol + 1))
						{
							case 'r': /* HR tag */
							case 'R':
								parse_hr_tag(p_frame, symbol, active_word_buffer);
								break;
								
							case '1': /* It's a header tag so dispatch it for processing */
							case '2':
							case '3':
							case '4':
							case '5':
							case '6':
								parse_header_tag(p_frame, symbol, active_word_buffer,1);
								break;
						}
						break;
					case 'i':
					case 'I':
						switch (*(symbol + 1))
						{
							case ' ': /* i (italic text style) tag */
							case '>':
								set_font_italic(p_frame->current_word, 1);
								break;
							case 'm': /* IMG tag */
							case 'M':
								parse_img_tag(p_frame, symbol, active_word_buffer);
								break;
						}
						break;

					case 'k': /* KBD tag? */
					case 'K':
						set_pre_font(p_frame->current_word,1);
						break;
					case 'l':
					case 'L':
						switch (*(symbol + 1))
						{
							case 'i': /* LI tag (list item) */
							case 'I':
								parse_li_tag(p_frame, symbol, active_word_buffer, font_step);
								space_found = true;
								break;
						}
						break;
					case 'm':
					case 'M':
						switch (*(symbol + 2))
						{
							case 'n': /* MENU tag */
							case 'N':
								parse_menu_tag(p_frame, symbol, active_word_buffer,1);
								break;
						}
						break;
					case 'o':
					case 'O':
						/* OBJECT, OPTGROUP and OPT may end up in here */
						switch (*(symbol + 1))
						{
							case 'l': /* OL tag (order list) */
							case 'L':
								parse_ol_tag(p_frame, symbol, active_word_buffer,1);
								break;
						}
						break;
					case 'p':
					case 'P':
						switch (*(symbol + 1))
						{
							case ' ': /* P tag (paragraph) */
							case '>':
								parse_p_tag(p_frame, symbol, active_word_buffer);
								break;
								
							case 'r':
							case 'R': /*  <pre> tag */
								p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

								add_paragraph(p_frame, active_word_buffer);

								p_frame->active_word = active_word_buffer;

								p_frame->current_paragraph->alignment = left;

								set_pre_font(p_frame->current_word,1);

								in_pre = true;
								
								break;
						}
						break;
					case 's':
					case 'S':
						switch (*(symbol + 1))
						{
							case ' ': /* S tag (strike through text style) */
							case '>':
								set_font_strike(p_frame->current_word, 1);
								break;
							case 'a': /*SAMP tag (sample code or script) */
							case 'A':
								set_pre_font(p_frame->current_word,1);
								break;
							case 'm': /* SMALL tag */
							case 'M':
								prev_sm_size = p_frame->current_word->styles.font_size;

								p_frame->current_word->styles.font_size = prev_sm_size * 2 / 3;

								p_frame->current_word->changed.font = true;
								break;
							case 'T':
							case 't':
								switch (*(symbol + 3))
								{
									case 'I': /* STRIKE tag (strike through text) */
									case 'i':
										set_font_strike(p_frame->current_word, 1);
										break;
									case 'o': /* STrong tag */
									case 'O':
										set_font_bold(p_frame->current_word, 1);
										break;
								}
								break;
							case 'u': /* SUB or SUP */
							case 'U':
								prev_su_size = p_frame->current_word->styles.font_size;
							
								switch (*(symbol + 2))
								{
									case 'b': /* sub tag */
									case 'B':
/*										p_frame->current_word->styles.font_size = p_frame->current_font_size * 2 / 3;*/
										p_frame->current_word->styles.font_size = prev_su_size * 2 / 3;
										p_frame->current_word->vertical_align = below;
										p_frame->current_word->changed.font = true;
										break;
									case 'P': /* sup tag */
									case 'p':
/*										p_frame->current_word->styles.font_size = p_frame->current_font_size * 2 / 3;*/
										p_frame->current_word->styles.font_size = prev_su_size * 2 / 3;
										p_frame->current_word->vertical_align = above;
										p_frame->current_word->changed.font = true;
										break;
								}
								break;
						}
						break;
					case 't':
					case 'T':
						switch (*(symbol + 1))
						{
							case 't': /* TT tag */
							case 'T':
								set_pre_font(p_frame->current_word,1);
								break;
							case 'i': /* title tag */
							case 'I':
								symbol = parse_title(symbol,p_frame->active_word);
								break;
							case 'a': /* table tag */
							case 'A':
								parse_table_tag(p_frame, symbol, active_word_buffer, 1);
								break;
							case 'r': /* tr tag (table row) */
							case 'R':
								/* increment the number of rows */
								p_frame->current_table->num_rows += 1;
								break;
							case 'd': /* td tag (table data cell) */
							case 'D':
								parse_td_tag(p_frame, symbol, active_word_buffer, 1);
								break;
							case 'h': /* th tag (table header cell) */
							case 'H':
								parse_th_tag(p_frame, symbol, active_word_buffer, 1);
								break;

						}
						break;
					case 'u': 
					case 'U':
						switch (*(symbol + 1))
						{
							case ' ': /* U tag (underlined text) */
							case '>':
								set_font_underline(p_frame->current_word, 1);
								break;
							case 'l': /* UL tag (unordered list) */
							case 'L':
								parse_ul_tag(p_frame, symbol, active_word_buffer, 1);
								break;
						}
						break;
					case 'v': /* VAR tag (variable tag) */
					case 'V':
						set_font_italic(p_frame->current_word, 1);
						break;

					/* ***********************      */
					/* next section closing tags    */
						
					case '/':
						symbol++;
						switch (*symbol)
						{
							case '\0':
								symbol--;
								break;
							case 'a':
							case 'A':
								parse_anchor (symbol, p_frame,0);
								break;
							case 'b':
							case 'B':
								switch (*(symbol + 1))
								{
									case 'i': /* end of big */
									case 'I':
										p_frame->current_word->styles.font_size = p_frame->current_font_size;
										p_frame->current_word->changed.font = true;
										break;
									case 'l': /* end of blockquote */
									case 'L':
										set_blockquote_text(p_frame, active_word_buffer, 0);
										break;
									case ' ': /* end of BOLD tag */
									case '>':
										set_font_bold(p_frame->current_word, 0);
										break;
								}
								break;
							case 'c':
							case 'C':
								switch (*(symbol + 1))
								{
									case ' ': /* end of C or CENTER tag */
									case '>':
									case 'e':
									case 'E':
										set_center_text(p_frame, active_word_buffer, 0);
										break;
									case 'i': /* end of CITE tag */
									case 'I':
										set_font_italic(p_frame->current_word, 0);
										break;
									case 'o': /* CODE tag closing */
									case 'O':
										set_pre_font(p_frame->current_word,0);
										break;
								}
								break;
							case 'd':
							case 'D':
								switch (*(symbol + 1))
								{
									case 'f': /* end of DFN tag */
									case 'F':
										set_font_italic(p_frame->current_word, 0);
										break;

									case 'i':
									case 'I':
										switch (*(symbol + 2))
										{
											case 'r': /* end of DIR */
											case 'R':
												parse_menu_tag(p_frame, symbol, active_word_buffer,0);
												break;
											case 'v': /* end of DIV */
											case 'V':
												parse_div_tag(p_frame, symbol, active_word_buffer, 0);
												break;
										}
										break;
									case 'l': /* end of DL tag */
									case 'L':
										parse_d_tags(p_frame, active_word_buffer, 0, 0);
										break;
								}
								break;
							case 'e': /* end of emphasis tag */
							case 'E':
								set_font_italic(p_frame->current_word, 0);
								break;
							case 'f':
							case 'F':
								switch (*(symbol + 1))
								{
									case 'o': /* close font tag */
									case 'O':
										parse_font_tag(p_frame, symbol, font_step, 0);
										break;
								}
								break;
							case 'h':
							case 'H':
								switch (*(symbol + 1))
								{
									case 't': /* close of HTML tag */
									case 'T':
										*(symbol + 5) =	'\0';
										p_frame->current_paragraph->eop_space = 20;
										break;
									case '1': /* end of Header tag */
									case '2':
									case '3':
									case '4':
									case '5':
									case '6':
										parse_header_tag(p_frame, symbol, active_word_buffer,0);
										break;
								}
								break;
							case 'i':
							case 'I':
								switch (*(symbol + 1))
								{
									case ' ': /* end of italic tag */
									case '>':
										set_font_italic(p_frame->current_word, 0);
										break;
								}
								break;
							case 'k': /* KBD tag close */
							case 'K':
								set_pre_font(p_frame->current_word,1);
								break;
							case 'm':
							case 'M':
								switch (*(symbol + 1))
								{
									case 'e': /* end of MENU tag */
									case 'E':
										parse_menu_tag(p_frame, symbol, active_word_buffer, 0);
										break;
								}
								break;
							case 'o':
							case 'O':
								switch (*(symbol + 1))
								{
									case 'l': /* end of OL tag */
									case 'L':
										parse_ol_tag(p_frame, symbol, active_word_buffer, 0);
										break;
								}
								break;
							case 'p':
							case 'P': 
								switch (*(symbol + 1))
								{
									case 'r':
									case 'R': /* end of pre tag */
										set_pre_font(p_frame->current_word,1);

										in_pre = false;
										break;
								}
								break;
							case 's':
							case 'S':
								switch (*(symbol + 1))
								{
									case ' ':
									case '>':
										set_font_strike(p_frame->current_word, 0);
										break;
									case 'a':
									case 'A':
										set_pre_font(p_frame->current_word,0);
										break;
									case 'm': /* End of SMALL tag */
									case 'M':
										p_frame->current_word->styles.font_size = prev_sm_size;
										p_frame->current_word->changed.font = true;
										break;
									case 't':
									case 'T':
										switch (*(symbol + 3))
										{
											case 'i': /* end of strike through */
											case 'I':
												set_font_strike(p_frame->current_word, 0);
												break;
											case 'o': /* end of strong */
											case 'O':
												set_font_bold(p_frame->current_word, 0);
												break;
										}
										break;
									case 'u': /* close sub or sup */
									case 'U':
										p_frame->current_word->styles.font_size = prev_su_size; /*p_frame->current_font_size; */
										p_frame->current_word->vertical_align = middle; /*bottom; baldrick - July 19, 2001 */
										p_frame->current_word->changed.font = true;
										break;
								}
								break;
							case 't':
							case 'T':
								switch (*(symbol + 1))
								{
									case 't': /* end TT tag */
									case 'T':
										set_pre_font(p_frame->current_word,0);
										break;
									case 'i': /* Title end tag */
									case 'I':
										symbol = kill_to_end(symbol);
										break;
									case 'a': /* table -> at least I think this is the only ta tag */
									case 'A':
										parse_table_tag(p_frame, symbol, active_word_buffer, 0);
										break;
									case 'h': /* table header */
									case 'H':
										break;
									case 'r': /* table row */
									case 'R':
										break;
									case 'd': /* table data cell */
									case 'D':
										break;

								}
								break;
							case 'u':
							case 'U':
								switch (*(symbol + 1))
								{
									case ' ': /* close U tag */
									case '>':
										set_font_underline(p_frame->current_word, 0);
										break;
									case 'l': /* close UL tag */
									case 'L':
										parse_ul_tag(p_frame, symbol, active_word_buffer,0);
										break;
								}
								break;
							case 'v': /* end of VAR tag */
							case 'V':
								set_font_italic(p_frame->current_word, 0);
								break;
						}
						break;
				}
				
				if (p_frame->current_word->changed.font == true)
				{
					vst_font (vdi_handle,
						  fonts[p_frame->current_word->styles.font]
						  [p_frame->current_word->styles.bold != 0]
						  [p_frame->current_word->styles.italic != 0]);
					vst_arbpt (vdi_handle, p_frame->current_word->styles.font_size, &u, &u, &u, &u);
					vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
					vqt_advance (vdi_handle, Space_Code,
						     &p_frame->current_word->space_width, &u, &u, &u);

					p_frame->current_word->word_height = distances[3];
					p_frame->current_word->word_tail_drop = distances[1];
				}
				symbol++;
				break;
			case 10: /* LF */
				if ((in_pre == true)&&(*(symbol - 1)==13))
				{
					*symbol = 32;
					symbol--;
					break;
				}			
			case 13: /* CR */
			case 12: /* FORM FEED ?????? */
				if ((in_pre == true))
				{
					p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

					add_paragraph(p_frame, active_word_buffer);
					p_frame->active_word = active_word_buffer;
				}
				else
				{
					*symbol = 32;
					symbol--;
				}
				break;
			case '&':
				if (*(symbol + 1) == '#')
				{
					output[0] = *(symbol + 2);
					output[1] = *(symbol + 3);
					output[2] = *(symbol + 4);
					symbol += 4;
					output[3] = '\0';
				
					*p_frame->active_word =	special_char_map (convert_to_number (output));
					p_frame->active_word++;
					space_found = false;
				}
				else if (*(symbol + 1) == ' ')
				{
					*p_frame->active_word = map (*symbol);
					p_frame->active_word++;
					break;
				}
				else
				{
					strcpy(output,"\0");
	
					while (*(symbol + 1) != ';' && *(symbol + 1) != '\0')
					{
						strncat(output,symbol + 1,1);
						symbol++;
					}

					symbol++;

					*p_frame->active_word = special_char_map_str(output,ISO1);
					p_frame->active_word++;
					space_found = false;
				}

				break;
			case ' ':
				if (!in_pre)
				{
					if (space_found == true)
						break;
	
					p_frame->current_word = add_word (p_frame,p_frame->current_word, active_word_buffer,p_frame->active_word);
					p_frame->active_word = active_word_buffer;
					space_found = true;
				}
			default:
				if (*symbol < 32)
					break;
				if (*symbol > 126)
					break;
				if (*symbol != ' ')
					space_found = false;

				*p_frame->active_word = map (*symbol);
				p_frame->active_word++;
		}

		if (code_processed == true)
		{
			code_processed = false;

			symbol = kill_to_end(symbol);
		}
		symbol++;

	}

	word_store (p_frame, active_word_buffer, p_frame->active_word);

	wind_update (BEG_UPDATE);
	graf_mouse (0, 0);
	wind_update (END_UPDATE);

	free (start_symbol);

	p_frame->frame_page_width += 5;

	return (start);
}

/* parse_text
 * this is the text parsing routine
 * for use with non formatted text files
 *
 * Nothing exciting just maps lines to paragraphs
 */
 
struct paragraph_item *
parse_text (char *symbol, struct frame_item *p_frame)
{
	struct paragraph_item *start;
	WORD u;
	char *start_symbol;
	WORD active_word_buffer[200];
	WORD distances[5], effects[3];
	WORD i;

	start_symbol = symbol;

	if (symbol == 0)
		return (new_paragraph ());

	start = p_frame->current_paragraph = new_paragraph ();
	p_frame->current_word = p_frame->current_paragraph->item;
	p_frame->active_word = active_word_buffer;

	wind_update (BEG_UPDATE);
	graf_mouse (2, 0);
	wind_update (END_UPDATE);

	current_highlighted_link_area = 0;

	vst_font (vdi_handle, fonts[0][0][0]);
	p_frame->current_font_size = POINT_SIZE;
	vst_arbpt (vdi_handle, p_frame->current_font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &p_frame->current_word->space_width, &u, &u, &u);

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	p_frame->current_word->word_height = distances[3];
	p_frame->current_word->word_tail_drop = distances[1];

	p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;
	p_frame->current_word->styles.font = pre_font;

	while (*symbol != '\0')
	{
		switch (*symbol)
		{
			case 9:  /* TAB */
				*symbol = 32;
				
				for (i = 0; i< 5;i++)
				{
					*p_frame->active_word = map (*symbol);
					p_frame->active_word++;
				}

				break;
			case 10: /* LF */
				if ((*(symbol - 1)==13))
				{
					*symbol = 32;
					symbol--;
					break;
				}			
			case 13: /* CR */
			case 12: /* FORM FEED ?????? */
				p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

				add_paragraph(p_frame, active_word_buffer);

				p_frame->active_word = active_word_buffer;
				break;
			default:
				if (*symbol < 32)
					break;
/*				
				if (*symbol > 126)
					break;
*/
				*p_frame->active_word = map (*symbol);
				p_frame->active_word++;
		}

		symbol++;
	}

	word_store (p_frame, active_word_buffer, p_frame->active_word);

	wind_update (BEG_UPDATE);
	graf_mouse (0, 0);
	wind_update (END_UPDATE);

	free (start_symbol);

	p_frame->frame_page_width += 5;

	return (start);
}
