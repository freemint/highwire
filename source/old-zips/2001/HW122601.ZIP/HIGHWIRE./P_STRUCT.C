
#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

void
destroy_paragraph_structure (struct paragraph_item *current_paragraph)
{
	struct paragraph_item *temp;

	while (current_paragraph != 0)
	{
		if (current_paragraph->item != 0)
			destroy_word_structure (current_paragraph->item);

		if (current_paragraph->table != 0)
			destroy_table_structure (current_paragraph->table);
			
		temp = current_paragraph->next_paragraph;
		free (current_paragraph);
		current_paragraph = temp;
	}
}


struct paragraph_item *
new_paragraph (void)
{
	struct paragraph_item *temp;
	temp = malloc (sizeof (struct paragraph_item));

	temp->item = new_word ();
	temp->alignment = left;
	temp->paragraph_code = none;
	temp->left_border = 0;
	temp->right_border = 0;
	temp->eop_space = 0;
	temp->current_paragraph_height = 0;
	temp->table = 0;
	temp->next_paragraph = 0;
	return (temp);
}


/* add_paragraph
 * 
 * Creates a new paragraph structure and links it into list
 * also creates a new word item and links it into the new paragraph
 *
 * 12/14/01 - modified to use frame_item info and directly modify frame - baldrick
 */

void
add_paragraph (struct frame_item *p_frame, WORD *active_word_buffer)
{
	struct paragraph_item *paragraph;
	struct word_item *word;


#if 0
	if (p_frame->current_word->word_width == 0)
	{
		if (p_frame->current_paragraph->item == p_frame->current_word)
/*			printf("item = current word              \r\n");
		else
			printf("item is NOT equal to current word\r\n");
*/			
		if(p_frame->current_word->word_code == none) 
			return; /* suppress creation of new paragraph return and use current */
	}
#endif 

	word_store (p_frame, active_word_buffer, p_frame->active_word);

	if (p_frame->frame_page_width < (p_frame->current_word->word_width + p_frame->current_indent_distance))
		p_frame->frame_page_width = p_frame->current_word->word_width + p_frame->current_indent_distance;

	word = malloc (sizeof (struct word_item));

	word->word_width = 0;
	word->word_height = p_frame->current_word->word_height;
	word->word_tail_drop = p_frame->current_word->word_tail_drop;
	word->styles.bold = p_frame->current_word->styles.bold;
	word->styles.italic = p_frame->current_word->styles.italic;
	word->styles.underlined = p_frame->current_word->styles.underlined;
	word->styles.strike = p_frame->current_word->styles.strike;
	word->styles.font = p_frame->current_word->styles.font;
	word->styles.font_size = p_frame->current_word->styles.font_size;
	word->space_width = p_frame->current_word->space_width;
	word->changed.style = false;
	word->changed.font = false;
	word->changed.colour = false;
	word->word_code = none;
	word->colour = p_frame->current_word->colour;
	word->vertical_align = p_frame->current_word->vertical_align;
	word->link = p_frame->current_word->link;
	word->next_word = 0;

	paragraph = malloc (sizeof (struct paragraph_item));

	paragraph->item = word;
	paragraph->alignment = p_frame->current_paragraph->alignment;
	paragraph->paragraph_code = none;
	paragraph->left_border = p_frame->current_paragraph->left_border;
	paragraph->right_border = p_frame->current_paragraph->right_border;
	paragraph->eop_space = 0;
	paragraph->current_paragraph_height = 0;
	paragraph->table = 0;
	paragraph->next_paragraph = 0;
	p_frame->current_paragraph->next_paragraph = paragraph;

	p_frame->current_paragraph = paragraph;
	
	p_frame->current_word = p_frame->current_paragraph->item;
}
