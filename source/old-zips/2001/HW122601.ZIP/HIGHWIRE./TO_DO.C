
#include <stdlib.h>

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

#include <string.h>

void
check_to_do_list (void)
{
	struct load_to_do *load_to_do_temp;
	struct parse_to_do *parse_to_do_temp;
	struct to_do_item *to_do_item_temp;

	while (read_to_do != 0)
	{
		switch (read_to_do->message_type)
		{
			case to_do_load_frame:
				/*load files + urls into memory ready for parsing*/
				load_to_do_temp = read_to_do->message;

				switch (load_to_do_temp->sub_type)
				{
					case 0:	/*clear settings and load new file into frame */

						reset_frame (load_to_do_temp->frame);
						load_to_do_temp->frame->frame_filename = load_to_do_temp->filename;
						load_to_do_temp->frame->frame_named_location = load_to_do_temp->named_location;
						load_to_do_temp->frame->frame_name = load_to_do_temp->frame_name;

						load_to_do_temp->frame->frame_top = load_to_do_temp->top;
						load_to_do_temp->frame->frame_left = load_to_do_temp->left;
						load_to_do_temp->frame->frame_height = load_to_do_temp->height;
						load_to_do_temp->frame->frame_width = load_to_do_temp->width;

						if (load_to_do_temp->border > 0)
							load_to_do_temp->frame->border = 1;

						add_parse_item_to_to_do_list (load_file(load_to_do_temp->filename),
									      load_to_do_temp->frame,get_decoder_type(load_to_do_temp->filename));
						break;

					case 1:	/*add new frame to current frame and load file into that frame*/
						if (load_to_do_temp->frame->next_frame != 0)
							destroy_frame_structure (load_to_do_temp->frame->next_frame);
						load_to_do_temp->frame->next_frame = new_frame ();
						load_to_do_temp->frame->next_frame->frame_filename = load_to_do_temp->filename;
						load_to_do_temp->frame->next_frame->frame_named_location = load_to_do_temp->named_location;
						load_to_do_temp->frame->next_frame->frame_name = load_to_do_temp->frame_name;

						load_to_do_temp->frame->next_frame->frame_top = load_to_do_temp->top;
						load_to_do_temp->frame->next_frame->frame_left = load_to_do_temp->left;
						load_to_do_temp->frame->next_frame->frame_height = load_to_do_temp->height;
						load_to_do_temp->frame->next_frame->frame_width = load_to_do_temp->width;

						if (load_to_do_temp->border > 0)
							load_to_do_temp->frame->next_frame->border = 1;

						add_parse_item_to_to_do_list (load_file(load_to_do_temp->filename),
									      load_to_do_temp->frame->next_frame,get_decoder_type(load_to_do_temp->filename));
						break;

					case 2:
						load_to_do_temp->frame = previous_frame;

						load_to_do_temp->frame->next_frame = new_frame ();
						load_to_do_temp->frame->next_frame->frame_filename = load_to_do_temp->filename;
						load_to_do_temp->frame->next_frame->frame_named_location = load_to_do_temp->named_location;
						load_to_do_temp->frame->next_frame->frame_name = load_to_do_temp->frame_name;

						load_to_do_temp->frame->next_frame->frame_top = load_to_do_temp->top;
						load_to_do_temp->frame->next_frame->frame_left = load_to_do_temp->left;
						load_to_do_temp->frame->next_frame->frame_height = load_to_do_temp->height;
						load_to_do_temp->frame->next_frame->frame_width = load_to_do_temp->width;

						if (load_to_do_temp->border > 0)
							load_to_do_temp->frame->next_frame->border = 1;

						add_parse_item_to_to_do_list (load_file(load_to_do_temp->filename),
									      load_to_do_temp->frame->next_frame,get_decoder_type(load_to_do_temp->filename));

						/* it's safe to free the filename here */
						free(load_to_do_temp->filename);
#if 0
/*						reset_frame (load_to_do_temp->frame);*/
						load_to_do_temp->frame->new_frame = new_frame ();
						load_to_do_temp->frame->new_frame->frame_filename = load_to_do_temp->filename;
						load_to_do_temp->frame->new_frame->frame_named_location = load_to_do_temp->named_location;
						add_parse_item_to_to_do_list (load_file(load_to_do_temp->filename),
									      load_to_do_temp->frame->new_frame);
/*load_to_do_temp->frame->frame_height = load_to_do_temp->frame->frame_height - load_to_do_temp->top;
load_to_do_temp->frame->frame_width = load_to_do_temp->frame->frame_width - load_to_do_temp->left;
*/
#endif

						break;	/*add sub frame to passed frame - not used yet */
				}
				break;

			case to_do_parse_frame:
				/* parse a file and attach it to the passed frame */
				parse_to_do_temp = read_to_do->message;

				switch(parse_to_do_temp->decoder)
				{
					case HTML_DECODER:
						parse_to_do_temp->frame->item =
							calculate_frame (parse_to_do_temp->file, parse_to_do_temp->frame);/*, &parse_to_do_temp->frame->frame_page_width);*/
						break;
					case TEXT_DECODER:
					default: /* pretend it's text */
						parse_to_do_temp->frame->item =
							parse_text (parse_to_do_temp->file, parse_to_do_temp->frame);/*, &parse_to_do_temp->frame->frame_page_width);*/
				}
				
				number_of_frames_left_to_load--;

				if (number_of_frames_left_to_load == 0)
				{
					calculate_frame_locations ();
					redraw (window_handle, 0, 0, 0, 0, the_first_frame);
				}

				break;
		}

		to_do_item_temp = read_to_do;
		free (read_to_do->message);
		read_to_do = to_do_item_temp->next_to_do;
		free (to_do_item_temp);

	}
	add_to_do = 0;
	return;
}

void
add_item_to_to_do_list (enum possible_message_types message_type, void *message_item)
{
	struct to_do_item *to_do_item_temp;

	to_do_item_temp = malloc (sizeof (struct to_do_item));

	if (add_to_do != 0)
		add_to_do->next_to_do = to_do_item_temp;
		
	add_to_do = to_do_item_temp;
	add_to_do->message_type = message_type;
	add_to_do->next_to_do = 0;
	add_to_do->message = message_item;

	if (read_to_do == 0)
		read_to_do = add_to_do;
}

/* add_load_item_to_to_do_list()
 *
 * inserts a load to do command into the queue for processing
 *
 * sub_type is the type of frame processing to preform
 * address is the resource to load into the frame
 * frame - value use depends on sub_type
 * info_frame - a holder frame for pre known attributes for the new frame
 *
 *  +1 added to malloc space
 * David Leaver December 21, 2001
 */

void
add_load_item_to_to_do_list (WORD sub_type, char *address, struct frame_item *frame, struct frame_item *info_frame)
{
	struct load_to_do *load_to_do_temp;

	/* increment the frame counter */
	number_of_frames_left_to_load++;

	/* malloc memory for struct, and the filename and frame_name
	 * buffers.  If we don't do this for the names, they are lost
	 */
	load_to_do_temp = malloc (sizeof (struct load_to_do));

	load_to_do_temp->filename = malloc (strlen(address)+1);
	
	if (info_frame->frame_name != 0)
		load_to_do_temp->frame_name = malloc (strlen(info_frame->frame_name)+1);

	load_to_do_temp->sub_type = sub_type;
	load_to_do_temp->named_location = translate_address (address);

	strcpy(load_to_do_temp->filename,address);
	load_to_do_temp->frame = frame;
	
	/* copy over information from the temp frame */
	load_to_do_temp->left = info_frame->frame_left;
	load_to_do_temp->top = info_frame->frame_top;
	load_to_do_temp->width = info_frame->frame_width;
	load_to_do_temp->height = info_frame->frame_height;
	load_to_do_temp->border = info_frame->border;

	if (info_frame->frame_name != 0)
		strcpy(load_to_do_temp->frame_name,info_frame->frame_name);
	else 
		load_to_do_temp->frame_name = 0;

	add_item_to_to_do_list (to_do_load_frame, load_to_do_temp);

	free(info_frame);
}

void
add_parse_item_to_to_do_list (char *file, struct frame_item *frame, WORD decoder)
{
	struct parse_to_do *parse_to_do_temp;
	parse_to_do_temp = malloc (sizeof (struct parse_to_do));

	parse_to_do_temp->decoder = decoder;
	parse_to_do_temp->file = file;
	parse_to_do_temp->frame = frame;
	add_item_to_to_do_list (to_do_parse_frame, parse_to_do_temp);
}
