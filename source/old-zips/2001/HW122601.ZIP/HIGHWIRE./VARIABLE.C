
#include "global.h"

/* ******** Variable Definitions ******************* */

/* To be in-program settings */
WORD link_colour = 12;
WORD highlighted_link_colour = 10;
WORD text_colour = 1;
WORD background_colour = 0;

WORD slider_bkg = 9;
WORD slider_col = 8;

/* ignore colors will track whether the user has selected
 * to ignore page level color modifications.
 * It is currently used to track monochrome resolutions.
 */
WORD ignore_colours = 0;


/* Globals */
enum bool frames_recalculated = false;
WORD vdi_handle, app_id, window_handle;

WORD fonts[3][2][2] = { 
	{ {5031, 5032}, {5033, 5034} },
	{ {5031, 5032}, {5033, 5034} },
	{ {5031, 5032}, {5033, 5034} }
};

/* ok there are 3 font families and these have 2 different effects
   
   What I know so far...

   [font family][bold face][italic face]
   
   font families
     0 - normal font
     1 - header font
     2 - pre font
     
    So you can have
   	header , bold, italic
   	header , bold, normal
   	header , normal, italic
   	...

   
*/

WORD event_messages[8];
WORD number_of_frames_left_to_load = 0;
struct frame_item *the_first_frame;
struct frame_item *previous_frame;


struct clickable_area *current_highlighted_link_area;
struct frame_item *current_highlighted_link_frame;
struct to_do_item *add_to_do;
struct to_do_item *read_to_do;
