
#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

struct table_step *
new_table_step (struct paragraph_item *p_table)
{
	struct table_step *temp;
	temp = malloc (sizeof (struct table_step));

	temp->table = p_table;
	temp->previous_table_step = 0;

	return (temp);
}

struct table_step *
add_table_step (struct table_step *old, struct paragraph_item *p_table)
{
	struct table_step *temp;

	temp = new_table_step (p_table);
	temp->previous_table_step = old;

	return (temp);
}

struct table_step *
destroy_table_step (struct table_step *current)
{
	struct table_step *temp;

	if (current->previous_table_step != 0)
	{
		temp = current->previous_table_step;
		free (current);

		return (temp);
	}
	else
	{
		free(current);
		return(0);
	}
}

/* ****************************** */

void
destroy_table_structure (struct table_item *current_table)
{
	struct table_child *temp_child;
	struct table_child *current_child;
	struct paragraph_item *current_paragraph;
	
	current_child = current_table->children;
	
	while (current_child != 0)
	{
		current_paragraph = current_child->item;

		destroy_paragraph_structure (current_paragraph);

		temp_child = current_child->next_child;
		free(current_child);
		current_child = temp_child;
	}
			
	free(current_table);
}


struct table_child *
new_table_child (void)
{
	struct table_child *temp;
	
	temp = malloc (sizeof (struct table_child));

	temp->height = 0;
	temp->width = 0;
	temp->alignment = left;
	temp->valignment = bottom;
	temp->colspan = 1;
	temp->rowspan = 1;
	temp->bgcolor = 0;
	temp->item = new_paragraph();
	temp->next_child = 0;
	
	return (temp);
}

struct table_item *
new_table (void)
{
	WORD i;
	
	struct table_item *temp;

	temp = malloc (sizeof (struct table_item));

	temp->num_cols = 0;
	temp->num_rows = 0;
	temp->table_height = 0;
	temp->forced_width = 0;
	temp->table_width = 0;
	temp->alignment = left;
	temp->border = 0;
	temp->cell_spacing = 0;
	temp->cell_padding = 0;
	temp->num_children = 0;
	temp->children = new_table_child();
	
	/* clear out col_widths array */
	for (i=0;i<50;i++)
		temp->col_widths[i] = 0;

	return (temp);
}

/*
 * determines the height of a table by walking it's paragraph list
 */
long calculate_subtable_height (struct table_item *current_table, struct frame_item *frame,long top);


long
calculate_table_height (struct table_item *current_table, struct frame_item *frame,long top)
{
	struct paragraph_item *current_paragraph;
	struct table_child *current_child;
	struct word_item *current_word, *line_start, *line_end;
	struct url_link *current_link;
	WORD left_indent, right_indent, current_line_width, line_tail = 0, line_height;
	WORD alignment_spacer = 0, height_spacer, table_w;
	WORD frame_w;
	WORD previous_word_height = 0;
	long current_height = 0L;
	long temp_height = 0L;
	long temp_row_height = 0L;
	enum bool clickable_area_exists = false;
	struct clickable_area *current_clickable_area;
	struct named_location *current_named_location;
	WORD temp_cols = 0;
	WORD temp_rows = 0;
	
	WORD left_border = 0, bottom_border = 0, right_border = 0;
	WORD temp_left = 0;
	WORD i;

	current_child = current_table->children;
	current_paragraph = current_child->item;

/*	if (!current_table->forced_width)*/
			current_table->table_width = calculate_table_width(current_table,frame, current_height);

	table_w = current_table->table_width;

	if (table_w > frame->frame_page_width)
	{
		frame->frame_page_width = table_w;
	}
	
	current_clickable_area = frame->first_clickable_area;
	current_named_location = frame->first_named_location;
	current_link = 0;

	frame_w = frame->frame.w;

	if (current_paragraph == 0)
		return (0);

	current_line_width = current_table->table_width;
			
	switch (current_table->alignment)
	{
		case center:
			left_border = (frame_w - current_line_width) / 2;
			break;
		case right:
			left_border = (frame_w - current_line_width) - 2;
			break;
		case left:
			left_border = 3;
			break;
		default: /* just assume it's left */
			left_border = 3;
	}

	left_border += frame->clip.x;

	if (current_table->border)
		left_border -= 1;

	left_border += 1;

	temp_left = left_border;
	
	while (current_child != 0)
	{
		/* first walk the paragraphs */

		current_paragraph = current_child->item ;
		current_word = current_paragraph->item;

		current_child->height = 0;

		while (current_paragraph != 0)
		{
			current_paragraph->current_paragraph_height = 0;

			current_word = current_paragraph->item;
		
			/* hr = horizontal ruler */
			if (current_paragraph->paragraph_code == hr)
			{
				current_child->width = current_word->word_width;

				current_paragraph->current_paragraph_height = abs (current_word->word_height) + 20;
	
				current_paragraph->area.x = current_paragraph->left_border + left_border;
				current_paragraph->area.y = (WORD)current_height;
				current_paragraph->area.w = current_word->word_width;
				current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

				current_child->height = current_paragraph->current_paragraph_height;

/*				temp_height += current_paragraph->current_paragraph_height;
*/
				temp_left += current_word->word_width;
				
				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}
			else if (current_paragraph->paragraph_code == img)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 */

				if (current_child->width == 0)
					current_child->width = current_word->word_width;

				current_paragraph->current_paragraph_height = abs (current_word->word_height);

				current_paragraph->area.x = current_paragraph->left_border + left_border;

				current_paragraph->area.y = (WORD)current_height + temp_height;
				current_paragraph->area.w = current_word->word_width;
				current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

				current_child->height += current_paragraph->current_paragraph_height;


/*				temp_height += current_paragraph->current_paragraph_height;
*/
				temp_left += current_word->word_width;

				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}
			else if (current_paragraph->paragraph_code == table)
			{
				printf("hit a subtable in table height\r\n");

				current_paragraph->table->table_height = calculate_subtable_height (current_paragraph->table, frame,current_height);
				current_child->height = current_paragraph->table->table_height;

/*				temp_height += current_paragraph->table->table_height;*/
				temp_left += current_word->word_width;

				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}

			left_indent = current_paragraph->left_border + left_border + temp_left;
			right_indent = current_paragraph->right_border; /* + right_border;*/

			/* Now walk the words */
			while (current_word != 0)
			{
				current_line_width = 0;
				line_start = current_word;
				line_height = 0;
				line_tail = 0;
				clickable_area_exists = false;

	
#if 0

		v_ftext16 (vdi_handle, 10, 10, current_word->item);

		vswr_mode(vdi_handle,1);
		v_ftext16 (vdi_handle, 10, current_height + 30, current_word->item);
#endif


				while (current_word != 0 
			       && (current_line_width + current_word->word_width) < (table_w))/* - left_indent - right_indent))*/
				{
					if (current_word->word_code == br && current_word != line_start)
						break;

					current_line_width += current_word->word_width;

					if (line_height < current_word->word_height)
						line_height = current_word->word_height;
					if (line_tail < current_word->word_tail_drop)
						line_tail = current_word->word_tail_drop;
					if (current_word->link != 0)
					{
						if (current_word->link->mode == href)
						{
							clickable_area_exists = true;

							if (current_link != 0 && current_word->link == 0)
							{
								current_link = 0;
							}
							else if (current_link == 0 && current_word->link != 0)
							{
								current_link = current_word->link;
	
								if (frame->first_clickable_area == 0)
								{
									current_clickable_area = frame->first_clickable_area = new_clickable_area();
								}
								else
								{
									if (current_clickable_area->next_area == 0)
										current_clickable_area->next_area = new_clickable_area();
									current_clickable_area = current_clickable_area->next_area;
								}
	
								current_clickable_area->x = left_border + current_line_width + alignment_spacer + temp_left;
/*								current_clickable_area->x = current_line_width + alignment_spacer;*/
								current_clickable_area->y = (WORD)(current_height + current_paragraph->current_paragraph_height)+(WORD)top;
								current_clickable_area->h =	line_height + line_tail;
								current_clickable_area->w = current_word->word_width;
								current_clickable_area->link = current_link;
							}
							else if (current_link == current_word->link)
								current_clickable_area->w += current_word->word_width;
							else if (current_link != 0  && current_word->link != 0)
							{
								if (current_clickable_area->next_area == 0)
									current_clickable_area->next_area = new_clickable_area ();
	
								current_clickable_area = current_clickable_area->next_area;
								current_link = current_word->link;
	
								if (current_clickable_area == 0)
									current_clickable_area = new_clickable_area ();

								current_clickable_area->x = left_border + current_line_width + alignment_spacer + temp_left;
							
/*								current_clickable_area->y = (WORD)(current_height + current_paragraph->current_paragraph_height) + (WORD)top;*/
								current_clickable_area->y = (WORD)(current_height) + current_child->height + (WORD)top;
								
								current_clickable_area->h = line_height + line_tail;
								current_clickable_area->w = current_word->word_width;
								current_clickable_area->link = current_link;
							}
						}
						else
						{
							if (frame->first_named_location == 0)
							{
								current_named_location = frame->first_named_location = 	new_named_location ();
								current_named_location->link = current_word->link;
								current_named_location->position = current_height + current_paragraph->current_paragraph_height + temp_height;
							}
							else
							{
								if (current_named_location->link != current_word->link)
								{
									if (current_named_location->next_location == 0)
										current_named_location->next_location = new_named_location();

									current_named_location = current_named_location->next_location;
									current_named_location->link = current_word->link;
									current_named_location->position = current_height + current_paragraph->current_paragraph_height + temp_height;
								}
							}
						}
					}

					current_word = current_word->next_word;
				}


				current_paragraph->current_paragraph_height += line_height + line_tail;		
			}

			temp_height += current_paragraph->current_paragraph_height;

			current_paragraph->left_border = (temp_left - left_border);
			
			/* we need to set the y here or it gets modified */
			current_paragraph->area.y = (WORD)current_height + current_child->height;

/*			if (temp_cols >= current_table->num_cols)
			{
*/
				if (current_paragraph->eop_space > 0)
					current_paragraph->current_paragraph_height += current_paragraph->eop_space;
				else
					current_height += current_paragraph->eop_space;
/*			}
*/			
			current_paragraph->area.x = current_paragraph->left_border;
			current_paragraph->area.w = current_line_width;
			current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

/*printf("area.w = %d  \r\n",current_line_width);		*/

			/* only advance height if we have finished a row */

			current_child->height += current_paragraph->current_paragraph_height;		

/*			if (current_paragraph->current_paragraph_height > temp_row_height)
			{
				temp_height = current_paragraph->current_paragraph_height;
				temp_row_height = current_paragraph->current_paragraph_height;
			}
*/
			temp_left += current_line_width;
		
			current_paragraph = current_paragraph->next_paragraph;
		}

		if (current_child->height > temp_row_height)
			temp_row_height = current_child->height;

		temp_cols = temp_cols + current_child->colspan;

		if (temp_cols >= current_table->num_cols)
		{
			temp_cols = 0;
			current_height += temp_row_height;

			temp_height = 0;
			temp_row_height = 0;
			temp_left = left_border;
		}
				
		current_child = current_child->next_child;
	}

	/* Ok now resort the whole mess, could probably be done better, but I'm mentally exhausted - baldrick 11/27/01 */

	temp_cols = 0;

	current_child = current_table->children;
	current_paragraph = current_child->item;
	
	while (current_child != 0)
	{
		/* first walk the paragraphs */
		current_paragraph = current_child->item ;
	
		temp_left = 0;

		for (i = 0; i < temp_cols; i++)
			temp_left += current_table->col_widths[i];

		while (current_paragraph != 0)
		{
			current_paragraph->left_border = temp_left;
			current_paragraph->area.x = current_paragraph->left_border;

			current_paragraph = current_paragraph->next_paragraph;
		}

		temp_cols = temp_cols + current_child->colspan;

		if (temp_cols >= current_table->num_cols)
		{			
			temp_cols = 0;
		}
		
		current_child = current_child->next_child;
	}

	return (current_height);
}

/*
 * determines the width of a table by walking it's paragraph list
 */

WORD
calculate_table_width (struct table_item *current_table, struct frame_item *frame,long top)
{
	struct paragraph_item *current_paragraph;
	struct table_child *current_child;
	struct word_item *current_word, *line_start;
	WORD current_line_width;
	WORD current_width = 0, max_width = 0;
	WORD temp_cols = 0;
	
	current_child = current_table->children;
	current_paragraph = current_child->item;

	if (current_paragraph == 0)
		return (0);

	/* This is a bad test, but strange things happen when we
	 * don't force the table to stay the same width
	 */
	 
	if (current_table->table_width > 0)
	{
		/* we still need to walk the childrent to get the col_widths */
		
		while (current_child != 0)
		{
			if (current_child->width > current_table->col_widths[temp_cols])
				current_table->col_widths[temp_cols] = current_child->width;
		
			temp_cols = temp_cols + current_child->colspan;
	
			if (temp_cols >= current_table->num_cols)
			{
				temp_cols = 0;
				current_width = 0;
			}

			current_child = current_child->next_child;
		}

/*		for (temp_cols = 0; temp_cols < current_table->num_cols; temp_cols++)
			printf("col[ %d ] = %d   \r\n",temp_cols,current_table->col_widths[temp_cols]);
*/		
		return(current_table->table_width);
	}
		
	while (current_child != 0)
	{
		/* first walk the paragraphs */
		current_paragraph = current_child->item ;
		current_word = current_paragraph->item;
	
		while (current_paragraph != 0)
		{
			current_word = current_paragraph->item;

			/* hr = horizontal ruler */
			if (current_paragraph->paragraph_code == hr)
			{
				current_child->width = current_word->word_width;

				current_width += current_child->width;
				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}
			else if (current_paragraph->paragraph_code == img)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 */

				/* if the width isn't predefined */
				if (current_child->width == 0)
					current_child->width = current_word->word_width;

				current_width += current_child->width;
				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}
			else if (current_paragraph->paragraph_code == table)
			{
				printf("hit a subtable\r\n");
				current_paragraph->table->table_width = calculate_subtable_width(current_table,frame, top);

				current_width += current_paragraph->table->table_width;
				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}

			/* Now walk the words */
			while (current_word != 0)
			{
				current_line_width = 0;
				line_start = current_word;
	

				while (current_word != 0 )
/*			       && (current_line_width + current_word->word_width) < (frame_w - left_indent - right_indent))*/
				{
					if (current_word->word_code == br && current_word != line_start)
						break;

					current_line_width += current_word->word_width;

/*
vswr_mode(vdi_handle,1);
		v_ftext16 (vdi_handle, 10, 15 * temp_cols, current_word->item);
*/
					current_word = current_word->next_word;
				}
			}

/*			current_child->width = current_line_width;
			current_child->width += current_table->cell_spacing;
*/
			if ((current_line_width + current_table->cell_spacing) > current_child->width)
				current_child->width = (current_line_width + current_table->cell_spacing);

			current_width += current_child->width;

			current_paragraph = current_paragraph->next_paragraph;
		}

		if (current_child->width > current_table->col_widths[temp_cols])
			current_table->col_widths[temp_cols] = current_child->width;
		
		temp_cols = temp_cols + current_child->colspan;

		if (temp_cols >= current_table->num_cols)
		{
			temp_cols = 0;
			current_width = 0;
		}

		current_child = current_child->next_child;
	}

	for (temp_cols = 0; temp_cols < current_table->num_cols; temp_cols++)
		max_width += current_table->col_widths[temp_cols];
		
	return (max_width);
}

WORD
calculate_subtable_width (struct table_item *current_table, struct frame_item *frame,long top)
{
	struct paragraph_item *current_paragraph;
	struct table_child *current_child;
	struct word_item *current_word, *line_start;
	WORD current_line_width;
	WORD current_width = 0, max_width = 0;
	WORD temp_cols = 0;
	
	current_child = current_table->children;
	current_paragraph = current_child->item;

	if (current_paragraph == 0)
		return (0);

	/* This is a bad test, but strange things happen when we
	 * don't force the table to stay the same width
	 */
	 
	if (current_table->table_width > 0)
	{
		/* we still need to walk the childrent to get the col_widths */
		
		while (current_child != 0)
		{
			if (current_child->width > current_table->col_widths[temp_cols])
				current_table->col_widths[temp_cols] = current_child->width;
		
			temp_cols = temp_cols + current_child->colspan;
	
			if (temp_cols >= current_table->num_cols)
			{
				temp_cols = 0;
				current_width = 0;
			}

			current_child = current_child->next_child;
		}

/*		for (temp_cols = 0; temp_cols < current_table->num_cols; temp_cols++)
			printf("col[ %d ] = %d   \r\n",temp_cols,current_table->col_widths[temp_cols]);
*/		
		return(current_table->table_width);
	}
		
	while (current_child != 0)
	{
		/* first walk the paragraphs */
		current_paragraph = current_child->item ;
		current_word = current_paragraph->item;
	
		while (current_paragraph != 0)
		{
			current_word = current_paragraph->item;

			/* hr = horizontal ruler */
			if (current_paragraph->paragraph_code == hr)
			{
				current_child->width = current_word->word_width;

				current_width += current_child->width;
				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}
			else if (current_paragraph->paragraph_code == img)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 */

				/* if the width isn't predefined */
				if (current_child->width == 0)
					current_child->width = current_word->word_width;

				current_width += current_child->width;
				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}
			else if (current_paragraph->paragraph_code == table)
			{
				printf("hit a subtable\r\n");
				current_width += current_paragraph->table->table_width;
				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}

			/* Now walk the words */
			while (current_word != 0)
			{
				current_line_width = 0;
				line_start = current_word;
	

				while (current_word != 0 )
/*			       && (current_line_width + current_word->word_width) < (frame_w - left_indent - right_indent))*/
				{
					if (current_word->word_code == br && current_word != line_start)
						break;

					current_line_width += current_word->word_width;

/*
vswr_mode(vdi_handle,1);
		v_ftext16 (vdi_handle, 10, 15 * temp_cols, current_word->item);
*/
					current_word = current_word->next_word;
				}
			}

/*			current_child->width = current_line_width;
			current_child->width += current_table->cell_spacing;
*/
			if ((current_line_width + current_table->cell_spacing) > current_child->width)
				current_child->width = (current_line_width + current_table->cell_spacing);

			current_width += current_child->width;

			current_paragraph = current_paragraph->next_paragraph;
		}

		if (current_child->width > current_table->col_widths[temp_cols])
			current_table->col_widths[temp_cols] = current_child->width;
		
		temp_cols = temp_cols + current_child->colspan;

		if (temp_cols >= current_table->num_cols)
		{
			temp_cols = 0;
			current_width = 0;
		}

		current_child = current_child->next_child;
	}

	for (temp_cols = 0; temp_cols < current_table->num_cols; temp_cols++)
		max_width += current_table->col_widths[temp_cols];
		
	return (max_width);
}

long
calculate_subtable_height (struct table_item *current_table, struct frame_item *frame,long top)
{
	struct paragraph_item *current_paragraph;
	struct table_child *current_child;
	struct word_item *current_word, *line_start, *line_end;
	struct url_link *current_link;
	WORD left_indent, right_indent, current_line_width, line_tail = 0, line_height;
	WORD alignment_spacer = 0, height_spacer, table_w;
	WORD frame_w;
	WORD previous_word_height = 0;
	long current_height = 0L;
	long temp_height = 0L;
	long temp_row_height = 0L;
	enum bool clickable_area_exists = false;
	struct clickable_area *current_clickable_area;
	struct named_location *current_named_location;
	WORD temp_cols = 0;
	WORD temp_rows = 0;
	
	WORD left_border = 0, bottom_border = 0, right_border = 0;
	WORD temp_left = 0;
	WORD i;

	current_child = current_table->children;
	current_paragraph = current_child->item;

/*	if (!current_table->forced_width)*/
			current_table->table_width = calculate_table_width(current_table,frame, current_height);

	table_w = current_table->table_width;

	if (table_w > frame->frame_page_width)
	{
		frame->frame_page_width = table_w;
	}
	
	current_clickable_area = frame->first_clickable_area;
	current_named_location = frame->first_named_location;
	current_link = 0;

	frame_w = frame->frame.w;

	if (current_paragraph == 0)
		return (0);

	current_line_width = current_table->table_width;
			
	switch (current_table->alignment)
	{
		case center:
			left_border = (frame_w - current_line_width) / 2;
			break;
		case right:
			left_border = (frame_w - current_line_width) - 2;
			break;
		case left:
			left_border = 3;
			break;
		default: /* just assume it's left */
			left_border = 3;
	}

	left_border += frame->clip.x;

	if (current_table->border)
		left_border -= 1;

	left_border += 1;

	temp_left = left_border;
	
	while (current_child != 0)
	{
		/* first walk the paragraphs */

		current_paragraph = current_child->item ;
		current_word = current_paragraph->item;

		current_child->height = 0;

		while (current_paragraph != 0)
		{
			current_paragraph->current_paragraph_height = 0;

			current_word = current_paragraph->item;
		
			/* hr = horizontal ruler */
			if (current_paragraph->paragraph_code == hr)
			{
				current_child->width = current_word->word_width;

				current_paragraph->current_paragraph_height = abs (current_word->word_height) + 20;
	
				current_paragraph->area.x = current_paragraph->left_border + left_border;
				current_paragraph->area.y = (WORD)current_height;
				current_paragraph->area.w = current_word->word_width;
				current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

				current_child->height = current_paragraph->current_paragraph_height;

/*				temp_height += current_paragraph->current_paragraph_height;
*/
				temp_left += current_word->word_width;
				
				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}
			else if (current_paragraph->paragraph_code == img)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 */

				if (current_child->width == 0)
					current_child->width = current_word->word_width;

				current_paragraph->current_paragraph_height = abs (current_word->word_height);

				current_paragraph->area.x = current_paragraph->left_border + left_border;

				current_paragraph->area.y = (WORD)current_height + temp_height;
				current_paragraph->area.w = current_word->word_width;
				current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

				current_child->height += current_paragraph->current_paragraph_height;


/*				temp_height += current_paragraph->current_paragraph_height;
*/
				temp_left += current_word->word_width;

				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}
			else if (current_paragraph->paragraph_code == table)
			{
				printf("hit a subtable in table height\r\n");

				current_child->height = current_paragraph->table->table_height;

/*				temp_height += current_paragraph->table->table_height;*/
				temp_left += current_word->word_width;

				current_paragraph = current_paragraph->next_paragraph;
				continue;
			}

			left_indent = current_paragraph->left_border + left_border + temp_left;
			right_indent = current_paragraph->right_border; /* + right_border;*/

			/* Now walk the words */
			while (current_word != 0)
			{
				current_line_width = 0;
				line_start = current_word;
				line_height = 0;
				line_tail = 0;
				clickable_area_exists = false;

	
#if 0

		v_ftext16 (vdi_handle, 10, 10, current_word->item);

		vswr_mode(vdi_handle,1);
		v_ftext16 (vdi_handle, 10, current_height + 30, current_word->item);
#endif


				while (current_word != 0 
			       && (current_line_width + current_word->word_width) < (table_w))/* - left_indent - right_indent))*/
				{
					if (current_word->word_code == br && current_word != line_start)
						break;

					current_line_width += current_word->word_width;

					if (line_height < current_word->word_height)
						line_height = current_word->word_height;
					if (line_tail < current_word->word_tail_drop)
						line_tail = current_word->word_tail_drop;
					if (current_word->link != 0)
					{
						if (current_word->link->mode == href)
						{
							clickable_area_exists = true;

							if (current_link != 0 && current_word->link == 0)
							{
								current_link = 0;
							}
							else if (current_link == 0 && current_word->link != 0)
							{
								current_link = current_word->link;
	
								if (frame->first_clickable_area == 0)
								{
									current_clickable_area = frame->first_clickable_area = new_clickable_area();
								}
								else
								{
									if (current_clickable_area->next_area == 0)
										current_clickable_area->next_area = new_clickable_area();
									current_clickable_area = current_clickable_area->next_area;
								}
	
								current_clickable_area->x = left_border + current_line_width + alignment_spacer + temp_left;
/*								current_clickable_area->x = current_line_width + alignment_spacer;*/
								current_clickable_area->y = (WORD)(current_height + current_paragraph->current_paragraph_height)+(WORD)top;
								current_clickable_area->h =	line_height + line_tail;
								current_clickable_area->w = current_word->word_width;
								current_clickable_area->link = current_link;
							}
							else if (current_link == current_word->link)
								current_clickable_area->w += current_word->word_width;
							else if (current_link != 0  && current_word->link != 0)
							{
								if (current_clickable_area->next_area == 0)
									current_clickable_area->next_area = new_clickable_area ();
	
								current_clickable_area = current_clickable_area->next_area;
								current_link = current_word->link;
	
								if (current_clickable_area == 0)
									current_clickable_area = new_clickable_area ();

								current_clickable_area->x = left_border + current_line_width + alignment_spacer + temp_left;
							
/*								current_clickable_area->y = (WORD)(current_height + current_paragraph->current_paragraph_height) + (WORD)top;*/
								current_clickable_area->y = (WORD)(current_height) + current_child->height + (WORD)top;
								
								current_clickable_area->h = line_height + line_tail;
								current_clickable_area->w = current_word->word_width;
								current_clickable_area->link = current_link;
							}
						}
						else
						{
							if (frame->first_named_location == 0)
							{
								current_named_location = frame->first_named_location = 	new_named_location ();
								current_named_location->link = current_word->link;
								current_named_location->position = current_height + current_paragraph->current_paragraph_height + temp_height;
							}
							else
							{
								if (current_named_location->link != current_word->link)
								{
									if (current_named_location->next_location == 0)
										current_named_location->next_location = new_named_location();

									current_named_location = current_named_location->next_location;
									current_named_location->link = current_word->link;
									current_named_location->position = current_height + current_paragraph->current_paragraph_height + temp_height;
								}
							}
						}
					}

					current_word = current_word->next_word;
				}


				current_paragraph->current_paragraph_height += line_height + line_tail;		
			}

			temp_height += current_paragraph->current_paragraph_height;

			current_paragraph->left_border = (temp_left - left_border);
			
			/* we need to set the y here or it gets modified */
			current_paragraph->area.y = (WORD)current_height + current_child->height;

/*			if (temp_cols >= current_table->num_cols)
			{
*/
				if (current_paragraph->eop_space > 0)
					current_paragraph->current_paragraph_height += current_paragraph->eop_space;
				else
					current_height += current_paragraph->eop_space;
/*			}
*/			
			current_paragraph->area.x = current_paragraph->left_border;
			current_paragraph->area.w = current_line_width;
			current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

/*printf("area.w = %d  \r\n",current_line_width);		*/

			/* only advance height if we have finished a row */

			current_child->height += current_paragraph->current_paragraph_height;		

/*			if (current_paragraph->current_paragraph_height > temp_row_height)
			{
				temp_height = current_paragraph->current_paragraph_height;
				temp_row_height = current_paragraph->current_paragraph_height;
			}
*/
			temp_left += current_line_width;
		
			current_paragraph = current_paragraph->next_paragraph;
		}

		if (current_child->height > temp_row_height)
			temp_row_height = current_child->height;

		temp_cols = temp_cols + current_child->colspan;

		if (temp_cols >= current_table->num_cols)
		{
			temp_cols = 0;
			current_height += temp_row_height;

			temp_height = 0;
			temp_row_height = 0;
			temp_left = left_border;
		}
				
		current_child = current_child->next_child;
	}

	/* Ok now resort the whole mess, could probably be done better, but I'm mentally exhausted - baldrick 11/27/01 */

	temp_cols = 0;

	current_child = current_table->children;
	current_paragraph = current_child->item;
	
	while (current_child != 0)
	{
		/* first walk the paragraphs */
		current_paragraph = current_child->item ;
	
		temp_left = 0;

		for (i = 0; i < temp_cols; i++)
			temp_left += current_table->col_widths[i];

		while (current_paragraph != 0)
		{
			current_paragraph->left_border = temp_left;
			current_paragraph->area.x = current_paragraph->left_border;

			current_paragraph = current_paragraph->next_paragraph;
		}

		temp_cols = temp_cols + current_child->colspan;

		if (temp_cols >= current_table->num_cols)
		{			
			temp_cols = 0;
		}
		
		current_child = current_child->next_child;
	}

	return (current_height);
}



/*
Ok here is the idea maybe to try.  what if we walked the rows and 
columns instead of the linked list
*/
