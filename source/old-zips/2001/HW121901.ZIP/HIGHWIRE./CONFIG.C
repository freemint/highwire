/*
 * Config.C
 *
 * ripped and modified from Qdialer.  Simply opens a file
 * and parses it out for recongized strings and their
 * values
 */

#include <stdlib.h> /* for atoi etc */

#include "global.h"

#include "ctype.h"  /* for toupper */

/* compare to strings
 */
 
WORD equ_txtn(char *s1, char *s2, WORD n)
{
    while (n--)
    {
        if (toupper(*s1) != toupper(*s2))
        {
            return (false);
        }
        
        if (*s1 == '\0')
            break;

        s1 += 1;
        s2 += 1;
    }
    return (true);
}

/* get a value from a variable 
 */
 
static char *getval(char *s)
{
	char *ptr;

	while (  *s != ' '
		  && *s != '\t'
		  && *s != '='
		  && *s
	)
		++s;

	while (*s && (*s == ' ' || *s == '\t' || *s == '='))
		*s++ = '\0';

	if (*s == '\0' || *s == '\r' || *s == '\n')
		return ((char *)NULL);

	ptr = s;

	while (*s && *s != '\r' && *s != '\n')
		++s;

	*s = '\0';

	return (ptr);
}

/* Read the config file and process any variables
 */
 
WORD
read_config(char *fn)
{
	char l[100], *n, *p;
	FILE *fp;

	fp = fopen(fn, "r");

	if (fp == (FILE *)NULL) 
	{
		/* probably should alert the user */
		return (-1);
	}

	while (fgets(l, (int)100,  fp) != (char *)NULL) 
	{
		if (!isalpha(l[0]))
			continue;

		n = l;
		p = getval(l);

		if (p == (char *)NULL)
			p = "";
	 
		if (equ_txtn(n, "NORMAL", 6))
		{
			fonts[normal_font][0][0] = atoi(p);
		}
		else if (equ_txtn(n, "ITALIC_NORMAL", 13))
		{
			fonts[normal_font][0][1] = atoi(p);
		}
		else if (equ_txtn(n, "BOLD_NORMAL", 11))
		{
			fonts[normal_font][1][0] = atoi(p);
		}
		else if (equ_txtn(n, "BOLD_ITALIC_NORMAL", 18))
		{
			fonts[normal_font][1][1] = atoi(p);
		}
		else if (equ_txtn(n, "HEADER", 6))
		{
			fonts[header_font][0][0] = atoi(p);
		}
		else if (equ_txtn(n, "ITALIC_HEADER", 13))
		{
			fonts[header_font][0][1] = atoi(p);
		}
		else if (equ_txtn(n, "BOLD_HEADER", 11))
		{
			fonts[header_font][1][0] = atoi(p);
		}
		else if (equ_txtn(n, "BOLD_ITALIC_HEADER", 18))
		{
			fonts[header_font][1][1] = atoi(p);
		}
		else if (equ_txtn(n, "TELETYPE", 8))
		{
			fonts[pre_font][0][0] = atoi(p);
		}
		else if (equ_txtn(n, "ITALIC_TELETYPE", 15))
		{
			fonts[pre_font][0][1] = atoi(p);
		}
		else if (equ_txtn(n, "BOLD_TELETYPE", 13))
		{
			fonts[pre_font][1][0] = atoi(p);
		}
		else if (equ_txtn(n, "BOLD_ITALIC_TELETYPE", 20))
		{
			fonts[pre_font][1][1] = atoi(p);
		}
	}

	fclose(fp);

	return (1);
}
