
#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

void
destroy_table_structure (struct table_item *current_table)
{
	struct table_child *temp_child;
	struct table_child *current_child;
	struct paragraph_item *current_paragraph;
	
	current_child = current_table->children;
	
	while (current_child != 0)
	{
		current_paragraph = current_child->item;

		destroy_paragraph_structure (current_paragraph);

		temp_child = current_child->next_child;
		free(current_child);
		current_child = temp_child;
	}
	
	free(current_table);
}


struct table_child *
new_table_child (void)
{
	struct table_child *temp;
	
	temp = malloc (sizeof (struct table_child));

	temp->height = 0;
	temp->width = 0;
	temp->alignment = left;
	temp->valignment = bottom;
	temp->colspan = 1;
	temp->rowspan = 1;
	temp->bgcolor = 0;
	temp->item = new_paragraph();
	temp->next_child = 0;
	
	return (temp);
}

struct table_item *
new_table (void)
{
	struct table_item *temp;
	temp = malloc (sizeof (struct table_item));

	temp->num_cols = 0;
	temp->num_rows = 0;
	temp->table_height = 0;
	temp->table_width = 0;
	temp->alignment = left;
	temp->border = 0;
	temp->cell_spacing = 0;
	temp->cell_padding = 0;
	temp->num_children = 0;
	temp->children = new_table_child();
	
	return (temp);
}

/*
 * determines the height of a table by walking it's paragraph list
 */

long
calculate_table_height (struct table_item *current_table)
{
	struct paragraph_item *current_paragraph;
	struct paragraph_item *table_paragraph;
	struct table_child *current_child;
	struct word_item *current_word, *line_start, *line_end;
	struct url_link *current_link;
	struct clickable_area *current_clickable_area;
	struct named_location *current_named_location;
	WORD left_indent, right_indent, current_line_width, line_tail = 0, line_height;
	WORD alignment_spacer, height_spacer, table_w;
	WORD previous_word_height = 0;
	long current_height = 0L;
	enum bool clickable_area_exists = false;

	WORD left_border = 0, bottom_border = 0, right_border = 0;

	current_paragraph = current_table->children->item;
	table_w = current_table->table_width;

	if (current_paragraph == 0)
		return (0);

	current_word = current_paragraph->item;

	/* first walk the paragraphs */
	
	while (current_paragraph != 0)
	{
		current_paragraph->current_paragraph_height = 0;
		current_word = current_paragraph->item;
		
/*printf("current_height = %ld            \r\n",current_height);
*/
		/* hr = horizontal ruler */
		if (current_paragraph->paragraph_code == hr)
		{
			current_paragraph->current_paragraph_height = abs (current_word->word_height) + 20;

			current_paragraph->area.x = current_paragraph->left_border;
			current_paragraph->area.y = (WORD)current_height;
			current_paragraph->area.w = current_word->word_width;
			current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

			current_height += current_paragraph->current_paragraph_height;
			current_paragraph = current_paragraph->next_paragraph;
			continue;
		}
		else if (current_paragraph->paragraph_code == img)
		{
			/* you might think that we should add the objects
			 * height as we process it in this section...
			 *
			 * However with tests this just adds junk to the bottom
			 * of the file and messes up all the link locations
			 *
			 * baldrick August 30, 2001
			 */

#if 0			 
			current_line_width = current_word->word_width;

			/* do the vertical offset */
			switch (current_paragraph->eop_space)
			{
				case center:
					left_border = 0;
					right_border = 0;
					break;
				case right:
					left_border = 0;
					right_border = current_line_width + 2;
					break;
				case left:
					left_border = current_line_width;
					right_border = 0;
					break;
				default: /* just assume it's centered, should be left */
					left_border = 0;
					right_border = 0;
			}

/*			bottom_border = current_height + abs(current_word->word_height);
*/
#endif
			current_paragraph->current_paragraph_height = abs (current_word->word_height);

			current_paragraph->area.x = current_paragraph->left_border;
			current_paragraph->area.y = (WORD)current_height;
			current_paragraph->area.w = current_word->word_width;
			current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

			current_height += current_paragraph->current_paragraph_height;
			current_paragraph = current_paragraph->next_paragraph;
			continue;
		}
		else if (current_paragraph->paragraph_code == table)
		{
			printf("hit a subtable\r\n");
			current_height += current_paragraph->table->table_height;
			current_paragraph = current_paragraph->next_paragraph;
			continue;
		}

		left_indent = current_paragraph->left_border;
		right_indent = current_paragraph->right_border;

#if 0
		left_indent = current_paragraph->left_border + left_border; /* baldrick August 28, 2001 modified to offset for pics */
		right_indent = current_paragraph->right_border + right_border;
#endif
		/* Now walk the words */
		while (current_word != 0)
		{
			current_line_width = 0;
			line_start = current_word;
			line_height = 0;
			line_tail = 0;
			clickable_area_exists = false;

#if 0

		v_ftext16 (vdi_handle, 10, 10, current_word->item);

#endif

			while (current_word != 0
		       && (current_line_width + current_word->word_width) < (table_w - left_indent - right_indent))
			{
				if (current_word->word_code == br && current_word != line_start)
					break;

				current_line_width += current_word->word_width;

				if (line_height < current_word->word_height)
					line_height = current_word->word_height;
				if (line_tail < current_word->word_tail_drop)
					line_tail = current_word->word_tail_drop;

				current_word = current_word->next_word;
			}

			current_paragraph->current_paragraph_height += line_height + line_tail;		
		}

		/* we need to set the y here or it gets modified */
		current_paragraph->area.y = (WORD)current_height;

		if (current_paragraph->eop_space > 0)
			current_paragraph->current_paragraph_height += current_paragraph->eop_space;
		else
			current_height += current_paragraph->eop_space;

		current_paragraph->area.x = current_paragraph->left_border;
		current_paragraph->area.w = current_line_width;
		current_paragraph->area.h = (WORD)(current_paragraph->current_paragraph_height);

		current_height += current_paragraph->current_paragraph_height;
		current_paragraph = current_paragraph->next_paragraph;
	}
	return (current_height);
}
