#include <stdio.h>
#include <vdi.h>

#include "global.h"


void
debug(char *output)
{
	vst_charmap(vdi_handle,1);
	vswr_mode(vdi_handle,1);
	v_ftext(vdi_handle,30,50,output);
	vswr_mode(vdi_handle,2);
	vst_charmap(vdi_handle,0);
}

void i_debug(WORD output)
{
	char out[7];
	
#ifdef __PUREC__
	sprintf(out,"%d",output);
#else
	stci_d(out,output);
#endif
	debug(out);
}