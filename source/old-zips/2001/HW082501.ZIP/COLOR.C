#include <stdlib.h>
#include <string.h>

#ifdef LATTICE
#include <aes.h>
#endif

#ifdef __PUREC__
#include <aes.h>
#include "vdicol.h"
#endif /* end PUREC */

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

#ifndef LATTICE
#include "stptok.h"
#endif

#include <ctype.h>

RGB1000 screen_colortab[256]; /* used to save colors */


/* Saves colors in global array screen_colortab[] 
 *
 * Really for us this should be loading the standard palette
 * I'm just grabbing whatever the system has set
 */
void
save_colors(void)
{
	int i;
	int coltab[3];
	int res_colors;
	
	res_colors = (1 << planes); /* Doesn't work in truecolor modes, only planar */
  
	if (planes > 8)
  		res_colors = 256;
 
	for (i=0;i<res_colors;i++)
	{
		vq_color(vdi_handle,i,0,coltab);

		screen_colortab[i].red = coltab[0];
		screen_colortab[i].green = coltab[1];
		screen_colortab[i].blue = coltab[2];			
	}
}

int 
remap_color(RGB1000 *color)
{
	int ii = 0;
	int hit_color = 0;
	RGB1000 best; /* used to temp hold the difference best color match */
	int best_no;   /* color index for best match */
	int res_colors = (1 << planes); /* Doesn't work in truecolor modes, only planar */
  
	if (planes > 8)
		res_colors = 256;

  	
/*printf("image red %d green %d blue %d\r\n",color->red,color->green,color->blue);
*/
	do
  	{
  		if ((color->red == screen_colortab[ii].red)&&
			(color->green == screen_colortab[ii].green)&&
			(color->blue == screen_colortab[ii].blue))
			{
				best_no = ii;
				hit_color = 1;
				break;
			}
				
		ii++;
  	}while(ii < res_colors);
	
	/* We didn't get an exact match, so approximate */
  	if(hit_color == 0)
  	{
		/* set best color match to 0*/
		best_no = 0;

		/* set initial differences to 1000, ensures that initial value is worst possible */
		best.red = 1000;
		best.green = 1000;
		best.blue = 1000;

		ii = 0;

		do
	  	{

			if (color->red > screen_colortab[ii].red)
			{
				if((color->red - screen_colortab[ii].red) <= best.red)
				{
					if (color->green > screen_colortab[ii].green)
					{
						if((color->green - screen_colortab[ii].green) <= best.green)
						{
							if (color->blue > screen_colortab[ii].blue)
							{
								if((color->blue - screen_colortab[ii].blue) <= best.blue)
								{
									best_no = ii;
									best.red = (color->red - screen_colortab[ii].red);
									best.green = (color->green - screen_colortab[ii].green);
									best.blue = (color->blue - screen_colortab[ii].blue);
								}
							}
							else
							{
								if((screen_colortab[ii].blue - color->blue) <= best.blue)
								{
									best_no = ii;
									best.red = (color->red - screen_colortab[ii].red);
									best.green = (color->green - screen_colortab[ii].green);
									best.blue = (screen_colortab[ii].blue - color->blue);
								}							
							}
						}
					}
					else
					{
						if((screen_colortab[ii].green - color->green) <= best.green)
						{
							if (color->blue > screen_colortab[ii].blue)
							{
								if((color->blue - screen_colortab[ii].blue) <= best.blue)
								{
									best_no = ii;
									best.red = (color->red - screen_colortab[ii].red);
									best.green = (screen_colortab[ii].green - color->green);
									best.blue = (color->blue - screen_colortab[ii].blue);
								}
							}
							else
							{
								if((screen_colortab[ii].blue - color->blue) <= best.blue)
								{
									best_no = ii;
									best.red = (color->red - screen_colortab[ii].red);
									best.green = (screen_colortab[ii].green - color->green);
									best.blue = (screen_colortab[ii].blue - color->blue);
								}							
							}
						}
					}
				}

			}
			else
			{
				if((screen_colortab[ii].red - color->red) <= best.red)
				{
					if (color->green > screen_colortab[ii].green)
					{
						if((color->green - screen_colortab[ii].green) <= best.green)
						{
							if (color->blue > screen_colortab[ii].blue)
							{
								if((color->blue - screen_colortab[ii].blue) <= best.blue)
								{
									best_no = ii;
									best.red = (screen_colortab[ii].red - color->red);
									best.green = (color->green - screen_colortab[ii].green);
									best.blue = (color->blue - screen_colortab[ii].blue);
								}
							}
							else
							{
								if((screen_colortab[ii].blue - color->blue) <= best.blue)
								{
									best_no = ii;
									best.red = (screen_colortab[ii].red - color->red);
									best.green = (color->green - screen_colortab[ii].green);
									best.blue = (screen_colortab[ii].blue - color->blue);
								}							
							}
						}
					}
					else
					{
						if((screen_colortab[ii].green - color->green) <= best.green)
						{
							if (color->blue > screen_colortab[ii].blue)
							{
								if((color->blue - screen_colortab[ii].blue) <= best.blue)
								{
									best_no = ii;
									best.red = (screen_colortab[ii].red - color->red);
									best.green = (screen_colortab[ii].green - color->green);
									best.blue = (color->blue - screen_colortab[ii].blue);
								}
							}
							else
							{
								if((screen_colortab[ii].blue - color->blue) <= best.blue)
								{
									best_no = ii;
									best.red = (screen_colortab[ii].red - color->red);
									best.green = (screen_colortab[ii].green - color->green);
									best.blue = (screen_colortab[ii].blue - color->blue);
								}							
							}
						}
					}
				}
			}

			ii++;
	  	}while(ii < res_colors);		

  	}	

/*printf("best red %d green %d blue %d\r\n",screen_colortab[best_no].red,screen_colortab[best_no].green,screen_colortab[best_no].blue);
*/
  return( best_no);
}


/**
 * Convert a hexadecimal digit into its corresponding decimal value.
 *
 * @param hex The hexadecimal digit.
 *
 * @return the decimal value.
 */
static int parse_convert_hex(char hex)
{
  if(hex >= '0' && hex <= '9')
    return hex - '0';
  if(hex >= 'a' && hex <= 'f')
    return hex - 'a' + 10;

  return 0;
}

/**
 * Converts a string in the form #rrggbb into a 24-bit colour value.
 * Later, this will also handle named colours.
 *
 * @param colour A string containing the colour code.
 *
 * @return a VDI color index
 *
 * originally kidnapped and changed from zen() with modifications since our
 * offset coming in is not equal to their offset.
 */
int
parse_convert_colour(char *colour)
{
	RGB1000 real_colour;
	int vdi_idx;
	
	real_colour.red = parse_convert_hex(tolower((int)colour[0])) * 16 +
		parse_convert_hex(tolower((int)colour[1]));
	real_colour.green = parse_convert_hex(tolower((int)colour[2])) * 16 +
		parse_convert_hex(tolower((int)colour[3]));
	real_colour.blue = parse_convert_hex(tolower((int)colour[4])) * 16 +
		parse_convert_hex(tolower((int)colour[5]));

	real_colour.red = (real_colour.red << 2);
	real_colour.green = (real_colour.green << 2);
	real_colour.blue = (real_colour.blue << 2);

	if (real_colour.red > 1000)
		real_colour.red = 1000;

	if (real_colour.green > 1000)
		real_colour.green = 1000;
		
	if (real_colour.blue > 1000)
		real_colour.blue = 1000;

	vdi_idx = remap_color(&real_colour);
	
	return vdi_idx;
}

