/* This file should contain the keyboard handler
 * routines.  ie. Input to forms, URL address etc
 *
 * right now it just handles hot key for UNDO - back up a page 
 * baldrick July 10, 2001
 */


#include <stdlib.h>
#include <string.h>

#ifdef __PUREC__
#include <aes.h>
#endif /* end PUREC */

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

#include <stdio.h>

void
key_pressed (struct frame_item *first_frame, WORD key)
{
	struct frame_item *current_frame;

	extern char prev_location[128];
	
/*	printf("key = %d\r\n",key);
*/

	current_frame = first_frame;

/*
	Doesn't handle forms yet so just skip down to hotkeys

	while (current_frame != 0)
	{
		if (mx < current_frame->clip.x + current_frame->clip.w + scroll_bar_width
		    && mx > current_frame->clip.x
		    && my < current_frame->clip.y + current_frame->clip.h + scroll_bar_width
		    && my > current_frame->clip.y)
		{
			frame_clicked (first_frame, current_frame, mx, my);
			return;
		}
		current_frame = current_frame->next_frame;
	}
*/

	/* nothing else so process hotkeys */
	
	switch (key)
	{
		case 24832: /* UNDO */
			add_load_item_to_to_do_list (0, prev_location, first_frame,0,0,-100,-100, (WORD)current_frame->border); /* baldrick Aug 3, 01 added 0,0 should be changed to real frame locations */
			break;
		default:
			break;
	}
	
	key = 0;
}


