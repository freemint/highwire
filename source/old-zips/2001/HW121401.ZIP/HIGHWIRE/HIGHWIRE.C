#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#include <aes.h>
#include <vdi.h>
#endif /* end PUREC */

#ifdef LATTICE
#include <mintbind.h>
#include <vdi.h>
#include <aes.h>
#endif

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

#include <stdio.h>

VDI_Workstation dev;

WORD planes;

int
main (int argc, char **argv)
{
	WORD u, x, y, w, h, result, mx, my, key = 0;
	enum bool exit = false;

	int vwork_out[57], numSets, id;


#ifdef USE_LIBWWW
	char def_address[] = "http://wh58-508.st.uni-magdeburg.de/sparemint/index.html";
#else
	char def_address[]="highwire.htm";
/*	char def_address[]="Excerpt.htm#testpoint1";*/
#endif

	char *address, name[], name2[]="Dies ist ein langer Text";

	if (argc > 1)
		address = argv[1];
	else
		address = def_address;

	/* handle network layer startup */
	
	if (!init_netlayer())
		return(0);

	app_id = appl_init ();
	vdi_handle = V_Opnvwk (&dev);

	vq_extnd(vdi_handle, 1, vwork_out);
	planes = vwork_out[4];
	
	if (planes < 2) /* monochrome ? */
	{
		/* set the scroller widget colors for monochrome */
		slider_bkg = 0;
		slider_col = 0;
	}
	
	Pdomain(1);

	/* grab the screen colors for later use */
	save_colors();

	wind_get (DESK, WF_WORKXYWH, &x, &y, &w, &h);
	window_handle = wind_create (NAME + CLOSER + FULLER + MOVER + SMALLER + SIZER + INFO, x, y, w, h);
	wind_set (window_handle, WF_INFO, address);
	wind_set (window_handle, WF_BEVENT, 1, 0, 0, 0);

	/* init paths and load config */
	init_paths();

	numSets=vst_load_fonts (vdi_handle, 0);

	vst_scratch (vdi_handle, SCRATCH_BOTH);
	vst_kern (vdi_handle, TRACK_NORMAL, PAIR_ON, &u, &u);
	vswr_mode (vdi_handle, MD_TRANS);
	
	vst_font (vdi_handle, fonts[0][0][0]);
	vst_charmap (vdi_handle, 0); /* 0 = Bitstream mapping 1 = Atari Ascii mapping */

#if 0
I disabled this and left the old in place since this didn't really work yet

    id = vqt_name(vdi_handle, 2, name );        /* 2. Zeichensatz  */
    vst_font( vdi_handle, id );                 /* ausw�hlen       */
    v_gtext( vdi_handle, 100, 100, name2 );      /* benutzen   */
#endif

	init_load(address);

	while (exit != true)
	{
		check_to_do_list ();

		result = evnt_multi (MU_MESAG + MU_BUTTON + MU_TIMER + MU_KEYBD, /*MU_BUTTON,MU_M1,MU_M2,MU_MESAG,MU_TIMER*/
				     1, 1, 1,	/*MOUSE - 1 click,left button,left button */
				     0, 0, 0, 0, 0,	/*M1 */
				     0, 0, 0, 0, 0,	/*M2 */
				     event_messages,	/*Returned messages */
#ifdef __GNUC__
				     100,	/* Timer */
#else
					 100, 0, /* Timer */
#endif
				     &mx, &my, &u, &u, &key, &u	/* returned mouse and keyboard states */
			);
		if (result & MU_MESAG)
			exit = process_messages (first_frame);
		if (result & MU_BUTTON)
			button_clicked (first_frame, mx, my);
		if (result & MU_TIMER)
			check_mouse_position (first_frame, mx, my);
		if (result & MU_KEYBD)
			key_pressed(first_frame,key);
	}

	/* 10-04-01 mj: moved exit part to a function (highwire_ex) for keyinput */
	highwire_ex();

	return 0;
}

void
highwire_ex(void) 
{
	wind_close (window_handle);
	wind_delete (window_handle);

	destroy_frame_structure (first_frame);

	vst_unload_fonts (vdi_handle, 0);
	appl_exit ();

	close_netlayer();
	exit(0);
}
