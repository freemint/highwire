#include <stdlib.h>

#ifdef __PUREC__
#include <aes.h>
#include <vdi.h>
#endif /* end PUREC */

#ifdef LATTICE
#include <mintbind.h>
#include <vdi.h>
#include <aes.h>
#endif

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

#include <stdio.h>

VDI_Workstation dev;

WORD planes;

int
main (int argc, char **argv)
{
	WORD u, x, y, w, h, result, mx, my, key = 0;
	enum bool exit = false;

	int vwork_out[57];


#ifdef USE_LIBWWW
	char def_address[] = "http://wh58-508.st.uni-magdeburg.de/sparemint/index.html";
#else
	char def_address[]="Excerpt.htm#testpoint1";
#endif

	char *address;

	if (argc > 1)
		address = argv[1];
	else
		address = def_address;

	/* handle network layer startup */
	
	if (!init_netlayer())
		return(0);

	app_id = appl_init ();
	vdi_handle = V_Opnvwk (&dev);

	vq_extnd(vdi_handle, 1, vwork_out);
	planes = vwork_out[4];

	/* grab the screen colors for later use */
	save_colors();

	wind_get (DESK, WF_WORKXYWH, &x, &y, &w, &h);
	window_handle = wind_create (NAME + CLOSER + FULLER + MOVER + SMALLER + SIZER, x, y, w, h);
	wind_set (window_handle, WF_BEVENT, 1, 0, 0, 0);

	/* init paths and load config */
	init_paths();

	vst_load_fonts (vdi_handle, 0);

	vst_scratch (vdi_handle, SCRATCH_BOTH);
	vst_kern (vdi_handle, TRACK_NORMAL, PAIR_ON, &u, &u);
	vswr_mode (vdi_handle, MD_TRANS);
	vst_font (vdi_handle, fonts[0][0][0]);
	vst_charmap (vdi_handle, 0); /* 0 = Bitstream mapping 1 = Atari Ascii mapping */

	init_load(address);

	while (exit != true)
	{
		check_to_do_list ();

		result = evnt_multi (MU_MESAG + MU_BUTTON + MU_TIMER + MU_KEYBD, /*MU_BUTTON,MU_M1,MU_M2,MU_MESAG,MU_TIMER*/
				     1, 1, 1,	/*MOUSE - 1 click,left button,left button */
				     0, 0, 0, 0, 0,	/*M1 */
				     0, 0, 0, 0, 0,	/*M2 */
				     event_messages,	/*Returned messages */
#ifdef __GNUC__
				     100,	/* Timer */
#else
					 100, 0, /* Timer */
#endif
				     &mx, &my, &u, &u, &key, &u	/* returned mouse and keyboard states */
			);
		if (result & MU_MESAG)
			exit = process_messages (first_frame);
		if (result & MU_BUTTON)
			button_clicked (first_frame, mx, my);
		if (result & MU_TIMER)
			check_mouse_position (first_frame, mx, my);
		if (result & MU_KEYBD)
			key_pressed(first_frame,key);
	}

	wind_close (window_handle);
	wind_delete (window_handle);

	destroy_frame_structure (first_frame);

	vst_unload_fonts (vdi_handle, 0);
	appl_exit ();

	close_netlayer();

	return 0;
}
