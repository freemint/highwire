#include <stdlib.h>

#ifdef __GNUC__

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <unistd.h>

#include <gemx.h>
#endif

#ifdef USE_LIBWWW
#include <w3c-libwww/wwwconf.h>
#include <w3c-libwww/WWWLib.h>
#include <w3c-libwww/WWWHTTP.h>
#include <w3c-libwww/WWWInit.h>
#endif

#include "global.h"


/*
 * init_netlayer
 *
 * currently
 *
 * handles stack specific start ups
 *
 * future
 *
 * handle stack module startup and initilization
 *
 * Baldrick - feb 28, 2001
 */
 

WORD
init_netlayer(void)
{
#ifdef USE_LIBWWW
	HTProfile_newPreemptiveClient ("Highwire", "0.0");
#endif

	return(1);
}

/*
 * close_netlayer
 *
 * currently
 *
 * handles stack specific exits
 *
 * future
 *
 * handle stack module cleanup and exit
 *
 * Baldrick - feb 28, 2001
 */
 

WORD
close_netlayer(void)
{
#ifdef USE_LIBWWW
	HTProfile_delete ();
#endif

	return(1);
}

/*
 * request_URI
 *
 * currently
 *
 * handles stack specific network transmission routines
 *
 * future
 *
 * handle stack module startup of transmission
 *
 * Baldrick - feb 28, 2001
 */
 

WORD
request_URI(const char *filename)
{
#ifdef USE_LIBWWW
	const char *url = filename;

	HTRequest *req;

	fprintf (stderr, "Try getting the URL\n");

	req = HTRequest_new ();
	if (req)
	{
		HTChunk *chunk;

		char *cwd;
		char *absolute_url;

		/* we want only the body */
		HTRequest_setOutputFormat (req, WWW_SOURCE);

		/* close connection immediately */
		HTRequest_addConnection (req, "close", "");

		cwd = HTGetCurrentDirectoryURL ();
		absolute_url = HTParse (url, cwd, PARSE_ALL);

		chunk = HTLoadToChunk (absolute_url, req);

		HT_FREE (absolute_url);
		HT_FREE (cwd);

		if (chunk)
			file = HTChunk_toCString (chunk);
		else
		{
			HTList *errs = HTRequest_error (req);
			HTError *err;
			fprintf (stderr, "HTLoadToChunk failed!\n");

			err = HTList_nextObject (errs);
			while (err)
			{
				const char *s = HTError_location (err);
				int x = HTError_severity (err);
				int index = HTError_index (err);

				fprintf (stderr, "%s: %i, %i\n", s, x, index);
				err = HTList_nextObject (errs);
			}
		}

		HTRequest_delete (req);
	}
	else
		fprintf (stderr, "HTRequest_new failed!\n");
#endif

	return(1);
}