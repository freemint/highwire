/* @(#)highwire/Location.h
 */
#ifndef __LOCATION_H__
#define __LOCATION_H__


struct s_location {
	unsigned __reffs;
	ENCODING encoding;
	BOOL     isTos;
	char   * File;
	char   * Path;
	char   * Anchor;
	char     FullName[4];
};


LOCATION new_location  (const char * src, LOCATION base);
void     free_location (LOCATION *);

LOCATION location_share  (LOCATION);



#endif /*__LOCATION_H__*/
