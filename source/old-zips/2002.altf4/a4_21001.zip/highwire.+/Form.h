#ifndef __FORM_H__
#define __FORM_H__


void * new_input (FRAME);
void input_draw   (void*, WORD x, WORD y);
BOOL input_isEdit (void*);



struct s_form_stack {
	FORM    form;
	struct font_style  SavedStyles;
	struct font_step * SavedFntStp;
	H_ALIGN            SavedAlign;
	short              Backgnd;
	FRMSTACK Previous;
	char _debug;
};

struct s_form {
	PARAGRPH Paragraph;
	FORM_METHOD f_method;		/* get, post, put... */
	char * action;				/* form processing agent */
	ENCODING accept_charset;
	FORM next;					/* next form for frame->FormList */
};


PARAGRPH form_start  (FRAME);
void     form_finish (FRAME);


#endif /* __FORM_H__ */
