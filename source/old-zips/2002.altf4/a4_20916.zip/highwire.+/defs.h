/* @(#)highwire/defs.h
 */
#define _HIGHWIRE_MAJOR_     0
#define _HIGHWIRE_MINOR_ /* 09 */ 9
#define _HIGHWIRE_REVISION_  0
#define _HIGHWIRE_BETATAG_   "alpha"
#define _HIGHWIRE_VERSION_   "0.09"


/* ******* Type Definitions ********* */

typedef enum { FALSE = (1!=1), TRUE = (1==1) } BOOL;

typedef enum {
	ENCODING_Unknown = 0,
	ENCODING_WINDOWS1252, ENCODING_ISO8859_2, ENCODING_UTF8, ENCODING_ATARIST
} ENCODING;

typedef enum {
	PAR_NONE = 0, PAR_LI, PAR_IMG, PAR_HR, PAR_TABLE, PAR_FORM
} PARAGRAPH_CODE;

typedef enum {
	ALN_LEFT = 0, ALN_JUSTIFY, ALN_CENTER, ALN_RIGHT,
	ALN_NO_FLT = ALN_JUSTIFY /* justify is impossible for floating */
} H_ALIGN;

typedef enum {
	ALN_TOP = 0, ALN_MIDDLE, ALN_BOTTOM, ALN_BASELINE,
	ALN_ABOVE, ALN_BELOW   /* what are these both for?  Sub & Sup */
} V_ALIGN;

typedef enum {
	BRK_NONE = 0,
	BRK_LN = 0x01, BRK_LEFT = 0x11, BRK_RIGHT = 0x21, BRK_ALL = 0x31
} L_BRK;

typedef enum {
	SCROLL_AUTO = 0, SCROLL_ALWAYS, SCROLL_NEVER
} SCROLL_CODE;

typedef enum {
	METH_GET = 0, METH_POST
} FORM_METHOD;


enum bullets {disc,square,circle,Number,alpha,Alpha,roman,Roman};

typedef enum {
	LANG_CS = ('c' << 8) + 's', 
	LANG_DA = ('d' << 8) + 'a',
	LANG_DE = ('d' << 8) + 'e', 
	LANG_EL = ('e' << 8) + 'l', 
	LANG_EN = ('e' << 8) + 'n', 
	LANG_ES = ('e' << 8) + 's', 
	LANG_FI = ('f' << 8) + 'i', 
	LANG_FR = ('f' << 8) + 'r', 
	LANG_HU = ('h' << 8) + 'u', 
	LANG_IT = ('i' << 8) + 't', 
	LANG_NL = ('n' << 8) + 'l', 
	LANG_NO = ('n' << 8) + 'o', 
	LANG_PL = ('p' << 8) + 'l', 
	LANG_PT = ('p' << 8) + 't', 
	LANG_RU = ('r' << 8) + 'u', 
	LANG_SL = ('s' << 8) + 'l', 
	LANG_SK = ('s' << 8) + 'k', 
	LANG_SV = ('s' << 8) + 'v', 
	LANG_TR = ('t' << 8) + 'r' 
} LANGUAGE;


/***** Forward Declarations *****/
typedef struct s_containr     * CONTAINR;   /* in Containr.h */
typedef struct s_table_stack  * TBLSTACK;   /* in Table.c */
typedef struct s_table        * TABLE;      /* in Table.c */
typedef struct s_form_stack   * FRMSTACK;   /* in Form.c */
typedef struct s_form         * FORM;       /* in Form.c */
typedef struct clickable_area * CLICKABLE;
typedef struct named_location * ANCHOR;
typedef struct paragraph_item * PARAGRPH;
typedef struct word_item      * WORDITEM;
typedef struct s_location     * LOCATION;   /* in Location.h */


#ifndef MagX_cookie
#define 	MagX_cookie		0x4D616758L
#endif

#ifndef AES_single
#define	AES_single	0
#define	AES_MagiC	1
#define	AES_Geneva	2
#define	AES_MTOS	3
#define	AES_nAES	4
#endif

#ifndef ck_entry 
typedef struct {
    long cktag;
    long ckvalue;
} ck_entry;
#endif

#ifndef GLOBAL
#define GLOBAL 0x0020
#define ALLOCMODE 3|GLOBAL
#endif

/* A few data type definitions */

typedef short WORD;
typedef unsigned short UWORD;

/* ********** Consts ************** */
#define Space_Code 561
#define normal_font 0
#define header_font 1
#define pre_font 2
#define scroll_bar_width 15
#define scroll_step 24
#define DOMAIN_MINT 1
#define HW_PATH_MAX 260  /* at least VFAT standard 260 */

#define numberof(arr)   (sizeof(arr) / sizeof(*arr))
						/* calculates the element number of an literally array
						 * at compile time.  doesn't work for pointers! */

#ifdef __PUREC__

#ifndef min
#define min(a, b)             ((a) < (b) ? (a) : (b))
#endif

#ifndef max
#define max(a, b)             ((a) > (b) ? (a) : (b))
#endif

#endif /* end PUREC */

/* ********** Structures ***************** */

typedef struct {
	WORD handle;
	WORD dev_id;
	WORD wchar;
	WORD hchar;
	WORD wbox;
	WORD hbox;
	WORD xres;
	WORD yres;
	WORD noscale;
	WORD xpixel;
	WORD hpixel;
	WORD cheights;
	WORD linetypes;
	WORD linewidths;
	WORD markertypes;
	WORD markersizes;
	WORD faces;
	WORD patterns;
	WORD hatches;
	WORD colours;
	WORD ngdps;
	WORD cangdps[10];
	WORD gdpattr[10];
	WORD cancolour;
	WORD cantextrot;
	WORD canfillarea;
	WORD cancellarray;
	WORD palette;
	WORD locators;
	WORD valuators;
	WORD choicedevs;
	WORD stringdevs;
	WORD wstype;
	WORD minwchar;
	WORD minhchar;
	WORD maxwchar;
	WORD maxhchar;
	WORD minwline;
	WORD zero5;
	WORD maxwline;
	WORD zero7;
	WORD minwmark;
	WORD minhmark;
	WORD maxwmark;
	WORD maxhmark;
	WORD screentype;
	WORD bgcolours;
	WORD textfx;
	WORD canscale;
	WORD planes;
	WORD lut;
	WORD rops;
	WORD cancontourfill;
	WORD textrot;
	WORD writemodes;
	WORD inputmodes;
	WORD textalign;
	WORD inking;
	WORD ruberbanding;
	WORD maxvertices;
	WORD maxintin;
	WORD mousebuttons;
	WORD widestyle;
	WORD widemode;
	WORD reserved[38];
} VDI_Workstation;


/* Modified size to st_size to eliminate one #ifdef in loader.c - Baldrick */
struct xattr {
	UWORD mode;
	long index;
	UWORD dev;
	UWORD reserved1;
	UWORD nlink;
	UWORD uid;
	UWORD gid;
	long st_size;
	long blksize;
	long nblocks;
	WORD mtime;
	WORD mdate;
	WORD atime;
	WORD adate;
	WORD ctime;
	WORD cdate;
	WORD attr;
	WORD reserved2;
	long reserved3;
	long reserved4;
};

/* ************ Parsing Constructs ************************ */

typedef struct long_offset {
	struct long_offset * Origin;
	long                 X, Y;
} OFFSET;

#ifndef __GRECT
# define __GRECT
typedef struct graphic_rectangle
{
	short g_x;
	short g_y;
	short g_w;
	short g_h;
} GRECT;
#endif

struct clipping_area {
	WORD x;
	WORD y;
	WORD w;
	WORD h;
};

#ifdef USE_IMGDATA /* avoid compilerbug in PureC */
struct s_img_data {
	/* MFDB */
	void * fd_addr;
	WORD   fd_w, fd_h;
	WORD   fd_wdwidth;
	WORD   fd_stand;
	WORD   fd_nplanes;
	WORD   fd_r1, fd_r2, fd_r3;
	/*---*/
	UWORD  img_w, img_h; /* original extents           */
	WORD   fgnd,  bgnd;  /* colors for due-chrome data */
	size_t mem_size;     /* additional size, of data   */
};
typedef const struct s_img_data * cIMGDATA;
typedef       struct s_img_data * pIMGDATA;
#else
#	define cIMGDATA const void *
#endif

typedef struct s_image {
	union {
		void   * Mfdb;
		cIMGDATA Data;
	}        u;
	WORDITEM word;
	PARAGRPH paragraph;
	CONTAINR container;
	LOCATION source;
	OFFSET offset;
	short  backgnd;
	short  set_w,  set_h;
	short  disp_w, disp_h;
	short  alt_w,  alt_h;
	short  vspace;
	short  hspace;
} * IMAGE;

struct font_step {
	WORD step;
	WORD colour;
	struct font_step *previous_font_step;
};

struct font_style {
	unsigned italic;
	unsigned bold;
	unsigned underlined;
	unsigned strike;
};

typedef union {
	unsigned long packed;
	struct {
		unsigned _pad1  :8; /* alignment, always 0 */
		unsigned color  :8;
		unsigned undrln :1;
		unsigned _pad2  :1; /* alignment, always 0 */
		unsigned strike :1;
		unsigned _pad3  :1; /* alignment, always 0 */
		unsigned italic :1;
		unsigned bold   :1;
		unsigned font   :2;
		unsigned size   :8;
	} s;
} TEXTATTR;
#define TEXTATTR(s,c) (((long)(c & 0xFF) <<16) | (s & 0xFF))
                      /* pseudo constructor for text size and colour */
#ifdef __LATICE__
# define _TAsplit(a,n) (((unsigned char *)&(a).packed)[n])
# define TA_Color(a)      _TAsplit(a,1)
# define TAsetUndrln(a,b) {if(b) _TAsplit(a,2)|=0x80; else _TAsplit(a,2)&=0x7F;}
# define TAgetUndrln(a)   ((_TAsplit(a,2) & 0x80) ? 8 :0)
# define TAsetStrike(a,b) {if(b) _TAsplit(a,2)|=0x20; else _TAsplit(a,2)&=0xDF;}
# define TAgetStrike(a)   ((_TAsplit(a,2) & 0x20) ? 1 :0)
# define TAsetItalic(a,b) {if(b) _TAsplit(a,2)|=0x08; else _TAsplit(a,2)&=0xF7;}
# define TAgetItalic(a)   ((_TAsplit(a,2) & 0x08) ? 1 :0)
# define TAsetBold(a,b)   {if(b) _TAsplit(a,2)|=0x04; else _TAsplit(a,2)&=0xFB;}
# define TAgetBold(a)     ((_TAsplit(a,2) & 0x04) ? 1 :0)
# define TAsetFont(a,f)   {_TAsplit(a,2) = (_TAsplit(a,2) & 0xFC) | (f & 0x03);}
# define TAgetFont(a)     (_TAsplit(a,2) & 0x03)
# define TA_Size(a)       _TAsplit(a,3)
#else
# define TA_Color(a)      ((a).s.color)
# define TAsetUndrln(a,b) {(a).s.undrln = (b ? 1 : 0);}
# define TAgetUndrln(a)   ((a).s.undrln ? 8 :0)
# define TAsetStrike(a,b) {(a).s.strike = (b ? 1 : 0);}
# define TAgetStrike(a)   ((a).s.strike ? 1 :0)
# define TAsetItalic(a,b) {(a).s.italic = (b ? 1 : 0);}
# define TAgetItalic(a)   ((a).s.italic ? 1 :0)
# define TAsetBold(a,b)   {(a).s.bold = (b ? 1 : 0);}
# define TAgetBold(a)     ((a).s.bold ? 1 :0)
# define TAsetFont(a,f)   {(a).s.font = f;}
# define TAgetFont(a)     ((a).s.font)
# define TA_Size(a)       ((a).s.size)
#endif
#define TAgetFace(a) (((short)(a).packed & 0x0F00) >>8)

struct word_item {
	UWORD  * item;
	WORD     length;  /* number of 16bit characters in item */
	L_BRK    line_brk;
	TEXTATTR attr;
	WORD h_offset;
	WORD word_width;
	WORD word_height;
	WORD word_tail_drop;
	WORD space_width;
	V_ALIGN vertical_align;
	struct s_image   * image;
	struct url_link  * link;
	struct word_item * next_word;
};

typedef struct word_line {
	WORDITEM Word;    /* the first word of the line */
	short    Count;   /* number of words */
	short    Ascend;  /* space above the baseline */
	short    Descend; /* space below the baseline */
	struct word_line * NextLine;
} * WORDLINE;

struct paragraph_item {
	WORDITEM item;
	TABLE    Table;
	FORM     Form;
	WORDLINE Line;    /* list of word lines */
	short    Indent;  /* horizontal offset to the left side */
	short    Rindent; /* indent of the right side */
	OFFSET   Offset;
	long     Width;
	long     Height;
	short    Backgnd; /* colour or -1 */
	PARAGRAPH_CODE paragraph_code;
	H_ALIGN alignment;
	H_ALIGN floating;
	WORD eop_space;
	long min_width;
	long max_width;
	PARAGRPH next_paragraph;
};

typedef struct {
	PARAGRPH Item;
	long     Minimum; /* smallest width where the content fits in    */
	long     Width;   /* set Value, must not be smaller than Minimum */
	long     Height;  /* calculated value resulting from given Width */
	short    Backgnd; /* -1 or colour value                          */
	H_ALIGN  Alignment;
	short    MarginTop, MarginBot; /* top and bottom margins */
	short    MarginLft, MarginRgt; /* left and right margins */
} CONTENT;

typedef struct frame_item {
	CONTAINR Container;
	LOCATION Location;
	ENCODING Encoding;
	CONTENT  Page;
	struct slider {
		long scroll;
		BOOL on;
		WORD lu, rd; /* left/up, right/down arrow borders */
		WORD pos;    /* slider position */
		WORD size;   /* slider size     */
	}    v_bar, h_bar;
	BOOL border;
	SCROLL_CODE scroll;
	WORD text_colour;
	WORD link_colour;
	char * base_target;
	struct clipping_area clip;
	struct clickable_area *first_clickable_area;
	struct named_location *first_named_location;
	struct list_stack_item *current_list;
	TBLSTACK TableStack;
	FRMSTACK FormStack;    /* FORM currently being processed */
	FORM FormList;     		/* FORM list for user interaction */
	struct text_buffer {
		short              backgnd;
		struct font_style  styles;
		PARAGRPH           paragraph;
		WORDITEM           word;      /* the item actually to process */
		WORDITEM           prev_wrd;  /* <br> tags affect this        */
		WORD               font_size;
		struct font_step * font_step;
		ANCHOR           * anchor;
		UWORD            * text;
		UWORD            * buffer;
	} current;
} * FRAME;
typedef struct text_buffer * TEXTBUFF;

struct list_stack_item {
	enum bullets bullet_style;
	WORD         counter;
	short        Indent;  /* horizontal offset to the left side */
	short        Hanging; /* left shift value for <li> bullet/number */
	short        Spacer;  /* between bullet/number and text */
	struct list_stack_item *next_stack_item;
};

/* ******************** Action Constructs ************************* */

struct clickable_area {
	OFFSET offset;
	WORD w;
	WORD h;
	struct url_link *link;
	struct clickable_area *next_area;
};

struct named_location {
	OFFSET offset;
	const char * address;
	struct named_location *next_location;
};

struct url_link {
	BOOL   isHref;
	char * address;
	union {
		ANCHOR anchor; /* if isHref == FALSE */
		char * target; /* if isHref == TRUE  */
	} u;
	ENCODING encoding;
};


#ifdef __PUREC__
/* Pure C 1.1 (file size 226538, file date 1992-10-25) reports an
 * error "Undefined structure 's_table[_stack]'"! Other versions only show
 * warnings. So let the compiler know the structures.
 * This seems the best place. I tested several other variants, that confuses us
 * programmers more. */
#include "Containr.h"
#include "Table.h"
#include "Form.h"
#include "Location.h"
#endif /* __PUREC__ */
