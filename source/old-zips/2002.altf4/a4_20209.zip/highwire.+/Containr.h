

#ifndef __GRECT
# define __GRECT
typedef struct graphic_rectangle
{
	short g_x;
	short g_y;
	short g_w;
	short g_h;
} GRECT;
#endif


typedef struct s_containr * CONTAINR;
struct s_containr {
	CONTAINR Parent, Sibling;
	short  ColSize, RowSize;
	GRECT  Area;
	char * Name;
	BOOL   Border;
	enum { CNT_EMPTY = 0,
	       CNT_FRAME = 1,
	       CNT_CLD_H = 2,
	       CNT_CLD_V = 3
	} Mode;
	union { CONTAINR Child;
	        FRAME    Frame;
	} u;
};


CONTAINR new_containr    (CONTAINR parent);
void     delete_containr (CONTAINR *);

void containr_fillup (CONTAINR , const char * text, BOOL colsNrows);
void containr_setup  (CONTAINR , FRAME);
void containr_clear  (CONTAINR );

CONTAINR containr_Base (FRAME);

BOOL containr_relocate  (CONTAINR , short x, short y);
BOOL containr_calculate (CONTAINR , const GRECT *);

void containr_redraw (CONTAINR , const GRECT *);


/* temporary functions for code compatibility */

short C_get_percent (CONTAINR , BOOL colsNrows);
void  C_get_offset  (CONTAINR , short * x, short * y);

