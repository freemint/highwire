typedef void       * CACHEOBJ;
typedef const void * CACHED;

void     cache_insert  (LOCATION, long hash, CACHEOBJ, size_t size);
CACHED   cache_lookup  (LOCATION, long hash, long * opt_found);
CACHEOBJ cache_bound   (CACHED);
CACHEOBJ cache_release (CACHED *);
size_t   cache_info    (size_t * size);
