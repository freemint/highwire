/* @(#)highwire/Table.h
 */
#ifndef __TABLE_H__
#define __TABLE_H__


typedef struct s_table_row * TAB_ROW;
typedef struct s_table_cell* TAB_CELL;


struct s_table_stack {
	TABLE    Table;
	TAB_ROW  PrevRow;  /* previous row, to be copied from for rowspan */
	TAB_ROW  WorkRow;  /* actual row to work on */
	TAB_CELL WorkCell; /* actual cell to work on */
	unsigned NumCells; /* number of used cells in the actual row */
	H_ALIGN  AlignH;
	V_ALIGN  AlignV;
	struct font_style  SavedStyles;
	struct font_step * SavedFntStp;
	H_ALIGN            SavedAlign;
	short              Backgnd;
	TBLSTACK Previous;

	char _debug;
};

struct s_table {
	PARAGRPH Paragraph;
	short    Color;
	short    Border;
	short    Spacing;
	short    Padding;
	short    SetWidth;
	short    SetHeight;
	TAB_ROW  Rows;
	unsigned NumCols;
	unsigned FixCols;
	unsigned NumRows;
	long   * Minimum;
	long   * Maximum;
	long   * ColWidth;
};

struct s_table_row {
	short    Color;
	TAB_CELL Cells;
	TAB_ROW  NextRow;
	long     MinHeight;
	long     Height;
};

struct s_table_cell {
	CONTENT   Content;
/*	short     Color;     * now in Content.Backgnd */
	V_ALIGN   AlignV;
	TAB_CELL  DummyFor;
	TAB_CELL  RightCell;
	TAB_CELL  BelowCell;
	short     ColSpan;
	short     RowSpan;
/*	PARAGRPH  Paragraph; * now in Content.Item    */
	OFFSET    Offset;
/*	long      Width;     * now in Content.Width   */
/*	long      Height;    * now in Content.Height  */

	char _debug;
};


PARAGRPH table_start  (FRAME);
void     table_row    (FRAME, BOOL beginNend);
PARAGRPH table_cell   (FRAME, BOOL is_head);
void     table_finish (FRAME);

long table_calc (TABLE, long max_width, CLICKABLE **);
long table_draw (TABLE, short x, long y, const GRECT * clip);


#endif /* __TABLE_H__ */
