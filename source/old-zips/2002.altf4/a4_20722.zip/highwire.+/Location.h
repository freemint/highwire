/* @(#)highwire/Location.h
 */
#ifndef __LOCATION_H__
#define __LOCATION_H__


struct s_location {
	unsigned __reffs;
	short    Proto;
	short    Port;
	void   * Host;
	BOOL     isTos;
	char   * File;
	char   * Path;
	char   * Anchor;
	char     FullName[4];
};


LOCATION new_location  (const char * src, LOCATION base);
void     free_location (LOCATION *);

LOCATION location_share (LOCATION);

int location_open (LOCATION, const char ** host_name);



#endif /*__LOCATION_H__*/
