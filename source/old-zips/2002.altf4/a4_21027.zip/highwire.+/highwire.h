/* resource set indices for HIGHWIRE */

#define MENUTREE               0 /* menu */
#define M_ABOUT                9 /* STRING in tree MENUTREE */
#define M_OPEN                18 /* STRING in tree MENUTREE */
#define M_INFO                20 /* STRING in tree MENUTREE */
#define M_QUIT                22 /* STRING in tree MENUTREE */
#define M_RELOAD              24 /* STRING in tree MENUTREE */
#define M_W1252               26 /* STRING in tree MENUTREE */
#define M_I8859_2             27 /* STRING in tree MENUTREE */
#define M_I8859_15            28 /* STRING in tree MENUTREE */
#define M_UTF8                29 /* STRING in tree MENUTREE */
#define M_UTF16               30 /* STRING in tree MENUTREE */
#define M_UTF16LE             31 /* STRING in tree MENUTREE */
#define M_MACINTOSH           32 /* STRING in tree MENUTREE */
#define M_ATARI_SYS           33 /* STRING in tree MENUTREE */
#define M_ATARINVDI           34 /* STRING in tree MENUTREE */
#define M_FONT_INC            36 /* STRING in tree MENUTREE */
#define M_FONT_DEC            37 /* STRING in tree MENUTREE */
#define M_LOGGING             39 /* STRING in tree MENUTREE */
#define M_ALT_TEXT            40 /* STRING in tree MENUTREE */

#define ABOUT                  1 /* form/dialog */
#define ABOUTOK                1 /* BUTTON in tree ABOUT */

#define URLINPUT               2 /* form/dialog */
#define URL_OK                 2 /* BUTTON in tree URLINPUT */
#define URL_CANCEL             3 /* BUTTON in tree URLINPUT */
#define URL_FILE               4 /* BUTTON in tree URLINPUT */
#define URL_ED_BG              5 /* IBOX in tree URLINPUT */
#define URL_EDIT               6 /* FBOXTEXT in tree URLINPUT */

#define RPOPUP                 3 /* form/dialog */
#define RPOP_BACK              1 /* TEXT in tree RPOPUP */
#define RPOP_FORWARD           3 /* TEXT in tree RPOPUP */
#define RPOP_VIEWSRC           4 /* TEXT in tree RPOPUP */
#define RPOP_RELOAD            5 /* TEXT in tree RPOPUP */
#define RPOP_INFO              7 /* TEXT in tree RPOPUP */

