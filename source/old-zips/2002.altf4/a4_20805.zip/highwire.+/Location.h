/* @(#)highwire/Location.h
 */
#ifndef __LOCATION_H__
#define __LOCATION_H__


struct s_location {
	unsigned __reffs;
	short    Proto;
	short    Port;
	void   * Host, * Dir;
	const char * File;
	const char * Path;
	const char * Anchor;
	const char   FullName[4];
};


LOCATION new_location  (const char * src, LOCATION base);
void     free_location (LOCATION *);

LOCATION location_share (LOCATION);

const char * location_Path  (LOCATION, UWORD * opt_len);
int          location_equal (LOCATION, LOCATION);

int location_open (LOCATION, const char ** host_name);



#endif /*__LOCATION_H__*/
