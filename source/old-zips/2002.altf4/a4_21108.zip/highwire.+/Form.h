#ifndef __FORM_H__
#define __FORM_H__


void * new_form (FRAME, char * target, char * action, const char * method);

void * new_input (PARSER);
void input_draw   (void*, WORD x, WORD y);
BOOL input_isEdit (void*);
WORD input_handle (void*, GRECT *);

#endif /* __FORM_H__ */
