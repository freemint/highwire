#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#include "global.h"
#include "Table.h"


struct blocking_area {
	struct {
		long width;
		long bottom;
	} L, R;
};


void
destroy_paragraph_structure (PARAGRPH current_paragraph)
{
	struct paragraph_item *temp;

	while (current_paragraph != 0)
	{
		if (current_paragraph->item != 0)
			destroy_word_structure (current_paragraph->item);
#if 0
		if (current_paragraph->table != 0)
			destroy_table_structure (current_paragraph->table);
#endif
		temp = current_paragraph->next_paragraph;
		free (current_paragraph);
		current_paragraph = temp;
	}
}


/*==============================================================================
 */
PARAGRPH
new_paragraph (TEXTBUFF current)
{
	PARAGRPH paragraph = malloc (sizeof (struct paragraph_item));
	
	current->styles.italic     = 0;
	current->styles.bold       = 0;
	current->styles.underlined = 0;
	current->styles.strike     = 0;
	
	current->word = NULL;
	
	paragraph->item    = new_word (current, FALSE);
	paragraph->Table   = NULL;
	paragraph->Line    = NULL;
	paragraph->Indent  = 0;
	paragraph->Rindent = 0;
	paragraph->Height  = 0;
	paragraph->Offset.Origin = NULL;
	paragraph->Offset.X      = 0;
	paragraph->Offset.Y      = 0;
	paragraph->Backgnd        = -1;
	paragraph->paragraph_code = PAR_NONE;
	paragraph->alignment      = ALN_LEFT;
	paragraph->floating       = ALN_NO_FLT;
	paragraph->eop_space      = 0;
	paragraph->min_width      = 0;
	paragraph->max_width      = 0;

	paragraph->next_paragraph = NULL;
	
	current->paragraph = paragraph;
	
	return paragraph;
}


/*==============================================================================
 * add_paragraph()
 * 
 * Creates a new paragraph structure and links it into list
 * also creates a new word item and links it into the new paragraph
 *
 * 12/14/01 - modified to use frame_item info and directly modify frame - baldrick
 *
 * AltF4 - Jan. 20, 2002:  replaced malloc of struct word_item by new_word().
 *
 */

PARAGRPH
add_paragraph (TEXTBUFF current)
{
	PARAGRPH paragraph = malloc (sizeof (struct paragraph_item));
	PARAGRPH copy_from = current->paragraph;
	
	paragraph->item  = new_word (current, FALSE);
	paragraph->Table = NULL;
	paragraph->Line    = NULL;
	paragraph->Indent  = copy_from->Indent;
	paragraph->Rindent = copy_from->Rindent;
	paragraph->Height  = 0;
	paragraph->Offset.Origin = copy_from->Offset.Origin;
	paragraph->Offset.X      = 0;
	paragraph->Offset.Y      = 0;
	paragraph->Backgnd        = -1;
	paragraph->paragraph_code = PAR_NONE;
	paragraph->floating       = ALN_NO_FLT;
	paragraph->alignment      = copy_from->alignment;
	paragraph->eop_space = 0;
	paragraph->min_width = 0;
	paragraph->max_width = 0;
	
	paragraph->next_paragraph = NULL;
	
	copy_from->next_paragraph = paragraph;
	current->paragraph        = paragraph;
	current->prev_wrd         = NULL;
	
	return paragraph;
}


/*------------------------------------------------------------------------------
 */
static void
paragraph_calc (PARAGRPH par, long width, CLICKABLE ** clck_pptr, struct blocking_area *blocker)
{
	WORDLINE * p_line    = &par->Line, line;
	WORDITEM   word      = par->item,  next;
	long       int_width = width;
	short      blocked   = 0x00;
	long       l_height  = 0;
	long       r_height  = 0;
	H_ALIGN    align;
	
	if (par->paragraph_code == PAR_IMG) {
		align = ALN_LEFT;
	} else {
		align = par->alignment;
		if (blocker->L.bottom) {
			l_height   = blocker->L.bottom - par->Offset.Y;
			int_width -= blocker->L.width;
			blocked   |= (BRK_LEFT & ~BRK_LN);
		}
		if (blocker->R.bottom) {
			r_height   = blocker->R.bottom - par->Offset.Y;
			int_width -= blocker->R.width;
			blocked   |= (BRK_RIGHT & ~BRK_LN);
		}
	}
	par->Height = 0;
	do {
		struct url_link * link;
		CLICKABLE clickable = NULL;
		short     count     = 1;
		short     offset, justify;
		BOOL      ln_brk;
		
		WORDITEM w_beg = NULL;
		short    w_len = 0;
		short    w_cnt = 0;

		while (word) {
			if (word->image) {
				image_calculate (word->image, int_width);
				break;
			}
			if (word->link || !word->space_width || word->length > 0) {
				break;
			}
			word = word->next_word;
		}
		if (!word) break;

		if ((line = *p_line) == NULL) {
			*p_line = line = malloc (sizeof(struct word_line));
			line->NextLine = NULL;
		}
		p_line = &line->NextLine;
		line->Paragraph = par;
		line->Word      = word;
		line->Ascend    = word->word_height;
		line->Descend   = word->word_tail_drop;
		offset = int_width - word->word_width + word->space_width;

		ln_brk = word->line_brk;

		while ((word = word->next_word) != NULL && !ln_brk) {
			if (word->image) {
				image_calculate (word->image, int_width);
			}
			if (word->space_width) {
				w_beg = word;
				w_cnt = count;
				w_len = offset;
			}
			if (word->word_width > offset) {
				if (w_beg) {
					word   = w_beg;
					count  = w_cnt;
					offset = w_len;
				}
				break;
			}
			if (line->Ascend  < word->word_height)
				 line->Ascend  = word->word_height;
			if (line->Descend < word->word_tail_drop)
				 line->Descend = word->word_tail_drop;
			offset -= word->word_width;
			ln_brk  = word->line_brk;
			count++;
		}
		next        = word;
		word        = line->Word;
		line->Count = count;
	
		if (align == ALN_JUSTIFY) {
			justify = (!ln_brk && next ? offset : 0);
			offset  = 0;
		} else if (align) {
			justify = 0;
			if (align == ALN_CENTER) offset /= 2;
		} else {
			justify = 0;
			offset  = 0;
		}

		offset -= word->space_width;

		if (blocked)
			offset += blocker->L.width;
		
		link = NULL;
		while(1) {
			if (word->image) {
				/* Origin set in new_image() */
				word->image->offset.X = offset;
				word->image->offset.Y = par->Height
				                      + line->Ascend - word->word_height;
			}

			if (!word->link) {
				link = NULL;

			} else if (!word->link->isHref) {
				/* Origin set in new_named_location() */
				word->link->u.anchor->offset.X = -par->Offset.X;
				word->link->u.anchor->offset.Y = par->Height;
				link = NULL;

			} else if (word->link == link) {
				clickable->w += word->word_width;

			} else {
				clickable = **clck_pptr;
				if (!clickable) {
					**clck_pptr = clickable = new_clickable_area();
				}
				*clck_pptr = &clickable->next_area;
				clickable->offset.Origin = &par->Offset;
				clickable->offset.X      = offset;
				clickable->offset.Y      = par->Height;
				clickable->w             = word->word_width;
				clickable->h             = line->Ascend + line->Descend;
				clickable->link   = link = word->link;
			}
			
			word->line     = line;
			word->h_offset = offset;

			if (!--count) break;

			if (justify) {
				short w = justify / count;
				offset  += w;
				justify -= w;
			}
			offset += word->word_width;
			word    = word->next_word;
		}
		line->Word->h_offset += line->Word->space_width;
		
		par->Height  += line->Ascend;
		line->OffsetY = par->Height;
		par->Height  += line->Descend;
		
		if (blocked) {
			if (blocked & (BRK_LEFT & ~BRK_LN)) {
				if (ln_brk & (BRK_LEFT & ~BRK_LN)) {
					if (par->Height < l_height) {
						line->Descend += l_height - par->Height;
						par->Height = l_height;
					}
				}
				if (par->Height >= l_height) {
					blocked   &= ~(BRK_LEFT & ~BRK_LN);
					int_width += blocker->L.width;
					blocker->L.bottom = blocker->L.width = l_height = 0;
				}
			}
			if (blocked & (BRK_RIGHT & ~BRK_LN)) {
				if (ln_brk & (BRK_RIGHT & ~BRK_LN)) {
					if (par->Height < r_height) {
						line->Descend += r_height - par->Height;
						par->Height = r_height;
					}
				}
				if (par->Height >= r_height) {
					blocked   &= ~(BRK_RIGHT & ~BRK_LN);
					int_width += blocker->R.width;
					blocker->R.bottom = blocker->R.width = r_height = 0;
				}
			}
		}
	} while ((word = next) != NULL);

	if ((line = *p_line) != NULL) {
		WORDLINE next_line;
		do {
			next_line = line->NextLine;
			free (line);
		} while ((line = next_line) != NULL);
		*p_line = NULL;
	}

	if (par->paragraph_code == PAR_IMG)
		int_width = par->item->word_width;

	par->Width = int_width;
}


/*==============================================================================
 * paragrph_word()
 *
 * Returns the word item at the coordinates x/y, relative to the paragraph's
 * origin.  The result will be NULL if the coordinates are befor the first or
 * after the last word of a line, or between two words and the right one isn't
 * a link.  In any case the calculated extents are stored in the long array.  
*/
WORDITEM
paragrph_word (PARAGRPH par, long x, long y, long area[4])
{
	WORDITEM word = NULL;
	WORDLINE line = par->Line;
	long     bot  = 0;
	
	while (line) {
		bot = line->OffsetY + line->Descend;
		if (bot <= y) {
			line = line->NextLine;
		} else {
			word    =  line->Word;
			area[1] += line->OffsetY - line->Ascend;
			area[3] =  line->Ascend + line->Descend;
			break;
		}
	}
	
	if (!word) {
		area[1] += bot;
		area[3] =  par->Height - bot;
	
	} else if (x < word->h_offset) {
		area[2] = word->h_offset;
		word = NULL;
	
	} else {
		WORDITEM url = NULL;
		short num = line->Count;
		short spc = word->h_offset;
		short lft = spc - word->space_width;
		short rgt = lft + word->word_width;
		while (rgt <= x) {
			lft = rgt;
			if (!word->link || !word->link->isHref) {
				url = NULL;
			} else if (!url || url->link != word->link) {
				url = word;
			}
			if (--num) {
				word = word->next_word;
				spc  = word->h_offset + word->space_width;
				rgt  = word->h_offset + word->word_width;
			} else {
				word = NULL;
				break;
			}
		}
		if (!word) {
			area[0] += lft;
			area[2] =  par->Width - lft;
		
		} else if (url && url != word) {
			area[0] += lft;
			area[2] =  rgt - lft;
		
		} else if (x < spc) {
			area[0] += lft;
			area[2] =  spc - lft;
			word = NULL;
		
		} else {
			area[0] += spc;
			area[2] =  rgt - spc;
		}
	}
	
	return word;
}


/*==============================================================================
 * paragraph_extend()
 *
 * Calculates the whole extents of all words which points to the same link.
 * The resulting rectangle has it's coordinates set relative to that of the
 * given word.
*/
GRECT
paragraph_extend (WORDITEM word)
{
	void   * link = word->link;
	short    lft  = word->h_offset, rgt, x;
	WORDLINE line = word->link->start->line;
	short    num  = line->Count;
	GRECT    ext  = { 0,0,0,0 };
	
	if (line != word->line) {
		WORDLINE orig = word->line;
		ext.g_y = (line->OffsetY - line->Ascend) - (orig->OffsetY - orig->Ascend);
		if (line->Paragraph != orig->Paragraph) {
			ext.g_y += line->Paragraph->Offset.Y - orig->Paragraph->Offset.Y;
			ext.g_x =  line->Paragraph->Offset.X - orig->Paragraph->Offset.X;
			lft     -= ext.g_x;
		}
	}
	word = line->Word;
	
	while (--num && word->link != link) {
		word = word->next_word;
	}
	rgt = lft;
	x   = word->h_offset + (word == line->Word ? 0 : word->space_width);
	while(1) {
		if (lft > x) {
			ext.g_x += x - lft;
			lft     =  x;
		}
		if (num) {
			do {
				WORDITEM next = word->next_word;
				if (next->link != link) {
					break;
				} else {
					word = next;
				}
			} while (--num);
		}
		x = word->h_offset + word->word_width
		  - (word == line->Word ? word->space_width : 0);
		if (rgt < x) {
			rgt = x;
		}
		ext.g_h += line->Ascend + line->Descend;
		
		if (num) {
			break;
		} else if (line->NextLine) {
			line = line->NextLine;
		} else {
			PARAGRPH par      = line->Paragraph;
			PARAGRPH next_par = par->next_paragraph;
			if (!next_par || !next_par->Line) {
				break;
			} else {
				short d_x = next_par->Offset.X - par->Offset.X;
				lft     += d_x;
				rgt     += d_x;
				ext.g_h += par->eop_space;
				line = next_par->Line;
			}
		}
		word = line->Word;
		if (word->link != link) {
			break;
		}
		num = line->Count -1;
		x   = word->h_offset;
	}
	ext.g_w = rgt - lft +1;
	
	return ext;
}


/*============================================================================*/
void
content_setup (CONTENT * content, TEXTBUFF current, short margns, short backgnd)
{
	if (current) {
		content->Item   = new_paragraph (current);
		current->backgnd = backgnd;
	} else {
		content->Item   = NULL;
	}
	content->Minimum   = 0;
	content->Width     = 0;
	content->Height    = 0;
	content->Backgnd   = backgnd;
	content->Alignment = ALN_LEFT;
	content->MarginTop = content->MarginBot =
	content->MarginLft = content->MarginRgt = margns;
}


/*============================================================================*/
void
content_destroy (CONTENT * content)
{
	PARAGRPH par = content->Item;

	while (par) {
		PARAGRPH next = par->next_paragraph;
		if (par->item)
			destroy_word_structure (par->item);
		if (par->Table)
			delete_table (&par->Table);
		free (par);
		par = next;
	}
	content->Item = NULL;
}


/*----------------------------------------------------------------------------*/
static WORDITEM
punch (WORDITEM * trash, WORDITEM beg, WORDITEM end)
{
	WORDITEM  next = end->next_word;
	end->next_word = *trash;
	*trash         = beg;
	return next;
}

/*==============================================================================
 * content_minimum()
 *
 * Returns the smallest width that is needed for a list of paragraphs.
 */
long
content_minimum (CONTENT * content)
{
	PARAGRPH paragraph = content->Item;
	long     min_width = 0;
	
	WORDITEM trash = NULL;
#if 0
	int n_empty = 0;
	int n_space = 0;
	#define _DEBUG
#endif
	while (paragraph) {
		long par_width;
		
		if (paragraph->paragraph_code == PAR_HR ||
		    paragraph->paragraph_code == PAR_TABLE) {
			
			par_width = paragraph->min_width
		             + paragraph->Indent + paragraph->Rindent;
		
		} else {
			long wrd_width = par_width = 0;
			
			BOOL       space = FALSE;
			WORDITEM   prev  = NULL;
			WORDITEM * p_wrd = &paragraph->item, word;
			while ((word = *p_wrd) != NULL) {
				
				if (!word->length && !word->image) { /* empty word, presave
				                                      * line break and remove */
					if (prev && word->line_brk) {
						prev->line_brk |= word->line_brk;
						space = FALSE;
						p_wrd = &prev->next_word;
					}
					*p_wrd = punch (&trash, *p_wrd, word);
				#ifdef _DEBUG
					n_empty++;
				#endif
					continue;
				}
				
				if (word->item[0] != Space_Code) {
					word->space_width = 0;
					if (word->image && word->image->set_w < 0) {
						wrd_width += 1 + word->image->hspace *2;
					} else {
						wrd_width += word->word_width;
					}
					if (word->line_brk) {
						if (par_width < wrd_width) {
							 par_width = wrd_width;
						}
						wrd_width = 0;
					}
					space = FALSE;
					prev  = word;
					p_wrd = &word->next_word;
					continue;
				}
				
				if (space) { /* two spaces in a row, remove the leading */
					space = FALSE;
					prev->next_word = punch (&trash,
					                         prev->next_word, prev->next_word);
				#ifdef _DEBUG
					n_space++;
				#endif
				}
				
				if (par_width < wrd_width) {
					 par_width = wrd_width;
				}
				
				if (word->length > 1) {
					wrd_width = word->word_width - word->space_width;
					prev  = word;
					p_wrd = &word->next_word;
					continue;
				
				} else {
					wrd_width = 0;
				}
				
				if (!prev) { /* leading space, remove */
					*p_wrd = punch (&trash, word, word);
				#ifdef _DEBUG
					n_space++;
				#endif
					continue;
				}
				
				if (word->line_brk) { /* space with line break,
				                       * presave and remove   */
					prev->line_brk |= word->line_brk;
					*p_wrd = punch (&trash, word, word);
				#ifdef _DEBUG
					n_space++;
				#endif
					continue;
				}
				
				/* normal space */
				
				space = TRUE;
				p_wrd = &word->next_word;
			}
			
			if (par_width < wrd_width) {
				 par_width = wrd_width;
			}
			paragraph->min_width = par_width;
			par_width += paragraph->Indent + paragraph->Rindent;
			
			if (space) {
				word = prev;
				while (word->next_word) {
					word = word->next_word;
				#ifdef _DEBUG
					n_space++;
				#endif
				}
				prev->next_word = punch (&trash, prev->next_word, word);
			}
		}
		if (min_width < par_width) {
			 min_width = par_width;
		}
		paragraph = paragraph->next_paragraph;
	}
#ifdef _DEBUG
	if (n_empty || n_space || trash) {
		struct word_item * w = trash;
		int sum = 0;
		while (w) {
			sum++;
			w = w->next_word;
		}
		if (n_empty) printf ("empty   = %i \n", n_empty);
		if (n_space) printf ("space   = %i \n", n_space);
		printf ("trash   = %i \n", sum);
	}
#endif
	
	min_width += content->MarginLft + content->MarginRgt;
	
	return (content->Minimum = min_width);
}


/*==============================================================================
 * content_maximum()
 *
 * Returns the largest width that occures in a list of paragraphs.
 */
long
content_maximum (CONTENT * content)
{
	PARAGRPH paragraph = content->Item;
	long     max_width = 0;
	
	while (paragraph) {
		if (!paragraph->max_width) {
			struct word_item * word = paragraph->item;
			long width = paragraph->Indent + paragraph->Rindent;
			while (word) {
				BOOL ln_brk = word->line_brk;
				width += word->word_width;
				word = word->next_word;
				if (ln_brk || !word) {
					if (paragraph->max_width < width) {
						 paragraph->max_width = width;
					}
					width = paragraph->Indent;
				}
			}
		}
		if (max_width < paragraph->max_width) {
			 max_width = paragraph->max_width;
		}
		paragraph = paragraph->next_paragraph;
	}
	return (max_width + content->MarginLft + content->MarginRgt);
}


/*==============================================================================
 */
long
content_calc (CONTENT * content, long set_width, CLICKABLE ** clck_pptr)
{
	PARAGRPH paragraph = content->Item;
	long     height    = content->MarginTop;
	struct blocking_area blocker = { {0, 0}, {0, 0} };
	
	content->Width = set_width;
	set_width     -= content->MarginLft + content->MarginRgt;
	
	while (paragraph) {
		long par_width = set_width - paragraph->Indent - paragraph->Rindent;
		long blk_width = set_width - blocker.L.width - blocker.R.width;
		paragraph->Offset.X = content->MarginLft + paragraph->Indent;
		paragraph->Offset.Y = height;

		if (paragraph->min_width > blk_width) {
			height = (blocker.L.bottom >= blocker.R.bottom
			          ? blocker.L.bottom : blocker.R.bottom);
			paragraph->Offset.Y = height;
			blocker.L.bottom = blocker.L.width =
			blocker.R.bottom = blocker.R.width = 0;
			blk_width = par_width;
		} else {
			blk_width -= paragraph->Indent + paragraph->Rindent;
		}
		
		if (paragraph->paragraph_code == PAR_HR) {
			struct word_item * word = paragraph->item;
			if (word->space_width < 0) {
				word->word_width = (blk_width * -word->space_width + 512) / 1024;
			} else {
				word->word_width = word->space_width;
			}
			if (word->word_width >= blk_width) {
				word->word_width = blk_width;
				word->h_offset   = 0;
			} else {
				if (word->word_width < 2) {
					word->word_width = 2;
				}
				if (paragraph->alignment <= ALN_JUSTIFY) {
					word->h_offset   = 0;
				} else {
					word->h_offset   =  blk_width - word->word_width;
					if (paragraph->alignment == ALN_CENTER) {
						word->h_offset /= 2;
					}
				}
			}
			paragraph->Offset.X += blocker.L.width;
			paragraph->Width  = par_width;
			paragraph->Height = word->word_height *2
			                  + (word->word_tail_drop > 0
			                     ? +word->word_tail_drop : -word->word_tail_drop);
			paragraph->eop_space = 0;
			
		} else if (paragraph->paragraph_code == PAR_TABLE) {
			paragraph->Offset.X += blocker.L.width;
			table_calc (paragraph->Table, par_width, clck_pptr);
		
		} else {   /* normal text or image */
			if (paragraph->paragraph_code == PAR_IMG) {
				paragraph->Offset.X += blocker.L.width;
			}
			paragraph_calc (paragraph, par_width, clck_pptr, &blocker);
		}
		
		switch (paragraph->floating) {
			case ALN_LEFT: {
				long new_bottom = height + paragraph->Height;
				if (blocker.L.bottom < new_bottom)
					 blocker.L.bottom = new_bottom;
				blocker.L.width += paragraph->Width;
			}	break;
			case ALN_RIGHT: {
				long new_bottom = height + paragraph->Height;
				if (blocker.R.bottom < new_bottom)
					 blocker.R.bottom = new_bottom;
				paragraph->Offset.X += blk_width - paragraph->Width; 
				blocker.R.width += paragraph->Width;
			}	break;
			case ALN_CENTER:
				paragraph->Offset.X += (blk_width - paragraph->Width) /2;
				blk_width = 0; /* avoid double centering */
			case ALN_NO_FLT:
				if (paragraph->Width < blk_width
				    && paragraph->alignment > ALN_JUSTIFY) {
					short indent = blk_width - paragraph->Width;
					if (paragraph->alignment == ALN_CENTER) indent /= 2;
					paragraph->Offset.X += indent;
				}
				height += paragraph->Height + paragraph->eop_space;
				if (blocker.L.bottom && blocker.L.bottom < height) {
					blocker.L.bottom = blocker.L.width = 0;
				}
				if (blocker.R.bottom && blocker.R.bottom < height) {
					blocker.R.bottom = blocker.R.width = 0;
				}
		}
		
		paragraph = paragraph->next_paragraph;
	}

	if (height < blocker.L.bottom) {
		 height = blocker.L.bottom;
	}
	if (height < blocker.R.bottom) {
		 height = blocker.R.bottom;
	}
	return (content->Height = height + content->MarginBot);
}


/*==============================================================================
 */
void
content_stretch (CONTENT * content, long height, V_ALIGN valign)
{
	long offset = height - content->Height;
	
	content->Height = height;
	
	if (valign && offset) {
		PARAGRPH par = content->Item;
		if (valign == ALN_MIDDLE) offset /= 2;
		while (par) {
			par->Offset.Y += offset;
			par = par->next_paragraph;
		}
	}
}


/*============================================================================*/
PARAGRPH
content_paragraph (CONTENT * content, long x, long y, long area[4])
{
	PARAGRPH par = content->Item;
	
	if (!par) {
		area[2] = content->Width;
		area[3] = content->Height;
	
	} else if (par->Offset.Y > y) {
		area[2] = content->Width;
		area[3] = par->Offset.Y;
		par = NULL;
	
	} else {
		PARAGRPH next;
		long     bot;
		while ((next = par->next_paragraph) != NULL && next->Offset.Y <= y) {
			par = next;
		}
		if ((bot = par->Offset.Y + par->Height) <= y) {
			area[1] += bot;
			area[2] =  content->Width;
			area[3] =  (next ? next->Offset.Y : content->Height) - bot;
			par = NULL;
		
		} else {
		/*	long lft = 0, rgt = 0;*/
		/*	do*/ if (x < par->Offset.X) {
			/*	if (par->floating == ALN_RIGHT) {
					rgt += par->Width;
					par = par->next_paragraph;
				} else */{
					area[1] += par->Offset.Y;
					area[2] =  par->Offset.X;
					area[3] =  par->Height;
					par = NULL;
				}
			} else if (x >= par->Offset.X + par->Width) {
			/*	if (par->floating == ALN_LEFT) {
					lft += par->Width;
					par = par->next_paragraph;
				} else */{
					area[0] += par->Offset.X + par->Width;
					area[1] += par->Offset.Y;
					area[2] =  content->Width - (par->Offset.X + par->Width);
					area[3] =  par->Height;
					par = NULL;
				}
			} else {
				area[0] += par->Offset.X;
				area[1] += par->Offset.Y;
				area[2] =  par->Width;
				area[3] =  par->Height;
			/*	break;*/
				
			} /*while (par);*/
		}
	}
	return par;
}
