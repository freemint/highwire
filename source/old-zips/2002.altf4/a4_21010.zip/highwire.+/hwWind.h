#ifndef __HW_WIND_H__
#define __HW_WIND_H__


typedef struct hw_window * HwWIND;
struct hw_window {
	WORD   Handle;
	BOOL   isFull;
	BOOL   isIcon;
	UWORD  isBusy;
	GRECT  Curr;
	GRECT  Work;
	HwWIND Next;
	void * Pane;
	FRAME  Active;
	char   Name[128];
	char   Info[128];
};


HwWIND new_hwWind    (const char * name, const char * info, const char * url);
void   delete_hwWind (HwWIND);

void hwWind_setName (HwWIND, const char *);
void hwWind_setInfo (HwWIND, const char *);
void hwWind_move    (HwWIND, PXY);
void hwWind_resize  (HwWIND, const GRECT *);
void hwWind_full    (HwWIND);
void hwWind_iconify (HwWIND, const GRECT *);
void hwWind_raise   (HwWIND, BOOL topNbot);

extern HwWIND hwWind_Top;
extern HwWIND hwWind_Focus;
HwWIND  hwWind_byValue  (long);
HwWIND  hwWind_byHandle (WORD);
#define hwWind_byCoord( x, y )   hwWind_byHandle (wind_find (x, y))

void hwWind_redraw (HwWIND, const GRECT *);


#endif /*__HW_WIND_H__*/
