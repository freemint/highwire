
PARAGRPH table_start  (FRAME);
void     table_row    (FRAME);
PARAGRPH table_cell   (FRAME);
void     table_finish (FRAME);

long table_calc (struct s_table *, long max_width);
long table_draw (struct s_table *, short x, short y);
