#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#include "global.h"

void
destroy_paragraph_structure (PARAGRPH current_paragraph)
{
	struct paragraph_item *temp;

	while (current_paragraph != 0)
	{
		if (current_paragraph->item != 0)
			destroy_word_structure (current_paragraph->item);

		if (current_paragraph->table != 0)
			destroy_table_structure (current_paragraph->table);
			
		temp = current_paragraph->next_paragraph;
		free (current_paragraph);
		current_paragraph = temp;
	}
}


PARAGRPH
new_paragraph (FRAME p_frame)
{
	struct paragraph_item * temp = malloc (sizeof (struct paragraph_item));

	temp->item  = new_word (p_frame, NULL, TRUE);
	temp->table = NULL;
	temp->paragraph_code = PAR_NONE;
	temp->alignment      = left;
	temp->left_border    = 0;
	temp->right_border   = 0;
	temp->eop_space      = 0;
	temp->current_paragraph_height = 0;
	temp->min_width      = 0;
	temp->max_width      = 0;
	
	temp->area.x = 0;
	temp->area.y = 0;
	temp->area.w = 0;
	temp->area.h = 0;

	temp->next_paragraph = 0;
	
	return (temp);
}


/* add_paragraph
 * 
 * Creates a new paragraph structure and links it into list
 * also creates a new word item and links it into the new paragraph
 *
 * 12/14/01 - modified to use frame_item info and directly modify frame - baldrick
 *
 * AltF4 - Jan. 20, 2002:  replaced malloc of struct word_item by new_word().
 *
 */

void
add_paragraph (FRAME p_frame, WORD *active_word_buffer)
{
	struct paragraph_item * paragraph;

	word_store (p_frame, active_word_buffer, p_frame->active_word);

	paragraph = malloc (sizeof (struct paragraph_item));

	paragraph->item  = new_word (p_frame, p_frame->current_word , FALSE);
	paragraph->table = NULL;
	paragraph->alignment = p_frame->current_paragraph->alignment;
	paragraph->paragraph_code = PAR_NONE;
	paragraph->left_border = p_frame->current_paragraph->left_border;
	paragraph->right_border = p_frame->current_paragraph->right_border;
	paragraph->eop_space = 0;
	paragraph->current_paragraph_height = 0;
	paragraph->min_width = 0;
	paragraph->max_width = 0;
	paragraph->next_paragraph = NULL;
	
	p_frame->current_paragraph->next_paragraph = paragraph;
	p_frame->current_paragraph                 = paragraph;
	p_frame->current_word = p_frame->current_paragraph->item;
}


/* content_minimum()
 *
 * Returns the smallest width that is nedded for a list of paragraphs.
 */
WORD
content_minimum (PARAGRPH paragraph)
{
	WORD width = 0;
	while (paragraph) {
		if (width < paragraph->min_width) {
			 width = paragraph->min_width;
		}
		paragraph = paragraph->next_paragraph;
	}
	return width;
}

/* content_maximum()
 *
 * Returns the largest width that occures in a list of paragraphs.
 */
long
content_maximum (PARAGRPH paragraph)
{
	long max_width = 0;
	while (paragraph) {
		if (!paragraph->max_width) {
			struct word_item * word = paragraph->item;
			long width = 0;
			while (word) {
				BOOL ln_brk = word->line_brk;
				if (word->item[0] != Space_Code || word->item[1]) {
					width += word->word_width;
				}
				word = word->next_word;
				if (ln_brk || !word) {
					if (paragraph->max_width < width) {
						 paragraph->max_width = width;
					}
					width = 0;
				}
			}
		}
		if (max_width < paragraph->max_width) {
			 max_width = paragraph->max_width;
		}
		paragraph = paragraph->next_paragraph;
	}
	return max_width;
}
