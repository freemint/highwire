/* ******* Type Definitions ********* */

typedef enum bool { FALSE = (1!=1), TRUE = (1==1) } BOOL;
		#define false FALSE
		#define true  TRUE

typedef enum {
	PAR_NONE, PAR_HR, PAR_OL, PAR_UL, PAR_IMG, PAR_TABLE
} PARAGRAPH_CODE;

enum paragraph_alignment {left,center,right};
enum vertical_alignment {above,top,middle,bottom,below};
enum bullets {disc,square,circle,Number,alpha,Alpha,roman,Roman};
enum direction {d_up,d_down,d_left,d_right};
enum link_mode {lnk_href,lnk_name};
enum possible_message_types {to_do_load_frame,to_do_parse_frame};


/***** Forward Declarations *****/
#ifdef __PUREC__
  /* we need this to keep pure c off from
   * warning about correct C code...   */
# pragma warn -stu
#endif
typedef struct s_containr * CONTAINR;   /* in Containr.h */

struct graphic_rectangle;


#ifndef MagX_cookie
#define 	MagX_cookie		0x4D616758
#endif

#ifndef AES_single
#define	AES_single	0
#define	AES_MagiC	1
#define	AES_Geneva	2
#define	AES_MTOS	3
#define	AES_nAES	4
#endif

#ifndef _cookies
#define	_cookies	((long **) 0x5A0L)
#endif

#ifndef ck_entry 
typedef struct {
    long cktag;
    long ckvalue;
} ck_entry;
#endif

#ifndef GLOBAL
#define GLOBAL 0x0020
#define ALLOCMODE 3|GLOBAL
#endif

/* A few data type definitions */

typedef short WORD;
typedef unsigned short UWORD;

/* ********** Consts ************** */
#define POINT_SIZE 12
#define Space_Code 561
#define normal_font 0
#define header_font 1
#define pre_font 2
#define scroll_bar_width 15
#define scroll_step 24
#define DOMAIN_MINT 1

#define ISO1	0
#define ATASCI	1

#define TEXT_DECODER 0
#define HTML_DECODER 1

#ifndef DESK
#define DESK 0
#endif

#ifndef WM_BOTTOMED
#define WM_BOTTOMED		33
#endif

#ifndef SCRATCH_BOTH
#define SCRATCH_BOTH 0
#define SCRATCH_BITMAP 1
#define SCRATCH_NONE 2

#define TRACK_NONE 0
#define TRACK_NORMAL 1
#define TRACK_TIGHT 2
#define TRACK_VERYTIGHT 3
#define PAIR_ON 1
#define PAIR_OFF 0
#endif

#ifdef __PUREC__

#ifndef min
#define min(a, b)             ((a) < (b) ? (a) : (b))
#endif

#ifndef max
#define max(a, b)             ((a) > (b) ? (a) : (b))
#endif

#endif /* end PUREC */

/* ********** Structures ***************** */

typedef struct 
{
	WORD handle;
	WORD dev_id;
	WORD wchar;
	WORD hchar;
	WORD wbox;
	WORD hbox;
	WORD xres;
	WORD yres;
	WORD noscale;
	WORD xpixel;
	WORD hpixel;
	WORD cheights;
	WORD linetypes;
	WORD linewidths;
	WORD markertypes;
	WORD markersizes;
	WORD faces;
	WORD patterns;
	WORD hatches;
	WORD colours;
	WORD ngdps;
	WORD cangdps[10];
	WORD gdpattr[10];
	WORD cancolour;
	WORD cantextrot;
	WORD canfillarea;
	WORD cancellarray;
	WORD palette;
	WORD locators;
	WORD valuators;
	WORD choicedevs;
	WORD stringdevs;
	WORD wstype;
	WORD minwchar;
	WORD minhchar;
	WORD maxwchar;
	WORD maxhchar;
	WORD minwline;
	WORD zero5;
	WORD maxwline;
	WORD zero7;
	WORD minwmark;
	WORD minhmark;
	WORD maxwmark;
	WORD maxhmark;
	WORD screentype;
	WORD bgcolours;
	WORD textfx;
	WORD canscale;
	WORD planes;
	WORD lut;
	WORD rops;
	WORD cancontourfill;
	WORD textrot;
	WORD writemodes;
	WORD inputmodes;
	WORD textalign;
	WORD inking;
	WORD ruberbanding;
	WORD maxvertices;
	WORD maxintin;
	WORD mousebuttons;
	WORD widestyle;
	WORD widemode;
	WORD reserved[38];
} VDI_Workstation;


/* Modified size to st_size to eliminate one #ifdef in loader.c - Baldrick */
struct xattr {
	UWORD mode;
	long index;
	UWORD dev;
	UWORD reserved1;
	UWORD nlink;
	UWORD uid;
	UWORD gid;
	long st_size;
	long blksize;
	long nblocks;
	WORD mtime;
	WORD mdate;
	WORD atime;
	WORD adate;
	WORD ctime;
	WORD cdate;
	WORD attr;
	WORD reserved2;
	long reserved3;
	long reserved4;
};

/* ************ Parsing Constructs ************************ */

/* part of attr_list() experimentation
 */

struct attr_step {
	char *attribute;
	char *value;
	struct attr_step *prev_attr_step;
};

struct clipping_area {
	WORD x;
/*	long y; */
	WORD y;
	WORD w;
	WORD h;
};

struct borders {
	WORD left;
	WORD right;
	long bottom;
};

struct font_step {
	WORD step;
	WORD colour;
	struct font_step *previous_font_step;
};

struct font_style {
	unsigned italic;
	unsigned bold;
	unsigned underlined;
	unsigned strike;
	unsigned font;
	WORD font_size;
};

struct word_changed {
	enum bool font;
	enum bool style;
	enum bool colour;
};

struct word_item {
	WORD *item;
	struct font_style styles;
	struct word_changed changed;
	BOOL line_brk;
	WORD word_width;
	WORD word_height;
	WORD word_tail_drop;
	WORD colour;
	WORD space_width;
	enum vertical_alignment vertical_align;
	struct url_link *link;
	struct word_item *next_word;
};

typedef struct paragraph_item * PARAGRPH;
struct paragraph_item {
	struct word_item *item;
	struct table_item *table;
	PARAGRAPH_CODE paragraph_code;
	enum paragraph_alignment alignment;
	WORD left_border;
	WORD right_border;
	WORD eop_space;
	WORD current_paragraph_height;
	long min_width;
	long max_width;
	struct clipping_area area;
	PARAGRPH next_paragraph;
};

struct table_step {
	struct paragraph_item *entry;
	struct table_item *parent;
	struct table_step *previous_table_step;
};

struct table_child {
	struct paragraph_item *item;
	WORD height;
	WORD width;
	WORD actual_height;
	WORD actual_width;
	WORD min_width;
	WORD alignment;
	WORD valignment;
	WORD colspan;
	WORD rowspan;
	WORD bgcolor;
	struct table_child *next_child;
};

struct table_row {
	struct paragraph_item *item;
	WORD height;
	WORD width;
	WORD actual_height;
	WORD actual_width;
	WORD min_width;
	WORD alignment;
	WORD valignment;
	WORD bgcolor;
	struct table_row *next_row;
};

struct table_item {
	WORD num_cols;
	WORD num_rows;
	WORD table_width;
	WORD actual_width;
	WORD min_width;
	long table_height;
	WORD alignment;
	WORD border;
	WORD bgcolor;
	/* ok this is Bad it needs to be reworked, but I'm not up to it atm - baldrick 11/27/01 */
	WORD col_widths[50]; /* this is a memory wasting fixed 50 column max array */
	WORD cell_spacing;
	WORD cell_padding;
	WORD num_children;
	struct borders current_borders;
	WORD screen_pts[4]; /* on screen rectangle of table */
	struct table_row *row;
	struct table_child *children;
	struct table_child *current_child;
	struct paragraph_item *current_paragraph;
};

typedef struct frame_item {
	CONTAINR Container;
	struct paragraph_item *item;
	WORD frame_width;
	WORD horizontal_scroll;
	long vertical_scroll;
	WORD frame_page_width;
	enum bool v_scroll_on;
	enum bool h_scroll_on;
	enum bool border;
	long current_page_height;
	WORD background_colour;
	WORD text_colour;
	WORD link_colour;
	struct clipping_area clip;
	struct clipping_area frame;
	struct clickable_area *first_clickable_area;
	struct named_location *first_named_location;
	char *frame_named_location;
	struct list_stack_item *current_list;
	struct paragraph_item *current_paragraph;
	WORD current_indent_distance;
	struct font_step *current_font_step;
	struct word_item *current_word;
	WORD *active_word;
	WORD current_font_size;
	struct table_step *parent_table;
	struct table_item *current_table;
	struct attr_step *current_attr;
} * FRAME;

/***** temporary -- AltF4 *
 * returns the next frame seen in a linear manner
 */
FRAME frame_next (FRAME);
/*****/

struct list_stack_item {
	enum bullets bullet_style;
	WORD current_list_count;
	struct list_stack_item *next_stack_item;
};

/* ******************** Action Constructs ************************* */

struct clickable_area {
	WORD x;
/*	long y;*/
	WORD y;
	WORD w;
	WORD h;
	struct url_link *link;
	struct clickable_area *next_area;
};

struct named_location {
	long position;
	struct url_link *link;
	struct named_location *next_location;
};

struct url_link {
	char *address;
	enum link_mode mode;
	char *target;
};
