#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "token.h" /* must be included before gem/gemx.h */
#include <gem.h>

#include "global.h"
#include "Loader.h"
#include "parser.h"
#include "fontbase.h"
#include "Containr.h"
#include "Location.h"
#include "inet.h"
#include "cache.h"


/*==============================================================================
 * Create 'about' page
 *
*/
BOOL
parse_about (void * arg)
{
	PARSER   parser  = arg;
	FRAME    frame   = parser->Frame;
	TEXTBUFF current = &parser->Current;
	char buf[100];
	const char * title = frame->Location->File;
	WORD     mode = 0; /* = normal, 1 = cache */
	CACHEINF info = NULL;
	size_t c_mem, c_num, c_clr = 0;
	
	current->font_step = new_step (3, frame->text_colour);
	
	font_byType (normal_font, 0x0000, -1, current->word);
	
	current->paragraph->alignment = ALN_CENTER;
	font_byType (header_font, FNT_BOLD, font_step2size (NULL, 7), current->word);
	
	if (strncmp ("cache", title, 5) == 0) {
		if (title[5] == '\0') {
			mode = 1;
		} else if (strncmp (title +5, "?clear", 6) == 0) {
			if (title[11] == '\0') {
				cache_clear (NULL);
				mode = 1;
			} else if (title[11] == '=') {
				char * rest;
				long   obj = strtol (title +12, &rest, 16);
				if (obj > 0 && !*rest) {
					cache_clear ((CACHED)obj);
					mode = 1;
				}
			}
		}
		if (mode) {
			containr_notify (parser->Target, HW_SetTitle, "About: Cache");
			title = "Objects in cache:";
		}
	}
	if (!mode) {
		containr_notify (parser->Target, HW_SetTitle, "About: HighWire");
		title = "Version Information";
	}
	render_text  (current, title);
	render_hrule (current, ALN_CENTER, -1024, 2);
	
	current->paragraph->alignment = ALN_LEFT;
	font_byType (normal_font, 0x0000, font_step2size (NULL, 3), current->word);
	
	c_num = cache_info (&c_mem, (mode == 1 ? &info : NULL));
	
	if (mode == 1) { /* "About: Cache" */
		if (info) {
			size_t i;
			for (i = 0; i < c_num; i++) {
				int iw = (int)(info[i].Hash >>12) & 0x0FFF;
				int ih = (int) info[i].Hash       & 0x0FFF;
				sprintf (buf, """%s"", ""%i*%i"", %li ",
				         info[i].File, iw, ih, info[i].Size);
				render_text (current, buf);
				if (info[i].Used) {
					sprintf (buf, "(%li)\r", info[i].Used);
					render_text (current, buf);
				} else {
					sprintf (buf, "about:cache?clear=0x%08lX", (long)info[i].Object);
					render_link (current, "[-]\r", buf, frame->link_colour);
					c_clr++;
				}
			}
			if (i > 0) {
				render_hrule (current, ALN_LEFT, -512, 2);
			}
			free (info);
		}
		
	} else {  /* "About: HighWire", main page */
	
		const char * i_net = inet_info();
		WORDITEM list[10], * w = &list[-1];
		WORD tab = 0;
		
		#ifdef GEM_MENU
			*(++w) = render_text (current, """GEMMenu:""""0.3""\r");
			tab    = (*w)->word_width;
		#endif
		
		*(++w) = render_text (current, """Core:"""
		                      _HIGHWIRE_VERSION_ " " _HIGHWIRE_BETATAG_ "\n");
		tab    = max (tab, (*w)->word_width);
		
		font_byType (-1, -1, font_step2size (NULL, 2), current->word);
		
		#ifdef LIBGIF
		{
			#define w /* avoid warnings due to shadowed */
			#include <gif_lib.h>
			#undef w
			const char * p = GIF_LIB_VERSION;
			while (*p && *p != '.' && !isdigit(*p)) p++;
			if (*p) {
				char * b = buf;
				*(++w) = render_text (current, """gif-lib:""");
				tab    = max (tab, (*w)->word_width);
				while (*p == '.' || isdigit(*p)) *(b++) = *(p)++;
				*(b++) = '';
				*(b++) = '\r';
				*(b)   = '\0';
				render_text (current, buf);
			}
		}
		#endif
		
		sprintf (buf, """GEMlib:""""%i.%02i.%i"" " __GEMLIB_BETATAG__ "\r",
		         __GEMLIB_MAJOR__, __GEMLIB_MINOR__, __GEMLIB_REVISION__);
		*(++w) = render_text (current, buf);
		tab    = max (tab, (*w)->word_width);
		
		#ifdef __MINTLIB__
			sprintf (buf,
			         """MiNTlib:""""%i.%02i.%i"" " __MINTLIB_BETATAG__ "\r",
			         __MINTLIB_MAJOR__, __MINTLIB_MINOR__, __MINTLIB_REVISION__);
			*(++w) = render_text (current, buf);
			tab    = max (tab, (*w)->word_width);
		#endif
		
		*(++w) = render_text (current, """compiled:""");
		tab    = max (tab, (*w)->word_width);
		#if defined (__GNUC__)
			sprintf (buf, "Gnu C """"%i.%02i, ", __GNUC__, __GNUC_MINOR__);
			render_text (current, buf);
		#elif defined (__PUREC__)
			sprintf (buf, "Pure C """"%i.%02x, ",
			         __PUREC__ >>8, __PUREC__ & 0xFF);
			render_text (current, buf);
		#elif defined (LATTICE)
			render_text (current, "Lattice C\n");
		#endif
		render_text (current, ""__DATE__ ", " __TIME__"\n");
		
		/* align left column */
		do {
			(*w)->word_width = tab;
		} while (--w >= list);
		
		font_byType (-1, -1, font_step2size (NULL, 3), current->word);
		if (i_net) {
			sprintf (buf, "(%s support enabled)", i_net);
			render_text (current, buf);
		}
		render_hrule (current, ALN_LEFT, -512, 2);
		
		render_link (current, "cached: ", "about:cache", frame->link_colour);
		c_clr = 1; /* show the 'clear' link always */
	}
	
	if (c_num) {
		sprintf (buf, "%lu object%s, %lu bytes ",
		         c_num, (c_num > 1 ? "s" : ""), c_mem);
		render_text (current, buf);
		if (c_clr) {
			render_link (current,
			             "[clear]", "about:cache?clear", frame->link_colour);
		} else {
			WORDITEM w = render_text (current, "[clear]");
			TA_Color(w->attr) = G_LBLACK;
		}
	} else {
		render_text (current, "(empty)");
	}
	
	word_store (current);

	delete_parser (parser);
		
	return FALSE;
}
