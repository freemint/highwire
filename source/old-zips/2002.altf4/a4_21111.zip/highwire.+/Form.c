#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "token.h"
#include <gemx.h>

#include "global.h"
#include "Form.h"
#include "fontbase.h"
#include "scanner.h"
#include "Loader.h"
#include "parser.h"


typedef struct s_form  * FORM;
typedef struct s_input * INPUT;

struct s_form {
	FRAME       Frame;
	FORM        Next;
	char      * Target;
	char      * Action;
	INPUT       RadioList;
	INPUT       RadioChck;
	FORM_METHOD Method;
};

typedef enum {
	IT_HIDDN = 1,
	IT_RADIO,
	IT_CHECK,
	IT_BUTTN,
	IT_TEXT
} INP_TYPE;

struct s_input {
	INPUT    Next;
	WORDITEM Word;
	PARAGRPH Paragraph;
	FORM     Form;
	INP_TYPE Type;
	BOOL     checked;
};


/*============================================================================*/
void *
new_form (FRAME frame, char * target, char * action, const char * method)
{
	FORM form = malloc (sizeof (struct s_form));
	
	form->Frame     = frame;
	form->Next      = frame->FormList;
	frame->FormList = form;
	
	form->Target = target;
	form->Action = action;
	form->Method = (method && stricmp (method, "post") == 0
	                ? METH_POST : METH_GET);
	form->RadioList = NULL;
	form->RadioChck = NULL;
	
	return form;
}


/*----------------------------------------------------------------------------*/
static INPUT
_alloc (INP_TYPE type, TEXTBUFF current, INPUT next)
{
	INPUT input = malloc (sizeof (struct s_input));
	input->Next      = next;
	input->Word      = current->word;
	input->Paragraph = current->paragraph;
	input->Form      = current->form;
	input->Type      = type;
	input->checked   = FALSE;
	
	return input;
}

/*----------------------------------------------------------------------------*/
static INPUT
form_radio (TEXTBUFF current, BOOL checked)
{
	FORM  form  = current->form;
	INPUT input = _alloc (IT_RADIO, current, form->RadioList);
	if (checked && !form->RadioChck) {
		input->checked  = TRUE;
		form->RadioChck = input;
	}
	form->RadioList = input;
	
	*(current->text++) = font_Nobrk(current->word->font);
	
	return input;
}

/*============================================================================*/
void *
new_input (PARSER parser)
{
	INPUT    input   = NULL;
	FRAME    frame   = parser->Frame;
	TEXTBUFF current = &parser->Current;
	WORDITEM word    = current->word;
	INP_TYPE type    = 0;
	BOOL     checked = FALSE;
	short    maxlen  = 0;
	short    asc     = word->word_height;
	short    dsc     = word->word_tail_drop;
	short    wid     = 0;
	char output[100];
	
	if (!current->form) {
		current->form = new_form (frame, NULL, NULL, NULL);
	}
	
	if (get_value (parser, KEY_TYPE, output, sizeof(output))) {
		const char * val;
		
		if (stricmp (output, "HIDDEN") == 0) {
			type = IT_HIDDN;
			word = NULL;
			
		} else if (stricmp (output, "RADIO") == 0) {
			input = form_radio (current, get_value (parser, KEY_CHECKED, NULL,0));
			if      ((asc -= dsc) < 1) asc = 1;
			else if (!(asc & 1))       asc++;
			dsc = 0;
			wid = asc;
			
		} else if (stricmp (output, "CHECKBOX") == 0) {
			type = IT_CHECK;
			checked = get_value (parser, KEY_CHECKED, NULL,0);
			*(current->text++) = font_Nobrk(current->word->font);
			if ((asc -= dsc +2) < 2) asc = 2;
			dsc = -1;
			wid = asc + dsc;
			
		} else if (stricmp (output, val = "Button") == 0 ||
		           stricmp (output, val = "Reset")  == 0 ||
		           stricmp (output, val = "Submit") == 0) {
			type = IT_BUTTN;
			if (get_value (parser, KEY_VALUE, output, sizeof(output))) {
				val = output;
			}
			if (!*val) {
				*(current->text++) = font_Nobrk(current->word->font);
			} else {
				scan_string_to_16bit (val, frame->Encoding, &current->text,
				                      current->word->font->Base->Mapping);
			}
			dsc++;
			
		} else if (stricmp (output, val = "TEXT")     == 0 ||
		           stricmp (output, val = "FILE")     == 0 ||
		           stricmp (output, val = "PASSWORD") == 0) {
			type = IT_TEXT;
			maxlen = get_value_unum (parser, KEY_MAXLENGTH, 0);
			if ((wid = get_value_unum (parser, KEY_SIZE, 0)) == 0) {
				if (!maxlen) maxlen = 20;
				wid = maxlen;
			} else if (!maxlen) {
				maxlen = wid;
			}
			*(current->text++) = font_Nobrk(current->word->font);
		}
	}
	
	if (type || input) {
		if (!input) {
			input = _alloc (type, current, NULL);
		}
		if (checked) {
			input->checked = TRUE;
		}
		if (word) {
			if (input->Type >= IT_BUTTN) {
				TEXTATTR word_attr = word->attr;
				if (wid) {
					font_byType (pre_font, 0x0000, -1, word);
					new_word (current, TRUE)->attr = word_attr;
					wid *= word->space_width;
				} else {
					font_byType (-1, 0x0000, -1, word);
					new_word (current, TRUE)->attr = word_attr;
					wid = word->word_width +2;
				}
			} else {
				new_word (current, TRUE);
			}
			word->input          = input;
			word->word_height    = asc +2;
			word->word_tail_drop = dsc +2;
			word->word_width     = wid +4;
		}
	}
	
	return input;
}


/*============================================================================*/
void
input_draw (void * _inp, WORD x, WORD y)
{
	INPUT    input = _inp;
	WORDITEM word = input->Word;
	short c_lu, c_rd;
	PXY p[5];
	p[2].p_x = (p[0].p_x = x) + word->word_width -1;
	p[1].p_y = y - word->word_height;
	p[3].p_y = y + word->word_tail_drop -1;
	
	if (input->Type >= IT_TEXT) {
		vsf_color (vdi_handle, G_WHITE);
		vsl_color (vdi_handle, G_LBLACK);
		c_lu = G_BLACK;
		c_rd = G_LWHITE;
	} else if (input->checked) {
		vsf_color (vdi_handle, G_LBLACK);
		vsl_color (vdi_handle, G_BLACK);
		c_lu = G_BLACK;
		c_rd = G_WHITE;
	} else {
		vsf_color (vdi_handle, G_LWHITE);
		vsl_color (vdi_handle, G_BLACK);
		c_lu = G_WHITE;
		c_rd = G_LBLACK;
	}
	if (input->Type == IT_RADIO) {
		p[1].p_x = p[3].p_x = (p[0].p_x + p[2].p_x) /2;
		p[0].p_y = p[2].p_y = (p[1].p_y + p[3].p_y) /2;
	} else {
		p[0].p_y = p[3].p_y;
		p[1].p_x = p[0].p_x;
		p[2].p_y = p[1].p_y;
		p[3].p_x = p[2].p_x;
	}
	p[4]     = p[0];
	v_fillarea (vdi_handle, 4, (short*)p);
	v_pline    (vdi_handle, 5, (short*)p);
	if (input->Type == IT_RADIO) {
		vsl_color (vdi_handle, c_lu);
		p[0].p_x++;
		p[1].p_y++; 
		v_pline (vdi_handle, 2, (short*)p);
		p[0].p_x++;
		p[1].p_y++; 
		v_pline (vdi_handle, 2, (short*)p);
		vsl_color (vdi_handle, c_rd);
		p[1].p_x++;   p[2].p_x -= 2;   p[4].p_x = p[0].p_x +1;
		p[1].p_y++;   p[3].p_y -= 2;   p[4].p_y = p[0].p_y +1;
		v_pline (vdi_handle, 4, (short*)(p +1));
		p[2].p_x++;
		p[3].p_y++; 
		v_pline (vdi_handle, 2, (short*)(p +2));
	
	} else {
		vsl_color (vdi_handle, c_lu);
		p[1].p_x = ++p[0].p_x;   p[2].p_x -= 2;
		p[1].p_y = ++p[2].p_y;   p[0].p_y -= 2;
		v_pline (vdi_handle, 3, (short*)p);
		if (input->Type == IT_BUTTN) {
			p[1].p_x = ++p[0].p_x;  --p[2].p_x;
			p[1].p_y = ++p[2].p_y;  --p[0].p_y;
			v_pline (vdi_handle, 3, (short*)p);
			vsl_color (vdi_handle, c_rd);
			p[0].p_x++;   p[1].p_x = ++p[2].p_x;
			p[2].p_y++;   p[1].p_y = ++p[0].p_y;
			v_pline (vdi_handle, 3, (short*)p);
			p[0].p_x--;
			p[2].p_y--;
		} else {
			vsl_color (vdi_handle, c_rd);
			p[0].p_x++;
			p[2].p_y++;
		}
		p[1].p_x = ++p[2].p_x;
		p[1].p_y = ++p[0].p_y;
		v_pline (vdi_handle, 3, (short*)p);
	}
	if (input->Type >= IT_BUTTN) {
		v_ftext16 (vdi_handle, x +3, y, word->item);
	}
}


/*============================================================================*/
BOOL
input_isEdit (void * _inp)
{
	INPUT input = _inp;
	
	return (input->Type >= IT_TEXT);
}


/*============================================================================*/
WORD
input_handle (void * _inp, GRECT * radio)
{
	INPUT input = _inp;
	WORD  rtn;
	
	switch (input->Type) {
		case IT_RADIO:
			if (input->checked) {
				rtn = 0;
			} else if (!input->Form->RadioChck) {
				input->checked = TRUE;
				rtn = 1;
			} else {
				INPUT check = input->Form->RadioChck;
				input->Form->RadioChck = input;
				radio->g_x = (check->Paragraph->Offset.X + check->Paragraph->Indent
				              + check->Word->h_offset)
				           - (input->Paragraph->Offset.X + input->Paragraph->Indent
				              + input->Word->h_offset);
				radio->g_y = word_offset (check->Word) - word_offset (input->Word);
				radio->g_w = check->Word->word_width;
				radio->g_h = check->Word->word_height + check->Word->word_tail_drop;
				check->checked = FALSE;
				input->checked = TRUE;
				rtn = 2;
			}
			break;
		case IT_CHECK:
			input->checked = !input->checked;
			rtn = 1;
			break;
		case IT_BUTTN:
			if (!input->checked) {
				input->checked = TRUE;
				rtn = 1;
				break;
			}
		default:
			rtn = 0;
	}
	return rtn;
}
