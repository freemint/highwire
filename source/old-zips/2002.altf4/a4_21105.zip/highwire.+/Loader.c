/* @(#)highwire/Loader.c
 *
 * Currently has ended up a junk file of initializations
 * loading routine and some assorted other routines
 * for file handling.
 */
#ifdef __PUREC__
#include <tos.h>
#include <ext.h>
#endif

#ifdef LATTICE
#include <dos.h>
#include <mintbind.h>

/* I'm certain this is in a .H somewhere, just couldn't find it - Baldrick*/
#define O_RDONLY    0x00
#define DTA struct FILEINFO
#define d_length size
#define E_OK		0x00
#endif

#ifdef __GNUC__
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>
# include <mintbind.h>
#endif

#include <gemx.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "global.h"
#include "av_comm.h"
#include "schedule.h"
#include "Containr.h"
#include "Location.h"
#include "Loader.h"
#include "http.h"
#include "inet.h"
#include "cache.h"
#include "hwWind.h"


static char *load_file (const LOCATION, ENCODING);


/*******************************************************************************
 * the following function should placed either in parse.c or render.c but
 * at the moment I have no clue where to do it best - AltF4 Feb. 4, 2002
 */

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * job function for parsing a file and attach it to the passed frame
 */
static BOOL
parser_job (void * arg)
{
	LOADER   loader = arg;
	CONTAINR cont   = loader->Target;
	FRAME    frame  = new_frame (loader->Location, loader->Encoding,
	                             loader->MarginW, loader->MarginH);

	frame->Container = cont;
	
	containr_clear (cont);
	cont->u.Frame = frame;
	
	switch (loader->MimeType)
	{
		case MIME_IMAGE:
			parse_image (NULL, frame);
			break;
		
		case MIME_TXT_HTML:
			if (loader->Location->Proto == 1) {
				parse_about (NULL, frame);
			} else if (loader->Location->File[0] == '\0') {
				parse_dir (NULL, frame);
			} else {
				parse_html (loader->Data, frame);
			}
			break;
		
		case MIME_TEXT: {
			char * p = loader->Data;
			while (isspace(*p)) p++;
			if (strncmp(p, "<!--", 4) == 0) {
				long i = min(500, (long)(loader->Data - p) + loader->DataSize - 15);
				while (--i > 0 && *(p++) != '>');
				while (--i > 0 && isspace(*p)) p++;
			}
			if (strnicmp (p, "<html>",          6) == 0 ||
			    strnicmp (p, "<!DOCTYPE HTML", 14) == 0) {
				parse_html (loader->Data, frame);
				break;
			}
		}
		default: /* pretend it's text */
			parse_text (loader->Data, frame);
	}

	if (!cont->Mode) {
		containr_setup  (cont, frame, loader->Location->Anchor);
		containr_notify (cont, HW_PageFinished, &cont->Area);
	
	} else {
		delete_frame (&frame);
		containr_calculate (cont, NULL);
		containr_notify    (cont, HW_PageFinished, NULL);
	}
	
	delete_loader (&loader);

	return FALSE;
}

/******************************************************************************/


/*============================================================================*/
const struct {
	const char * Ext;
	const MIMETYPE Type;
	const char * Appl;
}
mime_list[] = {
	{ "au",   MIME_AUDIO,      "GEMJing"  },
	{ "avr",  MIME_AUDIO,      "GEMJing"  },
	{ "dvs",  MIME_AUDIO,      "GEMJing"  },
	{ "gif",  MIME_IMG_GIF,    NULL       },
	{ "hsn",  MIME_AUDIO,      "GEMJing"  },
	{ "htm",  MIME_TXT_HTML,   NULL       },
	{ "html", MIME_TXT_HTML,   NULL       },
	{ "hyp",  MIME_APPL,       "ST-Guide" },
	{ "img",  MIME_IMG_X_XIMG, ""         },
	{ "jpeg", MIME_IMG_JPEG,   ""         },
	{ "jpg",  MIME_IMG_JPEG,   ""         },
	{ "mpg",  MIME_VID_MPEG,   "ANIPLAY"  },
	{ "pdf",  MIME_APP_PDF,    "MyPdf"    },
	{ "png",  MIME_IMG_PNG,    ""         },
	{ "snd",  MIME_AUDIO,      "GEMJing"  },
	{ "txt",  MIME_TXT_PLAIN,  NULL       },
	{ "wav",  MIME_AUDIO,      "GEMJing"  }
};
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
LOADER
new_loader (LOCATION loc)
{
	const char * ext;
	LOADER loader = malloc (sizeof (struct s_loader));
	loader->Location = location_share (loc);
	loader->Target   = NULL;
	loader->MimeType = MIME_TEXT;
	loader->Socket   = -1;
	loader->isChunked = 0;
	loader->DataSize  = 0;
	loader->DataFill  = 0;
	loader->Data      = NULL;
	
	if (loc->Proto == 2) {
		/*
		 * 'mailto:' request, to be handled by external application
		 */
		const char head[] = "mailto:";
		size_t len = strlen (loc->File);
		loader->Data = malloc (sizeof(head) + len);
		memcpy (loader->Data, head, sizeof(head) -1);
		memcpy (loader->Data + sizeof(head) -1, loc->File, len +1);
	
	} else if ((ext = strrchr (loc->File, '.')) != NULL && *(++ext)) {
		/*
		 * resolve the MIME type depending on the file name extension
		 */
		size_t i = 0;
		do if (stricmp (ext, mime_list[i].Ext) == 0) {
			loader->MimeType = mime_list[i].Type;
			if (mime_list[i].Appl) {
				loader->Data  = strdup (mime_list[i].Appl);
			}
			break;
		} while (++i < numberof(mime_list));
		
	} else if (loc->File[0] == '\0') { /* directory listing or default file */
		loader->MimeType = MIME_TXT_HTML;
	}
	return loader;
}


/*============================================================================*/
void
delete_loader (LOADER * p_loader)
{
	LOADER loader = *p_loader;
	if (loader) {
#ifdef USE_INET
		inet_close (loader->Socket);
#endif /* USE_INET */
		free_location (&loader->Location);
		if (loader->Data) free (loader->Data);
		free (loader);
		*p_loader = NULL;
	}
}


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#ifdef USE_INET
static BOOL
receive_job (void * arg)
{
	LOADER loader = arg;
	long   left = loader->DataSize - (loader->DataFill - loader->isChunked);
	char * p    = loader->Data     +  loader->DataFill;
	long   n    = -1;
	
/*	printf ("recive '%s' (%li) %li/%li+%i \n",
	        loader->Location->FullName, loader->DataFill,
	        left, loader->DataSize, loader->isChunked);
*/	
	while (left > 0 && (n = inet_recv (loader->Socket, p, left)) > 0) {
		p    += n;
		left -= n;
	}
	loader->DataFill = p - loader->Data;
	*p = '\0';
	
	if (!n && left) {
		return TRUE; /* re-schedule */
	}
	
	if (loader->isChunked && loader->DataFill > loader->DataSize) {
		char * ln_brk;
		char * chunk = loader->Data + loader->DataSize;
		*(chunk++) = '\0';
		if (*chunk == '\n') chunk++;
		
		loader->DataFill = loader->DataSize;
		
		if ((ln_brk = strchr (chunk, '\n')) != NULL) {
			char * tail = chunk;
			long   size = strtoul (chunk, &tail, 16);
			if (size > 0 && tail > chunk && tail <= ln_brk) {
				char * mem;
				loader->DataSize += size;
				if ((mem = malloc (loader->DataSize
				                   + loader->isChunked +1)) != NULL) {
					memcpy (mem, loader->Data, loader->DataFill);
					while (*(++ln_brk)) {
						mem[loader->DataFill++] = *ln_brk;
					}
					free (loader->Data);
					loader->Data = mem;
					
					return TRUE; /* re-schedule */
				}
			}
		}
	}
	inet_close (loader->Socket);
	loader->Socket   = -1;
	
	sched_insert (parser_job, loader);
	
	return FALSE;
}
#endif /* USE_INET */

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
static BOOL
loader_job (void * arg)
{
	LOADER loader = arg;
	
	if (loader->Location->Proto == 3) {
#ifdef USE_INET
		HTTP_HDR hdr;
		short    sock  = -1;
		short    reply = http_header (loader->Location, &hdr, &sock);
		
		if (hdr.MimeType) {
			loader->MimeType = hdr.MimeType;
			if (hdr.Encoding) {
				loader->Encoding = hdr.Encoding;
			}
		}
		if ((reply == 301 || reply == 302) && hdr.Rdir) {
			LOCATION loc = new_location (hdr.Rdir, loader->Location);
			free_location (&loader->Location);
			loader->Location = loc;
			inet_close (sock);
			
			return TRUE; /* re-schedule with the new location */
			
		} else if (reply == 200 && MIME_Major(loader->MimeType) == MIME_TEXT
		           && hdr.Size > 0) {
			loader->isChunked = (hdr.Chunked ? 10 : 0);
			loader->DataSize  = hdr.Size;
			loader->DataFill  = strlen (hdr.Tail);
			
			if (sock < 0) {
				loader->Data = malloc (loader->DataFill +1);
				memcpy (loader->Data, hdr.Tail, loader->DataFill +1);
				inet_close (sock);
			
			} else {
				loader->Socket = sock;
				loader->Data   = malloc (loader->DataSize + loader->isChunked +1);
				memcpy (loader->Data, hdr.Tail, loader->DataFill);
				
				sched_insert (receive_job, loader);
				return FALSE;
			}
		
		} else {
			loader->MimeType = MIME_TEXT;
			loader->Data     = strdup (hdr.Head);
		}
#endif /* USE_INET */
	} else {
		loader->Data = load_file (loader->Location, loader->Encoding);
	}
	if (!loader->Data) {
		loader->Data     = strdup ("<html><head><title>Error</title></head>"
		                           "<body><h1>Page not found!</h1></body></html>");
		loader->MimeType = MIME_TXT_HTML;
	}
	/* registers a parser job with the scheduler */
	sched_insert (parser_job, loader);

	return FALSE;
}


/*----------------------------------------------------------------------------*/
static short
find_application (const char * name)
{
	short id = -1;

	if (name == NULL && ((name = getenv ("AVSERVER")) == NULL || !*name)) {
		static const char * list[] = {
			"AVServer", "Jinnee", "Thing", "MagxDesk", "GEMINI",
			"StrngSrv", "DIRECT", "EASY",  "KAOS",
			NULL };
		const char ** desktop = list;
		while ((id = find_application (*desktop)) < 0 && *(++desktop));

	} else if (name && *name) {
		char buf[] = "        ", * p = buf;
		while (*name && *p) *(p++) = toupper (*(name++));
		id = appl_find (buf);
	}
	return id;
}


/*==============================================================================
 * small routine to call external viewer to view the SRC to
 * a file so that realtime comparisons can be made
 * baldrick August 9, 2002
*/
void
launch_viewer(const char *name)
{
	short id = find_application ("Viewer");

	if (id >= 0 || (id = find_application (NULL)) >= 0) {
		short msg[8];
		msg[0] = (VA_START);
		msg[1] = gl_apid;
		msg[2] = 0;
		*(char**)(msg +3) = strcpy (va_helpbuf, name);
		msg[5] = msg[6] = msg[7] = 0;
		appl_write (id, 16, msg);
	}
}

/*==============================================================================
 * registers a loader job with the scheduler.
 *
 * The parameters 'address', 'base' or 'target' can be NULL.
 * address == NULL: reread the file in base with default_encoding
 */
void
new_loader_job (const char *address, LOCATION base, CONTAINR target,
                ENCODING encoding, short margin_w, short margin_h)
{
	LOCATION loc    = new_location (address, base);
	LOADER   loader = new_loader (loc);
	
	loader->Target   = target;
	loader->Encoding = encoding;
	loader->MarginW  = margin_w;
	loader->MarginH  = margin_h;

	if (loc->Proto == 1) { /* 'about:' request */
		loader->MimeType = MIME_TXT_HTML;
		sched_insert (parser_job, loader);
	
	} else if (loc->Proto == 2) { /* 'mailto:' request */
		short id = id = find_application (NULL);
		if (id >= 0) {
			short msg[8] = { VA_START, };
			msg[1] = gl_apid;
			msg[2] = 0;
			*(char**)(msg +3) = strcpy (va_helpbuf, loader->Data);
			msg[5] = msg[6] = msg[7] = 0;
			appl_write (id, 16, msg);
		}
		delete_loader (&loader);
	
#ifdef USE_INET
	} else if (loc->Proto == 3) {
		sched_insert (loader_job, loader);
#endif /* USE_INET */
	
	} else if (loader->Data) {
		short           id = find_application (loader->Data);
		if (id >= 0 || (id = find_application (NULL)) >= 0) {
			short msg[8];
			msg[0] = (loader->MimeType == MIME_APP_PDF
			          ? PDF_AV_OPEN_FILE : VA_START);
			msg[1] = gl_apid;
			msg[2] = 0;
			*(char**)(msg +3) = strcpy (va_helpbuf, loc->FullName);
			msg[5] = msg[6] = msg[7] = 0;
			appl_write (id, 16, msg);

			if (target && !target->Mode) {
				free (loader->Data);
				loader->Data     = strdup ("\n\tLoading application...\n");
				loader->MimeType = MIME_TXT_PLAIN;

				containr_notify (target, HW_PageStarted, loc->FullName);
				sched_insert (parser_job, loader);

			} else {
				delete_loader (&loader);
			}
		}
	} else if (loc->Proto) {
		loader->Data     = strdup ("<html><head><title>Error</title></head>"
		                           "<body><h1>Protocol not supported!</h1></body>"
		                           "</html>");
		loader->MimeType = MIME_TXT_HTML;
		sched_insert (parser_job, loader);
	
	} else if (!loc->File[0]) {
		sched_insert (parser_job, loader);
		
	} else if (MIME_Major(loader->MimeType) == MIME_IMAGE) {
		loader->MimeType = MIME_IMAGE;
		sched_insert (parser_job, loader);
		
	} else {
		containr_notify (target, HW_PageStarted, loc->FullName);
		sched_insert (loader_job, loader);
	}
	
	free_location (&loc);
}


/******************************************************************************/

/* This is simply used at the moment to track the last working file */
char last_location[HW_PATH_MAX] = "\0";
ENCODING last_encoding = ENCODING_WINDOWS1252;

/* this is to store last page for backing up */
char prev_location[HW_PATH_MAX] = "\0";
ENCODING prev_encoding;


/*
 * get_fpath - gets a file path from a full path
 *
 * This probably should be elsewhere, but since I'm the only
 * person experimenting at the moment it sits here where I 
 * can easily find it - baldrick July 10, 2001
 */

static void
get_fpath(char *dest, const char *src)
{
	int i;

	for (i = (int)strlen(src); i >= 0; --i)
	{
		if (src[i] == '\\')
			break;
	}

	strcpy(dest, src);
	dest[i + 1] = '\0';
}


/* load_file
 * I modified the hell out of this to do local searching
 * It is probably not the prettiest.  - baldrick July 10, 2001
 */

static char *
load_file (const LOCATION loc, ENCODING encoding)
{
	static const char *pdf_ident=".pdf";
	const char *filename = loc->FullName;

	long size;

	/* a place to work */
	char temp_location[HW_PATH_MAX];

	char *file = NULL;

	int i;
	BOOL search_once = FALSE;

load_file_top:

	size = 0;

#ifdef DEBUG
	fprintf (stderr, "load_file: %s\n", filename);
#endif

	if(strstr (filename, pdf_ident) != NULL)
	{
		Send_AV(0, PDF_AV_OPEN_FILE, filename, NULL);

		/*	This must the full path the the file */
		/*	In this part should also be recognized anothe type of file (png, jpg,
		   avi, mov...)	*/
		/*	The file extensions (like .pdf)	should be stored not in the local
		   variable !!! */

		return(NULL);
	}
	else
	{
		/* local file or directory */

	#ifndef LATTICE
		struct stat file_info;

		/* If there is no file name, try to open the default file index.htm[l].
		 */
		if (loc->File[0] == '\0') {
			strcpy(temp_location, filename);
			strcat(temp_location, "index.html");
			if (stat(temp_location, &file_info) == 0) {
				filename = temp_location;
			} else {
				temp_location[strlen(temp_location) - 1] = '\0';
				if (stat(temp_location, &file_info) == 0) {
					filename = temp_location;
				} else {
					/* Create a directory listing of 'filename' in a temporary
					 * file.  Then open it.
					 * BUG:  not implemented!
					 */
				}
			}
		}

		if (stat (filename, &file_info) == 0)
			size = file_info.st_size;

	#else
		/* for Lattice */
		struct xattr file_info;
		long r;

		r = Fxattr(0, filename, &file_info);
		
		if (r != EINVFN) {  /* Fxattr() exists */
			if (r == E_OK)
				size = file_info.st_size;
		} else {  /* here for TOS filenames */
			DTA *old, new;

			old = Fgetdta();
			Fsetdta(&new);

			if (Fsfirst(filename, 0) == E_OK)
				size = new.d_length;

			Fsetdta(old);
		}
	#endif

		if (size)
		{
			int fh;

			fh = open (filename, O_RDONLY);

			file = malloc (size + 1);
			if (fh > 0 && file) {
				read (fh, file, size);
				close (fh);

				file[size] = '\0';

				/* store filename locally to keep it from being eaten */
				strcpy(temp_location,filename);

				/* if not reloading, then grab old last location in case the
				 * user wishes to go back to previous page
				 */
				if (strcmp(filename, last_location) != 0) 
				{
					strcpy(prev_location,last_location);
					prev_encoding = last_encoding;

					/* store the last successful location as a base ref for next
					 * if it is needed
					 * last_encoding will be updated if exist
					 * <META HTTP-EQUIV="Content-Type" CONTENT="... charset=...">
					 */

					strcpy(last_location,temp_location);
	
					/* the window title will be changed if a TITLE tag exists */
				/*	wind_set_str(window_handle, WF_NAME, filename);
					wind_set_str(window_handle, WF_INFO, filename);
				*/
				}
				/* The last_encoding is updated for every successful loaded
				 * file, since the user can try to find the suitable encoding
				 * for a text file.  We have to use the users decision when
				 * going back to this page. */
				last_encoding = encoding;
			}
		}
		else if (!search_once)
		{
			/* set search once to TRUE so that we don't loop forever */
			search_once = TRUE;

			/* file not here, but local so search? */

			get_fpath(temp_location, last_location);

			/* cat the new file onto the last location */

			strcat(temp_location,filename);

			/* Now we need to check if the have any forward
			 * slashes in their filename, since we are opening
			 * a local file, we need to convert them to backslash
			 */

			for (i = 0;i<strlen(temp_location);i++)
			{
				if (temp_location[i] == '/')
					temp_location[i] = '\\';
			}

			/* point filename to new location */
			filename = (char *)&temp_location[0];

			/* restart the loading */
			goto load_file_top;
		}
	}

	return file;
}


#if 0 /***** REPLACED *****/

/* init_load(char *file)
 *
 * file ->  URI of resource to load
 *
 * Handles initialization of loader routines and opens window
 *
 * This routine just moves alot of junk out of the main() routine
 * that doesn't necessarily belong there
 *
 * Realistically this should be probably renamed, reworked
 * and expanded
 *
 * Baldrick (Feb 28, 2001)
 *
 * modifications to handle new add_load_item_to_to_do_list()
 * baldrick (sept 6, 2001)
 *
 * wind_set( ADDR) for LATTICE
 * David Leaver Dec 21, 2001
 */

void
init_load(const char *file)
{
	static CONTAINR _base_container = NULL;

	if (!_base_container) {
		extern void wind_handler (HW_EVENT, long, CONTAINR, const void *);
		_base_container = new_containr (NULL);
		containr_register (_base_container, wind_handler, 0);
/*	} else {
		containr_clear (_base_container);
*/	}
/*	the_first_frame = new_frame (NULL, NULL);
	containr_setup (_base_container, the_first_frame);
*/
	wind_set_str   (window_handle, WF_NAME, file);
	wind_set_str   (window_handle, WF_INFO, file);
	wind_open      (window_handle, 50, 50, 600, 354);
	wind_get_grect (window_handle, WF_WORKXYWH, &_base_container->Area);
	set_mouse_watch (MO_ENTER, &_base_container->Area);

	/* set our window status to normal */
	win_status = 0;
	
	new_loader_job (file, NULL, _base_container, ENCODING_WINDOWS1252, -1,-1);
}
#endif /***** REPLACED *****/


/* added 10-04-01 mj. required for file selector */
#define EOS       '\0'  /* End of string */
#define BACKSLASH '\\'
static char fsel_path[HW_PATH_MAX];
char help_file[HW_PATH_MAX];

static void build_fname(char *dest, const char *s1, const char *s2)
{
	char *cptr;

	strcpy(dest, s1);  /* copy path */
	cptr = strrchr(dest, (int)BACKSLASH);  /* search last \ */
	if (cptr)
		strcpy(++cptr, s2);  /* there add the file name */
}


/* page_load
 *
 * calls the fileselector and loads the selected file
 *
 * added 10-04-01 mj.
 *
 * simplified AltF4 December 26, 2001
 *
 * return modified Rainer Seitel May 2002
 */
BOOL page_load(void)
{
	char fsel_file[HW_PATH_MAX] = "",
	     file[HW_PATH_MAX];
	WORD r, butt;  /* file selector exit button */

	if ((gl_ap_version >= 0x140 && gl_ap_version < 0x200)
	    || gl_ap_version >= 0x300 /* || getcookie(FSEL) */)
		r = fsel_exinput(fsel_path, fsel_file, &butt, "HighWire: Open HTML or text");
	else
		r = fsel_input(fsel_path, fsel_file, &butt);

	if (r && butt != FSEL_CANCEL)
	{
		build_fname (file, fsel_path, fsel_file);
		new_loader_job (file, NULL,
		                hwWind_Top->Pane, ENCODING_WINDOWS1252, -1,-1);
	}
	return butt;
}


/* init_paths
 *
 * Handles the initialization of the file paths
 *
 *  Currently just sets last_location to something in the directory
 * from which HighWire was launched, so that people on certain
 * systems can get the default values
 *
 * this could be useful for config files, RSC files etc.
 *
 * baldrick (August 14, 2001)
 */

void
init_paths(void)
{
	char config_file[HW_PATH_MAX];

	config_file[0] = Dgetdrv();
	config_file[0] += (config_file[0] < 26)? 'A' : -26 + '1';
	config_file[1] = ':';
	Dgetpath(config_file + 2, 0);

	if (config_file[strlen(config_file) - 1] != '\\')
		strcat(config_file,"\\");
		
/*		config_file[strlen(config_file)] = '\\'; old */

	strcpy(last_location, config_file);  /* save the start path */

	strcat(config_file, "highwire.cfg");

	/* this should be nicer than this crap test */

/*	if (read_config(config_file) == -1)
		form_alert(1, "[1][No configuration file |highwire.cfg found!][  OK  ]");
*/
	read_config(config_file);

	strcpy(fsel_path, last_location);  /* used by the first file selector call */
	strcat(fsel_path, "html\\*.HTM*");  /* uppercase is for the TOS file selector */

	strcpy(help_file, last_location);  /* used for keyboard F1 or Help */
	strcat(help_file, "html\\hwdoc.htm#Use");

	strcat(last_location, "html\\highwire.htm");
}


/* This identifies what AES you are running under.
 */

WORD
identify_AES(void)
{
	long	search_id;
	long	*search_p = (long *)Setexc(0x5A0/4, (void (*)())-1);
	WORD	retv = AES_single;

	if (search_p != NULL) {
		while ((search_id = *search_p) != 0) {
			if (search_id == 0x4D674D63L/*MgMc*/ || search_id == MagX_cookie)
				retv = AES_MagiC;
			if (search_id == 0x6E414553L/*nAES*/)
				retv = AES_nAES;
			if (search_id == 0x476E7661L/*Gnva*/)
				retv = AES_Geneva;

			search_p += 2;
		}
	}

	return retv;
}	/* Ends:	WORD identify_AES(void) */


/* Looks for MiNT or MagiC Cookies.  If found TRUE returned,
 * which indicates we can call extended Mxalloc() with GLOBAL flag.
 */

BOOL
can_extended_mxalloc(void)
{
	long	search_id;
	long	*search_p = (long *)Setexc(0x5A0/4, (void (*)())-1);
	BOOL	retv = FALSE;

	if (search_p != NULL) {
		while ((search_id = *search_p) != 0) {
			if (search_id == 0x4D674D63L || search_id == MagX_cookie
			   || search_id == 0x4D694E54L) {
				retv = TRUE;
				break;
			}
			search_p += 2;
		}
	}

	return retv;
}
