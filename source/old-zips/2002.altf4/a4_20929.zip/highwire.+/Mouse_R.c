/* @(#)highwire/Mouse_R.c
 */
#include <stdlib.h>
#include <string.h>

#include <gemx.h>

#include "global.h"
#include "Containr.h"
#include "Loader.h"


/*
 * handles mouse interaction with a frame
 */
void
button_clicked (WORD button, WORD mx, WORD my)
{
	CONTAINR cont = NULL;
	void   * hash = NULL;
	GRECT    watch;
	WORD     decx = 0, decy = 0;
	
	EVMULT_IN multi_in = { 0, };
	
	UWORD elem  = containr_Element (&cont, mx, my, &watch, NULL, &hash);
	FRAME frame = containr_Frame (cont);
	
	if (frame) {
		active_keyboard_frame = frame;
	#ifdef GEM_MENU
		update_menu (frame->Encoding);
	#endif
	}
	
	switch (PE_Type (elem)) {
		
		case PE_VBAR: {
			BOOL drag = FALSE;
			long step = 0;
		
			WORD y = my - frame->clip.g_y;
			
			if (y >= frame->v_bar.pos + frame->v_bar.size) {
				
				if (y >= frame->v_bar.rd) {                         /* down arrow */
					step = (button & LEFT_BUTTON ? +scroll_step : -scroll_step);
				
				} else if (button & LEFT_BUTTON) {                   /* down page */
					step = +(frame->clip.g_h - scroll_step);
			
				} else {                                          /* absolute set */
					drag = TRUE;
					decy = frame->v_bar.size /2;
				}
			
			} else if (y <= frame->v_bar.pos) {
				
				if (y <= frame->v_bar.lu) {                           /* up arrow */
					step = (button & LEFT_BUTTON ? -scroll_step : +scroll_step);
				
				} else if (button & LEFT_BUTTON) {                     /* up page */
					step = -(frame->clip.g_h - scroll_step);
			
				} else {                                          /* absolute set */
					drag = TRUE;
					decy = frame->v_bar.size /2;
				}
			
			} else if (button & LEFT_BUTTON) {                       /* realtime */
				drag = TRUE;
				decy = my - frame->clip.g_y - frame->v_bar.pos;
		
			} else {                                                   /* slider */
				short s_x  = frame->clip.g_x + frame->clip.g_w;
				short s_y  = 0;
				short sldr = frame->v_bar.rd - frame->v_bar.lu +1;
				graf_dragbox (scroll_bar_width, frame->v_bar.size,
				              s_x, frame->clip.g_y + frame->v_bar.pos,
				              s_x, frame->clip.g_y + frame->v_bar.lu,
				              scroll_bar_width, sldr,
				              &s_x, &s_y);
				sldr -= frame->v_bar.size;
				step  = ((frame->Page.Height - frame->clip.g_h)
				         * ((s_y - frame->clip.g_y) - frame->v_bar.lu) + (sldr /2))
				         / sldr
				      - frame->v_bar.scroll;
			}
			
			if (drag) {
				multi_in.emi_flags   = MU_BUTTON|MU_M1;
				multi_in.emi_m1leave = MO_LEAVE;
				multi_in.emi_m1.g_x  = 0;
				multi_in.emi_m1.g_y  = frame->clip.g_y
				                     + frame->v_bar.lu + frame->v_bar.pos;
				multi_in.emi_m1.g_w  = 10000;
				multi_in.emi_m1.g_h  = 1;
				
			} else {
				wind_scroll (window_handle, frame->Container, 0, step);
			}
		} break;
		
		case PE_HBAR: {
			BOOL drag = FALSE;
			long step = 0;
		
			WORD x = mx - frame->clip.g_x;
			
			if (x >= frame->h_bar.pos + frame->h_bar.size) {
				
				if (x >= frame->h_bar.rd) {                        /* right arrow */
					step = (button & LEFT_BUTTON ? +scroll_step : -scroll_step);
				
				} else if (button & LEFT_BUTTON) {                  /* right page */
					step = +(frame->clip.g_w - scroll_step);
			
				} else {                                          /* absolute set */
					drag = TRUE;
					decx = frame->h_bar.size /2;
				}
			
			} else if (x <= frame->h_bar.pos) {
				
				if (x <= frame->h_bar.lu) {                         /* left arrow */
					step = (button & LEFT_BUTTON ? -scroll_step : +scroll_step);
				
				} else if (button & LEFT_BUTTON) {                   /* left page */
					step = -(frame->clip.g_w - scroll_step);
			
				} else {                                          /* absolute set */
					drag = TRUE;
					decx = frame->h_bar.size /2;
				}
			
			} else if (button & LEFT_BUTTON) {                       /* realtime */
				drag = TRUE;
				decx = mx - frame->clip.g_x - frame->h_bar.pos;
		
			} else {                                                   /* slider */
				short s_x  = 0;
				short s_y  = frame->clip.g_y + frame->clip.g_h;
				short sldr = frame->h_bar.rd - frame->h_bar.lu +1;
				graf_dragbox (frame->h_bar.size, scroll_bar_width,
				              frame->clip.g_x + frame->h_bar.pos, s_y,
				              frame->clip.g_x + frame->h_bar.lu,  s_y,
				              sldr, scroll_bar_width,
				              &s_x, &s_y);
				sldr -= frame->h_bar.size;
				step  = ((frame->Page.Width - frame->clip.g_w)
				         * ((s_x - frame->clip.g_x) - frame->h_bar.lu) + (sldr /2))
				         / sldr
				      - frame->h_bar.scroll;
			}
			
			if (drag) {
				multi_in.emi_flags   = MU_BUTTON|MU_M2;
				multi_in.emi_m2leave = MO_LEAVE;
				multi_in.emi_m2.g_x  = frame->clip.g_x
				                     + frame->h_bar.lu + frame->h_bar.pos;
				multi_in.emi_m2.g_y  = 0;
				multi_in.emi_m2.g_w  = 1;
				multi_in.emi_m2.g_h  = 10000;
				
			} else {
				wind_scroll (window_handle, frame->Container, step, 0);
			}
		} break;
		
		case PE_TLINK: case PE_ILINK: {
			struct url_link * link = hash;
			if (*link->address == '#') {
				long dx, dy;
				if (containr_Anchor (cont, link->address, &dx, &dy)) {
					wind_scroll (window_handle, cont, dx, dy);
					check_mouse_position (mx, my);
				}
			} else {
				if (link->u.target) {
					CONTAINR target = containr_byName (cont, link->u.target);
					if (target) cont = target;
				}
				new_loader_job (link->address, frame->Location,
				                cont, link->encoding, -1,-1);
			}
		} break;
		
		default:
			if (elem >= PE_FRAME && (button & RIGHT_BUTTON)) {
				rpopup_open (mx, my);
			} else if (elem) {
				wind_set (window_handle, WF_TOP, 0, 0, 0, 0);
			}
	}
	
	if (multi_in.emi_flags) {
		long pg_h = frame->Page.Height - frame->clip.g_h;
		WORD sl_h = frame->v_bar.rd - frame->v_bar.lu - frame->v_bar.size;
		long top  = frame->clip.g_y + frame->v_bar.lu +1;
		long bot  = frame->clip.g_y + frame->v_bar.rd -1;
		long pg_w = frame->Page.Width - frame->clip.g_w;
		WORD sl_w = frame->h_bar.rd - frame->h_bar.lu - frame->h_bar.size;
		long lft  = frame->clip.g_x + frame->h_bar.lu +1;
		long rgt  = frame->clip.g_x + frame->h_bar.rd -1;
		long dx = 0, dy = 0;
		
		wind_update (BEG_MCTRL);
		
		multi_in.emi_bclicks = 1;
		multi_in.emi_bmask   = button;
		multi_in.emi_bstate  = 0x00;
		while (1) {
			WORD       msg[8];
			EVMULT_OUT out;
			short      event = evnt_multi_fast (&multi_in, msg, &out);
			
			if (event & MU_M1) {
				long y = out.emo_mouse.p_y - decy;
				if      (y >= bot) dy =  pg_h;
				else if (y >  top) dy = (pg_h * (y - top) + (top /2)) / sl_h;
				dy -= frame->v_bar.scroll;
				multi_in.emi_m1.g_y = out.emo_mouse.p_y;
			}
			if (event & MU_M2) {
				long x = out.emo_mouse.p_x - decx;
				if      (x >= rgt) dx =  pg_w;
				else if (x >  lft) dx = (pg_w * (x - lft) + (lft /2)) / sl_w;
				dx -= frame->h_bar.scroll;
				multi_in.emi_m2.g_x = out.emo_mouse.p_x;
			}
			if (dx || dy) {
				wind_scroll (window_handle, cont, dx, dy);
				dx = dy = 0;
			}
			if (event & MU_BUTTON) break;
		}
		wind_update (END_MCTRL);
	}
}

#if 0  /***** REPLACED *****/
void
button_clicked (WORD button, WORD mx, WORD my)
{
	CONTAINR cont = containr_byCoord (NULL, mx, my);
	FRAME    frame;
	
	if (!cont || (frame = containr_Frame (cont)) == NULL) {
		return;
	}
	
	mx -= frame->clip.g_x;
	my -= frame->clip.g_y;

	/* make certain it's inside our frame should have
	 * been done above - baldrick
	 */
	if (mx > frame->clip.g_w && my > frame->clip.g_h)
	{
		return;
	}

	if (button == 1) /* left mouse button */
	{
		/* *************** Vertical scroll ************** */

		if (frame->v_bar.on && mx > frame->clip.g_w)
		{
			long max_scroll = frame->Page.Height - frame->clip.g_h;
			long step       = 0;
		
			if (my < frame->v_bar.pos)
			{
				/* scroll up */
			
				if (frame->v_bar.scroll > 0)
				{
					step = -(my <= frame->v_bar.lu
					         ? scroll_step : frame->clip.g_h - scroll_step);
				}
			}
			else if (my >= frame->v_bar.pos + frame->v_bar.size)
			{
				/* scroll down */
				
				if (frame->v_bar.scroll < max_scroll)
				{
					step = (my >= frame->v_bar.rd
					        ? scroll_step : frame->clip.g_h - scroll_step);
				}
			}
			else   /*slider */
			{
				short s_x  = frame->clip.g_x + frame->clip.g_w;
				short s_y  = frame->clip.g_y + frame->v_bar.pos;
				short size = frame->v_bar.rd - frame->v_bar.lu +1;
				graf_dragbox (scroll_bar_width, frame->v_bar.size,
			              s_x, s_y,
			              s_x, frame->clip.g_y + frame->v_bar.lu,
			              scroll_bar_width, size,
			              &s_x, &s_y);
				s_y  -= frame->clip.g_y + frame->v_bar.lu;
				size -= frame->v_bar.size;
				step  = (max_scroll * s_y + (size /2)) / size
				      - frame->v_bar.scroll;
			}
		
			if (step)
				wind_scroll (window_handle, frame->Container, 0, step);
		}
	
		/* ******** Horizontal Scroll *********** */
	
		else if (frame->h_bar.on && my > frame->clip.g_h)
		{
			long max_scroll = frame->Page.Width - frame->clip.g_w;
			long step       = 0;
		
			if (mx < frame->h_bar.pos)
			{
				/* scroll left */
			
				if (frame->h_bar.scroll > 0)
				{
					step = -(mx <= frame->h_bar.lu
				         ? scroll_step : frame->clip.g_w - scroll_step);
				}
			}
			else if (mx >= frame->h_bar.pos + frame->h_bar.size)
			{
				/* scroll right */
				
				if (frame->h_bar.scroll < max_scroll)
				{
					step = (mx >= frame->h_bar.rd
					        ? scroll_step : frame->clip.g_w - scroll_step);
				}
			}
			else   /*slider */
			{
				short s_x  = frame->clip.g_x + frame->h_bar.pos;
				short s_y  = frame->clip.g_y + frame->clip.g_h;
				short size = frame->h_bar.rd - frame->h_bar.lu +1;
				graf_dragbox (frame->h_bar.size, scroll_bar_width,
			              s_x, s_y,
			              frame->clip.g_x + frame->h_bar.lu, s_y,
			              size, scroll_bar_width,
			              &s_x, &s_y);
				s_x  -= frame->clip.g_x + frame->h_bar.lu;
				size -= frame->h_bar.size;
				step  = (max_scroll * s_x + (size /2)) / size
			      - frame->h_bar.scroll;
			}
		
			if (step) 
				wind_scroll (window_handle, frame->Container, step, 0);
		}
	
		/* *********** Clickable areas ************* */

		else if (current_highlighted_link_area)
		{
			if (*current_highlighted_link_area->link->address == '#')
			{
				long dx, dy;
				char * addr = current_highlighted_link_area->link->address;
				cont        = current_highlighted_link_frame->Container;
				if (containr_Anchor (cont, addr, &dx, &dy)) {
					wind_scroll (window_handle, cont, dx, dy);
					check_mouse_position (mx + frame->clip.g_x, my + frame->clip.g_y);
				}
			}
			else
			{
				cont = (current_highlighted_link_area->link->u.target
			      ? containr_byName (current_highlighted_link_frame->Container,
			                         current_highlighted_link_area->link->u.target)
				      : NULL);

				if (!cont)
					cont = current_highlighted_link_frame->Container;

				new_loader_job (current_highlighted_link_area->link->address,
			                current_highlighted_link_frame->Location, cont,
			                current_highlighted_link_area->link->encoding, -1,-1);
			}
		}
		else
		{
			active_keyboard_frame = frame;

		#ifdef GEM_MENU
			update_menu (frame->Encoding);
		#endif
			wind_set (window_handle, WF_TOP, 0, 0, 0, 0);
		}
	} /* end of left button processing */
	else if (button == 2) /*right button processing */
	{
		mx += frame->clip.g_x;
		my += frame->clip.g_y;

		rpopup_open(mx,my);
	}
}
#endif  /***** REPLACED *****/


/* check_mouse_position()
 *
 * find the actual clickable to be highlighted.
 *
 * AltF4 - Feb. 17, 2002:  reworked to make use of container funtions and avoid
 *                         access of the global the_firt_frame and frame_next().
 */
void
check_mouse_position (WORD mx, WORD my)
{
#if 0 /* debugging */
	static GRECT WATCH = {0,0,-1,-1};
#	define WATCH WATCH
#endif

	static GRECT box = {0,0,-1,-1};
	
	void   * link = (current_highlighted_link_area ?
	                 current_highlighted_link_area->link : NULL);
	CONTAINR cont = NULL;
	void   * hash = NULL;
	GRECT watch, clip;
	
	UWORD elem = containr_Element (&cont, mx, my, &watch, &clip, &hash);
	
	current_highlighted_link_area  = NULL;
	current_highlighted_link_frame = NULL;
	
	if (!elem) {
		set_mouse_watch (MO_ENTER, &watch);
	
	} else {
		if (elem == PE_TLINK) {
			FRAME frame = containr_Frame (cont);
			struct clickable_area * current_area = frame->first_clickable_area;
			while (current_area) {
				if (current_area->link == hash) {
					current_highlighted_link_area  = current_area;
					current_highlighted_link_frame = frame;
					break;
				}
				current_area = current_area->next_area;
			}
		}
		set_mouse_watch (MO_LEAVE, &watch);
	}
	
#ifdef WATCH
	if (WATCH.g_w > 0 && WATCH.g_h > 0) {
		PXY p[5];
		p[1].p_x = p[2].p_x = (p[0].p_x = p[3].p_x = WATCH.g_x) + WATCH.g_w -1;
		p[2].p_y = p[3].p_y = (p[0].p_y = p[1].p_y = WATCH.g_y) + WATCH.g_h -1;
		p[4] = p[0];
		vswr_mode (vdi_handle, MD_XOR);
		vsl_color (vdi_handle, G_BLACK);
		v_hide_c (vdi_handle);
		v_pline (vdi_handle, 5, (short*)p);
		v_show_c (vdi_handle, 1);
		vswr_mode (vdi_handle, MD_TRANS);
	}
#endif

	if (link != hash) {
		if (link) {
			wind_redraw (window_handle, &box);
		}
		if (hash) {
			wind_redraw (window_handle, &clip);
			graf_mouse (POINT_HAND, NULL);
		} else {
			graf_mouse (ARROW, NULL);
		}
	}
	box = clip;
	
#ifdef WATCH
	WATCH = watch;
	if (WATCH.g_w > 0 && WATCH.g_h > 0) {
		PXY p[5];
		p[1].p_x = p[2].p_x = (p[0].p_x = p[3].p_x = WATCH.g_x) + WATCH.g_w -1;
		p[2].p_y = p[3].p_y = (p[0].p_y = p[1].p_y = WATCH.g_y) + WATCH.g_h -1;
		p[4] = p[0];
		vswr_mode (vdi_handle, MD_XOR);
		vsl_color (vdi_handle, G_BLACK);
		v_hide_c (vdi_handle);
		v_pline (vdi_handle, 5, (short*)p);
		v_show_c (vdi_handle, 1);
		vswr_mode (vdi_handle, MD_TRANS);
	}
#endif
}

#if 0 /***** REPLACED *****/
void
check_mouse_position (WORD mx, WORD my)
{
	CONTAINR cont;
	FRAME    current_frame = current_highlighted_link_frame;

	if (current_frame && current_highlighted_link_area)
	{
		long x_abs = (long)current_frame->clip.g_x - current_frame->h_bar.scroll;
		long y_abs = (long)current_frame->clip.g_y - current_frame->v_bar.scroll;
		GRECT area;
		area.g_x = x_abs + current_highlighted_link_area->offset.X;
		area.g_y = y_abs + current_highlighted_link_area->offset.Y;
		if (mx >= area.g_x && mx < area.g_x + current_highlighted_link_area->w &&
		    my >= area.g_y && my < area.g_y + current_highlighted_link_area->h) {
			/*
			 * the mouse pointer is still inside the actual clickable area,
			 * so nothing to redraw
			 */
			return;

		} else {
			area.g_w = current_highlighted_link_area->w;
			area.g_h = current_highlighted_link_area->h,

			current_highlighted_link_frame = NULL;
			current_highlighted_link_area  = NULL;
			graf_mouse (ARROW, NULL);
			wind_redraw (window_handle, &area);
		}
	}

	if ((cont = containr_byCoord (NULL, mx, my)) != NULL &&
	    (current_frame = containr_Frame (cont))  != NULL) {

		struct clickable_area *current_area = current_frame->first_clickable_area;
		long x_abs = (long)current_frame->clip.g_x - current_frame->h_bar.scroll;
		long y_abs = (long)current_frame->clip.g_y - current_frame->v_bar.scroll;

		mx -= x_abs;
		my -= y_abs;

		while (current_area && (
		       mx < current_area->offset.X || mx >= current_area->offset.X + current_area->w ||
		       my < current_area->offset.Y || my >= current_area->offset.Y + current_area->h)) {
			current_area = current_area->next_area;
		}
		if (current_area && current_area->link->isHref)
		{
			GRECT area;
			area.g_x = x_abs + current_area->offset.X;
			area.g_y = y_abs + current_area->offset.Y;
			area.g_w = current_area->w;
			area.g_h = current_area->h,

			current_highlighted_link_frame = current_frame;
			current_highlighted_link_area  = current_area;
			graf_mouse (POINT_HAND, NULL);
			wind_redraw (window_handle, &area);
		}
	}
}
#endif  /***** REPLACED *****/
