/* @(#)highwire/render.c
 */
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h> 

#include "token.h" /* must be included before gem/gemx.h */
#include <gemx.h>

#include "global.h"
#include "scanner.h"
#include "parser.h"
#include "Containr.h"
#include "Loader.h"
#include "Location.h"
#include "Logging.h"
#include "Table.h"
#include "http.h"


/* calculate end of paragraph space, eop_space */
#define EOP(a) ((a) * 2 / 3)


/* parser function flags */
#define PF_NONE   0x0000
#define PF_START  0x0001 /* no slash in tag   */
#define PF_PRE    0x0002 /* preformatted text */
#define PF_SPACE  0x0004 /* ignore spaces     */
#define PF_FONT   0x0008 /* font has changed  */
#define PF_ENCDNG 0x0010 /* charset encoding has changed   */
#define PF_SCRIPT 0x0020 /* <noscrip> inside a script area */


/* step2size()
 *
 * maps a font step of [0..7] to a font size.
 */
static WORD
step2size (struct font_step * fontstep, WORD step)
{
	static WORD size[8] = { 0, };
	static WORD s = 0;
	
	if (s != font_size)
	{
		WORD i;
		s = font_size;
		size[0] = s - (s / 2); /*7;*/
		size[1] = s - (s / 3); /* 8; */
		size[2] = (s + size[1]) /2;
		size[3] = s;
		for (i = 4; i <= 7; size[i++] = (s += 2));
	}
	if      (step < 0) step = 0;
	else if (step > 7) step = 7;
	if (fontstep) fontstep->step = step;
	
	return size[step];
}

static void
step_push (TEXTBUFF current, WORD step)
{
	current->font_step = add_step  (current->font_step);
	current->font_size = step2size (current->font_step, step);
}

static void
step_pop (TEXTBUFF current)
{
	current->font_step = destroy_step (current->font_step);
	current->font_size = step2size    (NULL, current->font_step->step);
}


#if 1
#	define map(c) (c == ' ' ? Space_Code : (UWORD)c - 32)
#else
static UWORD
map (char symbol)
{
	if (symbol == ' ')
		return (Space_Code);

	return ((WORD) (symbol - 32));
}
#endif


static WORD
list_indent (WORD type)
{
	switch (type)
	{
		case 0:
			return (font_size * 2);
		case 1:
			return (font_size * 3);
		case 2:
			return (font_size * 4);
	}
	return (0);
}


/* get_align()
 *
 * retrieves the alignment of a paragraph
 * based on frame->alignment (CENTER) or if it's in a Table
 */

static H_ALIGN
get_align(struct frame_item *p_frame)
{
	if (p_frame->Page.Alignment == ALN_CENTER &&
	    p_frame->current.paragraph->alignment == ALN_CENTER) {
		return (ALN_CENTER);
	}
	if (p_frame->TableStack && p_frame->TableStack->WorkCell) {
		return (p_frame->TableStack->WorkCell->Content.Alignment);
	}
	return (p_frame->Page.Alignment);
}


/*******************************************************************************
 *
 * Head And Structure Elements
*/

/*------------------------------------------------------------------------------
 * Document Head
 */
static UWORD
render_HTML_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		frame = frame;  /* unused */
	#endif
	
	if (!(flags & PF_START)) {
		*text = strchr (*text, '\0');
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * Title
 *
 * parses a title tag from a file 
 * and sets the window's title to this value
 * also watches for ISO Latin entities in the Title string
 * Baldrick Dec. 6, 2001
 *
 * Modified to use new ISO scanning routines
 * AltF4 Dec. 19, 2001
*/
static UWORD
render_TITLE_tag (FRAME frame, const char ** text, UWORD flags)
{
	if (flags & PF_START) {
		ENCODER_C encoder = encoder_char (frame->Encoding);
		char   window_title[129 +5] = "";
		char * title     = window_title;
		char * watermark = window_title + aes_max_window_title_length;
		BOOL   ready     = FALSE;
		const char * symbol = *text;
		
		do {
			switch(*symbol)
			{
				case '\0':
					ready = TRUE;
					break;
				case '\t':
				case '\r':
				case '\n':
					/* BUG: Replace contiguous white space by exact one space! */
					symbol++;
					break;
				case '&':
					if (title < watermark)
						title = scan_namedchar (&symbol, title, FALSE);
					else
						symbol++;
					break;
				case '<':
					if (symbol[1] == '/')
					{
						const char * sym = symbol + 2;
						if (parse_tag (&sym) == TAG_TITLE)
						{
							symbol = sym;
							ready  = TRUE;
							break;
						}
					}
				default:
					if (title < watermark)
						title = (*encoder)(&symbol, title);
					else
						symbol++;
					break;
			}
		} while (!ready);
		
		*title = window_title[aes_max_window_title_length] = '\0';
		
		if (strlen(window_title) > 0)
			containr_notify (frame->Container, HW_SetTitle, window_title);
		
		*text = symbol;
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * Frameset Tag
 *
 * it parses and processes the frameset information
 * until done and then returns to the main parser with
 * a pointer to the end of the frameset
 * baldrick - August 8, 2001
 *
 * There are some printf's in this section that are rem'd out
 * they are useful checks on the frame parsing and I'm not
 * certain that it's 100% correct yet.  So I have left them
 * baldrick - August 14, 2001
 *
 * Major reworks by AltF4 in late January - early Feb 2002
*/
static UWORD
render_FRAMESET_tag (FRAME frame, const char ** text, UWORD flags)
{
	const char * symbol    = *text;
	CONTAINR     container = frame->Container;
	LOCATION     base      = frame->Location;
	HTMLTAG tag   = TAG_FRAMESET;
	BOOL    slash = FALSE;
	int     depth = 0;

	if (!container) {
		errprintf ("render_frameset(): NO CONTAINER in '%s'!\n", base->File);
		exit(EXIT_FAILURE);
	} else if (container->Mode) {
		errprintf ("render_frameset(): container not cleared in '%s'!\n", base->File);
		exit(EXIT_FAILURE);
	}

	if (!(flags & PF_START)) {
		symbol = strchr (symbol, '\0');
	
	} else do {
	
		if (!slash) {

			/* only work on an empty container.  if not empty there was either a
			 * forgotten </framset> or more tags than defined in the frameset.
			 */
			if (!container->Mode) {

				if (tag == TAG_FRAMESET) {

					char output[100];
					BOOL border = (container->Parent
					               ? container->Parent->Border : TRUE);
					container->Border = (get_value_unum (KEY_FRAMEBORDER, border) > 0);

					/* ok the first thing we do is look for ROWS or COLS
					 * since when we are dumped here we are looking at a
					 * beginning of a FRAMESET tag
					 */

					if (get_value (KEY_COLS, output, sizeof(output))) {
						containr_fillup (container, output, TRUE);
						container = container->u.Child;
						depth++;
					}

					else /* at the moment settings of either COLS _and_ ROWS aren't
					      * working yet, so we make it mutual exlusive for now   */

					if (get_value (KEY_ROWS, output, sizeof(output))) {
						containr_fillup (container, output, FALSE);
						container = container->u.Child;
						depth++;
					}

				} else if (tag == TAG_FRAME) {
					char output[100];
					char  frame_file[HW_PATH_MAX];

					container->Mode   = CNT_FRAME;
					container->Name   = get_value_str (KEY_NAME);
					container->Border = container->Parent->Border;

					if (get_value (KEY_SCROLLING, output, sizeof(output))) {
						if      (stricmp (output, "yes")   == 0) container->scroll = SCROLL_ALWAYS;
						else if (stricmp (output, "no")  == 0)   container->scroll = SCROLL_NEVER;
						else if (stricmp (output, "auto") == 0)  container->scroll = SCROLL_AUTO;
					}
					else
						container->scroll = SCROLL_AUTO;

					if (get_value (KEY_SRC, frame_file, sizeof(frame_file))) {
						/* BUG: is there a CHARSET attribute? */
						new_loader_job (frame_file, base, container,
						                ENCODING_WINDOWS1252,
						                get_value_unum (KEY_MARGINWIDTH,  -1),
						                get_value_unum (KEY_MARGINHEIGHT, -1));
					} else {
						containr_calculate (container, NULL);
						containr_notify (container,
						                 HW_PageFinished, &container->Area);
					}

					if (container->Sibling) {
						container = container->Sibling;
					}
				}
			} /* endif (!container->Mode) */

		} else if (tag == TAG_FRAMESET) { /* && slash */

			container = container->Parent;

			if (--depth <= 0) break;

			if (container->Sibling) {
				container = container->Sibling;
			}
		}

		/* skip junk until the next <...> */

		while (*symbol && *(symbol++) != '<');
		if (*symbol) {
			slash = (*symbol == '/');
			if (slash) symbol++;
			tag = parse_tag (&symbol);
			continue;
		}
	}
	while (*symbol);

	#if 0
	{
		extern void containr_debug (CONTAINR);
		containr_debug (container);
	}
	#endif

	*text = symbol;
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Base URL And Target
*/
static UWORD
render_BASE_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		frame->base_target = get_value_str (KEY_TARGET);
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * Meta Descriptions
*/
static UWORD
render_META_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		char output[100];
	
		if (get_value (KEY_HTTP_EQUIV, output, sizeof(output)) &&
		    stricmp   (output, "Content-Type") == 0            &&
		    get_value (KEY_CONTENT, output, sizeof(output))) {
			
			ENCODING cset = http_charset (output, strlen(output), NULL);
			if (cset) {
				frame->Encoding = cset;
				flags |= PF_ENCDNG;
			}
			/* http://www.iana.org/assignments/character-sets */
		}
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * Script Area
 *
 * skip everything until </STYLE> tag
*/
static UWORD
render_STYLE_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		frame = frame;  /* unused */
	#endif
	
	if (flags & PF_START) {
		const char * line = *text;
		do {
			BOOL slash;
			while (*line && *(line++) != '<');
			slash = (*line == '/');
			if (slash) line++;
			if (parse_tag (&line) == TAG_STYLE && slash) {
				break;
			}
		} while (*line);
	
		*text = line;
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * Background Sound
 *
 * Processes embedded multi media objects.
 * Currently it simply fires up a new loader job and lets
 * the loader find out what to do.
 *
 * AltF4 - Mar. 01, 2002
*/
static UWORD
render_BGSOUND_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		char snd_file[HW_PATH_MAX];

		if (get_value (KEY_SRC, snd_file, sizeof(snd_file))) {
			new_loader_job (snd_file, frame->Location,
			                NULL, ENCODING_WINDOWS1252, -1,-1);
		}
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * Document Body
 *
 * modifications for new color routines
 * AltF4 - December 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
*/
static UWORD
render_BODY_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		WORD margin;
		
		if (!ignore_colours)
		{
			WORD color;
	
			if ((color = get_value_color (KEY_TEXT)) >= 0)
			{
				frame->text_colour = frame->current.font_step->colour = color;
				TA_Color(frame->current.word->attr)                   = color;
			}
			if ((color = get_value_color (KEY_BGCOLOR)) >= 0)
			{
				frame->Page.Backgnd = frame->current.backgnd = color;
			}
			if ((color = get_value_color (KEY_LINK)) >= 0)
			{
				frame->link_colour = color;
			}
		}
		
		if ((margin = get_value_unum (CSS_MARGIN, -1)) >= 0) {
			frame->Page.MarginTop = frame->Page.MarginBot =
			frame->Page.MarginLft = frame->Page.MarginRgt = margin;
			
		} else {
			if ((margin = get_value_unum (KEY_MARGINHEIGHT, -1)) >= 0 ||
			    (margin = get_value_unum (KEY_TOPMARGIN, -1)) >= 0) {
				frame->Page.MarginTop = frame->Page.MarginBot = margin;
			}
			if ((margin = get_value_unum (KEY_MARGINWIDTH, -1)) >= 0 ||
			    (margin = get_value_unum (KEY_LEFTMARGIN, -1)) >= 0) {
				frame->Page.MarginLft = frame->Page.MarginRgt = margin;
			}
		}
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * Script Area
 *
 * actually skips everything until </SCRIPT> or <NOSCRIPT> tag
*/
static UWORD
render_SCRIPT_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		frame = frame;  /* unused */
	#endif
	
	if (flags & PF_START) {
		const char * line = *text, * save = NULL;
		do {
			BOOL    slash;
			HTMLTAG tag;
			while (*line && *(line++) != '<');
			slash = (*line == '/');
			if (slash) line++;
			else       save = line +1;
			tag = parse_tag (&line);
			if (slash) {
				if (tag == TAG_SCRIPT) {
					flags &= ~PF_SCRIPT;
					break;
				}
			} else if (tag == TAG_NOSCRIPT) {
				flags |= PF_SCRIPT;
				break;
			} else {
				line = save;
			}
		} while (*line);
	
		*text = line;
	
	} else {
		flags &= ~PF_SCRIPT;
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * NoScript Area
 *
 * actually skips everything until </SCRIPT> or <NOSCRIPT> tag
*/
static UWORD
render_NOSCRIPT_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		frame = frame;  /* unused */
	#endif
	
	if ((flags & (PF_START|PF_SCRIPT)) == PF_SCRIPT) {
		flags = render_SCRIPT_tag (frame, text, flags);
	}
	return flags;
}


/*******************************************************************************
 *
 * Font style and phrase elements
*/

/*------------------------------------------------------------------------------
 * Bold Text
*/
static UWORD
render_B_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	word_set_bold (&frame->current, (flags & PF_START));
	return flags;
}

/*------------------------------------------------------------------------------
 * Base Font Setting
*/
static UWORD
render_BASEFONT_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		char output[10];
		struct font_step * f_step = frame->current.font_step;
		
		while (f_step->previous_font_step) {
			f_step = f_step->previous_font_step;
		}
		
		if (get_value (KEY_SIZE, output, sizeof(output)))
		{
			if (*output == '+') {
				if (isdigit(output[1])) {
					f_step->step += output[1]  - '0';
				}
			} else {
				if (*output == '-') {
					if (isdigit(output[1])) {
						f_step->step -= output[1]  - '0';
					}
				} else if (isdigit(output[0])) {
					f_step->step = output[0]  - '0';
				}
				if (f_step->step < 1) f_step->step = 1;
			}
			if (f_step->step > 7) f_step->step = 7;
			
			if (f_step == frame->current.font_step) {
				frame->current.font_size = step2size (NULL, f_step->step);
				word_set_point (&frame->current, frame->current.font_size);
			}
		}
	}
	return flags;
}

/*------------------------------------------------------------------------------
 * Big Font Size
*/
static UWORD
render_BIG_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		step_push (current, current->font_step->step +1);
	} else {
		step_pop (current);
	}
	word_set_point (current, current->font_size);
	return flags;
}

/*------------------------------------------------------------------------------
 * Citation
*/
#define render_CITE_tag   render_I_tag

/*----------------------------------------------------------------------------*/
static UWORD
render_CODE_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	word_set_font (current, (flags & PF_START ? pre_font : normal_font));
	TAsetCondns   (current->word->attr, (flags & PF_START));
	return flags;
}

/*------------------------------------------------------------------------------
 *  Instance Definition
*/
#define render_DFN_tag   render_I_tag

/*------------------------------------------------------------------------------
 *  Emphasis Text
*/
#define render_EM_tag   render_I_tag

/*------------------------------------------------------------------------------
 * Font Tag
 *
 * color handling modified to new routines
 * AltF4 - Dec 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 *
 * Baldrick - March 1, 2002: modifications to always store a font step
 *            so that we don't loose our size on complex sites
*/
static UWORD
render_FONT_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		char output[10];
		WORD step = frame->current.font_step->step;

		if (get_value (KEY_SIZE, output, sizeof(output))) {
		
			if (*output == '+') {
				if (isdigit(output[1])) {
					step += output[1]  - '0';
				}
			} else {
				if (*output == '-') {
					if (isdigit(output[1])) {
						step -= output[1]  - '0';
					}
				} else if (isdigit(output[0])) {
					step = output[0]  - '0';
				}
				if (step < 1) step = 1;
			}
		}
		step_push (&frame->current, step);

		if (!ignore_colours) {
			WORD color = get_value_color (KEY_COLOR);

			if (color >= 0)
			{
				frame->current.font_step->colour = color;
				word_set_color (&frame->current, color);
			}
		}
	
	} else {
		step_pop (&frame->current);
		word_set_color (&frame->current, (frame->current.word->link
		                                  ? frame->link_colour
		                                  : frame->current.font_step->colour));
	}
	word_set_point (&frame->current, frame->current.font_size);
	return flags;
}

/*------------------------------------------------------------------------------
 * Italic Text
*/
static UWORD
render_I_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	word_set_italic (&frame->current, (flags & PF_START));
	return flags;
}

/*------------------------------------------------------------------------------
 *  Keyboard Input Text Style
*/
#define render_KBD_tag render_TT_tag

/*------------------------------------------------------------------------------
 *  Strike Through Text Style
*/
#define render_S_tag   render_STRIKE_tag

/*------------------------------------------------------------------------------
 *  Sample Code Or Script Text Style
*/
#define render_SAMP_tag   render_TT_tag

/*------------------------------------------------------------------------------
 * Small Font Size
*/
static UWORD
render_SMALL_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		step_push (current, current->font_step->step -1);
	} else {
		step_pop (current);
	}
	word_set_point (current, current->font_size);
	return flags;
}

/*------------------------------------------------------------------------------
 * Strike Through Text Style
*/
static UWORD
render_STRIKE_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	word_set_strike (&frame->current, (flags & PF_START));
	return flags;
}

/*------------------------------------------------------------------------------
 * Strong Text Style
*/
#define render_STRONG_tag   render_B_tag

/*------------------------------------------------------------------------------
 * Subscript Text
*/
static UWORD
render_SUB_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		step_push (current, current->font_step->step -1);
		current->word->vertical_align = ALN_BELOW;
	} else {
		step_pop (current);
		current->word->vertical_align = ALN_BOTTOM;
	}
	word_set_point (current, current->font_size);
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Superscript Text
*/
static UWORD
render_SUP_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		step_push (current, current->font_step->step -1);
		current->word->vertical_align = ALN_ABOVE;
	} else {
		step_pop (current);
		current->word->vertical_align = ALN_BOTTOM;
	}
	word_set_point (current, current->font_size);
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Teletype Text Style
*/
static UWORD
render_TT_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	word_set_font (&frame->current, (flags & PF_START ? pre_font : normal_font));
	return flags;
}

/*------------------------------------------------------------------------------
 * Underlined Text
*/
static UWORD
render_U_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	word_set_underline (&frame->current, (flags & PF_START));
	return flags;
}

/*------------------------------------------------------------------------------
 *  Variable Name Text Style
*/
#define render_VAR_tag render_I_tag

/*------------------------------------------------------------------------------
 *  Example Text Style
*/
#define render_XMP_tag render_TT_tag


/*******************************************************************************
 *
 * Special Text Level Elements
*/

/*------------------------------------------------------------------------------
 * Anchor Or Link
*/
static UWORD
render_A_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	WORDITEM word    = current->word;
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		char * output;

		if ((output = get_value_str (KEY_HREF)) != NULL)
		{
			char out2[30];
			
			char * target = get_value_str (KEY_TARGET);
			if (!target && frame->base_target) {
				target = strdup (frame->base_target);
			}
			
			if (!word->link) {
				word_set_underline (current, TRUE);
			}
			word_set_color (current, frame->link_colour);

			word->link = new_url_link (output, TRUE, target);
			
			/* Asume ENCODING_WINDOWS1252, which is commen practice. */
			word->link->encoding = ENCODING_WINDOWS1252;
			if (get_value(KEY_CHARSET, out2, sizeof(out2))) {
				if (stricmp(out2, "ISO-8859-2") == 0)
					word->link->encoding = ENCODING_ISO8859_2;
				else if (stricmp(out2, "UTF-8") == 0)
					word->link->encoding = ENCODING_UTF8;
				else if (stricmp(out2, "atarist") == 0)
					word->link->encoding = ENCODING_ATARIST;
			}
		}
		else if ((output = get_value_str (KEY_NAME)) != NULL
		         || (output = get_value_str (KEY_ID)) != NULL)
		{
			word->link = new_url_link (output, FALSE, NULL);
			word->link->u.anchor = new_named_location (word->link->address,
			                                          &current->paragraph->Offset);
			*current->anchor = word->link->u.anchor;
			current->anchor  = &word->link->u.anchor->next_location;
			
			/* prevent from getting deleted if empty */
			*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
			new_word (current, TRUE);
			current->word->link = NULL;
			word->word_width = 0;
		}	
	
	} else if (word->link) {
		word_set_color     (current, current->font_step->colour);
		word_set_underline (current, FALSE);
		word->link = NULL;
	}
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Language Dependent Quotation Marks (in-paragraph citation)
 *
 * Source: The Unicode Standard Version 3.0, section 6.1.
 * BUG: Should work for nested quotes, alternating double and single.
 * BUG: Must use LANG set elsewere as default.
 *
 * Rainer Seitel, 2002-03-29
*/
static UWORD
render_Q_tag (FRAME frame, const char ** _text, UWORD flags)
{
	static LANGUAGE language = LANG_EN;
	UWORD ** text = &frame->current.text;
	char buf[6];
	#ifdef __PUREC__
		_text = _text;  /* unused */
	#endif
	
	if (get_value(KEY_LANG, buf, sizeof(buf))) {
		strlwr(buf);
		language = *((UWORD *)buf);
	}
	switch (language) {
		case LANG_CS:  /* Czech, German, Slovak */
		case LANG_DE:
		case LANG_SK:
			if (flags & PF_START) {
				**text = 107;  /* U+201E DOUBLE LOW-9 QUOTATION MARK */
				++*text;
			} else {
				**text = 104;  /* U+201C LEFT DOUBLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_FR:  /* French, Greek, Russian */
		case LANG_EL:
		case LANG_RU:
			if (flags & PF_START) {
				**text = 125;  /* U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			} else {
				**text = 126;  /* U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_HU:  /* Hungarian, Polish */
		case LANG_PL:
			if (flags & PF_START) {
				**text = 107;  /* U+201E DOUBLE LOW-9 QUOTATION MARK */
				++*text;
			} else {
				**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_SL:  /* Slovenian */
			if (flags & PF_START) {
				**text = 126;  /* U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			} else {
				**text = 125;  /* U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_DA:  /* Danish, Finnish, Norwegian, Swedish */
		case LANG_FI:
		case LANG_NO:
		case LANG_SV:
			**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
			++*text;
			break;
		default:  /* else Dutch, English, Italian, Portuguese, Spanish, Turkish quotes */
			if (flags & PF_START) {
				**text = 104;  /* U+201C LEFT DOUBLE QUOTATION MARK */
				++*text;
			} else {
				**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
				++*text;
			}
	}
	
	return flags;
}

/*----------------------------------------------------------------------------*/
#define render_EMBED_tag   render_BGSOUND_tag


/*------------------------------------------------------------------------------
 * Propritary IOD4 Browser Tag
 *
 * see http://www.backspace.org/iod/Winhelp.html
 *
 * Matthias Jaap, 2002-07-22
*/
static UWORD
render_IOD_tag (FRAME frame, const char ** text, UWORD flags)
{
	char output[100];

	#ifdef __PUREC__
		frame = frame;  /* unused */
		text  = text;   /* unused */
	#endif
	
	if (flags & PF_START)
	{
		get_value (KEY_SHOUT, output, sizeof(output));
		wind_set_str   (window_handle, WF_INFO, output);
	}
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Image
*/
static UWORD
render_IMG_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		TEXTBUFF current  = &frame->current;
		H_ALIGN  floating = ALN_NO_FLT;
		V_ALIGN  v_align  = ALN_BOTTOM;
		TEXTATTR word_attr   = current->word->attr;
		short word_height    = current->word->word_height;
		short word_tail_drop = current->word->word_tail_drop;
		short word_v_align   = current->word->vertical_align;
		
		WORDITEM word;
		char output[100];
		char img_file[HW_PATH_MAX];
	
		if (alternative_text_is_on) {
			if (get_value(KEY_ALT, output, sizeof(output))) {
				scan_string_to_16bit(output, frame->Encoding, &current->text);
			}
			return flags;
		}
	
		if (get_value (KEY_ALIGN, output, sizeof(output))) {
			if      (stricmp (output, "left")   == 0) floating = ALN_LEFT;
			else if (stricmp (output, "right")  == 0) floating = ALN_RIGHT;
			else if (stricmp (output, "center") == 0) floating = ALN_CENTER;
			
			else if (stricmp (output, "top")    == 0) v_align = ALN_TOP;
			else if (stricmp (output, "middle") == 0) v_align = ALN_MIDDLE;
			/* else                                   v_align = ALN_BOTTOM */
			if (floating != ALN_NO_FLT) {
				if (current->paragraph->item != current->word) {
					add_paragraph (current);
				}
				current->paragraph->paragraph_code = PAR_IMG;
				current->paragraph->floating       = floating;
			}
		}
		word = current->word;
		word->vertical_align = v_align;
		
		if (get_value (KEY_ALT, output, sizeof(output))) {
			char * alt = output;
			while (isspace (*alt)) alt++;
			if (*alt) {
				WORD u, distances[5], effects[3];
				scan_string_to_16bit (alt, frame->Encoding, &current->text);
				TAsetItalic (word->attr, FALSE);
				TAsetBold   (word->attr, FALSE);
				TAsetFont   (word->attr, header_font);
				TA_Size     (word->attr) = 10;
				vst_font (vdi_handle, fonts[header_font][0][0]);
				vst_arbpt (vdi_handle, TA_Size (word->attr), &u,&u,&u,&u);
				vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
				word->word_height = distances[3];
				flags |= PF_FONT;
			}
		}
		
		get_value (KEY_SRC, img_file, sizeof(img_file));
		
		new_image (frame->Container,
		           get_value_size (KEY_WIDTH), get_value_size (KEY_HEIGHT),
		           get_value_size (KEY_VSPACE),get_value_size (KEY_HSPACE),
		           img_file, frame->Location);
	
		if (floating == ALN_NO_FLT) {
			new_word (current, TRUE);
		} else {
			TA_Color(word->attr) = current->font_step->colour;
			add_paragraph (current);
			flags |= PF_SPACE;
		}
		current->word->attr           = word_attr;
		current->word->word_height    = word_height;
		current->word->word_tail_drop = word_tail_drop;
		current->word->vertical_align = word_v_align;
	}
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Line BReak
*/
static UWORD
render_BR_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		char output[10];
		TEXTBUFF current = &frame->current;
		L_BRK    clear   = BRK_LN;
	
		if (get_value (KEY_CLEAR, output, sizeof(output))) {
			if      (stricmp (output, "right") == 0) clear = BRK_RIGHT;
			else if (stricmp (output, "left")  == 0) clear = BRK_LEFT;
			else if (stricmp (output, "all")   == 0) clear = BRK_ALL;
		} else if (get_value (KEY_CLEAR, NULL,0)) {
			clear = BRK_ALL; /* old style */
		}
		
		if (current->prev_wrd) {
			current->prev_wrd->line_brk = clear;
			current->word->vertical_align = ALN_BOTTOM;
		}
	}
	return (flags|PF_SPACE);
}


/*******************************************************************************
 *
 * Block Level Elements
*/

/*------------------------------------------------------------------------------
 * Headings
*/
static UWORD
render_H_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;

	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START)
	{
		short cur_color = frame->current.font_step->colour;
		
		if ((!frame->current_list)||(frame->current.paragraph->item->word_width > 0))
		{
			current->paragraph->eop_space = EOP(current->font_size);

			add_paragraph (current);

			switch (toupper (get_value_char (KEY_ALIGN)))
			{
				case 'R':
					current->paragraph->alignment = ALN_RIGHT;
					break;
				case 'C':
					current->paragraph->alignment = ALN_CENTER;
					break;
				case 'J':
				case 'L':
					current->paragraph->alignment = ALN_LEFT;
			}
		}
		
		step_push (current, 7 - (get_value_char (KEY_H_HEIGHT) - '0'));

		if (!ignore_colours) {
			short color = get_value_color (KEY_BGCOLOR);
			if (color >= 0 && color != current->backgnd) {
				current->paragraph->Backgnd   = color;
				current->paragraph->eop_space = 2;
			}
			color = get_value_color (KEY_COLOR);

			if (color == -1)	color = cur_color;
				
			current->font_step->colour = (color < 0 ? frame->text_colour : color);
		}
		word_set_font (current, header_font);
		word_set_bold (current, TRUE);
	}
	else
	{
		add_paragraph (current);

		current->paragraph->alignment = get_align(frame);

		step_pop (current);
		word_set_font (current, normal_font);
		word_set_bold (current, FALSE);
	}
	word_set_point (current, current->font_size);
	word_set_color (current, current->font_step->colour);
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Horizontal Ruler
 *
 * Completely reworked:
 * - hr_wrd->space_width:    line width (absolute or negative percent)
 * - hr_wrd->word_height:    vertical distance to the line
 * - hr_wrd->word_tail_drop: line size (height, negative for 'noshade')
 *
 * AltF4 - July 21, 2002
*/
static UWORD
render_HR_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		TEXTBUFF current = &frame->current;
		TEXTATTR attrib  = current->word->attr;
		PARAGRPH           hr_par;
		struct word_item * hr_wrd;
		char output[100];
	
		current->paragraph->eop_space = 0;
		hr_par = add_paragraph(current);
		hr_wrd = current->word;
	
		add_paragraph (current);
	
		hr_par->paragraph_code = PAR_HR;
		hr_par->alignment      = ALN_CENTER;
		if (get_value (KEY_ALIGN, output, sizeof(output))) {
			if      (stricmp (output, "left")  == 0) hr_par->alignment = ALN_LEFT;
			else if (stricmp (output, "right") == 0) hr_par->alignment = ALN_RIGHT;
		}
		hr_wrd->word_height   += hr_wrd->word_tail_drop;
		if ((hr_wrd->word_tail_drop = get_value_unum (KEY_SIZE, 0)) == 0 &&
		    (hr_wrd->word_tail_drop = get_value_unum (KEY_HEIGHT, 0)) == 0) {
			hr_wrd->word_tail_drop = 2;
		} else if (hr_wrd->word_tail_drop > 100) {
			hr_wrd->word_tail_drop = 100;
		}
		hr_wrd->word_height = (hr_wrd->word_height + hr_wrd->word_tail_drop) /2;
		if (get_value (KEY_NOSHADE, NULL,0)) {
			hr_wrd->word_tail_drop = -hr_wrd->word_tail_drop;
		}
		if ((hr_wrd->space_width = get_value_size (KEY_WIDTH)) == 0) {
			hr_wrd->space_width = -1024;
		}
		if (!ignore_colours) {
			WORD color = get_value_color (KEY_BGCOLOR);
			if (color >= 0 && color != current->backgnd) {
				hr_par->Backgnd = color;
			}
			color = get_value_color (KEY_COLOR);
			TA_Color(hr_wrd->attr) = (color                  >= 0 ? color    :
			                          hr_wrd->word_tail_drop <= 1 ? G_LBLACK :
			                          hr_par->Backgnd        >= 0 ? hr_par->Backgnd :
			                                                        current->backgnd);
		} else if (hr_wrd->word_tail_drop <= 1) {
			TA_Color(hr_wrd->attr) = G_BLACK;
		}
		
		current->word->attr = attrib;
		flags |= PF_SPACE;
	}
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Paragraph
 *
 * BUG: We must ignore empty paragraphs. Else <LI><P>...</P><P>...</P></LI>
 * looks bad. Vertical space is made by <P>&nbsp;</P>.
 * Rainer Seitel, 2002-03-16
*/
static UWORD
render_P_tag (FRAME frame, const char ** text, UWORD flags)
{
	PARAGRPH par = frame->current.paragraph;
	char     buf[8];

	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START)
	{
		H_ALIGN align = get_align (frame);

		par->eop_space = EOP(frame->current.font_size);

		par = add_paragraph (&frame->current);

		if (get_value (KEY_ALIGN, buf, sizeof(buf))) {
			if      (stricmp (buf, "right")   == 0) align = ALN_RIGHT;
			else if (stricmp (buf, "center")  == 0) align = ALN_CENTER;
			else if (stricmp (buf, "justify") == 0) align = ALN_JUSTIFY;
		}
		par->alignment = align;

		if (!ignore_colours) {
			WORD color = get_value_color (KEY_COLOR);
			if (color >= 0) {
				word_set_color (&frame->current, color);
			}
		}
	}
	else
	{
		par->eop_space = 0;

		par = add_paragraph (&frame->current);

		par->alignment = get_align(frame);

		if (!ignore_colours) {
			word_set_color (&frame->current,
			                frame->current.font_step->colour);
		}
	}

	frame->current.word->vertical_align = ALN_BOTTOM;
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Center Aligned Text
*/
#define render_C_tag   render_CENTER_tag

static UWORD
render_CENTER_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	add_paragraph (&frame->current);

	if (flags & PF_START) {
		frame->Page.Alignment               = ALN_CENTER;
		frame->current.paragraph->alignment = ALN_CENTER;
	} else {
		frame->Page.Alignment               = ALN_LEFT;
		frame->current.paragraph->alignment = get_align(frame);
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Quoted Passage
 *
 * A block quotation is a special paragraph, that consists of citated text.
 * A HTML browser can indent, surround with quotation marks, or use italic for
 * this paragraph.
 * http://purl.org/ISO+IEC.15445/Users-Guide.html#blockquote
*/
static UWORD
render_BLOCKQUOTE_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	current->paragraph->eop_space = EOP(current->font_size);
	add_paragraph (current);

	if (flags & PF_START)
	{
		#if 1
		/* BUG: TITLE support not ready.  This try leads to another problem:
		 * We need the entity and encoding conversion as a separate function.
		 * Or we do it complete before parsing.  But then PLAINTEXT is not
		 * possible.  It seems, this is this the reason, why it's deprecated. */
		char output[100];
		WORD u, distances[5], effects[3];
		#endif

		current->paragraph->alignment = ALN_LEFT;
		current->paragraph->Indent += list_indent (2);
		current->paragraph->Rindent += list_indent (2);

		#if 1
		if (get_value(KEY_TITLE, output, sizeof(output))) {
			short font_face = TAgetFace (current->word->attr);
			word_set_bold (current, TRUE);
			if (font_face != TAgetFace (current->word->attr)) {
				vst_font (vdi_handle,
				          fonts[TAgetFont  (current->word->attr)]
				               [TAgetBold  (current->word->attr)]
				               [TAgetItalic(current->word->attr)]);
				vst_arbpt (vdi_handle, TA_Size (current->word->attr), &u,&u,&u,&u);
				vqt_fontinfo(vdi_handle, &u, &u, distances, &u, effects);
				current->word->word_height = distances[3];
				current->word->word_tail_drop = distances[1];
				vqt_advance(vdi_handle, Space_Code,
				            &current->word->space_width, &u, &u, &u);
				current->word->space_width++;
			}
			scan_string_to_16bit(output, frame->Encoding, &current->text);
			current->paragraph->eop_space = EOP(current->font_size);
			add_paragraph(current);
			word_set_bold (current, FALSE);
		}
		#endif
	}
	else
	{
		current->paragraph->Indent  -= list_indent(2);
		current->paragraph->Rindent -= list_indent(2);
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Document Divisions
 *
 * DIV is only partially implemented from my understanding
 * baldrick - December 14, 2001
*/
static UWORD
render_DIV_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START)
	{
		PARAGRPH paragraph = frame->current.paragraph;

		paragraph->eop_space = EOP(frame->current.font_size);

		paragraph = add_paragraph (&frame->current);

		switch (toupper (get_value_char (KEY_ALIGN)))
		{
			case 'R': paragraph->alignment = ALN_RIGHT;  break;
			case 'C': paragraph->alignment = ALN_CENTER; break;
			case 'L': paragraph->alignment = ALN_LEFT;   break;
		}
	}
	else
	{
		add_paragraph(&frame->current)->alignment = get_align(frame);
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Preformatted Text
*/
static UWORD
render_PRE_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		current->paragraph->eop_space = EOP(current->font_size);
		add_paragraph (current);
		current->paragraph->alignment = ALN_LEFT;
		word_set_font (current, pre_font);
		flags |= PF_PRE;
	} else {
		word_set_font (current, normal_font);
		flags &= ~PF_PRE;
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Plain Text
*/
static UWORD
render_PLAINTEXT_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		TEXTBUFF current = &frame->current;
		current->paragraph->eop_space = EOP(current->font_size);
		add_paragraph (current);
		/* from now on plain text, never ending */
		parse_text (*text, frame);
		*text = strchr (*text, '\0');
	}
	
	return flags;
}

/*------------------------------------------------------------------------------
 * Listing Text
*/
static UWORD
render_LISTING_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current = &frame->current;
	
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		current->paragraph->eop_space = EOP(current->font_size);
		add_paragraph (current);
		current->paragraph->alignment = ALN_LEFT;
		word_set_font (current, pre_font);
		TAsetCondns (current->word->attr, TRUE);
		flags |= PF_PRE;
	} else {
		word_set_font (current, normal_font);
		TAsetCondns (current->word->attr, FALSE);
		flags &= ~PF_PRE;
	}
	
	return (flags|PF_SPACE);
}


/*******************************************************************************
 *
 * Lists
*/

/*------------------------------------------------------------------------------
 * Ordered List
*/
static UWORD
render_OL_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current   = &frame->current;
	PARAGRPH paragraph = current->paragraph;
	struct list_stack_item *temp_list_holder;

	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		if (!frame->current_list)
			paragraph->eop_space = EOP(current->font_size);

		paragraph = add_paragraph (current);

		if (frame->current_list)
			paragraph->Indent = frame->current_list->Indent;
		
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = frame->current_list;
		temp_list_holder->Spacer  = current->word->word_height *2 /3;
		temp_list_holder->Hanging = temp_list_holder->Spacer *4;
		temp_list_holder->Indent  = paragraph->Indent + temp_list_holder->Hanging;
		
		frame->current_list  = temp_list_holder;
		paragraph->alignment = ALN_LEFT;
		paragraph->Indent    = temp_list_holder->Indent;

		switch (get_value_char (KEY_TYPE))
		{
			case 'a':
				frame->current_list->bullet_style = alpha;
				break;
			case 'A':
				frame->current_list->bullet_style = Alpha;
				break;
			case 'i':
				frame->current_list->bullet_style = roman;
				break;
			case 'I':
				frame->current_list->bullet_style = Roman;
				break;
			default:
				frame->current_list->bullet_style = Number;
		}

		frame->current_list->counter = get_value_unum (KEY_START, 1);  /* BUG: long! */
	}
	else if (frame->current_list)
	{
		WORD indent = frame->current_list->Indent
		            - frame->current_list->Hanging;
		frame->current_list = remove_stack_item (frame->current_list);
		if (!frame->current_list)
			paragraph->eop_space += current->font_size / 3;

		add_paragraph (current)->Indent = indent;
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Unordered List
*/
static UWORD
render_UL_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current   = &frame->current;
	PARAGRPH paragraph = current->paragraph;
	struct list_stack_item *temp_list_holder;

	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		if (!frame->current_list)
			paragraph->eop_space = EOP(current->font_size);

		paragraph = add_paragraph (current);

		if (frame->current_list)
			paragraph->Indent = frame->current_list->Indent;
		
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = frame->current_list;
		temp_list_holder->Spacer  = current->word->word_height *2 /3;
		temp_list_holder->Hanging = temp_list_holder->Spacer *4;
		temp_list_holder->Indent  = paragraph->Indent + temp_list_holder->Hanging;
		
		paragraph->alignment  = ALN_LEFT;
		paragraph->Indent     = temp_list_holder->Indent;

		switch (get_value_char (KEY_TYPE))
		{
			case 'S':
			case 's':
				temp_list_holder->bullet_style = square;
				break;
			case 'c':
			case 'C':
				temp_list_holder->bullet_style = circle;
				break;
			case 'd':
			case 'D':
				temp_list_holder->bullet_style = disc;
			default:
				if (frame->current_list)
					temp_list_holder->bullet_style = (frame->current_list->bullet_style + 1) % 3;
		}

		frame->current_list = temp_list_holder;
	}
	else if (frame->current_list)
	{
		WORD indent = frame->current_list->Indent
		            - frame->current_list->Hanging;
		frame->current_list = remove_stack_item (frame->current_list);
		if (!frame->current_list)
			paragraph->eop_space += current->font_size / 3;

		add_paragraph (current)->Indent = indent;
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Menu List
 *
 * it's also possible that we could map this onto render_UL_tag
 * baldrick - December 13, 2001
*/
static UWORD
render_MENU_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current   = &frame->current;
	PARAGRPH paragraph = current->paragraph;
	struct list_stack_item *temp_list_holder;

	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START)
	{
		if (!frame->current_list)
			paragraph->eop_space = EOP(current->font_size);

		paragraph = add_paragraph (current);

		if (frame->current_list)
			paragraph->Indent = frame->current_list->Indent;
		
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = frame->current_list;
		temp_list_holder->Spacer  = current->word->word_height *2 /3;
		temp_list_holder->Hanging = temp_list_holder->Spacer *4;
		temp_list_holder->Indent  = paragraph->Indent + temp_list_holder->Hanging;
		
		frame->current_list  = temp_list_holder;
		paragraph->alignment = ALN_LEFT;
		paragraph->Indent    = temp_list_holder->Indent;
	}
	else if (frame->current_list)
	{
		WORD indent = frame->current_list->Indent
		            - frame->current_list->Hanging;
		frame->current_list = remove_stack_item (frame->current_list);
		if (!frame->current_list)
			paragraph->eop_space += current->font_size / 3;

		add_paragraph (current)->Indent = indent;
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Directory List
*/
#define render_DIR_tag   render_MENU_tag

/* Recursively converts a positive long to a decimal number wide string.
 * Rainer Seitel, 2002-03-11
 */
static void long2decimal(UWORD **p_ws, long l)
{
	if (l >= 10)
		long2decimal(p_ws, l / 10);

	**p_ws = map((l % 10) + '0');
	(*p_ws)++;
}


/* Recursively converts a positive long to an alphabet number wide string.
 * Rainer Seitel, 2002-03-11
 */
static void long2alpha(UWORD **p_ws, long l, BOOL upper)
{
	if (l > 26)
		long2alpha(p_ws, l / 26, upper);

	**p_ws = map(((l - 1) % 26) + (upper? 'A' : 'a'));
	(*p_ws)++;
}


static WORD
list_marker (struct frame_item *p_frame)
{
	UWORD * active_word = p_frame->current.text;
	WORD    indent_type = 0;
	WORD    count       = p_frame->current_list->counter;

	switch (p_frame->current_list->bullet_style)
	{
		case disc:
			*(active_word++) = 342;  /* U+2022 BULLET */
			indent_type = 0;
			break;
		case square:
			*(active_word++) = 507;  /* U+25AA BLACK SMALL SQUARE */
			indent_type = 0;
			break;
		case circle:
			*(active_word++) = 499;  /* U+25E6 WHITE BULLET */
			indent_type = 0;
			break;
		case Number:
			if (count < 0) {
				*(active_word++) = 283;  /* U+2212 MINUS SIGN */
				count = -count;
			}
			long2decimal(&active_word, count);
			*(active_word++) = 14;  /* U+002E . */
			p_frame->current_list->counter++;
			indent_type = 1;
			break;
		case alpha:
			if (count != 0) {
				if (count < 0) {
					*(active_word++) = 283;  /* U+2212 MINUS SIGN */
					count = -count;
				}
				long2alpha(&active_word, count, FALSE);
				*(active_word++) = 14;  /* U+002E . */
				p_frame->current_list->counter++;
				indent_type = 1;
				break;
			}
			/* else use @ as small alphabet zero */
		case Alpha:
			if (count < 0) {
				*(active_word++) = 283;  /* U+2212 MINUS SIGN */
				count = -count;
			}
			long2alpha(&active_word, count, TRUE);
			*(active_word++) = 14;  /* U+002E . */
			p_frame->current_list->counter++;
			indent_type = 1;
			break;
		case roman:
			if (count > 0 && count < 3000) {
				switch (count / 1000 * 1000) {
				case 2000:
					*(active_word++) = map('m');
				case 1000:
					*(active_word++) = map('m');
					break;
				}
				switch ((count % 1000) / 100 * 100) {
				case 300:
					*(active_word++) = map('c');
				case 200:
					*(active_word++) = map('c');
				case 100:
					*(active_word++) = map('c');
					break;
				case 400:
					*(active_word++) = map('c');
				case 500:
					*(active_word++) = map('d');
					break;
				case 600:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					break;
				case 700:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					break;
				case 800:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					break;
				case 900:
					*(active_word++) = map('c');
					*(active_word++) = map('m');
					break;
				}
				switch ((count % 100) / 10 * 10) {
				case 30:
					*(active_word++) = map('x');
				case 20:
					*(active_word++) = map('x');
				case 10:
					*(active_word++) = map('x');
					break;
				case 40:
					*(active_word++) = map('x');
				case 50:
					*(active_word++) = map('l');
					break;
				case 60:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					break;
				case 70:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					break;
				case 80:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					break;
				case 90:
					*(active_word++) = map('x');
					*(active_word++) = map('c');
					break;
				}
				switch (count % 10) {
				case 3:
					*(active_word++) = map('i');
				case 2:
					*(active_word++) = map('i');
				case 1:
					*(active_word++) = map('i');
					break;
				case 4:
					*(active_word++) = map('i');
				case 5:
					*(active_word++) = map('v');
					break;
				case 6:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					break;
				case 7:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					break;
				case 8:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					break;
				case 9:
					*(active_word++) = map('i');
					*(active_word++) = map('x');
					break;
				}
			} else {  /* BUG: small Roman numerals >= 3000 not implemented! */
				long2decimal(&active_word, count);
			}
			*(active_word++) = 14;  /* U+002E . */
			p_frame->current_list->counter++;
			indent_type = 1;
			break;
		case Roman:
			/* Sources:
			 * Friedlein, Gottfried: Die Zahlzeichen und das elementare Rechnen
			 * der Griechen und R�mer und des christlichen Abendlandes vom 7.
			 * bis 13. Jahrhundert. - unver�nderter Neudruck der Ausgabe von
			 * 1869. - Wiesbaden : Dr. Martin S�ndig oHG, 1968.
			 * Ifroh, Georges: Universalgeschichte der Zahlen. - Frankfurt am
			 * Main ; New York : Campus, 1986. - ISBN 3-593-33666-9. - Kapitel
			 * 9. (Histoire Universelle des Chiffres. - Paris : Seghers, 1981.)
			 * Rainer Seitel, 2002-03-11
			 */
			if (count > 0 && count < 20000) {
				if (count >= 10000) {
					*(active_word++) = map('(');
					*(active_word++) = map('(');
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
				}
				switch ((count % 10000) / 1000 * 1000) {
				case 9000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 8000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 7000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 6000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					break;
				case 5000:
					*(active_word++) = map('M');
				case 4000:
					*(active_word++) = map('M');
				case 3000:
					*(active_word++) = map('M');
				case 2000:
					*(active_word++) = map('M');
				case 1000:
					*(active_word++) = map('M');
					break;
				}
				switch ((count % 1000) / 100 * 100) {
				case 300:
					*(active_word++) = map('C');
				case 200:
					*(active_word++) = map('C');
				case 100:
					*(active_word++) = map('C');
					break;
				case 400:
					*(active_word++) = map('C');
				case 500:
					*(active_word++) = map('D');
					break;
				case 600:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					break;
				case 700:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					break;
				case 800:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					break;
				case 900:
					*(active_word++) = map('C');
					*(active_word++) = map('M');
					break;
				}
				switch ((count % 100) / 10 * 10) {
				case 30:
					*(active_word++) = map('X');
				case 20:
					*(active_word++) = map('X');
				case 10:
					*(active_word++) = map('X');
					break;
				case 40:
					*(active_word++) = map('X');
				case 50:
					*(active_word++) = map('L');
					break;
				case 60:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					break;
				case 70:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					break;
				case 80:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					break;
				case 90:
					*(active_word++) = map('X');
					*(active_word++) = map('C');
					break;
				}
				switch (count % 10) {
				case 3:
					*(active_word++) = map('I');
				case 2:
					*(active_word++) = map('I');
				case 1:
					*(active_word++) = map('I');
					break;
				case 4:
					*(active_word++) = map('I');
				case 5:
					*(active_word++) = map('V');
					break;
				case 6:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					break;
				case 7:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					break;
				case 8:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					break;
				case 9:
					*(active_word++) = map('I');
					*(active_word++) = map('X');
					break;
				}
			} else {  /* BUG: Roman numerals >= 20000 not implemented! */
				long2decimal(&active_word, count);
			}
			*(active_word++) = 14;  /* U+002E . */
			p_frame->current_list->counter++;
			indent_type = 1;
			break;
	}

	p_frame->current.text = active_word;

	return list_indent (indent_type);
}


/*------------------------------------------------------------------------------
 * List Item
*/
static UWORD
render_LI_tag (FRAME frame, const char ** text, UWORD flags)
{
	TEXTBUFF current  = &frame->current;

	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (!frame->current_list) {
		if (flags & PF_START) {
			current->prev_wrd->line_brk = BRK_LN;
		}
	
	} else if (flags & PF_START) {
		PARAGRPH li_par   = current->paragraph;
		WORD     old_size = TA_Size (current->word->attr);
		WORD     indent   = frame->current_list->Hanging
		                  - frame->current_list->Spacer;
		WORD     u;
		
		/* this basically just catches that it's not the first LI in a list */
		if (li_par->item != current->word) {
			li_par = add_paragraph (current);
		}
		li_par->Indent = frame->current_list->Indent;
	
		switch (get_value_char (KEY_TYPE))
		{
			case 'a':
				frame->current_list->bullet_style = alpha;
				break;
			case 'A':
				frame->current_list->bullet_style = Alpha;
				break;
			case 'i':
				frame->current_list->bullet_style = roman;
				break;
			case 'I':
				frame->current_list->bullet_style = Roman;
				break;
			case '1':
				frame->current_list->bullet_style = Number;
				break;
			case 'd':
			case 'D':
				frame->current_list->bullet_style = disc;
				break;
			case 'c':
			case 'C':
				frame->current_list->bullet_style = circle;
				break;
			case 's':
			case 'S':
				frame->current_list->bullet_style = square;
				break;
		}
		frame->current_list->counter = get_value_unum (KEY_VALUE,
		                                            frame->current_list->counter);
		
		word_set_point (current, step2size (NULL, current->font_step->step -2));
		vst_arbpt (vdi_handle, TA_Size (current->word->attr), &u, &u, &u, &u);
		list_marker (frame);
		add_paragraph (current)->alignment = ALN_LEFT;
		
		if (li_par->item->word_width > indent) {
			current->paragraph->Indent += li_par->item->word_width - indent;
			li_par->Indent -= frame->current_list->Hanging;
		} else {
			li_par->Indent -= li_par->item->word_width
			                + frame->current_list->Spacer;
		}
		li_par->eop_space = -(li_par->item->word_height +
		                      li_par->item->word_tail_drop);
		
		word_set_point (current, old_size);
		flags |= PF_FONT;
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Definition List
*/
static UWORD
render_DL_tag (FRAME frame, const char ** text, UWORD flags)
{
	PARAGRPH prev_par  = frame->current.paragraph;
	PARAGRPH paragraph = add_paragraph (&frame->current);

	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	paragraph->alignment = ALN_LEFT;

	if (flags & PF_START)
	{
		struct list_stack_item *temp_list_holder;
		
		if (!frame->current_list)
			prev_par->eop_space = EOP(frame->current.font_size);
		else
			paragraph->Indent = frame->current_list->Indent;
		
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = frame->current_list;
		temp_list_holder->Spacer  = frame->current.word->word_height *2 /3;
		temp_list_holder->Hanging = temp_list_holder->Spacer *4;
		temp_list_holder->Indent  = paragraph->Indent
		                          + temp_list_holder->Hanging;
		frame->current_list = temp_list_holder;
		paragraph->Indent   = temp_list_holder->Indent;
	}
	else if (frame->current_list)
	{
		paragraph->Indent = frame->current_list->Indent
		                  - frame->current_list->Hanging;
		frame->current_list = remove_stack_item (frame->current_list);
		if (!frame->current_list) {
			prev_par->eop_space += frame->current.font_size / 3;
		}
	}
	
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Definition Term
*/
static UWORD
render_DT_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif

	if (flags & PF_START && frame->current_list){
		PARAGRPH paragraph = add_paragraph (&frame->current);
		paragraph->alignment = ALN_LEFT;
		paragraph->Indent = frame->current_list->Indent
		                  - frame->current_list->Hanging;
	}
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Definition Text
*/
static UWORD
render_DD_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif

	if (flags & PF_START && frame->current_list){
		PARAGRPH paragraph = add_paragraph (&frame->current);
		paragraph->alignment = ALN_LEFT;
		paragraph->Indent = frame->current_list->Indent;
	}
	return (flags|PF_SPACE);
}


/*******************************************************************************
 *
 * Tables
*/

/*------------------------------------------------------------------------------
 * Start Or End
*/
static UWORD
render_TABLE_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START) {
		table_start (frame);
	} else if (frame->TableStack) {
		table_finish (frame);
	}
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Table Row
*/
static UWORD
render_TR_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (frame->TableStack) {
		table_row (frame, (flags & PF_START));
	}
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Table Data Cell
*/
static UWORD
render_TD_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START && frame->TableStack) {
		table_cell (frame, FALSE);
		flags |= PF_FONT;
	}
	return (flags|PF_SPACE);
}

/*------------------------------------------------------------------------------
 * Table Header Cell
*/
static UWORD
render_TH_tag (FRAME frame, const char ** text, UWORD flags)
{
	#ifdef __PUREC__
		text = text;  /* unused */
	#endif
	
	if (flags & PF_START && frame->TableStack) {
		table_cell (frame, TRUE);
		flags |= PF_FONT;
	}
	return (flags|PF_SPACE);
}


/*******************************************************************************
 *
 * Fill-out Formulars
*/

#define render_FORM_tag     NULL
#define render_INPUT_tag    NULL
#define render_OPTION_tag   NULL
#define render_SELECT_tag   NULL
#define render_TEXTAREA_tag NULL


/*==============================================================================
 * The HTML Parsing Routine
 *
 * AltF4 - Feb. 04, 2002: renamed to parse_html() because that matches more its
 *                        functionality, corresponding to parse_text().
 */
BOOL
parse_html (const char *symbol, struct frame_item *p_frame)
{
	time_t start_clock = clock();
	
	TEXTBUFF  current = &p_frame->current;
	ENCODER_W encoder = encoder_word (p_frame->Encoding & 0x7Fu);
	UWORD active_word_buffer[500];  /* 500 is enough for 124 UTF-8 characters,
	                                 * if the encoding is unrecognized, parsed
	                                 * as single byte characters in PRE mode. */
	UWORD * watermark_1 = active_word_buffer + sizeof(active_word_buffer)
	                    - sizeof(*active_word_buffer);
	UWORD * watermark_4 = watermark_1 - sizeof(*active_word_buffer) *4;
	BOOL space_found = TRUE;  /* skip leading spaces */
	BOOL in_pre      = FALSE;
	BOOL linetoolong = FALSE;  /* "line too long" error printed? */
	WORD u, distances[5], effects[3];
	
	ENCODING force_cset = (p_frame->Encoding & 0x80u
	                       ? p_frame->Encoding & 0x7Fu : 0);
	if (force_cset) {
		p_frame->Encoding = force_cset;
	}
	
	if (symbol == NULL) return FALSE;

	current->text = current->buffer = active_word_buffer;

	vst_font (vdi_handle, fonts[0][0][0]);
	current->font_step = new_step (3, p_frame->text_colour);
	vst_arbpt (vdi_handle, current->font_size, &u,&u,&u,&u);
	vqt_advance (vdi_handle, Space_Code, &current->word->space_width, &u,&u,&u);
	current->word->space_width++;

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	current->word->word_height = distances[3];
	current->word->word_tail_drop = distances[1];

	while (*symbol != '\0')
	{
		if (*symbol == '<')
		{
			TEXTATTR attrib = current->word->attr;
			BOOL flags;
			BOOL start_tag = (*(++symbol) != '/');
			if (!start_tag) symbol++;
			
			flags = (start_tag   ? PF_START : PF_NONE)
			      | (in_pre      ? PF_PRE   : PF_NONE)
			      | (space_found ? PF_SPACE : PF_NONE);

			if (current->text > current->buffer) {
				new_word (current, TRUE);
			}
		#if 1
		{
			typedef UWORD (*RENDER)(FRAME, const char **, UWORD);
			static RENDER render[] = {
				NULL,
				#undef SMALL                   /* prevent an error because this
				                                * is already defined in gem.h   */
				#define render_FRAME_tag NULL /* not needed */
				/* now create the function table */
				#define __TAG_ITEM(t)   render_##t##_tag
				#include "token.h"
			};
			HTMLTAG tag = parse_tag (&symbol);
			if (tag && render[tag]) {
				flags = (render[tag])(p_frame, &symbol, flags);
			}
		}
		#else
			switch (parse_tag (&symbol))
			{
				case TAG_A:
					flags = render_A_tag (p_frame, &symbol, flags);
					break;
				case TAG_B:
					flags = render_B_tag (p_frame, &symbol, flags);
					break;
				case TAG_BASE:
					flags = render_BASE_tag (p_frame, &symbol, flags);
					break;
				case TAG_BASEFONT:
					flags = render_BASEFONT_tag (p_frame, &symbol, flags);
					break;
				case TAG_BGSOUND:
				case TAG_EMBED:
					flags = render_BGSOUND_tag (p_frame, &symbol, flags);
					break;
				case TAG_BIG:
					flags = render_BIG_tag (p_frame, &symbol, flags);
					break;
				case TAG_BLOCKQUOTE:
					flags = render_BLOCKQUOTE_tag (p_frame, &symbol, flags);
					break;
				case TAG_BODY:
					flags = render_BODY_tag (p_frame, &symbol, flags);
					break;
				case TAG_BR:
					flags = render_BR_tag (p_frame, &symbol, flags);
					break;
				case TAG_C:
				case TAG_CENTER:
					flags = render_CENTER_tag (p_frame, &symbol, flags);
					break;
				case TAG_CITE:
					flags = render_CITE_tag (p_frame, &symbol, flags);
					break;
				case TAG_CODE:
					flags = render_CODE_tag (p_frame, &symbol, flags);
					break;
				case TAG_DFN:
					flags = render_DFN_tag  (p_frame, &symbol, flags);
					break;
				case TAG_DIR:
					flags = render_DIR_tag  (p_frame, &symbol, flags);
					break;
				case TAG_DIV:
					flags = render_DIV_tag  (p_frame, &symbol, flags);
					break;
				case TAG_DL: /* (definition list) */
					flags = render_DL_tag   (p_frame, &symbol, flags);
					break;
				case TAG_DT: /* (definition term) */
					flags = render_DT_tag   (p_frame, &symbol, flags);
					break;
				case TAG_DD: /* (definition description) */
					flags = render_DD_tag   (p_frame, &symbol, flags);
					break;
				case TAG_EM:
					flags = render_EM_tag   (p_frame, &symbol, flags);
					break;
				case TAG_FONT:
					flags = render_FONT_tag (p_frame, &symbol, flags);
					break;
				
				case TAG_FORM:
/*					if (start_tag)
						form_start (p_frame);
					else if (p_frame->FormStack)
						form_finish (p_frame);
*/
					break;
				case TAG_H: /* header tag <H1>..<H6> */
					flags = render_H_tag   (p_frame, &symbol, flags);
					break;
				case TAG_HR:
					flags = render_HR_tag  (p_frame, &symbol, flags);
					break;
				case TAG_I:
					flags = render_I_tag   (p_frame, &symbol, flags);
					break;
				case TAG_IMG:
					flags = render_IMG_tag (p_frame, &symbol, flags);
					break;
				
				case TAG_INPUT:
					break;
				
				case TAG_IOD:
					flags = render_IOD_tag (p_frame, &symbol, flags);
					break;
				case TAG_KBD:
					flags = render_KBD_tag (p_frame, &symbol, flags);
					break;
				case TAG_LI: /* (list item) */
					flags = render_LI_tag (p_frame, &symbol, flags);
					break;
				case TAG_LISTING:
					flags = render_LISTING_tag (p_frame, &symbol, flags);
					break;
				case TAG_MENU:
					flags = render_MENU_tag (p_frame, &symbol, flags);
					break;
				
				case TAG_META:
					flags = render_META_tag (p_frame, &symbol, flags);
					break;
				case TAG_OL:
					flags = render_OL_tag (p_frame, &symbol, flags);
					break;
				
				case TAG_OPTION:
					break;
				
				case TAG_P: /* (paragraph) */
					flags = render_P_tag (p_frame, &symbol, flags);
					break;
				
				case TAG_PLAINTEXT:
					flags = render_PLAINTEXT_tag (p_frame, &symbol, flags);
					break;
				case TAG_PRE:
					flags = render_PRE_tag    (p_frame, &symbol, flags);
					break;
				case TAG_Q:
					flags = render_Q_tag      (p_frame, &symbol, flags);
					break;
				case TAG_S:
					flags = render_S_tag      (p_frame, &symbol, flags);
					break;
				case TAG_SAMP:
					flags = render_SAMP_tag   (p_frame, &symbol, flags);
					break;
				case TAG_SUP:
					flags = render_SUP_tag    (p_frame, &symbol, flags);
					break;
				case TAG_SCRIPT:
					flags = render_SCRIPT_tag (p_frame, &symbol, flags);
					break;
				case TAG_NOSCRIPT:
					flags = render_NOSCRIPT_tag (p_frame, &symbol, flags);
					break;
				case TAG_SMALL:
					flags = render_SMALL_tag  (p_frame, &symbol, flags);
					break;
				case TAG_STRIKE:
					flags = render_STRIKE_tag (p_frame, &symbol, flags);
					break;
				case TAG_STRONG:
					flags = render_STRONG_tag (p_frame, &symbol, flags);
					break;
				case TAG_STYLE:
					flags = render_STYLE_tag (p_frame, &symbol, flags);
					break;
				case TAG_SUB:
					flags = render_SUB_tag    (p_frame, &symbol, flags);
					break;

				case TAG_SELECT:
					break;
				
				case TAG_TABLE:
					flags = render_TABLE_tag (p_frame, &symbol, flags);
					break;
				case TAG_TR: /* (table row) */
					flags = render_TR_tag (p_frame, &symbol, flags);
					break;
				case TAG_TD: /* (table data cell) */
					flags = render_TD_tag (p_frame, &symbol, flags);
					break;
				case TAG_TH: /* (table header cell) */
					flags = render_TH_tag (p_frame, &symbol, flags);
					break;
				
				case TAG_TEXTAREA:
					if (start_tag) {
						current->paragraph->eop_space = EOP(current->font_size);
						add_paragraph (current);
						current->paragraph->alignment = ALN_LEFT;
						word_set_font (current, pre_font);
					} else {
						word_set_font (current, normal_font);
					}
					in_pre = start_tag;
					break;
				
				case TAG_TITLE:
					flags = render_TITLE_tag (p_frame, &symbol, flags);
					break;
				case TAG_TT:
					flags = render_TT_tag (p_frame, &symbol, flags);
					break;
				case TAG_U:
					flags = render_U_tag  (p_frame, &symbol, flags);
					break;
				case TAG_UL: /* (unordered list) */
					flags = render_UL_tag  (p_frame, &symbol, flags);
					break;
				case TAG_VAR:
					flags = render_VAR_tag (p_frame, &symbol, flags);
					break;
				case TAG_XMP:
					flags = render_XMP_tag (p_frame, &symbol, flags);
					break;
				
				case TAG_FRAMESET: /* frame processing */
					flags = render_FRAMESET_tag (p_frame, &symbol, flags);
					break;
				case TAG_HTML:
					flags = render_HTML_tag (p_frame, &symbol, flags);
					break;
				
				/* we don't set a 'default:' directive here because at least gcc
				 * can tell us if we have forgotten a TAG this way   */

				 case TAG_FRAME:
				 case TAG_Unknown:
				 case TAG_LastDefined: ;
			}
		#endif
			in_pre      = (flags & PF_PRE   ? TRUE : FALSE);
			space_found = (flags & PF_SPACE ? TRUE : FALSE);
			if (flags & PF_ENCDNG) {
				if (force_cset) {
					p_frame->Encoding = force_cset;
				} else {
					extern ENCODING last_encoding;  /* from Loader.c */
					last_encoding = p_frame->Encoding;  /* used for Undo key */
					encoder = encoder_word (p_frame->Encoding);
				}
				flags &= ~PF_ENCDNG;
			}
			if (flags & PF_FONT) {
				flags &= PF_FONT;
				attrib.packed = 0x300uL; /* force font setting */
			} else {
				attrib.packed ^= current->word->attr.packed;
				attrib.packed &= (TA_SizeMASK|TA_FaceMASK);
			}
			if (attrib.packed) {
				WORDITEM word = current->word;
				long w = 0;
				if (TAgetFace (attrib)) {
					vst_font (vdi_handle, fonts[TAgetFont  (word->attr)]
					                           [TAgetBold  (word->attr)]
					                           [TAgetItalic(word->attr)]);
				}
				vst_arbpt (vdi_handle, TA_Size (word->attr), &u,&u,(WORD*)&w,&u);
				if (TAgetCondns (word->attr)) {
					vst_setsize32 (vdi_handle, (w *8 +5) /11, &u,&u,&u,&u);
				}
				vqt_advance (vdi_handle, Space_Code, &word->space_width, &u,&u,&u);
				word->space_width++;
				vqt_fontinfo (vdi_handle, &u,&u, distances, &u, effects);
				word->word_height    = distances[3];
				word->word_tail_drop = distances[1];
			}

			continue;
		}

		switch (*symbol)
		{
			case '&':
				if (current->text < watermark_4) {
					current->text = scan_namedchar (&symbol, current->text, TRUE);
				} else if (linetoolong == FALSE) {
					errprintf("parse_html(): Line too long in '%s'!\n",
					          p_frame->Location->File);
					linetoolong = TRUE;
				}
				space_found = FALSE;
				break;
			
			case ' ':
				if (in_pre) {
					if (current->text < watermark_4) {
						*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					} else if (linetoolong == FALSE) {
						errprintf("parse_html(): Line too long in '%s'!\n",
						          p_frame->Location->File);
						linetoolong = TRUE;
					}
					symbol++;
					break;
				}
				goto white_space;
			
			case 9:  /* HT HORIZONTAL TABULATION */
				if (in_pre) {
					if (current->text < watermark_4 -8) {
						do {
							*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
						} while (((current->text - active_word_buffer) & 7) != 0);
					} else if (linetoolong == FALSE) {
						errprintf("parse_html(): Line too long in '%s'!\n",
						          p_frame->Location->File);
						linetoolong = TRUE;
					}
					symbol++;
					break;
				}
				goto white_space;
			
			case 13: /* CR CARRIAGE RETURN */
				if (*(symbol + 1) == 10)  /* HTTP, TOS, or DOS text file */
					symbol++;
				/* else Macintosh text file */
			case 10: /* LF LINE FEED */
			case 11: /* VT VERTICAL TABULATION */
			case 12: /* FF FORM FEED */
				if (in_pre) {
					/* BUG: empty paragrahps were ignored otherwise */
					*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					add_paragraph(current);
					symbol++;
					break;
				}
				/* else fall through */
				
			white_space: /* if (!in_pre) */
				if (!space_found) {
					new_word (current, TRUE);
					*(current->text++) = Space_Code;
					space_found = TRUE;
				}
				while (isspace (*(++symbol)));
				break;
			
			default:
				if (current->text < watermark_4) {
					current->text = (*encoder)(&symbol, current->text);
				} else if (linetoolong == FALSE) {
					errprintf("parse_html(): Line too long in '%s'!\n",
					          p_frame->Location->File);
					linetoolong = TRUE;
					symbol++;
				}
				space_found = FALSE;
		}
	}

	word_store (current);
	while (p_frame->TableStack) {
		table_finish (p_frame);
	}
	content_minimum (&p_frame->Page);

	logprintf(LOG_BLUE, "%ld ms for '%s%s'\n",
	          (clock() - start_clock) * 1000 / CLK_TCK,
	          location_Path (p_frame->Location, NULL), p_frame->Location->File);

	return FALSE;
}


/*==============================================================================
 * Parse Plain Text
 *
 * this is the text parsing routine
 * for use with non formatted text files
 *
 * Nothing exciting just maps lines to paragraphs
 */

BOOL
parse_text (const char *symbol, struct frame_item *p_frame)
{
	time_t start_clock = clock();
	
	TEXTBUFF current  = &p_frame->current;
	ENCODER_W encoder = encoder_word (p_frame->Encoding &= 0x7F);
	PARAGRPH previous = NULL;
	WORD     linefeed;
	UWORD active_word_buffer[500];  /* 500 is enough for 124 UTF-8 characters
	                                 * parsed as single byte characters. */
	UWORD * watermark_1 = active_word_buffer + sizeof(active_word_buffer)
	                    - sizeof(*active_word_buffer);
	UWORD * watermark_4 = watermark_1 - sizeof(*active_word_buffer) *4;
	WORD u, distances[5], effects[3];
	BOOL linetoolong = FALSE;  /* "line too long" error printed? */

	if (symbol == NULL) return FALSE;

	current->text = current->buffer = active_word_buffer;
	
	word_set_font (current, pre_font);
	
	vst_font (vdi_handle, fonts[0][0][0]);
	vst_arbpt (vdi_handle, current->font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &current->word->space_width, &u,&u,&u);
	current->word->space_width++;
	
	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	current->word->word_height    = distances[3];
	current->word->word_tail_drop = distances[1];
	
	linefeed = current->word->word_height + current->word->word_tail_drop;

	while (*symbol != '\0')
	{
		switch (*symbol)
		{
			case 9: /* HT HORIZONTAL TABULATION */
				if (current->text < watermark_4) {
					size_t pos = (current->text - active_word_buffer) /2;
					UWORD  num = 4 - ((UWORD)pos & 0x0003);
					while (num--) {
						*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					}
				} else if (!linetoolong) {
					errprintf ("parse_text(): Line too long in '%s'!\n",
					           p_frame->Location->File);
					linetoolong = TRUE;
				}
				symbol++;
				break;
			
			case 13: /* CR CARRIAGE RETURN */
				if (*(symbol +1) == 10)  /* HTTP, TOS, or DOS text file */
					symbol++;
				/* else Macintosh text file */
			case 10: /* LF LINE FEED */
			case 11: /* VT VERTICAL TABULATION */
			case 12: /* FF FORM FEED */
				if (current->text > active_word_buffer) {
					current->word->line_brk = BRK_LN;
					new_word (current, TRUE);
					previous = NULL;
				} else if (!previous) {
					*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					previous = current->paragraph;
					add_paragraph(current);
				} else {
					previous->eop_space += linefeed;
				}
				symbol++;
				break;
			
			default: {
				if (*symbol <= 32 || *symbol == 127) {
					if (current->text < watermark_1) {
						*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					} else if (!linetoolong) {
						errprintf ("parse_text(): Line too long in '%s'!\n",
						           p_frame->Location->File);
						linetoolong = TRUE;
					}
					symbol++;
				
				} else {
					if (current->text < watermark_4) {
						current->text = (*encoder)(&symbol, current->text);
					} else if (!linetoolong) {
						errprintf ("parse_text(): Line too long in '%s'!\n",
						           p_frame->Location->File);
						linetoolong = TRUE;
						symbol++;
					}
				}
			}
		}
	}
	if (current->text > active_word_buffer || !previous) {
		word_store (current);
	} else {
		previous->next_paragraph = NULL;
		destroy_paragraph_structure (current->paragraph);
	}
	content_minimum (&p_frame->Page);

	logprintf (LOG_BLUE, "%ld ms for '%s%s'\n",
	           (clock() - start_clock) * 1000 / CLK_TCK,
	          location_Path (p_frame->Location, NULL), p_frame->Location->File);

	return FALSE;
}
