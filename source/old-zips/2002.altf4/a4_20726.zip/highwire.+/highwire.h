/* resource set indices for HIGHWIRE */

#define MENUTREE               0 /* menu */
#define M_ABOUT                8 /* STRING in tree MENUTREE */
#define M_OPEN                17 /* STRING in tree MENUTREE */
#define M_INFO                19 /* STRING in tree MENUTREE */
#define M_QUIT                21 /* STRING in tree MENUTREE */
#define M_RELOAD              23 /* STRING in tree MENUTREE */
#define M_1252                25 /* STRING in tree MENUTREE */
#define M_ISO8859_2           26 /* STRING in tree MENUTREE */
#define M_UTF8                27 /* STRING in tree MENUTREE */
#define M_ATAR_SYS            28 /* STRING in tree MENUTREE */
#define M_FONT_INC            30 /* STRING in tree MENUTREE */
#define M_FONT_DEC            31 /* STRING in tree MENUTREE */

#define ABOUT                  1 /* form/dialog */
#define ABOUTOK                1 /* BUTTON in tree ABOUT */

#define URLINPUT               2 /* form/dialog */
#define URL_OK                 2 /* BUTTON in tree URLINPUT */
#define URL_CANCEL             3 /* BUTTON in tree URLINPUT */
#define URL_FILE               4 /* BUTTON in tree URLINPUT */
#define URL_ED_BG              5 /* IBOX in tree URLINPUT */
#define URL_EDIT               6 /* FBOXTEXT in tree URLINPUT */

