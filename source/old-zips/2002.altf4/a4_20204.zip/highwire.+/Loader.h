#ifndef __LOADER_H__
#define __LOADER_H__


typedef struct frame_item * FRAME;

typedef struct s_loader {
	FRAME Target;    /* where the data schould go to */
	FRAME TmpFrame;  /* holds some data to get over  */
	WORD  ParseType; /* how shall datas be attached to the target frame */
	
	char * Data;
	
	char       * FileName;
	const char * Anchor;
	WORD         Decoder;
	char         Address[1];
} * LOADER;


LOADER new_loader    (const char * address);
void   delete_loader (LOADER *);

void new_loader_job (WORD type, char *address, FRAME target, FRAME info_frame);


#endif /*__LOADER_H__*/
