
#include "defs.h"

/* To compile a version with a GEM Menubar uncomment
 * the following line.
 */
 
/*#define GEM_MENU 1
*/

#ifdef GEM_MENU
#include "highwire.h"
#endif


/* for printf for testing */
#include <stdio.h>

/* ******** Variable Definitions ******************* */

/* Globals */
extern VDI_Workstation vdi_dev;
extern enum bool frames_recalculated;
extern WORD vdi_handle;
extern WORD app_id;
extern WORD window_handle;
extern WORD win_status;
extern WORD pre_status;

extern WORD planes; /* used to track screen planes -- bit depth */

extern WORD fonts[3][2][2];
extern WORD event_messages[8];
extern WORD number_of_frames_left_to_load;
extern struct frame_item *the_first_frame;
extern struct frame_item *previous_frame;
extern struct clickable_area *current_highlighted_link_area;
extern struct frame_item *current_highlighted_link_frame;
extern struct to_do_item *add_to_do;
extern struct to_do_item *read_to_do;

/* To be in-program settings */
extern WORD link_colour;
extern WORD highlighted_link_colour;
extern WORD text_colour;

extern WORD slider_bkg;
extern WORD slider_col;

extern WORD ignore_colours;

/* ****************** Function Defs ******************************** */

WORD V_Opnvwk(VDI_Workstation *);
WORD V_Opnwk(WORD, VDI_Workstation *);


void draw_frame_contents(struct frame_item *current_frame, struct paragraph_item *,WORD,long,WORD,WORD,WORD);
long calculate_frame_height(struct frame_item *);
void calculate_frame_locations(void);
void blit_block(struct frame_item *,WORD , enum direction );
struct word_item *list_marker(struct frame_item *);
enum bool process_messages(struct frame_item *);
void redraw(WORD,WORD,WORD,WORD,WORD,struct frame_item *);
void redraw_frame(WORD,WORD,WORD,WORD,WORD,struct frame_item *);
void scroll_bar(struct frame_item *, WORD);
WORD special_char_map(WORD);
void button_clicked(struct frame_item *,WORD ,WORD );
void frame_clicked(struct frame_item *,struct frame_item *,WORD ,WORD );
void check_mouse_position(struct frame_item *, WORD , WORD );
void draw_frame_borders(struct frame_item *,WORD);

/* in Config.c */
WORD read_config(char *fn);

/* in f_struct.c */
struct frame_item *temp_frame (void);

/* in highwire.c */
void highwire_ex(void);
#ifdef GEM_MENU
void handle_menu(WORD item, WORD *msg);
void do_info_dialog(void);
#endif

/* in keyinput.c */
void key_pressed (struct frame_item *first_frame, WORD key);
int page_load(void );
void build_fname( char *dest, char *s1, char *s2 );

/* in loader.c */
char * load_file(const char *);
void init_load(char *file);
char *translate_address(char *);
WORD get_decoder_type(char *filename);
long search_for_named_location(char *,struct named_location *);
void init_paths(void);
WORD identify_AES(void);

/* in render.c */
struct paragraph_item *parse_text (char *symbol, struct frame_item *p_frame);
struct paragraph_item *parse_html (char *symbol, struct frame_item *p_frame);
WORD convert_to_number(const char *text);
WORD list_indent(WORD);
WORD map(char symbol);
struct url_link *new_url_link(char *, enum link_mode, char *);
struct font_step *new_step(WORD);
struct font_step *add_step(struct font_step *);
struct font_step *destroy_step(struct font_step *);
struct list_stack_item *remove_stack_item(struct list_stack_item *);
struct list_stack_item *new_stack_list_item(void);
struct frame_item *new_frame(void);
void reset_frame(struct frame_item *);
void destroy_frame_structure(struct frame_item *);
void destroy_clickable_area_structure(struct clickable_area *);
struct clickable_area *new_clickable_area();
void destroy_named_location_structure(struct named_location *);
struct named_location *new_named_location();

void check_to_do_list(void);
struct named_location * new_named_location(void);
struct clickable_area * new_clickable_area(void);

/* in color.c */

void save_colors(void);
WORD remap_color (long value);

/* in netlayer.c */

WORD init_netlayer(void);
WORD close_netlayer(void);
WORD request_URI(const char *);

/* in p_struct.c */

void destroy_paragraph_structure(struct paragraph_item *);
struct paragraph_item *new_paragraph(void);
void add_paragraph(struct frame_item *p_frame, WORD *);

/* in table.c */

struct table_step *new_table_step (struct paragraph_item *p_table);
struct table_step *add_table_step (struct table_step *old, struct paragraph_item *p_table);
struct table_step *destroy_table_step (struct table_step *current);

void destroy_table_structure (struct table_item *current_table);
struct table_child *new_table_child (void);
struct table_child *insert_empty_child (struct table_child *prev);
struct table_item *new_table (void);
long calculate_table_height (struct table_item *current_table, struct frame_item *frame, long tab_top);
WORD calculate_table_width (struct table_item *current_table, struct frame_item *frame,long tab_top);

/* in to_do.c */

void add_item_to_to_do_list(enum possible_message_types, void *);
void add_load_item_to_to_do_list (WORD, char *, struct frame_item *, struct frame_item *);
void add_parse_item_to_to_do_list(char *, struct frame_item *, WORD);

/* in w_struct.c */

void destroy_word_structure(struct word_item *);
struct word_item *new_word(const struct word_item * copy_from, BOOL changed);
struct word_item *add_word(struct frame_item *,struct word_item *,WORD *, WORD *);
void word_store(struct frame_item *,WORD *, WORD *);
