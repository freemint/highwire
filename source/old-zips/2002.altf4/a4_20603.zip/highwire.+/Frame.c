/* @(#)highwire/Frame.c
 */
#include <stdlib.h>
#include <string.h>

#include <gem.h>

#include "global.h"
#include "Table.h"
#include "Location.h"


/*==============================================================================
 *
 * creates a new frame structure and initializes it's values
 */
FRAME
new_frame (LOCATION loc)
{
	FRAME frame = malloc (sizeof (struct frame_item));

	frame->Container    = NULL;
	frame->Location     = location_share (loc);
	frame->page_minimum = 0;
	frame->page_width   = 0;
	frame->page_height  = 0;
	frame->h_bar.scroll = 0;
	frame->v_bar.scroll = 0;
	frame->v_bar.on     = FALSE;
	frame->h_bar.on     = FALSE;
	frame->border       = FALSE;
	frame->background_colour   = (ignore_colours ? G_WHITE : G_LWHITE);
	frame->text_colour         = G_BLACK;
	frame->link_colour         = link_colour;
	frame->base_target         = NULL;
	frame->clip.x = 0;
	frame->clip.y = 0;
	frame->clip.w = 0;
	frame->clip.h = 0;
	frame->first_clickable_area = NULL;
	frame->first_named_location = NULL;
	frame->current_list         = NULL;
	frame->current_font_step = NULL;
	frame->current_attr      = NULL;
	frame->TableStack        = NULL;
	
	frame->current.backgnd   = frame->background_colour;
	frame->current.anchor    = &frame->first_named_location;
	frame->current.buffer    = NULL;
	frame->current.text      = NULL;
	frame->current.font_size = font_size;
	frame->current.word      = NULL;
	frame->current.paragraph = NULL;
	frame->item              = new_paragraph (&frame->current);

	return frame;
}


/*============================================================================*/
void
delete_frame (FRAME * p_frame)
{
	FRAME frame = *p_frame;
	if (frame) {
		if (frame->item)
			destroy_paragraph_structure (frame->item);
		if (frame->first_clickable_area)
			destroy_clickable_area_structure (frame->first_clickable_area);
		if (frame->first_named_location)
			destroy_named_location_structure (frame->first_named_location);
		free_location (&frame->Location);
	
		if (frame->base_target)
			free (frame->base_target);
		
		if (frame == current_highlighted_link_frame) {
			current_highlighted_link_frame = NULL;
			current_highlighted_link_area  = NULL;
		}
		free (frame);
	
		*p_frame = NULL;
	}
}


/*============================================================================*/
void
frame_calculate (FRAME frame, const GRECT * clip)
{
   CLICKABLE * clck_ptr = &frame->first_clickable_area, clickable;
	long  old_width      = (frame->h_bar.on
	                        ? frame->page_width  - frame->clip.w : 0);
	long  old_height     = (frame->v_bar.on
	                        ? frame->page_height - frame->clip.h : 0);
	short scrollbar_size = scroll_bar_width;
	
	*(GRECT*)&frame->clip = *clip;
	
	if (frame->border) {
		frame->clip.x++;
		frame->clip.y++;
		frame->clip.w -= 2;
		frame->clip.h -= 2;
		scrollbar_size--;
	}
	
	if (frame->page_minimum <= frame->clip.w) {
		frame->page_width = frame->clip.w;
		frame->h_bar.on   = FALSE;
	} else {
		frame->page_width = frame->page_minimum;
		frame->h_bar.on   = TRUE;
		frame->clip.h    -= scrollbar_size;
	}
   frame->page_height = content_calc (frame->item, frame->page_width,
                                      &clck_ptr);
	if (frame->page_height <= frame->clip.h) {
		frame->v_bar.on = FALSE;
	} else {
		frame->v_bar.on = TRUE;
		frame->clip.w  -= scrollbar_size;
		
		if (!frame->h_bar.on) {
			if (frame->page_minimum > frame->clip.w) {
				frame->page_width = frame->page_minimum;
				frame->h_bar.on   = TRUE;
				frame->clip.h    -= scrollbar_size;
			} else {
				frame->page_width  = frame->clip.w;
			   clck_ptr = &frame->first_clickable_area;
			   frame->page_height = content_calc (frame->item, frame->page_width,
			                                      &clck_ptr);
			}
		}
	}
	*clck_ptr = NULL;
	clickable = frame->first_clickable_area;
	while (clickable) {
		OFFSET * offset = clickable->offset.Origin;
		while (offset) {
			clickable->offset.X += offset->X;
			clickable->offset.Y += offset->Y;
			offset = offset->Origin;
		}
		clickable = clickable->next_area;
	}
	
	if (!frame->h_bar.on) {
		frame->h_bar.scroll = 0;
	
	} else {
		long new_width = frame->page_width - frame->clip.w;
		if (old_width) {
			long scroll = (frame->h_bar.scroll * 1024 + old_width /2)
			            / old_width;
			frame->h_bar.scroll = (scroll * new_width + 512) / 1024;
		}
		if (frame->h_bar.scroll > new_width) {
			 frame->h_bar.scroll = new_width;
		}
		frame->h_bar.lu = scroll_bar_width -1;
		frame->h_bar.rd = frame->clip.w - scroll_bar_width +1;
		if (frame->border) {
			frame->h_bar.lu--;
		} else if (!frame->v_bar.on) {
			frame->h_bar.rd--;
		}
		frame->h_bar.size = (long)(frame->h_bar.rd - frame->h_bar.lu +1)
		                  * frame->clip.w / frame->page_width;
		if (frame->h_bar.size < scroll_bar_width) {
			 frame->h_bar.size = scroll_bar_width;
		}
		frame_slider (&frame->h_bar, new_width);
	}
	
	if (!frame->v_bar.on) {
		frame->v_bar.scroll = 0;
	
	} else {
		long new_height = frame->page_height - frame->clip.h;
		if (old_height) {
			long scroll = (frame->v_bar.scroll * 1024 + old_height /2)
			            / old_height;
			frame->v_bar.scroll = (scroll * new_height + 512) / 1024;
		}
		if (frame->v_bar.scroll > new_height) {
			 frame->v_bar.scroll = new_height;
		}
		frame->v_bar.lu = scroll_bar_width -1;
		frame->v_bar.rd = frame->clip.h - scroll_bar_width +1;
		if (frame->border) {
			frame->v_bar.lu--;
		} else if (!frame->h_bar.on) {
			frame->v_bar.rd--;
		}
		frame->v_bar.size = (long)(frame->v_bar.rd - frame->v_bar.lu +1)
		                  * frame->clip.h / frame->page_height;
		if (frame->v_bar.size < scroll_bar_width) {
			 frame->v_bar.size = scroll_bar_width;
		}
		frame_slider (&frame->v_bar, new_height);
	}
}


/*============================================================================*/
BOOL
frame_slider (struct slider * slider, long max_scroll)
{
	short size = slider->rd - slider->lu +1 - slider->size;
	short step = (slider->scroll * size + (max_scroll /2)) / max_scroll
	           - (slider->pos - slider->lu);
	slider->pos += step;
	
	return  (step != 0);
}


/*============================================================================*/
OFFSET *
frame_anchor (FRAME frame, const char * name)
{
	ANCHOR anchor = frame->first_named_location;
	
	while (*name == '#') name++;
	
	while (anchor) {
		if (strcmp (name, anchor->address) == 0) {
			return &anchor->offset;
		}
		anchor = anchor->next_location;
	}
	return NULL;
}
