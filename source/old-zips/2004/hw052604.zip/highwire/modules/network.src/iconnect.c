/*
 *  Wrapper file to compile 'Iconnect.OVL'
*/

#define USE_ICNN

#include "network.c"