/*
 *  Wrapper file to compile 'Sting.OVL'
*/

#define USE_STNG

#include "network.c"