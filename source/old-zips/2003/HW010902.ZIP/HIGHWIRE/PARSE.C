#include <stdlib.h>
#include <string.h>


#include <ctype.h>
#include "token.h"
extern HTMLTAG parse (char ** line);
extern int     Variable (HTMLKEY key, char * output, size_t max_len);
extern char  * Variable_str (HTMLKEY key);


#include <gemx.h>

#include "global.h"
#include "Scanner.h"

#ifndef LATTICE
#include "stptok.h"
#endif

/* just for printf for testing */
#include <stdio.h>


#if 0
static FILE * _dbg_f = NULL;
# define DBG_START   if (!_dbg_f) _dbg_f = fopen ("/tmp/hw-log.txt", "w");
# define DBG(t)      { fprintf (_dbg_f, t "\n"); fflush (_dbg_f); }

#else
# define DBG_START
# define DBG(t)
#endif


char window_title[80];


WORD
convert_to_number (const char *text)
{
	char *next;
	long value;

	if (*text == '"')
		text++;
		
	value = strtol (text, &next, 0);

	/* XXX */
	if (next && *next == '%')
		value = -value;

	return value;
}

void
word_store (struct frame_item *p_frame, WORD *active_word_buffer, WORD *active_word)
{
	WORD pts[8], string_length;

	*active_word = 0;
	for (string_length = 0; active_word_buffer[string_length] != 0; string_length++) ;
	string_length++;
	p_frame->current_word->item = malloc (string_length * 2);
	memcpy (p_frame->current_word->item, active_word_buffer, string_length * 2);

	vqt_f_extent16 (vdi_handle, p_frame->current_word->item, pts);

	p_frame->current_word->word_width += pts[2] - pts[0];
}

WORD
map (char symbol)
{
	if (symbol == ' ')
		return (Space_Code);
		
	return ((WORD) (symbol - 32));
}

WORD
list_indent (WORD type)
{
	switch (type)
	{
		case 0:
			return (POINT_SIZE * 2);
		case 1:
			return (POINT_SIZE * 3);
		case 2:
			return (POINT_SIZE * 4);
	}
	return (0);
}


/* set_pre_font()
 *
 * just a couple of lines that modify the current font to being 
 * the PRE font.
 * Used in numerous places
 *
 *  current_word is the current_word
 *  flag determines operation
 *     if 1 set to pre_font
 *     if not 1 turn off prefont
 */
 
static void
set_pre_font(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
		current_word->styles.font = pre_font;
	else
		current_word->styles.font = normal_font;

	current_word->changed.font = true;

}

/* set_font_bold
 * 
 * changes the value of the BOLD status of a word
 *
 * current_word  = current word
 * flag determines operation
 *    if 1 add to bold
 *    if not 1 subtract from bold
 */

static void
set_font_bold(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.bold++;
										
		if (current_word->styles.bold == 1)
			current_word->changed.font = true;
	}
	else
	{
		if (current_word->styles.bold > 0)
			current_word->styles.bold--;
				
		if(current_word->styles.bold == 0)
			current_word->changed.font = true;
	}
}

/* set_font_italic()
 * 
 * changes the value of the Italic status of a word
 *
 * current_word = current word
 * flag determines operation
 *    if 1 add to italic
 *    if not 1 subtract from italic
 */

static void
set_font_italic(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.italic++;
	
		if (current_word->styles.italic == 1)
			current_word->changed.font = true;
	}
	else
	{
		if (current_word->styles.italic > 0)
			current_word->styles.italic--;
											
		if (current_word->styles.italic == 0)
			current_word->changed.font = true;
	}
}

/* set_font_strike()
 *
 * changes the value of the Strike status of a word
 * 
 * current_word = current word
 * flag determines operation
 *    if 1 add to strike
 *    if not 1 subtract from strike
 */
 
static void
set_font_strike(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.strike++;
		current_word->changed.style = true;
	}
	else
	{
		if (current_word->styles.strike != 0)
			current_word->styles.strike--;

		current_word->changed.style = true;
	}
}

/* set_font_underline()
 *
 * changes the value of the underlined status of a word
 * 
 * current_word = current word
 * flag determines operation
 *    if 1 add to underline
 *    if not 1 subtract from underline
 */
 
static void
set_font_underline(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.underlined++;
		current_word->changed.style = true;
	}
	else
	{
		if (current_word->styles.underlined != 0)
			current_word->styles.underlined--;

		current_word->changed.style = true;
	}
}

/* set_center_text()
 *
 * changes the value of paragraphs alignment
 * 
 * flag determines operation
 *    if 1  center text
 *    if not 1 left justify text
 */
 
static void
set_center_text(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	if (flag == 1)
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	if (flag == 1)
		p_frame->current_paragraph->alignment = center;
	else
		p_frame->current_paragraph->alignment = 0;
}

/* set_blockquote_text()
 *
 * changes the value of paragraphs indentation
 * 
 * flag determines operation
 *    if 1  blockquote text
 *    if not 1  unindent text
 */
 
static void
set_blockquote_text(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	add_paragraph(p_frame,active_word_buffer);

	p_frame->active_word = active_word_buffer;

	if (flag == 1)
	{
		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->eop_space = 0;
		p_frame->current_paragraph->left_border += list_indent (2);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
	else
	{
		p_frame->current_paragraph->left_border -= list_indent(2);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
}


/* parse anchor
 * ideally you drop the input on this routine
 * and it parses and processes the body tag information
 * baldrick - December 3, 2001
 * 
 * flag determines operation
 *    if 1  start d tag
 *    if not 1 end d tag
 * baldrick - December 17, 2001
 */

static void
parse_anchor (struct frame_item *p_frame, WORD flag)
{
	if (flag == 1)
	{
		char * output = Variable_str (KEY_HREF);
		char   out2[100];

		DBG("+ parse_anchor");
		if (output)
		{						
			p_frame->current_word->colour = p_frame->link_colour; /*link_colour;*/
			p_frame->current_word->changed.colour = true;

			if (Variable (KEY_TARGET, out2, sizeof(out2)))
			{
				p_frame->current_word->link = new_url_link (output, lnk_href, out2);
			}
			else
			{
				p_frame->current_word->link = new_url_link (output, lnk_href, p_frame->frame_name);
			}
			free (output);
		}
		else if (Variable (KEY_NAME, out2, sizeof(out2)))
		{
			p_frame->current_word->link = new_url_link(out2, lnk_name, p_frame->frame_name);
		}	
	}
	else
	{
		DBG("- parse_anchor");
		p_frame->current_word->colour = p_frame->text_colour;
		p_frame->current_word->link = 0;
		p_frame->current_word->changed.colour = true;
	}
}

/* parse body tag
 * ideally you drop the input on this routine
 * and it parses and processes the body tag information
 *
 * baldrick - December 3, 2001
 *
 * modifications for new color routines
 * AltF4 - December 26, 2001
 */

static void
parse_body (struct frame_item *p_frame)
{
	if (!ignore_colours)
	{
		char output[100];
	
		DBG("+ parse_body");
		if (Variable (KEY_TEXT, output, sizeof(output)))
		{
			long color = scan_color (output);
			if (color >= 0)
				p_frame->text_colour = remap_color (color);
		}
		if (Variable (KEY_BGCOLOR, output, sizeof(output)))
		{
			long color = scan_color (output);
			if (color >= 0)
				p_frame->background_colour = remap_color (color);
		}
		if (Variable (KEY_LINK, output, sizeof(output)))
		{
			long color = scan_color (output);
			if (color >= 0)
				p_frame->link_colour = remap_color (color);
		}
	}
}

/* parse_d_tags()
 *
 * processes the d tags DL, DT, DD
 * 
 * type determines the type of d tag
 *    0 = DL tag
 *    1 = DT tag
 *    2 = DD tag
 *
 * flag determines operation
 *    if 1  start d tag
 *    if not 1 end d tag
 */
 
static void
parse_d_tags(struct frame_item *p_frame, WORD *active_word_buffer,
			 WORD type, WORD flag)
{
	DBG("parse_d_tags");
	add_paragraph(p_frame,active_word_buffer);

	p_frame->current_paragraph->alignment = left;

	if (flag == 1)
	{
		DBG("+ parse_d_tags");
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->eop_space = 0;


		if (type == 0)       /* dl tag start */
			p_frame->current_paragraph->left_border += list_indent (2);
		else if (type == 1)  /* dt tag start */
			p_frame->current_paragraph->left_border -= list_indent (2);
		else if (type == 2)  /* dd tag start */
			p_frame->current_paragraph->left_border = list_indent (2);

		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
	else
	{
		DBG("- parse_d_tags");
		if (type == 0) /* dl tag end */
		{
			p_frame->current_paragraph->eop_space = p_frame->current_font_size;

			p_frame->current_paragraph->left_border -= list_indent(2);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse DIV tag
 * ideally you drop the input on this routine
 * and it parses and processes the DIV tag information
 *
 * DIV is only partially implemented from my understanding
 * baldrick - December 14, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_div_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	
	if (flag == 1)
	{
		DBG("+ parse_div_tag");
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->active_word = active_word_buffer;

		if (Variable (KEY_ALIGN, output, sizeof(output)))
		{
			switch (toupper (*output))
			{
				case 'R':
					p_frame->current_paragraph->alignment = right;
					break;
				case 'C':
					p_frame->current_paragraph->alignment = center;
					break;
				case 'L':
					p_frame->current_paragraph->alignment = left;
					break;
			}
		}
	}
	else
	{
		DBG("- parse_div_tag");
		add_paragraph(p_frame, active_word_buffer);
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
	}
}

/* parse font tag
 * ideally you drop the input on this routine
 * and it parses and processes the font tag information
 *
 * baldrick - December 14, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 *
 * color handling modified to new routines
 * AltF4 - Dec 26, 2001
 */

static void
parse_font_tag(struct frame_item *p_frame, WORD font_step, WORD flag)
{
	char output[100];

	if (flag == 1)
	{
		DBG("+ parse_font_tag");
		if (Variable (KEY_SIZE, output, sizeof(output)))
		{
			p_frame->current_font_step = add_step (p_frame->current_font_step);

			if (*output == '+' || *output == '-')
				p_frame->current_font_step->step += convert_to_number (output);
			else
				p_frame->current_font_step->step = convert_to_number (output);
									
			/* added +1 to font_step in next calculation
			 * this is not perfect, but does fix some of the problems
			 * with font size when there is a size variable
			 * Basically the smallest size fonts are way too small
			 * baldrick July 20, 2001
			 */
									
			p_frame->current_font_size = p_frame->current_font_step->step * font_step; /*(font_step + 1);*/
																	
			p_frame->current_word->styles.font_size = p_frame->current_font_size; 
			p_frame->current_word->changed.font = true;

	/*		printf("font size = %d\r\n",p_frame->current_word->styles.font_size);*/
		}

		if (!ignore_colours)
		{
			if (Variable (KEY_COLOR, output, sizeof(output)))
			{
				long color = scan_color (output);
				if (color >= 0)
				{
					p_frame->current_word->colour = remap_color (color);
					p_frame->current_word->changed.colour = true;
				}
			}
		}
	}
	else
	{
		DBG("- parse_font_tag");
		p_frame->current_font_step = destroy_step(p_frame->current_font_step);
		p_frame->current_font_size = p_frame->current_font_step->step * font_step;
		p_frame->current_word->styles.font_size = p_frame->current_font_size;
		p_frame->current_word->colour = p_frame->text_colour;
		p_frame->current_word->changed.colour = true;
		p_frame->current_word->changed.font = true;
	}
}


/* parse header tag
 * ideally you drop the input on this routine
 * and it parses and processes the header tag information
 *
 * baldrick - August 20, 2001
 * mj - added strupr and 'j' - 10-01-01
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_header_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	WORD size = 0;

	if (flag == 1)
	{
		DBG("+ parse_header_tag");
	    /* This next line I'm not 100% certain of.  If Headings don't
	     * have enough space then remove this line - baldrick Dec 14, 01 
	     *
	     * Ok there is an error here somewhere. On MagicPC this runs and
	     * modifies the height of the space around header tags
	     * on my TT under Magic it crashes - baldrick Dec 14, 01 (evening)
	     */
	/*	p_frame->current_word = p_frame->current_paragraph->item;
	*/

		p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

		add_paragraph(p_frame, active_word_buffer);

		if (Variable (KEY_ALIGN, output, sizeof(output)))
		{
			switch (*(strupr(output)))
			{
				case 'R':
					p_frame->current_paragraph->alignment = right;
					break;
				case 'C':
					p_frame->current_paragraph->alignment = center;
					break;
				case 'J':
				case 'L':
					p_frame->current_paragraph->alignment = left;
			}
		}	
							
		p_frame->current_word->styles.font = header_font;
	
		if (Variable (KEY_H_HEIGHT, output, sizeof(output)))
		{
			switch (*output)
			{
				case '1':
					size = p_frame->current_font_size * 2;
					break;
				case '2':
					size = p_frame->current_font_size + (p_frame->current_font_size / 2);
					break;
				case '3':
					size = p_frame->current_font_size + (p_frame->current_font_size / 4);
					break;
				case '4':
					size = p_frame->current_font_size;
					break;
				case '5':
					size = p_frame->current_font_size - (p_frame->current_font_size / 5);
					break;
				case '6':
					size = p_frame->current_font_size - (p_frame->current_font_size / 3);
					break;
			}
		}
		p_frame->current_word->styles.font_size = size;
		p_frame->current_word->styles.bold++;
		p_frame->current_word->changed.font = true;
	
		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		DBG("- parse_header_tag");
		add_paragraph(p_frame,active_word_buffer);
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
		p_frame->current_word->styles.font = normal_font;
		p_frame->current_word->styles.font_size = p_frame->current_font_size;
		p_frame->current_word->styles.bold = 0;
		p_frame->current_word->changed.font = true;
	}
}

/* parse MENU tag
 * ideally you drop the input on this routine
 * and it parses and processes the MENU tag information
 *
 * I left symbol in this since we might need it, I'm not certain
 * it's also possible that we could map this onto parse_ul
 * baldrick - December 13, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_menu_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{
		DBG("+ parse_menu_tag");
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;
								
		add_paragraph(p_frame, active_word_buffer);
									
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent (0);
									
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
								
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item =	p_frame->current_list;

		if (p_frame->current_list != 0)
			temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;

		p_frame->current_list = temp_list_holder;
	}
	else
	{
		DBG("- parse_menu_tag");
		if (p_frame->current_list != 0)
		{
			if (p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space=-(p_frame->current_word->word_height);
												
			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);

			p_frame->active_word = active_word_buffer;
			p_frame->current_list = p_frame->current_list->next_stack_item;
			p_frame->current_paragraph->left_border -= list_indent(0);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse P tag
 * ideally you drop the input on this routine
 * and it parses and processes the P tag information
 *
 * baldrick - December 14, 2001
 */

static void
parse_p_tag(struct frame_item *p_frame, WORD *active_word_buffer)
{
	char output[100];
	enum paragraph_alignment prev_alignment;

	DBG("parse_p_tag");
	prev_alignment = p_frame->current_paragraph->alignment;
	
	p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	if (Variable (KEY_ALIGN, output, sizeof(output)))
	{
		switch (toupper(*output))
		{
			case 'R':
				p_frame->current_paragraph->alignment = right;
				break;
			case 'C':
				p_frame->current_paragraph->alignment = center;
				break;
			case 'L':
				p_frame->current_paragraph->alignment = left;
		}
	}
	else
	{
		p_frame->current_paragraph->alignment = prev_alignment; /*left;*/
	}
}

/* parse LI tag
 * ideally you drop the input on this routine
 * and it parses and processes the LI tag information
 *
 * baldrick - December 12, 2001
 */

static void
parse_li_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD font_step)
{
	char output[100];
	
	DBG("parse_li_tag");
	p_frame->current_word->word_code = br;

	if (Variable (KEY_TYPE, output, sizeof(output))) switch (*output)
	{
		case 'a':
			p_frame->current_list->bullet_style = alpha;
			break;
		case 'A':
			p_frame->current_list->bullet_style = Alpha;
			break;
		case 'i':
			p_frame->current_list->bullet_style = roman;
			break;
		case 'I':
			p_frame->current_list->bullet_style = Roman;
			break;
		case '1':
			p_frame->current_list->bullet_style = Number;
			break;
		case 'd':
		case 'D':
			p_frame->current_list->bullet_style = disc;
			break;
		case 'c':
		case 'C':
			p_frame->current_list->bullet_style = circle;
			break;
		case 's':
		case 'S':
			p_frame->current_list->bullet_style = square;
			break;
	}
								
	if (Variable (KEY_VALUE, output, sizeof(output)))
		p_frame->current_list->current_list_count = convert_to_number(output);
										
	p_frame->current_word->styles.font_size = 2 * font_step;
	p_frame->current_word->changed.font = true;

	p_frame->current_word = list_marker(p_frame);
	p_frame->active_word = active_word_buffer;

	p_frame->current_word->styles.font_size = p_frame->current_font_step->step * font_step;
	p_frame->current_word->changed.font = true;
}

/* parse OL tag
 * ideally you drop the input on this routine
 * and it parses and processes the OL tag information
 *
 * baldrick - December 12, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_ol_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{
		DBG("+ parse_ol_tag");
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->active_word = active_word_buffer;

		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent(1);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = p_frame->current_list;
		p_frame->current_list = temp_list_holder;
								
		if (Variable (KEY_TYPE, output, sizeof(output))) switch (*output)
		{
			case 'a':
				p_frame->current_list->bullet_style = alpha;
				break;
			case 'A':
				p_frame->current_list->bullet_style = Alpha;
				break;
			case 'i':
				p_frame->current_list->bullet_style = roman;
				break;
			case 'I':
				p_frame->current_list->bullet_style = Roman;
				break;
			default:
				p_frame->current_list->bullet_style = Number;
		}
							
		if (Variable (KEY_START, output, sizeof(output)))
			p_frame->current_list->current_list_count = convert_to_number(output);
		else
			p_frame->current_list->current_list_count = 1;

		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		DBG("- parse_ol_tag");
		if (p_frame->current_list != 0)
		{
			if(p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space = -(p_frame->current_word->word_height);

			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);
			p_frame->active_word = active_word_buffer;
			p_frame->current_list = remove_stack_item(p_frame->current_list);
			p_frame->current_paragraph->left_border -= list_indent(1);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}	
	}
}

/* parse UL tag
 * ideally you drop the input on this routine
 * and it parses and processes the UL tag information
 * baldrick - December 12, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_ul_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{	
		DBG("+ parse_ul_tag");
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent (0);

		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	
		temp_list_holder = new_stack_list_item();
		temp_list_holder->next_stack_item = p_frame->current_list;

		if (Variable (KEY_TYPE, output, sizeof(output))) switch (*output)
		{
			case 'S':
			case 's':
				temp_list_holder->bullet_style = square;
				break;
			case 'c':
			case 'C':
				temp_list_holder->bullet_style = circle;
				break;
			case 'd':
			case 'D':
				temp_list_holder->bullet_style = disc;
			default:
				if (p_frame->current_list != 0)
					temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;
		}
		p_frame->current_list = temp_list_holder;

		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		DBG("- parse_ul_tag");
		if (p_frame->current_list != 0)
		{
			if (p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space =- (p_frame->current_word->word_height);
			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);
			p_frame->active_word = active_word_buffer;
			p_frame->current_list = remove_stack_item(p_frame->current_list);
			p_frame->current_paragraph->left_border -= list_indent(0);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse table tag 
 * ideally you drop the input on this routine
 * and it parses and processes the table tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 *
 * Modifications for new color routines
 * AltF4 - December 26, 2001
 */

static void
parse_table_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];

	if (flag == 1)
	{
		DBG("+ parse_table_tag");
		add_paragraph(p_frame, active_word_buffer);

		/* link this paragraph into the list */
		p_frame->parent_table = add_table_step (p_frame->parent_table, p_frame->current_paragraph);

		p_frame->active_word = active_word_buffer;
								
		p_frame->current_paragraph->paragraph_code = table;

		p_frame->current_paragraph->table = new_table();
		p_frame->current_table = p_frame->current_paragraph->table;

		if (Variable (KEY_ALIGN, output, sizeof(output)))
		{
			switch (toupper(*output))
			{
				case 'R':
					p_frame->current_table->alignment = right;
					break;
				case 'C':
					p_frame->current_table->alignment = center;
					break;
				case 'L':
					p_frame->current_table->alignment = left;
			}
		}
		else
		{
			p_frame->current_table->alignment = left;
		}
		
		if (Variable (KEY_WIDTH, output, sizeof(output)))
			p_frame->current_table->table_width = convert_to_number(output);

		if (Variable (KEY_BORDER, output, sizeof(output)))
			p_frame->current_table->border = 1;
		else
			p_frame->current_table->border = 0;

		if (!ignore_colours)
		{
			if (Variable (KEY_BGCOLOR, output, sizeof(output)))
			{
				long color = scan_color (output);
				if (color >= 0)
					p_frame->current_table->bgcolor = remap_color (color);
				else
					p_frame->current_table->bgcolor = p_frame->background_colour;
			}
			else
			{
				p_frame->current_table->bgcolor = p_frame->background_colour;
			}
		}
		else
		{
			p_frame->current_table->bgcolor = p_frame->background_colour;
		}
	
		if (Variable (KEY_CELLSPACING, output, sizeof(output)))
			p_frame->current_table->cell_spacing = convert_to_number(output);
		else
			p_frame->current_table->cell_spacing = 5;
								
		if (Variable (KEY_CELLPADDING, output, sizeof(output)))
			p_frame->current_table->cell_padding = convert_to_number(output);
		else
			p_frame->current_table->cell_padding = 0;

		if (p_frame->current_table->table_width > p_frame->frame_page_width)
			p_frame->frame_page_width = p_frame->current_table->table_width;

		p_frame->current_child = p_frame->current_table->children;
	}
	else
	{
		DBG("- parse_table_tag");
		/* set current paragraph to before the start of this table */
		
		p_frame->current_paragraph = p_frame->parent_table->table;
		
		/* walk back up list */
		
		p_frame->parent_table = destroy_table_step(p_frame->parent_table);
	}
}

/* parse th tag (table header cell )
 * ideally you drop the input on this routine
 * and it parses and processes the th tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 *
 * Modifications for new color routines
 * AltF4 - December 26, 2001
 */

static void
parse_th_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	WORD temp = 0;

	if (flag == 1)
	{
		DBG("+ parse_th_tag");
		/* store any words floating around in the buffer */
								
		word_store (p_frame, active_word_buffer, p_frame->active_word);

		/* we need to create a new child */
								
		/* this first test will just supress the 
		 * creation of an extra child at the front of 
		 * the table's children list
		 */
			
		if (p_frame->current_table->num_children != 0)
		{
			p_frame->current_child->next_child = new_table_child();
			p_frame->current_child = p_frame->current_child->next_child;
		}
								
		p_frame->current_table->num_children += 1;
								
		if (p_frame->current_table->num_rows <= 1)
		{
			p_frame->current_table->num_cols += 1;
		}
								
		if (!ignore_colours)
		{
			if (Variable (KEY_BGCOLOR, output, sizeof(output)))
			{
				long color = scan_color (output);
				if (color >= 0)
					p_frame->current_child->bgcolor = remap_color (color);
			}
		}

		if (Variable (KEY_COLSPAN, output, sizeof(output)))
		{
			temp = convert_to_number(output);
																	
			if (p_frame->current_table->num_rows <= 1)
			{
				p_frame->current_table->num_cols += temp;
				
				/* adjust it by one to account for 1 previously added */
				
				p_frame->current_table->num_cols -= 1;
			}
									
			p_frame->current_child->colspan = temp;
		}
		else
		{
			p_frame->current_child->colspan = 1;
		}							

		if (Variable (KEY_ROWSPAN, output, sizeof(output)))
		{
			temp = convert_to_number(output);
																	
			p_frame->current_child->rowspan = temp;
		}
		else
		{
			p_frame->current_child->rowspan = 1;
		}
		
		if (Variable (KEY_ALIGN, output, sizeof(output)))
		{
			switch (*output)
			{
				case 'r':
				case 'R':
					p_frame->current_child->alignment = right;
					break;
				case 'c':
				case 'C':
					p_frame->current_child->alignment = center;
					break;
				case 'l':
				case 'L':
					p_frame->current_child->alignment = left;
			}
		}
		else
			p_frame->current_child->alignment = left;

		if (Variable (KEY_HEIGHT, output, sizeof(output)))
			p_frame->current_child->height = convert_to_number(output);

		if (Variable (KEY_WIDTH, output, sizeof(output)))
			p_frame->current_child->width = convert_to_number(output);

		p_frame->current_paragraph = p_frame->current_child->item;
		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
									
		set_font_bold(p_frame->current_word, 1);

		p_frame->current_paragraph->alignment = center;

	}
	else
	{
		DBG("- parse_th_tag");
		/* Any special considerations for a closing th tag? */
		;
	}
}

/* parse td tag (table data cell )
 * ideally you drop the input on this routine
 * and it parses and processes the td tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 *
 * Modifications for new color routines
 * AltF4 - December 26, 2001
 */

static void
parse_td_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	WORD temp = 0;

	if (flag == 1)
	{
		DBG("+ parse_td_tag");
		/* store any words floating around in the buffer */
								
		word_store (p_frame, active_word_buffer, p_frame->active_word);

		/* we need to create a new child */
								
		/* this first test will just supress the 
		 * creation of an extra child at the front of 
		 * the table's children list
		 */
								
		if (p_frame->current_table->num_children != 0)
		{
			p_frame->current_child->next_child = new_table_child();
			p_frame->current_child = p_frame->current_child->next_child;
		}
								
		p_frame->current_table->num_children += 1;
								
		/* This might not be a good test
		 * we want to count the columns in the 
		 * first row. But if a Table has only
		 * one row it doesn't necessarily have a tr tag
		 *
		 * so we hope that we don't hit bad tables with
		 * multiple rows and no tr tag before first row
		 */
								 
		if (p_frame->current_table->num_rows <= 1)
		{
			p_frame->current_table->num_cols += 1;
		}

		if (!ignore_colours)
		{
			if (Variable (KEY_BGCOLOR, output, sizeof(output)))
			{
				long color = scan_color (output);
				if (color >= 0)
					p_frame->current_child->bgcolor = remap_color (color);
			}
		}
		
		if (Variable (KEY_COLSPAN, output, sizeof(output)))
		{
			temp = convert_to_number(output);

			if (p_frame->current_table->num_rows <= 1)
			{
				p_frame->current_table->num_cols += temp;
				
				/* adjust it by one to account for 1 previously added */
				
				p_frame->current_table->num_cols -= 1;
			}

			p_frame->current_child->colspan = temp;
		}
		else
		{
			p_frame->current_child->colspan = 1;
		}
		
		if (Variable (KEY_ROWSPAN, output, sizeof(output)))
		{
			temp = convert_to_number(output);
																	
			p_frame->current_child->rowspan = temp;
		}
		else
		{
			p_frame->current_child->rowspan = 1;
		}
		
		if (Variable (KEY_ALIGN, output, sizeof(output)))
		{
			switch (toupper(*output))
			{
				case 'R':
					p_frame->current_child->alignment = right;
					break;
				case 'C':
					p_frame->current_child->alignment = center;
					break;
				case 'L':
					p_frame->current_child->alignment = left;
			}
		}
		else
		{
			p_frame->current_child->alignment = left;
		}

		if (Variable (KEY_HEIGHT, output, sizeof(output)))
			p_frame->current_child->height = convert_to_number(output);

		if (Variable (KEY_WIDTH, output, sizeof(output)))
			p_frame->current_child->width = convert_to_number(output);

		p_frame->current_paragraph = p_frame->current_child->item;
		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		DBG("- parse_td_tag");
		/* Any special considerations for a closing td tag? */
		;
	}
}

/* parse hr tag
 * ideally you drop the input on this routine
 * and it parses and processes the hr tag information
 *
 * baldrick - December 5, 2001
 */

static void
parse_hr_tag(struct frame_item *p_frame, WORD *active_word_buffer)
{
	char output[100];

	DBG("parse_hr_tag");
	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;
	p_frame->current_paragraph->paragraph_code = hr;

	if (Variable (KEY_ALIGN, output, sizeof(output)))
	{
		switch (toupper(*output))
		{
			case 'R':
				p_frame->current_paragraph->eop_space = 2;
				break;
			case 'C':
				p_frame->current_paragraph->eop_space = 1;
				break;
			default:
				p_frame->current_paragraph->eop_space = 0;
		}
	}

	if (Variable (KEY_WIDTH, output, sizeof(output)))
		p_frame->current_word->word_width = convert_to_number(output);
	else
		p_frame->current_word->word_width = -100;

	if (Variable (KEY_SIZE, output, sizeof(output)))
		p_frame->current_word->word_height = convert_to_number(output);
	else
		p_frame->current_word->word_height = 2;

	if (Variable (KEY_NOSHADE, NULL,0))
		p_frame->current_word->word_height = -p_frame->current_word->word_height;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;
	p_frame->current_word->changed.font = true;
}

/* parse img tag
 * ideally you drop the input on this routine
 * and it parses and processes the header tag information
 *
 * baldrick - Dec 4, 2001
 */

static void
parse_img_tag(struct frame_item *p_frame, WORD *active_word_buffer)
{
	char output[100];
	char img_file[100];

	DBG("parse_img_tag");
	add_paragraph(p_frame, active_word_buffer);

	p_frame->current_paragraph->paragraph_code = img;

	if (Variable (KEY_ALIGN, output, sizeof(output)))
	{
		switch (toupper(*output))
		{
			case 'R':
				p_frame->current_paragraph->eop_space = 2;
				break;
			case 'C':
				p_frame->current_paragraph->eop_space = 1;
				break;
			default:
				p_frame->current_paragraph->eop_space = 0;
		}
	}
	else /* Assume center if not otherwise specifiec */
	{
		p_frame->current_paragraph->eop_space = 1; /* should be left */
	}
	
	if (Variable (KEY_WIDTH, output, sizeof(output)))
		p_frame->current_word->word_width = convert_to_number(output);
	else
		p_frame->current_word->word_width = 10;

	if (p_frame->current_word->word_width > p_frame->frame_page_width)
		p_frame->frame_page_width = p_frame->current_word->word_width;
								
	if (Variable (KEY_HEIGHT, output, sizeof(output)))
		p_frame->current_word->word_height = convert_to_number(output);
	else
		p_frame->current_word->word_height = 10;

	p_frame->current_word->word_tail_drop = p_frame->current_word->word_height;

	if (Variable (KEY_SRC, img_file, sizeof(img_file)))
	{
		/*  This next line just shows the parsed IMG SRC
		    if you were going to process the message you 
		    would dispatch this off with a load_to_do message
		    with a new type for IMG's.
		    
		    You would also need to add a bit more information
		    for the IMG handling, mainly a MFDB should do the 
		    job.  This could possibly be linked to an already
		    existing item.
		    
		    You would then need to work in a message retrieval
		    from the external application to get the notification
		    of image decompression.  
		    
		    Modify the height and width of the paragraph to match
		    the height and width of the returned img and issue
		    a redraw for it's parent frame.
		    
		printf("img file = %s   \r\n",img_file);
		*/
	}

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	p_frame->current_word->changed.font = true;
}

/* parse_title
 *
 * parses a title tag from a file 
 * and sets the window's title to this value
 * also watches for ISO Latin entities in the Title string
 * Baldrick Dec. 6, 2001
 *
 * Modified to use new ISO scanning routines 
 * AltF4 Dec. 19, 2001
 */
 
static char *
parse_title (char *symbol, WORD *active_word)
{
	int ready = false;
	
	DBG("parse_title");
	window_title[0] = '\0';

	while (!ready)
	{
		switch(*symbol)
		{
			case '\0':
				ready = true;
				break;
			case '\r':
			case '\n':
				symbol++;
				break;
			case '&': {
				/* the 'symbol' pointer will be set by the scanner function
				 * to the expression end, ';' or '\0'.
				 */
				char chr = (char)scan_namedchar (&symbol, ATASCI);
				strncat(window_title,&chr,1);
				symbol++;
			}	break;
			case '<':
				if (symbol[1] == '/')
				{
					char * sym = symbol +2;
					if (parse (&sym) == TAG_TITLE)
					{
						symbol = sym;
						ready  = true;
						break;
					}
				}
			default:
				strncat(window_title,symbol,1);
				symbol++;
				break;
		}
	}									

	if (strlen(window_title) > 0)
		wind_set_str(window_handle, WF_NAME, window_title);

	return(symbol);
}

/* parse frameset
 * ideally you drop the input on this routine
 * and it parses and processes the frameset information
 * until done and then returns to the main parser with
 * a pointer to the end of the frameset
 * baldrick - August 8, 2001
 *
 * at the moment there is a hard coded limit of 10 frames.
 * Could or should be changed in the future.
 *
 * There are some printf's in this section that are rem'd out
 * they are useful checks on the frame parsing and I'm not
 * certain that it's 100% correct yet.  So I have left them
 * baldrick - August 14, 2001
 */
 
static char *
parse_frameset(char *symbol)
{
	char output[100],frame_file[100],frame_name[100];
	int no_rows = 0, no_cols = 0;
	int rows[10], cols[10],row = 0,col = 0;
	int rows_first = 0; /* tracks whether to parse rows first */
	char *raw_xy;
	struct frame_item *t_frame;
	
	int cur_xoffset = 0, cur_yoffset = 0;
	int border = 1;
	int start_frame = 0;
	int prev_parse = 0;		/* if 0 COLS if 1 ROWS */
	int i;
	
	HTMLTAG tag   = TAG_FRAMESET;
	int     slash = false;
	int     depth = -1;
	
	DBG("parse_frameset");
	
	/* preset frame_xy array */
	for (i = 0; i<10; i++)
	{
		rows[i] = 0;
		cols[i] = 0;
	}
	
	do
	{
		if (tag == TAG_FRAMESET)
		{
			if (!slash)
			{
				int multiple = false;
				
				depth++;
				
				/* ok the first thing we do is look for ROWS or COLS
				 * since when we are dumped here we are looking at a
				 * beginning of a FRAMESET tag
				 */
			
				if (Variable (KEY_COLS, output, sizeof(output)))
				{
					/* Ok we have found COLS so we need to parse it
					 * to discover how many columns there are in FRAMESET
					 */
			
					cols[no_cols] = convert_to_number(output);
					no_cols += 1;
			
					/* set rows_first to 0 */
					prev_parse = rows_first;
					rows_first = 0;
			
					/* set our pointer to start of output */
					raw_xy = output;
					
					while(1)
					{
						raw_xy = stptok (raw_xy, frame_file, 100, ",");
			
						if (!raw_xy || !*raw_xy)
							break;
			
						cols[no_cols] = convert_to_number(raw_xy);
						no_cols += 1;
					}
					
					/* we've found a COLS in this set so turn multiple on
					 * in case we have a ROWS as well
					 */
					 
					multiple = true;
				}
				
				if (Variable (KEY_ROWS, output, sizeof(output)))
				{
					/* Ok we have found ROWS so we need to parse it
					 * to discover how many rows there are in FRAMESET
					 */
					 
					rows[no_rows] = convert_to_number(output);
					no_rows += 1;
					
					/* if no multiple set rows first to 1 */
					if (!multiple)
					{
						prev_parse = rows_first;
						rows_first = 1;
					}
					
					/* set our pointer to start of output */
					raw_xy = output;
					
					while(1)
					{
						raw_xy = stptok (raw_xy, frame_file, 100, ",");
			
						if (!raw_xy || !*raw_xy)
							break;
			
						rows[no_rows] = convert_to_number(raw_xy);
			
						/* increment the row counter */
						no_rows += 1;
					}
					
				}
				
				/* check if they want Borders */
				
				if (Variable (KEY_FRAMEBORDER, output, sizeof(output)))
				{
					/* Ok we have found FRAMEBORDER so we need to set it
					 */
					border = 1;
				}
				else
				{
					border = 0;
				}
			}
			else /* slash */
			{
				if (depth-- <= 0) break;
	
				rows_first = prev_parse;
	
				if (rows_first > 0)
					row += 1;
				else
					col += 1;
	
				if (rows_first == 1)
					cur_yoffset += rows[row - 1];
				else
					cur_xoffset += cols[col - 1];
	
				/* make certain it's not a stupid value
				 * for either x or y offset, something like
				 * 100% of area would be bad
				 */
	
				if(cur_xoffset == -100)
					cur_xoffset = 0;
	
				if(cur_yoffset == -100)
					cur_yoffset = 0;
			}
		}
		else if (tag == TAG_FRAME  &&  !slash)
		{
			if (Variable (KEY_SRC, frame_file, sizeof(frame_file)))
			{

		#if 1
		
				/* check if the frame has a name or not */
	
				if (!Variable (KEY_NAME, frame_name, sizeof(frame_name)))
				{
					frame_name[0] = '\0';
				}
				
				/* create temp frame */
				t_frame = temp_frame();
				
				/* set temp frame values to what we want for new frame*/
				t_frame->frame_left = cur_xoffset;
				t_frame->frame_top  = cur_yoffset;
				t_frame->frame_width = cols[col];
				t_frame->frame_height = rows[row];
				t_frame->border = border;
				t_frame->frame_name = frame_name;
				
				if (start_frame == 0)
				{
					add_load_item_to_to_do_list (0, frame_file, previous_frame, t_frame);
					start_frame = 1;
				}
				else
				{
					add_load_item_to_to_do_list (2, frame_file, previous_frame, t_frame);
				}
				if (rows_first == 1) cur_yoffset += rows[row++];
				else                 cur_xoffset += cols[col++];
				
				
		#else
				
			if (Variable (KEY_SRC, output, sizeof(output)))
			{
/*				unsigned char c = *output;
				
				if (c == 186 || c == '"')
					output[strlen (output) - 1] = '\0';
				
				printf("output = %s\r\n",output);
*/				

				strncpy(frame_file,output,strlen(output));
				frame_file[strlen(output)] = '\0';

				/* check if the frame has a name */
	
				if (Variable (KEY_NAME, output, sizeof(output)))
				{
					strncpy(frame_name,output,strlen(output));
					frame_name[strlen(output)] = '\0';
				}
				else
				{
					frame_name[0] = '\0';
				}
				
				if (rows_first == 1)
				{
					if (start_frame == 0)
					{
						/*printf("rows y offset = %d x_offset = %d cols[col] = %d rows[row] = %d\r\n",cur_yoffset, cur_xoffset,cols[col],rows[row]);*/

						/* create temp frame */
						t_frame = temp_frame();
				
						/* set temp frame values to what we want for new frame*/
						t_frame->frame_left = 0;
						t_frame->frame_top = 0;
						t_frame->frame_width = cols[col];
						t_frame->frame_height = rows[row];
						t_frame->border = border;
						t_frame->frame_name = frame_name;
						
						add_load_item_to_to_do_list (0, frame_file, previous_frame, t_frame);

						start_frame = 1;

						cur_yoffset = rows[row];
					}
					else
					{
						/*printf("rows y offset = %d x_offset = %d cols[col] = %d rows[row] = %d\r\n",cur_yoffset, cur_xoffset,cols[col],rows[row]);*/

						/* create temp frame */
						t_frame = temp_frame();
				
						/* set temp frame values to what we want for new frame*/
						t_frame->frame_left = cur_xoffset;
						t_frame->frame_top = cur_yoffset;
						t_frame->frame_width = cols[col];
						t_frame->frame_height = rows[row];
						t_frame->border = border;
						t_frame->frame_name = frame_name;
				
						add_load_item_to_to_do_list (2, frame_file, previous_frame, t_frame);

						cur_yoffset += rows[row];
					}
					row += 1;

				}
				else							
				{
					if (start_frame == 0)
					{
						/*printf("cols y offset = %d x_offset = %d cols[col] = %d rows[row] = %d\r\n",cur_yoffset, cur_xoffset,cols[col],rows[row]);*/

						/* create temp frame */
						t_frame = temp_frame();
				
						/* set temp frame values to what we want for new frame*/
						t_frame->frame_left = 0;
						t_frame->frame_top = 0;
						t_frame->frame_width = cols[col];
						t_frame->frame_height = rows[row];
						t_frame->border = border;
						t_frame->frame_name = frame_name;
				
						add_load_item_to_to_do_list (0, frame_file, previous_frame, t_frame);
	
						start_frame = 1;

						cur_xoffset = cols[col];
					}
					else
					{
						/*printf("cols y offset = %d x_offset = %d cols[col] = %d rows[row] = %d\r\n",cur_yoffset, cur_xoffset,cols[col],rows[row]);*/

						/* create temp frame */
						t_frame = temp_frame();
				
						/* set temp frame values to what we want for new frame*/
						t_frame->frame_left = cur_xoffset;
						t_frame->frame_top = cur_yoffset;
						t_frame->frame_width = cols[col];
						t_frame->frame_height = rows[row];
						t_frame->border = border;
						t_frame->frame_name = frame_name;
				
						add_load_item_to_to_do_list (2, frame_file, previous_frame, t_frame);

						cur_xoffset += cols[col];
					}
					
					col += 1;
				}
		
		#endif
		
			}
		}
		
		/* skip junk until the next <...> */
		
		while (*symbol && *(symbol++) != '<');
		if (*symbol) {
			if ((slash = (*symbol == '/'))) symbol++;
			tag = parse (&symbol);
			continue;
		}
	}
	while (*symbol);
	
	return symbol;
}


struct word_item *
list_marker (struct frame_item *p_frame)
{
	WORD modulo = 0, count, word[5], *active_word, indent_type = 0;
	struct word_item *n_word;

	active_word = word;
	
	if (p_frame->current_list == 0)
		return (p_frame->current_word);

	count = p_frame->current_list->current_list_count;

	switch (p_frame->current_list->bullet_style)
	{
		case disc:
			*active_word = 342;
			active_word++;
			indent_type = 0;
			break;
		case square:
			*active_word = 507; /* baldrick - robert had 559;*/
			active_word++;
			indent_type = 0;
			break;
		case circle:
			*active_word = 353;
			active_word++;
			indent_type = 0;
			break;
		case Number:
			while (count > 9)
			{
				count -= 10;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 48);
				active_word++;
			}
			*active_word = map (count + 48);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case Alpha:
			while (count > 26)
			{
				count -= 26;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 64);
				active_word++;
			}
			*active_word = map (count + 64);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case alpha:
			while (count > 26)
			{
				count -= 26;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 96);
				active_word++;
			}
			*active_word = map (count + 96);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case roman:
		case Roman:
			break;
	}

 /* This might fail with new add_word routine */
 
	n_word = add_word (p_frame,p_frame->current_word, word, active_word);

	p_frame->current_word->word_width = list_indent (indent_type);

	if (p_frame->current_word->word_width + p_frame->current_indent_distance > p_frame->frame_page_width)
		p_frame->frame_page_width = p_frame->current_word->word_width + p_frame->current_indent_distance;

	return (n_word);
}

/* calculate_frame
 * this is the main parsing routine
 */
struct paragraph_item *
calculate_frame (char *symbol, struct frame_item *p_frame)
{
	struct paragraph_item *start;
	WORD u, font_step;
	WORD prev_sm_size, prev_su_size; /* one for before small and one for before sub/p */
	enum bool space_found = false, in_pre = false;
	char output[1024]; /* baldrick - this should be done dynamically somehow */
	char *start_symbol;
	WORD active_word_buffer[300]; /* this can be too small for run on lines */

	WORD distances[5], effects[3];

	DBG_START; DBG(">>>");
	
	start_symbol = symbol;

	if (symbol == 0)
		return (new_paragraph ());

	start = p_frame->current_paragraph = new_paragraph ();
	p_frame->current_word = p_frame->current_paragraph->item;
	p_frame->active_word = active_word_buffer;
	p_frame->current_list = 0;
	wind_update (BEG_UPDATE);
	graf_mouse (2, 0);
	wind_update (END_UPDATE);

	current_highlighted_link_area = 0;

	vst_font (vdi_handle, fonts[0][0][0]);
	prev_su_size = prev_sm_size = p_frame->current_font_size = POINT_SIZE;
	p_frame->current_font_step = new_step(3);
	font_step = p_frame->current_font_size / p_frame->current_font_step->step;
	vst_arbpt (vdi_handle, p_frame->current_font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &p_frame->current_word->space_width, &u, &u, &u);

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	p_frame->current_word->word_height = distances[3];
	p_frame->current_word->word_tail_drop = distances[1];
	
	while (*symbol != '\0')
	{
		if (*symbol == '<')
		{
			p_frame->current_word = add_word (p_frame,p_frame->current_word, active_word_buffer,p_frame->active_word);
			p_frame->active_word = active_word_buffer;
			symbol++;
			
			if (*symbol == '!')
			{
				while (*(++symbol)) {
					if (*symbol == '>') {
						symbol++;
						break;
					}
				}
			}
			else
			{
				int  flag = (*symbol != '/');
				if (!flag)
					symbol++;
				switch (parse (&symbol))
				{
					case TAG_A:
						parse_anchor (p_frame, flag);
						break;
					case TAG_B: /* (bold text) */
						set_font_bold (p_frame->current_word, flag);
						break;
					case TAG_BASEFONT:
						if (flag && Variable (KEY_SIZE, output, sizeof(output)))
						{
							p_frame->current_font_step = add_step (p_frame->current_font_step);
							p_frame->current_font_step->step = convert_to_number (output);
							p_frame->current_font_size = p_frame->current_font_step->step * font_step;
							p_frame->current_word->styles.font_size = p_frame->current_font_size;
							p_frame->current_word->changed.font = true;
						}
						break;
					case TAG_BIG:
						if (flag)
							p_frame->current_word->styles.font_size = p_frame->current_font_size * 3 / 2;
						else
							p_frame->current_word->styles.font_size = p_frame->current_font_size;
						p_frame->current_word->changed.font = true;
						break;
					case TAG_BR:
						if (flag)
						{
							p_frame->current_word->word_code = br;
							/* maybe need this? current_word->changed.font = true; */
						}
						break;
					case TAG_BLOCKQUOTE:
						set_blockquote_text (p_frame, active_word_buffer, flag);
						break;
					case TAG_BODY:
						if (flag)
							parse_body (p_frame);
						break;
					case TAG_C: case TAG_CENTER:
						set_center_text (p_frame, active_word_buffer, flag);
						break;
					case TAG_CITE:
						set_font_italic (p_frame->current_word, flag);
						break;
					case TAG_CODE:
						set_pre_font (p_frame->current_word,flag);
						break;
					case TAG_DFN: /* (instance definition) */
						set_font_italic (p_frame->current_word, flag);
						break;
					case TAG_DIR:
						parse_menu_tag (p_frame, active_word_buffer,flag);
						break;
					case TAG_DIV: /* (generic language style container) */
						parse_div_tag (p_frame, active_word_buffer, flag);
						break;
					case TAG_DL: /* (definition list) */
						parse_d_tags (p_frame, active_word_buffer, 0, flag);
						break;
					case TAG_DT: /* (definition term) */
						if (flag)
							parse_d_tags (p_frame, active_word_buffer, 1, 1);
						break;
					case TAG_DD: /* (definition description) */
						if (flag)
							parse_d_tags (p_frame, active_word_buffer, 2, 1);
						break;
					case TAG_EM: /* (emphasis tag) */
						set_font_italic (p_frame->current_word, flag);
						break;
					case TAG_FONT:
						parse_font_tag (p_frame, font_step, flag);
						break;
					case TAG_FRAMESET: /* frame processing */
						if (flag) 
							symbol = parse_frameset (symbol);
						break;				
					case TAG_H: /* header tag <H1>..<H6> */
						parse_header_tag (p_frame, active_word_buffer, flag);
						break;
					case TAG_HR:
						if (flag)
							parse_hr_tag (p_frame, active_word_buffer);
						break;
					case TAG_HTML:
						if (!flag)
						{
							*symbol = '\0';
							p_frame->current_paragraph->eop_space = 20;
						}
						break;
					case TAG_I: /* (italic text style) tag */
						set_font_italic (p_frame->current_word, flag);
						break;
					case TAG_IMG:
						if (flag)
							parse_img_tag (p_frame, active_word_buffer);
						break;
					case TAG_KBD: /* KBD tag? */
						set_pre_font (p_frame->current_word,1);
						break;
					case TAG_LI: /* (list item) */
						if (flag)
						{
							parse_li_tag (p_frame, active_word_buffer, font_step);
							space_found = true;
						}
						break;
					case TAG_MENU:
						parse_menu_tag (p_frame, active_word_buffer, flag);
						break;
					case TAG_OL:
						parse_ol_tag (p_frame, active_word_buffer, flag);
						break;
					case TAG_P: /* (paragraph) */
						if (flag)
							parse_p_tag (p_frame, active_word_buffer);
						break;
					case TAG_PRE:
						if (flag)
						{
							p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;
							add_paragraph (p_frame, active_word_buffer);
							p_frame->active_word = active_word_buffer;
							p_frame->current_paragraph->alignment = left;
							set_pre_font (p_frame->current_word,1);
							in_pre = true;
						}
						else
						{
							set_pre_font (p_frame->current_word,1);
							in_pre = false;
						}
						break;
					case TAG_S: case TAG_STRIKE: /* (strike through text style) */
						set_font_strike (p_frame->current_word,  flag);
						break;
					case TAG_SAMP: /* (sample code or script) */
						set_pre_font (p_frame->current_word, flag);
						break;
					case TAG_SMALL:
						if (flag)
						{
							prev_sm_size = p_frame->current_word->styles.font_size;
							p_frame->current_word->styles.font_size = prev_sm_size * 2 / 3;
						}
						else
						{
							p_frame->current_word->styles.font_size = prev_sm_size;
						}
						p_frame->current_word->changed.font = true;
						break;
					case TAG_STRONG:
						set_font_bold (p_frame->current_word, flag);
						break;
					case TAG_SUB:
						if (flag)
						{
						/*	p_frame->current_word->styles.font_size = p_frame->current_font_size * 2 / 3;*/
							p_frame->current_word->styles.font_size = prev_su_size * 2 / 3;
							p_frame->current_word->vertical_align = below;
						}
						else
						{
							p_frame->current_word->styles.font_size = prev_su_size; /*p_frame->current_font_size; */
							p_frame->current_word->vertical_align = middle; /*bottom; baldrick - July 19, 2001 */
						}
						p_frame->current_word->changed.font = true;
						break;
					case TAG_SUP:
						if (flag)
						{
						/*	p_frame->current_word->styles.font_size = p_frame->current_font_size * 2 / 3;*/
							p_frame->current_word->styles.font_size = prev_su_size * 2 / 3;
							p_frame->current_word->vertical_align = above;
						}
						else
						{
							p_frame->current_word->styles.font_size = prev_su_size; /*p_frame->current_font_size; */
							p_frame->current_word->vertical_align = middle; /*bottom; baldrick - July 19, 2001 */
						}
						p_frame->current_word->changed.font = true;
						break;
					case TAG_TABLE:
						parse_table_tag (p_frame, active_word_buffer, flag);
						break;
					case TAG_TD: /* (table data cell) */
						if (flag)
							parse_td_tag (p_frame, active_word_buffer, 1);
						break;
					case TAG_TH: /* (table header cell) */
						if (flag)
							parse_th_tag (p_frame, active_word_buffer, 1);
						break;
					case TAG_TITLE:
						if (flag)
							symbol = parse_title (symbol, p_frame->active_word);
						break;
					case TAG_TR: /* (table row) */
						/* increment the number of rows */
						if (flag)
							p_frame->current_table->num_rows += 1;
						break;
					case TAG_TT:
						set_pre_font (p_frame->current_word, flag);
						break;
					case TAG_U: /* (underlined text) */
						set_font_underline (p_frame->current_word, flag);
						break;
					case TAG_UL: /* (unordered list) */
						parse_ul_tag (p_frame, active_word_buffer, flag);
						break;
					case TAG_VAR: /* (variable tag) */
						set_font_italic (p_frame->current_word, flag);
						break;
					
					/* we don't set a 'default:' directive here because at least gcc
					 * can tell us if we have forgotten a TAG this way   */
					 
					 case TAG_FRAME:
					 case TAG_Unknown: ;
				}
			}
			if (p_frame->current_word->changed.font == true)
			{
				vst_font (vdi_handle,
					  fonts[p_frame->current_word->styles.font]
					  [p_frame->current_word->styles.bold != 0]
					  [p_frame->current_word->styles.italic != 0]);
				vst_arbpt (vdi_handle, p_frame->current_word->styles.font_size, &u, &u, &u, &u);
				vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
				vqt_advance (vdi_handle, Space_Code,
					     &p_frame->current_word->space_width, &u, &u, &u);

				p_frame->current_word->word_height = distances[3];
				p_frame->current_word->word_tail_drop = distances[1];
			}
			
			continue;
		}
		
		switch (*symbol)
		{
			case 10: /* LF */
				if ((in_pre == true)&&(*(symbol - 1)==13))
				{
					*symbol = 32;
					symbol--;
					break;
				}			
			case 13: /* CR */
			case 12: /* FORM FEED ?????? */
				if ((in_pre == true))
				{
					p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

					add_paragraph(p_frame, active_word_buffer);
					p_frame->active_word = active_word_buffer;
				}
				else
				{
					*symbol = 32;
					symbol--;
				}
				break;
			case '&':
				/* the 'symbol' pointer will be set by the scanner function
				 * to the expression end, ';' or '\0'.
				 * AltF4 Dec 19, 2001
				 */

				*p_frame->active_word = scan_namedchar (&symbol, ISO1);
				p_frame->active_word++;
				space_found = false;
				break;
			case ' ':
				if (!in_pre)
				{
					if (space_found == true)
						break;
	
					p_frame->current_word = add_word (p_frame,p_frame->current_word, active_word_buffer,p_frame->active_word);
					p_frame->active_word = active_word_buffer;
					space_found = true;
				}
			default:
				if (*symbol < 32)
					break;
				if (*symbol > 126)
					break;
				if (*symbol != ' ')
					space_found = false;

				*p_frame->active_word = map (*symbol);
				p_frame->active_word++;
		}
		symbol++;

	}

	word_store (p_frame, active_word_buffer, p_frame->active_word);

	wind_update (BEG_UPDATE);
	graf_mouse (0, 0);
	wind_update (END_UPDATE);

	free (start_symbol);

	p_frame->frame_page_width += 5;
	
	DBG("<<<");
	
	return (start);
}

/* parse_text
 * this is the text parsing routine
 * for use with non formatted text files
 *
 * Nothing exciting just maps lines to paragraphs
 */
 
struct paragraph_item *
parse_text (char *symbol, struct frame_item *p_frame)
{
	struct paragraph_item *start;
	WORD u;
	char *start_symbol;
	WORD active_word_buffer[200];
	WORD distances[5], effects[3];
	WORD i;

	start_symbol = symbol;

	if (symbol == 0)
		return (new_paragraph ());

	start = p_frame->current_paragraph = new_paragraph ();
	p_frame->current_word = p_frame->current_paragraph->item;
	p_frame->active_word = active_word_buffer;

	wind_update (BEG_UPDATE);
	graf_mouse (2, 0);
	wind_update (END_UPDATE);

	current_highlighted_link_area = 0;

	vst_font (vdi_handle, fonts[0][0][0]);
	p_frame->current_font_size = POINT_SIZE;
	vst_arbpt (vdi_handle, p_frame->current_font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &p_frame->current_word->space_width, &u, &u, &u);

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	p_frame->current_word->word_height = distances[3];
	p_frame->current_word->word_tail_drop = distances[1];

	p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;
	p_frame->current_word->styles.font = pre_font;

	while (*symbol != '\0')
	{
		switch (*symbol)
		{
			case 9:  /* TAB */
				*symbol = 32;
				
				for (i = 0; i< 5;i++)
				{
					*p_frame->active_word = map (*symbol);
					p_frame->active_word++;
				}

				break;
			case 10: /* LF */
				if ((*(symbol - 1)==13))
				{
					*symbol = 32;
					symbol--;
					break;
				}			
			case 13: /* CR */
			case 12: /* FORM FEED ?????? */
				p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

				add_paragraph(p_frame, active_word_buffer);

				p_frame->active_word = active_word_buffer;
				break;
			default:
				if (*symbol < 32)
					break;
/*				
				if (*symbol > 126)
					break;
*/
				*p_frame->active_word = map (*symbol);
				p_frame->active_word++;
		}

		symbol++;
	}

	word_store (p_frame, active_word_buffer, p_frame->active_word);

	wind_update (BEG_UPDATE);
	graf_mouse (0, 0);
	wind_update (END_UPDATE);

	free (start_symbol);

	p_frame->frame_page_width += 5;

	return (start);
}
