
#include <stdlib.h>
#include <string.h>

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

void
destroy_frame_structure (struct frame_item *current_frame)
{
	struct frame_item *temp;

	while (current_frame != 0)
	{
		if (current_frame->item != 0)
			destroy_paragraph_structure (current_frame->item);
/* we need to kill the new_frame list if it exists */

		if (current_frame->first_clickable_area != 0)
			destroy_clickable_area_structure (current_frame->first_clickable_area);
		if (current_frame->first_named_location != 0)
			destroy_named_location_structure (current_frame->first_named_location);
		temp = current_frame->next_frame;
		free (current_frame);
		current_frame = temp;
	}
}

/* 
 * creates a new frame structure and initializes it's values
 * it also links previous_frame * to the new space for when
 * we create the next frame we have someplace to link it to
 */

struct frame_item *
new_frame (void)
{
	struct frame_item *temp;
	temp = malloc (sizeof (struct frame_item));
	memset (temp, 0, sizeof (struct frame_item));

	temp->item = 0;
	temp->frame_width = 0;
	temp->frame_height = 0;
	temp->frame_left = 0;
	temp->frame_top = 0;
	temp->horizontal_scroll = 0;
	temp->vertical_scroll = 0;
	temp->border = false;
	temp->frame_page_width = 0;
	temp->next_frame = 0;
	temp->current_page_height = 0;
	temp->background_colour = 0;
	temp->text_colour = 1;
	temp->link_colour = link_colour;
	temp->clip.x = 0;
	temp->clip.y = 0;
	temp->clip.w = 0;
	temp->clip.h = 0;
	temp->first_clickable_area = 0;
	temp->first_named_location = 0;
	temp->frame_filename = 0;
	temp->frame_named_location = 0;
	temp->frame_name = 0;

	temp->current_indent_distance = 0;

	temp->active_word = 0;
	temp->parent_table = 0;
	
	temp->current_attr = 0;
	
	previous_frame = temp;
	
	return (temp);
}

void
reset_frame (struct frame_item *frame)
{
	if (frame->first_clickable_area != 0)
		destroy_clickable_area_structure (frame->first_clickable_area);
	if (frame->item != 0)
		destroy_paragraph_structure (frame->item);
	frame->item = 0;

/* we need to walk the new_frame list down here and destroy it if it exists */

	frame->frame_width = 0;
	frame->frame_height = 0;
	frame->frame_left = 0;
	frame->frame_top = 0;
	frame->horizontal_scroll = 0;
	frame->vertical_scroll = 0;
	frame->border = false;
	frame->frame_page_width = 0;
	frame->current_page_height = 0;
	frame->background_colour = 0;
	frame->text_colour = 1;
	frame->link_colour = link_colour;
	frame->clip.x = 0;
	frame->clip.y = 0;
	frame->clip.w = 0;
	frame->clip.h = 0;
	frame->first_clickable_area = 0;
	frame->first_named_location = 0;
	frame->frame_filename = 0;
	frame->frame_named_location = 0;
	frame->frame_name = 0;

	frame->current_indent_distance = 0;

	frame->active_word = 0;

	frame->current_attr = 0;

}

/* temp_frame()
 * 
 * this is used to create a temporary dummy frame to hold
 * information for the add_load_to_do() routine.
 * this routine does not touch previous_frame variable
 */

struct frame_item *
temp_frame (void)
{
	struct frame_item *temp;
	temp = malloc (sizeof (struct frame_item));
	memset (temp, 0, sizeof (struct frame_item));

	temp->item = 0;
	temp->frame_width = 0;
	temp->frame_height = 0;
	temp->frame_left = 0;
	temp->frame_top = 0;
	temp->horizontal_scroll = 0;
	temp->vertical_scroll = 0;
	temp->border = false;
	temp->frame_page_width = 0;
	temp->next_frame = 0;
	temp->current_page_height = 0;
	temp->background_colour = 0;
	temp->text_colour = 1;
	temp->link_colour = link_colour;
	temp->clip.x = 0;
	temp->clip.y = 0;
	temp->clip.w = 0;
	temp->clip.h = 0;
	temp->first_clickable_area = 0;
	temp->first_named_location = 0;
	temp->frame_filename = 0;
	temp->frame_named_location = 0;
	temp->frame_name = 0;

	temp->current_indent_distance = 0;
	
	temp->active_word = 0;

	temp->current_attr = 0;

	return (temp);
}
