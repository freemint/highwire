/* @(#)highwire/window.h
 */
#ifndef __HW_WIND_H__
#define __HW_WIND_H__


struct s_window {
	struct s_window *next;  /* top window first, sorted for ^W */
	WORD handle;
	struct {
		unsigned open      : 1;
		unsigned full      : 1;
		unsigned iconified : 1;
		unsigned shaded    : 1;
	} flags;
	#define WINSTRLEN 128
	char name[WINSTRLEN];  /* memory used by AES */
	char info[WINSTRLEN];  /* memory used by AES */
	CONTAINR container;    /* base container of the window */
	/* There is a difference between container and active_frame->Container! */
	struct frame_item *active_frame;  /* for keyboard commands and menu bar */
};


extern WINDOWP window_list;
#ifndef MULTIPLE_WINDOWS
extern WINDOW window;
#endif


const WINDOW * new_window(const char *file);
void delete_window(short handle);

void window_move(WORD handle, const GRECT * new);
void window_resize(WORD handle, const GRECT * new);
void window_full(WORD handle);
void window_iconify(WORD handle, GRECT *new);
void window_uniconify(WORD handle, GRECT *new);
void window_shade(WORD handle, BOOL is_shaded);
void window_top(WORD handle);
void window_bottom(WORD handle);

const WINDOW * window_byHandle(short handle);
#define window_byCoord(x, y) window_byHandle(wind_find(x, y))
CONTAINR window_ContainerByHandle(short handle);
void window_cycle(void);
void window_cycle_frames(void);
void window_reload_all(void);

void window_redraw (short hdl, const GRECT * p_clip);
void wind_scroll (short hdl, CONTAINR, long dx, long dy);
void wind_handler (HW_EVENT event, long arg, CONTAINR cont, const void * gen_ptr);


#endif /*__WINDOW_H__*/
