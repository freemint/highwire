/* @(#)highwire/window.c
 */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include <gem.h>

#include "global.h"
#include "Logging.h"
#include "window.h"


static WORD  inc_xy = 0;
static BOOL  bevent;
static GRECT desk_area;
static GRECT curr_area;

#ifdef MULTIPLE_WINDOWS
WINDOWP window_list = NULL;
#else
WINDOW window, *window_list = &window;
#endif


/*----------------------------------------------------------------------------*/
static void
set_name (const WINDOW * const win, const char * text)
{
	if (text && text[0]) {
		strncpy (win->name, text, sizeof(win->name));
		win->name[sizeof(win->name) - 1] = '\0';
	} else {
		win->name[0] = '\0';
	}
	wind_set_str (win->handle, WF_NAME, win->name);
}


/*----------------------------------------------------------------------------*/
static void
set_info (const WINDOW * const win, const char * text)
{
	if (text && text[0]) {
		strncpy (win->info, text, sizeof(win->info));
		win->info[sizeof(win->info) - 1] = '\0';
	} else {
		win->info[0] = '\0';
	}
	wind_set_str (win->handle, WF_INFO, win->info);
}


/*============================================================================*/
const WINDOW *
new_window(const char *url)
{
#ifdef GEM_MENU
	extern OBJECT * menutree;
#endif
	WORD handle;
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;
#else
#define win (&window)
#endif

	if (!inc_xy) {
		WORD out, u;
		bevent = (appl_xgetinfo(AES_WINDOW, &out, &u,&u,&u) && (out & 0x20));
		wind_get_grect (DESKTOP_HANDLE, WF_WORKXYWH, &desk_area);
		wind_calc_grect (WC_BORDER, VSLIDE|HSLIDE, &desk_area, &curr_area);
		curr_area.g_w -= desk_area.g_w;
		curr_area.g_h -= desk_area.g_h;
		inc_xy = (curr_area.g_w >= curr_area.g_h ? curr_area.g_w : curr_area.g_h);
		if (desk_area.g_w < 800) {
			curr_area = desk_area;
			curr_area.g_w = (desk_area.g_w *2) /3;
		} else {
			curr_area.g_x = desk_area.g_x + inc_xy;
			curr_area.g_y = desk_area.g_y + inc_xy;
			curr_area.g_w = desk_area.g_w /2;
			curr_area.g_h = (desk_area.g_h *4) /5;
		}

	} else {
		curr_area.g_x += inc_xy;
		if (curr_area.g_x + curr_area.g_w > desk_area.g_x + desk_area.g_w) {
			curr_area.g_x = desk_area.g_x;
		}
		curr_area.g_y += inc_xy;
		if (curr_area.g_y + curr_area.g_h > desk_area.g_y + desk_area.g_h) {
			curr_area.g_y = desk_area.g_y;
		}
	}

	#ifdef RAINER /* sizes for Rainers's test computers */
	{
	GRECT area;
	area.g_x = (desk_area.g_w == 640)? desk_area.g_x : 64;
	area.g_y = desk_area.g_y;
	area.g_w = (desk_area.g_w == 640)? desk_area.g_w : desk_area.g_w - 64;
	area.g_h = min(desk_area.g_h, 1025);
	handle = wind_create_grect (NAME|CLOSER|FULLER|MOVER|SMALLER|SIZER|INFO, &area);
	}
	#else
	handle = wind_create_grect (NAME|CLOSER|FULLER|MOVER|SMALLER|SIZER|INFO, &desk_area);
	#endif
#ifdef MULTIPLE_WINDOWS
	if (handle < 0 || (win = calloc(1, sizeof(WINDOW))) == NULL) {
		if (handle >= 0)
			wind_delete(handle);
#else
#define win (&window)
	if (handle < 0) {
#endif
		form_alert(1, "[3][HighWire cannot open window!][  OK  ]");
		return NULL;
	}

#ifdef MULTIPLE_WINDOWS
	win->next = window_list;
	window_list = win;
#endif
	win->handle = handle;

#ifdef GEM_MENU
	menu_ienable(menutree, M_SOURCE, ENABLE);
	menu_ienable(menutree, M_CYCLE, window_list->next != NULL);
	menu_ienable(menutree, M_CLOSE, ENABLE);
#endif

	win->container = new_containr(NULL);
	win->container->Window = win;
	containr_register(win->container, wind_handler, (long)win);

	window_resize (handle, &curr_area);
	set_name(win, url);
	set_info(win, url);

	if (bevent)
		wind_set(handle, WF_BEVENT, 1, 0, 0, 0);
	wind_open_grect (handle, &curr_area);

	logprintf(LOG_MAGENTA, "new_window(): window_list %p, next %p, handle %d, container %p, active_frame %p\n",
	    window_list, win->next, win->handle, win->container, win->active_frame);

	if (url && url[0])
		new_loader_job(url, NULL, win->container, MIME_Unknown, ENCODING_WINDOWS1252, -1, -1);

	return win;
}


/*============================================================================*/
void delete_window(WORD handle)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win, *winp;

	for (winp = &window_list; *winp && (*winp)->handle != handle; winp = &((*winp)->next));
	win = *winp;  /* extract window from old position */
	*winp = win->next;

#ifdef GEM_MENU
	menu_ienable(menutree, M_SOURCE, window_list != NULL);
	menu_ienable(menutree, M_CYCLE, window_list != NULL && window_list->next != NULL);
	menu_ienable(menutree, M_CLOSE, window_list != NULL);
#endif

	delete_containr(&win->container);
	free(win);
	wind_delete(handle);

#ifdef GEM_MENU
	update_menu();
#endif
	check_mouse_position (-1, -1);

#else
	(void)handle;
	exit(EXIT_SUCCESS);
#endif
}


/*============================================================================*/
void window_move(WORD handle, const GRECT * new)
{
	GRECT work;
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

	for (win = window_list; win && win->handle != handle; win = win->next);

	if (win)
#endif
	{
		wind_set_grect (handle, WF_CURRXYWH, new);
		wind_get_grect (handle, WF_WORKXYWH, &work);
		containr_relocate (win->container, work.g_x, work.g_y);
	}
	check_mouse_position (-1, -1);
}


/*============================================================================*/
void window_resize(WORD handle, const GRECT * new)
{
	GRECT work;
	WORD msg[8];
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

	for (win = window_list; win && win->handle != handle; win = win->next);

	if (win)
#endif
	{
		wind_set_grect (handle, WF_CURRXYWH, new);
		wind_get_grect (handle, WF_WORKXYWH, &work);
		containr_calculate (win->container, &work);
		win->flags.full = FALSE;

		/* Send a redraw message to myself, instead of a complete redraw.
		 * This allows the AES to merge it with its own redraw message.
		 */
		msg[0] = WM_REDRAW;
		msg[1] = gl_apid;
		msg[2] = 0;
		msg[3] = handle;
		*(GRECT *)&msg[4] = work;
		appl_write(gl_apid, 16, msg);
	}
	check_mouse_position (-1, -1);
}


/*============================================================================*/
/* Realistically under some AES we should check if the
 * window belongs to us.  Before proceding with modification.
 * I have witnessed this under MagiC with Jinnee.  I'm not
 * certain if it's specific to those.
 * The check won't hurt anyone else though.
 * / baldrick
 */
void window_full(WORD handle)
{
	GRECT new;
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

	for (win = window_list; win && win->handle != handle; win = win->next);

	if (win)
#else
#define win (&window)
#endif
	{
		if (win->flags.full)
		{
			/* Shrink Window to normal */
			wind_get_grect(handle, WF_PREVXYWH, &new);
			win->flags.full = FALSE;
		}
		else
		{
			/* Full window */
			wind_get_grect(handle, WF_FULLXYWH, &new);
			win->flags.full = TRUE;
		}
		wind_set_grect(handle, WF_CURRXYWH, &new);
		wind_get_grect (handle, WF_WORKXYWH, &new);
		containr_calculate (win->container, &new);
	}
}


/*============================================================================*/
/* Iconify.
 */
void window_iconify(WORD handle, GRECT *new)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

	for (win = window_list; win && win->handle != handle; win = win->next);

	if (win)
#endif
	{
		wind_set_grect(handle, WF_ICONIFY, new);
		win->flags.iconified = TRUE;
		wind_set (handle, WF_BOTTOM, 0, 0, 0, 0);
	}
	check_mouse_position (-1, -1);
}


/*============================================================================*/
void window_uniconify(WORD handle, GRECT *new)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

	for (win = window_list; win && win->handle != handle; win = win->next);

	if (win)
#endif
	{
		wind_set_grect(handle, WF_UNICONIFY, new);
		win->flags.iconified = FALSE;
		wind_set (handle, WF_TOP, 0, 0, 0, 0);
	}
	check_mouse_position (-1, -1);
}


/*============================================================================*/
/* A shaded window has only a title bar.  It must ignore content changes by
 * keyboard.
 * Supported by WINX 2.3n beta, N.AES 1.1.7, MagiC 5.2.
 */
void window_shade(WORD handle, BOOL is_shaded)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

	for (win = window_list; win && win->handle != handle; win = win->next);

	if (win)
#else
	(void)handle;
#endif
		win->flags.shaded = is_shaded;
}


/*============================================================================*/
void window_top(WORD handle)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win, *winp;

	if (!window_list)
		return;

logprintf(LOG_MAGENTA, "window_list = %p, next %p\n", window_list, window_list->next);

	                         /* search pointer to window */
	for (winp = &window_list; *winp && (*winp)->handle != handle; winp = &((*winp)->next));
	win = *winp;             /* extract window from old position */
	*winp = win->next;
	win->next = window_list;  /* insert window as first */
	window_list = win;

logprintf(LOG_MAGENTA, "window_list = %p, next %p\n", window_list, window_list->next);
#endif

	wind_set(handle, WF_TOP, 0, 0, 0, 0);

#ifdef GEM_MENU
	update_menu();
#endif
}


/*============================================================================*/
void window_bottom(WORD handle)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win, *winp;

logprintf(LOG_MAGENTA, "window_list = %p, next %p\n", window_list, window_list->next);

	for (winp = &window_list; *winp && (*winp)->handle != handle; winp = &((*winp)->next));
	for (win = *winp; win->next; win = win->next);  /* get last window */
	win->next = *winp;       /* add bottomed as last */
	*winp = (*winp)->next;   /* delete old position */
	win->next->next = NULL;  /* new last window has no next */

logprintf(LOG_MAGENTA, "window_list = %p, next %p\n", window_list, window_list->next);

#ifdef GEM_MENU
	update_menu();
#endif
#endif

	wind_set (handle, WF_BOTTOM, 0, 0, 0, 0);
	check_mouse_position (-1, -1);
}


/*============================================================================*/
const WINDOW *
window_byHandle(short handle)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

	for (win = window_list; win && win->handle != handle; win = win->next);

	return win;

#else
	(void)handle;

	return &window;
#endif
}


/*============================================================================*/
CONTAINR
window_ContainerByHandle(short handle)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

	for (win = window_list; win && win->handle != handle; win = win->next);

	return win? win->container : NULL;

#else
	(void)handle;

	return window.container;
#endif
}


/*============================================================================*/
void
window_cycle(void)
{
#ifdef MULTIPLE_WINDOWS
	WINDOWP win;

logprintf(LOG_MAGENTA, "window_list = %p, next %p\n", window_list, window_list->next);
	/* need at least 2 windows to cycle */
	if (!window_list || !window_list->next)
		return;

	for (win = window_list; win->next; win = win->next);  /* get last window */
	win->next = window_list;        /* first window becomes new last */
	window_list = win->next->next;  /* list starts at old second */
	win->next->next = NULL;        /* new last window has no next */
logprintf(LOG_MAGENTA, "window_list = %p, next %p\n", window_list, window_list->next);

#ifdef GEM_MENU
	update_menu();
#endif
	wind_set(window_list->handle, WF_TOP, 0, 0, 0, 0);
#endif
}


/*============================================================================*/
void
window_cycle_frames(void)
{
	window_list->active_frame = frame_next(window_list->active_frame);
#ifdef GEM_MENU
	update_menu ();
#endif
}


/*============================================================================*/
void
window_redraw (short hdl, const GRECT * clip)
{
	GRECT work, rect = desk_area;
#ifdef MULTIPLE_WINDOWS
	const WINDOW *win;

	for (win = window_list; win && win->handle != hdl; win = win->next);

	if (!win)
		return;
#endif

	wind_update (BEG_UPDATE);

	if (clip && !rc_intersect (clip, &rect)) {
		rect.g_w = rect.g_h = 0;
	}

	if (!win->flags.iconified) {
		work = win->container->Area;
		if (!rc_intersect (&rect, &work)) {
			rect.g_w = rect.g_h = 0;
		} else {
			wind_get_grect (hdl, WF_FIRSTXYWH, &rect);
		}
		while (rect.g_w > 0 && rect.g_h > 0) {
			if (rc_intersect (&work, &rect)) {
				containr_redraw (win->container, &rect);
			}
			wind_get_grect (hdl, WF_NEXTXYWH, &rect);
		}

	} else /* win->flags.iconified */ {
		wind_get_grect (hdl, WF_WORKXYWH, &work);
		if (!rc_intersect (&rect, &work)) {
			rect.g_w = rect.g_h = 0;
		} else {
			wind_get_grect (hdl, WF_FIRSTXYWH, &rect);
		}
		while (rect.g_w > 0 && rect.g_h > 0) {
			if (rc_intersect (&work, &rect)) {
				/* ... */
			}
			wind_get_grect (hdl, WF_NEXTXYWH, &rect);
		}
	}

	check_mouse_position (-1, -1);
	wind_update (END_UPDATE);
}
#undef win


/*============================================================================*/
void
wind_scroll (short hdl, CONTAINR cont, long dx, long dy)
{
	GRECT clip, work;
#ifdef MULTIPLE_WINDOWS
	const WINDOW *win;

	for (win = window_list; win && win->handle != hdl; win = win->next);

	if (!win)
		return;
#endif

	wind_get_grect (0,   WF_WORKXYWH, &clip);
	wind_get_grect (hdl, WF_WORKXYWH, &work);

	if (containr_shift (cont, &dx, &dy)
	    && rc_intersect (&clip, &work) && rc_intersect (&cont->Area, &work)) {
		wind_update (BEG_UPDATE);
		check_mouse_position (0, 0);  /* deselect highlighted links */
		wind_get_grect (hdl, WF_FIRSTXYWH, &clip);
		while (clip.g_w > 0 && clip.g_h > 0) {
			if (rc_intersect (&work, &clip)) {
				containr_scroll (cont, &clip, dx, dy);
			}
			wind_get_grect (hdl, WF_NEXTXYWH, &clip);
		}
		check_mouse_position (-1, -1);
		wind_update (END_UPDATE);
	}
}


/*============================================================================*/
void wind_handler (HW_EVENT, long, CONTAINR, const void *); /* keep gcc quiet */
void
wind_handler (HW_EVENT event, long arg, CONTAINR cont, const void * gen_ptr)
{
	(void)arg;  /* unused at the moment, so suppress warning by Pure C */

	switch (event) {

		case HW_PageCleared:
			logprintf(LOG_BLACK, "wind_handler(HW_PageCleared, , %p)\n", gen_ptr);/*temporary*/
			break;

		case HW_PageStarted:
			logprintf(LOG_BLACK, "wind_handler(HW_PageStarted, , '%s')\n", gen_ptr);/*temporary*/
			if (!number_of_frames_left_to_load++) {
				graf_mouse (BUSYBEE, NULL);
			}
			set_info (cont->Window, gen_ptr);
			/* fall through */
		case HW_SetTitle:
			logprintf(LOG_BLACK, "wind_handler(HW_SetTitle, , '%s')\n", gen_ptr);/*temporary*/
			if (!cont->Parent) {
				set_name (cont->Window, gen_ptr);
			} else {
				/* The title of a frame can overwrite the window info. */
		case HW_SetInfo:
				logprintf(LOG_BLACK, "wind_handler(HW_SetInfo, , '%s')\n", gen_ptr);/*temporary*/
				set_info (cont->Window, gen_ptr);
			}
			break;

		case 10: /* HW_ImgStarted */
			if (!number_of_frames_left_to_load++) {
				graf_mouse (BUSYBEE, NULL);
			}
			set_info (cont->Window, gen_ptr);
			break;

		case 11: /* HW_ImgFinished */
			window_redraw (cont->Window->handle, gen_ptr);
			set_info (cont->Window, "");
			if (!number_of_frames_left_to_load || !--number_of_frames_left_to_load) {
				check_mouse_position (-1, -1);
			}
			break;

		case HW_PageFinished:
			if (gen_ptr) {
				window_redraw (cont->Window->handle, gen_ptr);
				cont->Window->active_frame = containr_Frame (cont);
			#ifdef GEM_MENU
				update_menu ();
			#endif
			}
			if (!number_of_frames_left_to_load || !--number_of_frames_left_to_load) {
				check_mouse_position (-1, -1);
			}
			break;

		default:
			errprintf ("wind_handler (%i, %p)\n", event, cont);
	}
}


/*============================================================================*/
void window_reload_all(void)
{
	const WINDOW *win;
	FRAME frame;

	for (win = window_list; win; win = win->next) {
		frame = win->active_frame;
		do
			new_loader_job(NULL, frame->Location, frame->Container,
			               frame->MimeType, frame->Encoding,
			               frame->Page.MarginLft, frame->Page.MarginTop);
		while ((frame = frame_next(frame)) != win->active_frame);
	}
}
