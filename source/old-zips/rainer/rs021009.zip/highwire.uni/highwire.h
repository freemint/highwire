 /*  Resource C-Header-File v1.3 f�r ResourceMaster ab v2.06 by ARDISOFT  */

#define MENUTREE 0  /* menu */
#define M_ABOUT 10  /* STRING in tree MENUTREE */
#define M_OPEN 19  /* STRING in tree MENUTREE */
#define M_RELOAD 20  /* STRING in tree MENUTREE */
#define M_INFO 22  /* STRING in tree MENUTREE */
#define M_SOURCE 23  /* STRING in tree MENUTREE */
#define M_CYCLE 25  /* STRING in tree MENUTREE */
#define M_CLOSE 26  /* STRING in tree MENUTREE */
#define M_QUIT 28  /* STRING in tree MENUTREE */
#define M_1252 31  /* STRING in tree MENUTREE */
#define M_ISO8859_2 32  /* STRING in tree MENUTREE */
#define M_ISO8859_15 33  /* STRING in tree MENUTREE */
#define M_UTF8 34  /* STRING in tree MENUTREE */
#define M_UTF16 35  /* STRING in tree MENUTREE */
#define M_UTF16LE 36  /* STRING in tree MENUTREE */
#define M_MACINTOSH 37  /* STRING in tree MENUTREE */
#define M_ATAR_SYS 38  /* STRING in tree MENUTREE */
#define M_ATARINVDI 39  /* STRING in tree MENUTREE */
#define M_FONT_INC 41  /* STRING in tree MENUTREE */
#define M_FONT_DEC 42  /* STRING in tree MENUTREE */
#define M_LOGGING 44  /* STRING in tree MENUTREE */
#define M_ALT_TEXT 45  /* STRING in tree MENUTREE */
#define M_HELP 47  /* STRING in tree MENUTREE */

#define ABOUT 1  /* form/dial */
#define ABOUT_OK 1  /* BUTTON in tree ABOUT */
#define ABOUT_VERSION 3  /* FTEXT in tree ABOUT */
#define ABOUT_GDOSFONT 4  /* FTEXT in tree ABOUT */

#define URLINPUT 2  /* form/dial */
#define URL_OK 2  /* BUTTON in tree URLINPUT */
#define URL_CANCEL 3  /* BUTTON in tree URLINPUT */
#define URL_FILE 4  /* BUTTON in tree URLINPUT */
#define URL_ED_BG 5  /* IBOX in tree URLINPUT */
#define URL_EDIT 6  /* FBOXTEXT in tree URLINPUT */

#define RPOPUP 3  /* form/dial */
#define RPOP_BACK 1  /* TEXT in tree RPOPUP */
#define RPOP_FORWARD 3  /* TEXT in tree RPOPUP */
#define RPOP_VIEWSRC 4  /* TEXT in tree RPOPUP */
#define RPOP_RELOAD 5  /* TEXT in tree RPOPUP */
#define RPOP_INFO 7  /* TEXT in tree RPOPUP */
