/* @(#)highwire/font.c
 *
 * This module provides font management for the HighWire HTML browser.
 * Rainer Seitel, 2002-08-08
 */


#include "string.h"

#include "gemx.h"

#include "global.h"
#include "Logging.h"
#include "window.h"


/* Needs NVDI � 3!
 */
void font_init(void)
{
	WORD u;
	WORD number_of_fonts;

	vst_kern (vdi_handle, TRACK_NORMAL, PAIR_ON, &u, &u);
	vst_scratch (vdi_handle, SCRATCH_BOTH);

	number_of_fonts = vdi_dev.faces + vst_load_fonts(vdi_handle, 0);
	/* menu_logging(); */
	logprintf(LOG_BLUE, "############### %d fonts available, %d system font.\n",
	          number_of_fonts, vdi_dev.faces);

#if defined(ONLY_BICS)
	vst_font (vdi_handle, fonts[normal_font][0][0]);  /* for vst_charmap()! */
	vst_charmap (vdi_handle, MAP_BITSTREAM);

#elif defined(ONLY_UNICODE)
	if      (font_get_id_by_face("Caslon",                fonts[normal_font]));
	else if (font_get_id_by_face("Ballymun RO",           fonts[normal_font]));
	else if (font_get_id_by_face("Times New Roman",       fonts[normal_font]));
	else if (font_get_id_by_face("Arial",                 fonts[normal_font]));
	else if (font_get_id_by_face("TITUS Cyberbit Basic",  fonts[normal_font]));
	else if (font_get_id_by_face("Lucida Sans Unicode",   fonts[normal_font]));
	else if (font_get_id_by_face("Verdana",               fonts[normal_font]));
	else if (font_get_id_by_face("Tahoma",                fonts[normal_font]));
	else if (font_get_id_by_face("Baskerville",           fonts[normal_font]));
	else if (font_get_id_by_face("Bitstream Charter",     fonts[normal_font]));

	if      (font_get_id_by_face("Arial Black",           fonts[header_font]));
	else if (font_get_id_by_face("Impact",                fonts[header_font]));
	else if (font_get_id_by_face("Franklin Gothic",       fonts[header_font]));

	if      (font_get_id_by_face("Everson Mono Terminal", fonts[pre_font]));
	else if (font_get_id_by_face("Courier New",           fonts[pre_font]));
	else if (font_get_id_by_face("Courier 10 Pitch",      fonts[pre_font]));

	/* For the CJK range. */
	font_get_id_by_face("SquareGothic", fonts[cjk_font]);

	vst_font (vdi_handle, fonts[normal_font][0][0]);  /* for vst_map_mode()! */
	vst_map_mode(vdi_handle, MAP_UNICODE);

#else
	#error "Automatic recognizing of the VDI character sets not implemented!"
#endif
}


/* Wrong binding in GEM lib! */
short vqt_name_and_id(short handle, short font_format, const char *font_name, char *ret_name)
{
	size_t n = 1;
	short i;

	/* Release registers used for parameters as first step helps optimizing. */
	vdi_control[6] = handle;
	vdi_intin[0] = font_format;
	while (*font_name)
		vdi_intin[n++] = *font_name++;
	vdi_control[0] = 230;
	vdi_control[1] = 0;
	vdi_control[3] = n;
	vdi_control[5] = 100;
	vdi(&vdi_params);
	for (i = 1; i < vdi_control[4]; i++)
		*ret_name++ = vdi_intout[i];
	*ret_name = '\0';
	return vdi_intout[0];
}


/* Wrong binding in GEM lib! */
short vst_name(short handle, short font_format, const char *font_name, char *ret_name)
{
	size_t n = 1;
	short i;

	/* Release registers used for parameters as first step helps optimizing. */
	vdi_control[6] = handle;
	vdi_intin[0] = font_format;
	while (*font_name)
		vdi_intin[n++] = *font_name++;
	vdi_control[0] = 230;
	vdi_control[1] = 0;
	vdi_control[3] = n;
	vdi_control[5] = 0;
	vdi(&vdi_params);
	for (i = 1; i < vdi_control[4]; i++)
		*ret_name++ = vdi_intout[i];
	*ret_name = '\0';
	return vdi_intout[0];
}


/* Gets the IDs of our 4 styles with bold and italic of the given font face.
 * 'face' is a comma seperated list of font face names.
 * Needs NVDI � 3.02!
 */
BOOL font_get_id_by_face(char *face, WORD font[2][2])
{
#ifdef ONLY_UNICODE
	char *next_face;
	WORD id;
	/* NVDI requires 128 byte for ret_name of vqt_name_and_id() and vst_name()! */
	char styles[100], *style_p, style_found[128];
	#define FUNCTION vqt_name_and_id /*vst_name*/
	#define INVALID_ID 0             /*1*/

	logprintf(LOG_BLUE, "font_get_id_by_name('%s')\n", face);
	next_face = strtok(face, ",");

	do {
		strcpy(styles, next_face);
		style_p = styles + strlen(styles);

		id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
		if (id == INVALID_ID) {
			strcpy(style_p, " Normal");
			id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
			if (id == INVALID_ID) {
				strcpy(style_p, " Roman");
				id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
				if (id == INVALID_ID) {
					strcpy(style_p, "Md BT");
					id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
				}
			}
		}
		if (id != INVALID_ID) {
			font[0][0] = font[0][1] = font[1][0] = font[1][1] = id;
			logprintf(LOG_BLUE, "Font '%s' has ID %d '%s'\n", styles, id, style_found);

			strcpy(style_p, " Bold");
			id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
			if (id == INVALID_ID) {
				strcpy(style_p, " Black");
				id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
				if (id == INVALID_ID) {
					strcpy(style_p, "Bd BT");
					id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
				}
			}
			if (id != INVALID_ID) {
				font[1][0] = font[1][1] = id;
				logprintf(LOG_BLUE, "Font '%s' has ID %d '%s'\n", styles, id, style_found);
			}

			strcpy(style_p, " Italic");
			id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
			if (id == INVALID_ID) {
				strcpy(style_p, " Oblique");
				id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
			}
			if (id != INVALID_ID) {
				font[0][1] = font[1][1] = id;
				logprintf(LOG_BLUE, "Font '%s' has ID %d '%s'\n", styles, id, style_found);
			}

			strcpy(style_p, " Bold Italic");
			id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
			if (id == INVALID_ID) {
				strcpy(style_p, " Bold Oblique");
				id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
				if (id == INVALID_ID) {
					strcpy(style_p, " Black Italic");
					id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
					if (id == INVALID_ID) {
						strcpy(style_p, " Black Oblique");
						id = FUNCTION(vdi_handle, 2|4|8, styles, style_found);
					}
				}
			}
			if (id != INVALID_ID) {
				font[1][1] = id;
				logprintf(LOG_BLUE, "Font '%s' has ID %d '%s'\n", styles, id, style_found);
			}

			return TRUE;
		}

		next_face = strtok(NULL, ",");
	} while (next_face);

	logprintf(LOG_RED, "get_font_id_by_name() failed.\n");

#else
	(void)face; (void)font;
#endif

	return FALSE;
}


/* Reinitialize fonts after a FNT_CHANGED message.
 */
void font_reinit(void)
{
	logprintf(LOG_BLUE, "Reinitialize fonts.\n");
	vst_unload_fonts(vdi_handle, 0);
	font_init();
	window_reload_all();
}
