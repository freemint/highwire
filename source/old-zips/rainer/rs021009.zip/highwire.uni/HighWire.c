/* @(#)highwire/HighWire.c
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef __PUREC__
#include <tos.h>

#else /* LATTICE || __GNUC__ */
#include <mintbind.h>
#endif

#include <gemx.h>

#include "global.h"
#include "Logging.h"
#include "schedule.h"
#include "containr.h"
#include "window.h"

extern char *gslongname;
extern char *gsanswer;
extern char *gsi;  /* extern GS_INFO *gsi; */
extern char *va_helpbuf;


static void highwire_ex(void);


VDI_Workstation vdi_dev;
VDI_GDOS vdi_gdos;

#ifdef GEM_MENU
OBJECT *about;
OBJECT *rpopup;
OBJECT *menutree;
#endif

static EVMULT_IN multi_in = {
	MU_MESAG|MU_BUTTON|MU_TIMER|MU_KEYBD /*|MU_M1 */,

	0x102, 3, 0,			/* mouses */

	MO_LEAVE, { -1,-1, 1, 1 },  /* M1 */
	0,        {  0, 0, 0, 0 },  /* M2 */
	1, 0                        /* Timer */
};


/*============================================================================*/
int
main (int argc, char **argv)
{
	WORD info, u;
	BOOL quit = FALSE;
	WORD AES_type;
	char def_address[] = "html\\highwire.htm";
	char *address; 

	if (argc > 1)
		address = argv[1];
	else
		address = def_address;

	if (V_Opnvwk (&vdi_dev) <= 0) {
		exit (EXIT_FAILURE);
	}
	atexit (highwire_ex);

	if (appl_init() < 0) {
		exit (EXIT_FAILURE);
	}

	/* Get GDOS type, NVDI version, etc. if possible.
	 * Problem:  If NVDI is in mode TOS bug compatibility, vq_vgdos() returns
	 *           -65536.  Therefore check NVDI version for this GDOS.
	 */
	if (vq_vgdos() == GDOS_FSM)
		vdi_gdos.vector       = TRUE;  /* SpeedoGDOS or NVDI � 3 */
	getcookie(0x4E564449L/*NVDI*/, &vdi_gdos.nvdi);
	if (vdi_gdos.nvdi) {
		vdi_gdos.nvdi_version = vdi_gdos.nvdi->nvdi_version;
		vdi_gdos.vector       = vdi_gdos.nvdi_version >= 0x300;
		vdi_gdos.unicode      = vdi_gdos.nvdi_version >= 0x400;
	}
#ifdef ONLY_UNICODE
	/* HighWire for Unicode TrueType fonts needs NVDI � 4.
	 */
	if (!vdi_gdos.unicode) {
		form_alert(1, "[3][HighWire for Unicode TrueType |fonts needs NVDI � 4!][ Exit ]");
		exit(EXIT_FAILURE);
	}
#else
	/* HighWire needs a Speedo fonts GDOS, that is SpeedoGDOS or NVDI � 3.
	 * Problem: If NVDI is in mode TOS bug compatibility, it returns -65536.
	 * In this case check if the cookie FSMC exists.
	 */
	if (!vdi_gdos.vector) {
		form_alert(1, "[3][HighWire needs SpeedoGDOS |or NVDI � 3!][ Exit ]");
		exit(EXIT_FAILURE);
	}
#endif

	/* Allocate all GLOBAL memory merged to one block.  The reason for using one
	 * block is, that MiNT with memory protection internally allocates 8 KiB.
	 * GLOBAL is needed for inter process communication under memory protection.
	 * 'Sysconf()' is from Frank Naumann in article
	 * <199904241138.a34259@l2.maus.de> in Maus.Computer.Atari.Programmieren.
     *
     * here is the old routine in case the new one is problematic
	 *	if (can_extended_mxalloc()) gslongname = (char *)Mxalloc(128 + HW_PATH_MAX, ALLOCMODE);
	 */
	if (Sysconf(-1) != EINVFN)
		gslongname = (char *)Mxalloc(32 + 16 + 2 * HW_PATH_MAX, ALLOCMODE);
	else
		gslongname = (char *)Malloc(32 + 16 + 2 * HW_PATH_MAX);
	if (!gslongname) {
		form_alert(1, "[3][HighWire got no GLOBAL memory! ][ Exit ]");
		exit(EXIT_FAILURE);
	}
	gsi        = gslongname + 32;
	gsanswer   = gsi + 16/*sizeof(GS_INFO)*/;
	va_helpbuf = gsanswer + HW_PATH_MAX;
	Init_AV_Protocol();

	if (vdi_dev.planes < 2) /* monochrome ? */
	{
		/* set the scroller widget colors for monochrome */
		slider_bkg = G_WHITE;
		slider_col = G_WHITE;

		/* turn ignore_colours on so that we can read the text
		 * on a monochrome display
		 */

		ignore_colours = TRUE;
	}

	/* identify the AES and issue appropriate initialization calls
	 */

	AES_type = identify_AES();

	/* If you know a documented length greater than 79 characters, add it. */
	if (AES_type == AES_nAES)
		aes_max_window_title_length = 127;

	/* BUG: This should fix single TOS but Geneva will probably still fail. */
	if (AES_type != AES_single)
		/* our name in the application menu */
		menu_register(gl_apid, "  HighWire HTML");

	(void)Pdomain(1);  /* we know about long file names */

#ifdef GEM_MENU
	if (!rsrc_load("highwire.rsc")) {
		form_alert(1, "[3][HighWire cannot load |highwire.rsc!][ Exit ]");
		exit(EXIT_FAILURE);
	}
	rsrc_gaddr(R_TREE, MENUTREE, &menutree);
	rsrc_gaddr(R_TREE, ABOUT, &about);
	rsrc_gaddr(R_TREE, RPOPUP, &rpopup);

	menu_bar(menutree, MENU_INSTALL);
#endif

	if (appl_xgetinfo(AES_MESSAGE, &info, &u, &u, &u) && (info & 8))
		/* we know about AP_TERM message */
		shel_write(SWM_NEWMSG, 1, 0, NULL, NULL);

	/* grab the screen colors for later use */
	save_colors();

	if (AES_type == AES_single)
		init_logging();

	/* init paths and load config */
	init_paths();

	vswr_mode (vdi_handle, MD_TRANS);

	font_init();

	if (!new_window(address))
		exit(EXIT_FAILURE);
	set_mouse_watch (MO_ENTER, &window_list->container->Area);

	while (!quit)
	{
		WORD       msg[8];
		EVMULT_OUT out;
		short      event = evnt_multi_fast (&multi_in, msg, &out);

		if (event & MU_M1) {
			check_mouse_position (out.emo_mouse.p_x, out.emo_mouse.p_y);
		}
		if (event & MU_MESAG) {
			quit = process_messages (msg, out.emo_mouse, out.emo_kmeta);
		}
		if (event & MU_BUTTON) {
			button_clicked (out.emo_mbutton, out.emo_mouse.p_x, out.emo_mouse.p_y);
		}
		if (event & MU_KEYBD) {
			key_pressed (out.emo_kreturn, out.emo_kmeta);
		}
		schedule (1);
	}

	/* Now the C library calls highwire_ex(). */
	return EXIT_SUCCESS;
}  /* main() */


/*============================================================================*/
void
set_mouse_watch (WORD leaveNenter, const GRECT * watch)
{
	if (!watch) {
		multi_in.emi_flags &= ~MU_M1;

	} else {
		multi_in.emi_flags  |= MU_M1;
		multi_in.emi_m1leave = leaveNenter;
		multi_in.emi_m1      = *watch;
	}
}

const GRECT * mouse_watch = &multi_in.emi_m1;


/*----------------------------------------------------------------------------*/
/* The HighWire exit code called by the C library.
 * Frees resources other than memory and files.
 */
static void
highwire_ex (void)
{
	if (gl_apid > 0) {
		WINDOWP win;

		for (win = window_list; win; win = win->next)
			wind_delete(win->handle);

		Exit_AV_Protocol();

	#ifdef GEM_MENU
		menu_bar(menutree, MENU_REMOVE);
		rsrc_free();
	#endif

		appl_exit ();
	}
	vst_unload_fonts (vdi_handle, 0);
	v_clsvwk         (vdi_handle);
}
