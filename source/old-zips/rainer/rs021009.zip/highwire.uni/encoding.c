/* @(#)highwire/encoding.c
 */
#include <stddef.h>

#include "defs.h"
#include "logging.h"
#include "token.h"
#include "scanner.h"


WCHAR * unicode_to_bics  (WCHAR uni, WCHAR * dst);
char  * unicode_to_atari (WCHAR uni, char  * dst);


/*----------------------------------------------------------------------------*/
#define BEG_UTF8 0x80

static WCHAR
utf8_to_unicode (const char ** psymbol)
{
	const char * s = *psymbol;
	long         ch = *(s++);
	BOOL         utf8ok;
	short        octets, mask, shift, i;

	/* Uses code from Kosta Kostis, utf8.c, 1.3, 2001-03-04. */
	/* calculate number of additional octets to be read,
	 * check validity of octets read
	 */
	octets = 0;
	utf8ok = TRUE;
	if ((ch >= 0xC0) && (ch <= 0xFD) && (s[0] >= 0x80) && (s[0] <= 0xBF)) {
		++octets;  /* 1 octet for U+0080..U+07FF */
		if (ch > 0xDF) {
			if ((s[1] >= 0x80) && (s[1] <= 0xBF)) {
				++octets;  /* 2 octets for U+0800..U+FFFF */
				if (ch > 0xEF) {
					if ((s[2] >= 0x80) && (s[2] <= 0xBF)) {
						++octets;  /* 3 octets for U+10000..U+1FFFFF */
						if (ch > 0xF7) {
							if ((s[3] >= 0x80) && (s[3] <= 0xBF)) {
								++octets;  /* 4 octets for U+200000..U+3FFFFFF */
								if (ch > 0xFB) {
									if ((s[4] >= 0x80) && (s[4] <= 0xBF)) {
										++octets;  /* 5 octets for U+4000000..U+7FFFFFFF */
									} else {
										utf8ok = FALSE;
									}
								}
							} else {
								utf8ok = FALSE;
							}
						}
					} else {
						utf8ok = FALSE;
					}
				}
			} else {
				utf8ok = FALSE;
			}
		}
	} else {
		utf8ok = FALSE;
	}

	/* nonshortest forms are illegal */
	if ((ch < 0xC2) || ((ch == 0xE0) && (s[0] < 0xA0))
	    || ((ch == 0xF0) && (s[0] < 0x90)) || ((ch == 0xF8) && (s[0] < 0x88))
	    || ((ch == 0xFC) && (s[0] < 0x84)))
		utf8ok = FALSE;

	if (utf8ok) {
		/* calculate value */
		mask = (1 << (6 - octets)) - 1;  /* 0x1F, 0x0F, 0x07, 0x03, 0x01 */
		shift = octets * 6;  /* 30, 24, 18, 12, 6 */
		ch = (ch & mask) << shift;
		for (i = 0, shift -= 6; i < octets ; ++i, shift -= 6)
			ch += (long)(*s++ & 0x3F) << shift;
	} else {
		ch = 0xFFFD;  /* U+FFFD REPLACEMENT CHARACTER */
		s += octets;
	}
	*psymbol = s;

	/* Surrogates Area not supported by NVDI */
	if (ch >= 0xD800 && ch <= 0xDFFF || ch >= 0xFFFE)
		ch = 0xFFFD;

#ifdef ONLY_UNICODE
	/* some characters to ignore */
	if (ch == 0x070F || ch >= 0x180B && ch <= 0x180E || ch >= 0x200B && ch <= 0x200D
	    || ch == 0x2060 || ch == 0x2061 || ch >= 0xFE00 && ch <= 0xFE0F || ch == 0xFEFF)
		ch = 0x0000;
#endif

	return ch;
}


/* Translation table for ISO/IEC 8859-2 Latin 2 characters to Unicode.
 */
static const WCHAR ISO8859_2_to_Unicode[] = {
	/*         .0     .1     .2     .3     .4     .5     .6     .7     .8     .9     .A     .B     .C     .D     .E     .F */
	/* A. */ 0x00A0,0x0104,0x02D8,0x0141,0x00A4,0x013D,0x015A,0x00A7,0x00A8,0x0160,0x015E,0x0164,0x0179,0x00AD,0x017D,0x017B,
	/* B. */ 0x00B0,0x0105,0x02DB,0x0142,0x00B4,0x013E,0x015B,0x02C7,0x00B8,0x0161,0x015F,0x0165,0x017A,0x02DD,0x017E,0x017C,
	/* C. */ 0x0154,0x00C1,0x00C2,0x0102,0x00C4,0x0139,0x0106,0x00C7,0x010C,0x00C9,0x0118,0x00CB,0x011A,0x00CD,0x00CE,0x010E,
	/* D. */ 0x0110,0x0143,0x0147,0x00D3,0x00D4,0x0150,0x00D6,0x00D7,0x0158,0x016E,0x00DA,0x0170,0x00DC,0x00DD,0x0162,0x00DF,
	/* E. */ 0x0155,0x00E1,0x00E2,0x0103,0x00E4,0x013A,0x0107,0x00E7,0x010D,0x00E9,0x0119,0x00EB,0x011B,0x00ED,0x00EE,0x010F,
	/* F. */ 0x0111,0x0144,0x0148,0x00F3,0x00F4,0x0151,0x00F6,0x00F7,0x0159,0x016F,0x00FA,0x0171,0x00FC,0x00FD,0x0163,0x02D9
};
#define BEG_ISO8859_2_to_Unicode 0xA0


/* Translation table for Apple Macintosh Roman characters to Unicode.
 */
static const WCHAR macintosh_to_Unicode[] = {
	/*         .0     .1     .2     .3     .4     .5     .6     .7     .8     .9     .A     .B     .C     .D     .E     .F */
	/* 8. */ 0x00C4,0x00C5,0x00C7,0x00C9,0x00D1,0x00D6,0x00DC,0x00E1,0x00E0,0x00E2,0x00E4,0x00E3,0x00E5,0x00E7,0x00E9,0x00E8,
	/* 9. */ 0x00EA,0x00EB,0x00ED,0x00EC,0x00EE,0x00EF,0x00F1,0x00F3,0x00F2,0x00F4,0x00F6,0x00F5,0x00FA,0x00F9,0x00FB,0x00FC,
	/* A. */ 0x2020,0x00B0,0x00A2,0x00A3,0x00A7,0x2022,0x00B6,0x00DF,0x00AE,0x00A9,0x2122,0x00B4,0x00A8,0x2260,0x00C6,0x00D8,
	/* B. */ 0x221E,0x00B1,0x2264,0x2265,0x00A5,0x00B5,0x2202,0x2211,0x220F,0x03C0,0x222B,0x00AA,0x00BA,0x03A9,0x00E6,0x00F8,
	/* C. */ 0x00BF,0x00A1,0x00AC,0x221A,0x0192,0x2248,0x2206,0x00AB,0x00BB,0x2026,0x00A0,0x00C0,0x00C3,0x00D5,0x0152,0x0153,
	/* D. */ 0x2013,0x2014,0x201C,0x201D,0x2018,0x2019,0x00F7,0x25CA,0x00FF,0x0178,0x2044,0x20AC,0x2039,0x203A,0xFB01,0xFB02,
	/* E. */ 0x2021,0x00B7,0x201A,0x201E,0x2030,0x00C2,0x00CA,0x00C1,0x00CB,0x00C8,0x00CD,0x00CE,0x00CF,0x00CC,0x00D3,0x00D4,
	/* F. */ 0xF8FF,0x00D2,0x00DA,0x00DB,0x00D9,0x0131,0x02C6,0x02DC,0x00AF,0x02D8,0x02D9,0x02DA,0x00B8,0x02DD,0x02DB,0x02C7
};
#define BEG_macintosh_to_Unicode 0x80


#ifdef ONLY_UNICODE
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
static WCHAR *
utf16_to_utf16(const WCHAR ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	/* Surrogates Area not supported by NVDI */
	if (ch >= 0xD800 && ch <= 0xDFFF || ch >= 0xFFFE)
		ch = 0xFFFD;

	/* some characters to ignore */
	if (ch == 0x070F || ch >= 0x180B && ch <= 0x180E || ch >= 0x200B && ch <= 0x200D
	    || ch == 0x2060 || ch == 0x2061 || ch >= 0xFE00 && ch <= 0xFE0F || ch == 0xFEFF)
		ch = 0x0000;

	if (ch >= 32 && ch != 127) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


/*----------------------------------------------------------------------------*/
#ifdef __PUREC__
/* Intel uint16_t <-> Motorola uint16_t */
WCHAR swap_int16(WCHAR d0) 0xE058; /* inline assembler: ror.w #8,D0 */
/* Intel uint32_t <-> Motorola uint32_t */
/*uint32_t rorw_8_d0(uint32_t d0) 0xE058;*/  /* inline assembler: ror.w #8,D0 */
/*uint32_t swap_d0(uint32_t d0) 0x4840;*/    /* inline assembler: swap  D0    */
/*#define swap_int32(d0) rorw_8_d0(swap_d0(rorw_8_d0(d0)))*/
#else
static WCHAR swap_int16(WCHAR ch)
{
	return (ch >> 8) || (ch << 8);
}
#endif

static WCHAR *
utf16le_to_utf16(const WCHAR ** src, WCHAR * dst)
{
	WCHAR ch = swap_int16(*((*src)++));

	/* Surrogates Area not supported by NVDI */
	if (ch >= 0xD800 && ch <= 0xDFFF || ch >= 0xFFFE)
		ch = 0xFFFD;

	/* some characters to ignore */
	if (ch == 0x070F || ch >= 0x180B && ch <= 0x180E || ch >= 0x200B && ch <= 0x200D
	    || ch == 0x2060 || ch == 0x2061 || ch >= 0xFE00 && ch <= 0xFE0F || ch == 0xFEFF)
		ch = 0x0000;

	if (ch >= 32 && ch != 127) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


static WCHAR *
utf8_to_utf16 (const char ** src, WCHAR * dst)
{
	WCHAR ch = **src;

	if (ch >= BEG_UTF8) {
		ch  = utf8_to_unicode (src);
	} else {
		(*src)++;
	}
	if (ch >= 32 && ch != 127) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


/* Translation table for windows-1252 characters to Unicode.
 * Codes not used in windows-1252 are mapped to U+FFFD.
 */
const WCHAR windows1252_to_Unicode[] = {
	/*         .0     .1     .2     .3     .4     .5     .6     .7     .8     .9     .A     .B     .C     .D     .E     .F */
	/* 8. */ 0x20AC,0xFFFD,0x201A,0x0192,0x201E,0x2026,0x2020,0x2021,0x02C6,0x2030,0x0160,0x2039,0x0152,0xFFFD,0x017D,0xFFFD,
	/* 9. */ 0xFFFD,0x2018,0x2019,0x201C,0x201D,0x2022,0x2013,0x2014,0x02DC,0x2122,0x0161,0x203A,0x0153,0xFFFD,0x017E,0x0178
};
#define BEG_windows1252_to_Unicode 0x80

static WCHAR *
windows1252_to_utf16 (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_windows1252_to_Unicode && ch <= 0x9F) {
		*(dst++) = windows1252_to_Unicode[ch - BEG_windows1252_to_Unicode];
	} else if (ch >= 32 && ch != 127) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


static WCHAR *
iso8859_2_to_utf16 (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_ISO8859_2_to_Unicode) {
		*(dst++) = ISO8859_2_to_Unicode[ch - BEG_ISO8859_2_to_Unicode];
	} else if (ch >= 32 && ch < 127) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


/*----------------------------------------------------------------------------*/
static WCHAR *
iso8859_15_to_utf16 (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if      (ch == 0xA4) ch = 0x20AC;
	else if (ch == 0xA6) ch = 0x0160;
	else if (ch == 0xA8) ch = 0x0161;
	else if (ch == 0xB4) ch = 0x017D;
	else if (ch == 0xB8) ch = 0x017E;
	else if (ch == 0xBC) ch = 0x0152;
	else if (ch == 0xBD) ch = 0x0153;
	else if (ch == 0xBE) ch = 0x0178;
	if (ch >= 32 && ch < 127 || ch >= 160) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


/*----------------------------------------------------------------------------*/
static WCHAR *
macintosh_to_utf16 (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_macintosh_to_Unicode) {
		ch = macintosh_to_Unicode[ch - BEG_macintosh_to_Unicode];
	}
	if (ch >= 32 && ch != 127) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


/* Translation table for Atari ST system font characters to Unicode.
 */
static const WCHAR Atari_to_Unicode[] = {
	/*         .0     .1     .2     .3     .4     .5     .6     .7     .8     .9     .A     .B     .C     .D     .E     .F */
	/* 7F */ 0x0394,
	/* 8. */ 0x00C7,0x00FC,0x00E9,0x00E2,0x00E4,0x00E0,0x00E5,0x00C7,0x00EA,0x00EB,0x00E8,0x00EF,0x00EE,0x00EC,0x00C4,0x00C5,
	/* 9. */ 0x00C9,0x00E6,0x00C6,0x00F4,0x00F6,0x00F2,0x00FB,0x00F9,0x00FF,0x00D6,0x00DC,0x00A2,0x00A3,0x00A5,0x00DF,0x0192,
	/* A. */ 0x00E1,0x00ED,0x00F3,0x00FA,0x00F1,0x00D1,0x00AA,0x00BA,0x00BF,0x2310,0x00AC,0x00BD,0x00BC,0x00A1,0x00AB,0x00BB,
	/* B. */ 0x00C3,0x00F5,0x00D8,0x00F8,0x0153,0x0152,0x00C0,0x00C3,0x00D5,0x00A8,0x00B4,0x2020,0x00B6,0x00A9,0x00AE,0x2122,
	/* C. */ 0x0133,0x0132,0x05D0,0x05D1,0x05D2,0x05D3,0x05D4,0x05D5,0x05D6,0x05D7,0x05D8,0x05D9,0x05DB,0x05DC,0x05DE,0x05E0,
	/* D. */ 0x05E1,0x05E2,0x05E4,0x05E6,0x05E7,0x05E8,0x05E9,0x05EA,0x05DF,0x05DA,0x05DD,0x05E3,0x05E5,0x00A7,0x2038,0x221E,
	/* E. */ 0x03B1,0x03B2,0x0393,0x03C0,0x03A3,0x03C3,0x00B5,0x03C4,0x03A6,0x0398,0x03A9,0x03B4,0x222E,0x03C6,0x2208,0x2229,
	/* F. */ 0x2261,0x00B1,0x2265,0x2264,0x2320,0x2321,0x00F7,0x2248,0x00B0,0x2022,0x00B7,0x221A,0x207F,0x00B2,0x00B3,0x00AF
};
#define BEG_Atari_to_Unicode 0x7F

static WCHAR *
atari_to_utf16 (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_Atari_to_Unicode) {
		*(dst++) = Atari_to_Unicode[ch - BEG_Atari_to_Unicode];
	} else if (ch >= 32) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


/* Translation table for Atari NVDI 4 Euro / Style Fonts characters to Unicode.
 */
static const WCHAR AtariNVDI_to_Unicode[] = {
	/*         .0     .1     .2     .3     .4     .5     .6     .7     .8     .9     .A     .B     .C     .D     .E     .F */
	/* 7F */ 0x0394,
	/* 8. */ 0x00C7,0x00FC,0x00E9,0x00E2,0x00E4,0x00E0,0x00E5,0x00C7,0x00EA,0x00EB,0x00E8,0x00EF,0x00EE,0x00EC,0x00C4,0x00C5,
	/* 9. */ 0x00C9,0x00E6,0x00C6,0x00F4,0x00F6,0x00F2,0x00FB,0x00F9,0x00FF,0x00D6,0x00DC,0x00A2,0x00A3,0x00A5,0x00DF,0x0192,
	/* A. */ 0x00E1,0x00ED,0x00F3,0x00FA,0x00F1,0x00D1,0x00AA,0x00BA,0x00BF,0x2310,0x00AC,0x00BD,0x00BC,0x00A1,0x00AB,0x00BB,
	/* B. */ 0x00C3,0x00F5,0x00D8,0x00F8,0x0153,0x0152,0x00C0,0x00C3,0x00D5,0x00A8,0x00B4,0x2020,0x00B6,0x00A9,0x00AE,0x2122,
	/* C. */ 0x00C2,0x00C1,0x00CA,0x00CB,0x00C8,0x00CE,0x00CF,0x00CC,0x00CD,0x00D4,0x00D2,0x00D3,0x00DB,0x00D9,0x00DA,0x201E,
	/* D. */ 0x201C,0x201D,0x201A,0x2018,0x2039,0x203A,0x2013,0x2014,0x2019,0x2191,0x2193,0x2192,0x2190,0x00A7,0x2030,0x221E,
	/* E. */ 0x03B1,0x03B2,0x0393,0x03C0,0x03A3,0x03C3,0x00B5,0x03C4,0x03A6,0x0398,0x03A9,0x03B4,0x20AC,0x03C6,0x2208,0x2229,
	/* F. */ 0x2261,0x00B1,0x2265,0x2264,0x2320,0x2321,0x00F7,0x2248,0x00B0,0x2022,0x00B7,0x221A,0x207F,0x00B2,0x00B3,0x00AF
};
#define BEG_AtariNVDI_to_Unicode 0x7F

static WCHAR *
atarinvdi_to_utf16 (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_AtariNVDI_to_Unicode) {
		*(dst++) = AtariNVDI_to_Unicode[ch - BEG_AtariNVDI_to_Unicode];
	} else if (ch >= 32) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}
#endif /* ONLY_UNICODE */


#ifdef ONLY_BICS
#include "uni_bics.h"  /* The only reason for this seperate file is to compile
                        * it with tools/uni_bics.c from that directory. */

static WCHAR *
windows1252_to_bics (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_windows1252_to_BICS) {
		*(dst++) = windows1252_to_BICS[ch - BEG_windows1252_to_BICS];
	} else if (ch == ' ') {
		*(dst++) = Space_Code;
	} else if (ch > 32 && ch < 127) {
		*(dst++) = ch - 32;
	} /* else ignore control characters */

	return dst;
}


/* Translation table for ISO/IEC 8859-2 Latin 2 characters to BICS.
 * Two characters are not in BICS: C0, E0. Replaced by the unaccentuated letters.
 */
static const WCHAR ISO8859_2_to_BICS[] = {
	/*       .0  .1  .2  .3  .4  .5  .6  .7  .8  .9  .A  .B  .C  .D  .E  .F */
	/* A. */ 560,171,144,170,278,175,410,110,135,412,415,364,368, 13,370,372,
	/* B. */ 339,177,247,174,129,232,409,139,141,411,414,416,367,183,369,371,
	/* C. */  50,261,257,374,255,395,376,148,378,251,172,245,243,241,237,478,
	/* D. */ 169,194,198,200,204,404,206,284,406,220,210,423,216,224,419,121,
	/* E. */  82,262,258,373,256,394,375,149,377,252,178,246,244,242,238,379,
	/* F. */ 173,193,197,199,203,403,205,285,405,219,209,422,215,223,418,181
};
#define BEG_ISO8859_2_to_BICS 0xA0

static WCHAR *
iso8859_2_to_bics (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_ISO8859_2_to_BICS) {
		*(dst++) = ISO8859_2_to_BICS[ch - BEG_ISO8859_2_to_BICS];
	} else if (ch == ' ') {
		*(dst++) = Space_Code;
	} else if (ch > 32 && ch < 127) {
		*(dst++) = ch - 32;
	} /* else ignore control characters */

	return dst;
}


/* Translation table for Atari characters to BICS.
 * Character code 559 replaces anything I couldn't easily map.
 * baldrick March 13, 2002
 */
static const WCHAR Atari_to_BICS[] = {
	/*       .0  .1  .2  .3  .4  .5  .6  .7  .8  .9  .A  .B  .C  .D  .E  .F */
	/* 7F */ 314,
	/* 8. */ 148,215,252,258,256,260,117,149,248,246,250,236,238,240,255,113,
	/* 9. */ 251,118,114,203,205,201,213,211,221,206,216, 98, 97,274,121, 99,
	/* A. */ 262,242,199,209,195,196,538,544,127,310,309,153,151,128,125,126,
	/* B. */ 254,207,115,119,120,116,259,253,208,135,129,108,279,332,333,334,
	/* C. */ 275,276,559,559,559,559,559,559,559,559,559,559,559,559,559,559,
	/* D. */ 559,559,559,559,559,559,559,559,559,559,559,559,559,110, 62,303,
	/* E. */ 319,320,313,326,316,327,325,328,317,324,318,321,428,329,298,299,
	/* F. */ 287,286,290,291,300,301,285,289,339,342,102,302,543,160,161,230
};
#define BEG_Atari_to_BICS 0x7F

static WCHAR *
atari_to_bics (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_Atari_to_BICS) {
		*(dst++) = Atari_to_BICS[ch - BEG_Atari_to_BICS];
	} else if (ch == ' ') {
		*(dst++) = Space_Code;
	} else if (ch > 32) {
		*(dst++) = ch - 32;
	} /* else ignore control characters */

	return dst;
}


/* Translation table for Atari NVDI 4 Euro / Style Fonts characters to BICS.
 */
static const WCHAR AtariNVDI_to_BICS[] = {
	/*       .0  .1  .2  .3  .4  .5  .6  .7  .8  .9  .A  .B  .C  .D  .E  .F */
	/* 7F */ 314,
	/* 8. */ 148,215,252,258,256,260,117,149,248,246,250,236,238,240,255,113,
	/* 9. */ 251,118,114,203,205,201,213,211,221,206,216, 98, 97,274,121, 99,
	/* A. */ 262,242,199,209,195,196,538,544,127,310,309,153,151,128,125,126,
	/* B. */ 254,207,115,119,120,116,259,253,208,135,129,108,279,332,333,334,
	/* C. */ 257,261,247,245,249,237,235,239,241,204,202,200,214,212,210,107,
	/* D. */ 104,105,106,103,123,124,111,112,  7,295,292,293,294,110,100,303,
	/* E. */ 319,320,313,326,316,327,325,328,317,324,318,321,298,329,322,299,
	/* F. */ 287,286,290,291,300,301,285,289,339,342,102,302,543,160,161,230
};
#define BEG_AtariNVDI_to_BICS 0x7F

static WCHAR *
atarinvdi_to_bics (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_AtariNVDI_to_BICS) {
		*(dst++) = AtariNVDI_to_BICS[ch - BEG_AtariNVDI_to_BICS];
	} else if (ch == ' ') {
		*(dst++) = Space_Code;
	} else if (ch > 32) {
		*(dst++) = ch - 32;
	} /* else ignore control characters */

	return dst;
}


/* Translation table for Unicode characters to BICS is in uni_bics.h.
 */
WCHAR *
unicode_to_bics (WCHAR uni, WCHAR * dst)
{
	if (uni < 0x0100u) {
		const char * src = ((char*)&uni) +1;
		dst = windows1252_to_bics (&src, dst);

	} else {
		const WCHAR * arr = Unicode_to_BICS;

		while (uni != *(arr++)) {
			while (*(arr++));
			if (*arr == 0xFFFDu) { /* value wasn't found in table */
				arr++;              /* U+FFFD REPLACEMENT CHARACTER */
				break;
			}
		}
		while (*arr) {
			*(dst++) = *(arr++);
		}
	}
	return dst;
}


/*----------------------------------------------------------------------------*/
static WCHAR *
utf8_to_bics (const char ** src, WCHAR * dst)
{
	WCHAR ch = **src;

	if (ch >= BEG_UTF8) {
		ch  = utf8_to_unicode (src);
		dst = unicode_to_bics (ch, dst);
	} else {
		if (ch == ' ') {
			*(dst++) = Space_Code;
		} else if (ch > 32 && ch < 127) {
			*(dst++) = ch - 32;
		} /* else ignore control characters */
		(*src)++;
	}

	return dst;
}


/*----------------------------------------------------------------------------*/
static WCHAR *
utf16_to_bics(const WCHAR ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	/* Surrogates Area not supported by NVDI */
	if (ch >= 0xD800 && ch <= 0xDFFF || ch >= 0xFFFE)
		ch = 0xFFFD;

	/* some characters to ignore */
	if (ch == 0x070F || ch >= 0x180B && ch <= 0x180E || ch >= 0x200B && ch <= 0x200D
	    || ch == 0x2060 || ch == 0x2061 || ch >= 0xFE00 && ch <= 0xFE0F || ch == 0xFEFF)
		ch = 0x0000;

	if (ch >= 32 && ch < 127 || ch >= 160) {
		dst = unicode_to_bics (ch, dst);
	} /* else ignore control characters */

	return dst;
}


/*----------------------------------------------------------------------------*/
#ifdef __PUREC__
/* Intel uint16_t <-> Motorola uint16_t */
WCHAR swap_int16(WCHAR d0) 0xE058; /* inline assembler: ror.w #8,D0 */
#else
static WCHAR swap_int16(WCHAR ch)
{
	return (ch >> 8) || (ch << 8);
}
#endif

static WCHAR *
utf16le_to_bics(const WCHAR ** src, WCHAR * dst)
{
	WCHAR ch = swap_int16(*((*src)++));

	/* Surrogates Area not supported by NVDI */
	if (ch >= 0xD800 && ch <= 0xDFFF || ch >= 0xFFFE)
		ch = 0xFFFD;

	/* some characters to ignore */
	if (ch == 0x070F || ch >= 0x180B && ch <= 0x180E || ch >= 0x200B && ch <= 0x200D
	    || ch == 0x2060 || ch == 0x2061 || ch >= 0xFE00 && ch <= 0xFE0F || ch == 0xFEFF)
		ch = 0x0000;

	if (ch >= 32 && ch < 127 || ch >= 160) {
		dst = unicode_to_bics (ch, dst);
	} /* else ignore control characters */

	return dst;
}


/*----------------------------------------------------------------------------*/
static WCHAR *
iso8859_15_to_bics (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if      (ch == 0xA4) ch = 0x20AC;
	else if (ch == 0xA6) ch = 0x0160;
	else if (ch == 0xA8) ch = 0x0161;
	else if (ch == 0xB4) ch = 0x017D;
	else if (ch == 0xB8) ch = 0x017E;
	else if (ch == 0xBC) ch = 0x0152;
	else if (ch == 0xBD) ch = 0x0153;
	else if (ch == 0xBE) ch = 0x0178;
	if (ch >= 32 && ch < 127 || ch >= 160) {
		dst = unicode_to_bics (ch, dst);
	} /* else ignore control characters */
	return dst;
}


/*----------------------------------------------------------------------------*/
static WCHAR *
macintosh_to_bics (const char ** src, WCHAR * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_macintosh_to_Unicode) {
		ch = macintosh_to_Unicode[ch - BEG_macintosh_to_Unicode];
	}
	return unicode_to_bics (ch, dst);
}
#endif /* ONLY_BICS */


/*==============================================================================
 * Select encoder function according to ENCODING to read one (possible
 * multibyte) character from 'src' and write 0 to 4 characters of 16 bit width
 * to 'dst'.  The 'src' content will be set behind the read character and the
 * address behind the written character.
 */
ENCODER_W
encoder_word (ENCODING encoding)
{
	switch (encoding) {
	#if defined(ONLY_UNICODE)
		case ENCODING_WINDOWS1252: return windows1252_to_utf16;
		case ENCODING_ISO8859_2:   return iso8859_2_to_utf16;
		case ENCODING_ISO8859_15:  return iso8859_15_to_utf16;
		case ENCODING_UTF8:        return utf8_to_utf16;
		case ENCODING_UTF16:       return utf16_to_utf16;
		case ENCODING_UTF16LE:     return utf16le_to_utf16;
		case ENCODING_MACINTOSH:   return macintosh_to_utf16;
		case ENCODING_ATARIST:     return atari_to_utf16;
		case ENCODING_ATARINVDI:   return atarinvdi_to_utf16;
		default: /* error */ ;
			errprintf ("encoder_word(): invalid %i\n", encoding);
			return windows1252_to_utf16;
	#elif defined(ONLY_BICS)
		case ENCODING_WINDOWS1252: return windows1252_to_bics;
		case ENCODING_ISO8859_2:   return iso8859_2_to_bics;
		case ENCODING_ISO8859_15:  return iso8859_15_to_bics;
		case ENCODING_UTF8:        return utf8_to_bics;
		case ENCODING_UTF16:       return utf16_to_bics;
		case ENCODING_UTF16LE:     return utf16le_to_bics;
		case ENCODING_MACINTOSH:   return macintosh_to_bics;
		case ENCODING_ATARIST:     return atari_to_bics;
		case ENCODING_ATARINVDI:   return atarinvdi_to_bics;
		default: /* error */ ;
			errprintf ("encoder_word(): invalid %i\n", encoding);
			return windows1252_to_bics;
	#endif
	}
}


/* Translation table for Unicode characters to Atari system font.
 * With Style-Fonts and Atari standard TORG 105, U+20AC EURO SIGN is 236.  With
 * Milan TOS it is 222.  Here I used the "element of" symbol.
 * Rainer Seitel, 2002-03
 * Format: {Unicode, zero to five Atari system font characters, 0}, 0
 * *3.2* before: new in Unicode 3.2
 *               http://www.unicode.org/unicode/reports/tr28/
 *               http://www.unicode.org/charts/PDF/U32-????.pdf
 * *HW* before: HighWire private use character
 * *�* before: not the correct glyph, but recognizable
 */
static const WCHAR Unicode_to_Atari[] = {
/*�*/0x80,'�',0, 0x82,'\'',0, 0x83,'�',0, 0x84,'"',0, 0x85,'.','.','.',0, 
0x86,'�',0, /*�*/0x87,'�',0, 0x88,'^',0, 0x89,'�','/','o','o',0, 
/*�*/0x8A,'S',0, /*�*/0x8B,'<',0, 0x8C,'�',0, /*�*/0x8E,'Z',0, 0x91,'\'',0, 
0x92,'\'',0, 0x93,'"',0, 0x94,'"',0, 0x95,'�',0, 0x96,'-',0, 0x97,'-','-',0, 
/*�*/0x98,'~',0, 0x99,'�',0, /*�*/0x9A,'s',0, /*�*/0x9B,'>',0, 0x9C,'�',0, 
/*�*/0x9E,'z',0, /*�*/0x9F,'Y',0,
0x00A0,' ',0, 0x00A1,'�',0, 0x00A2,'�',0, 0x00A3,'�',0, 0x00A5,'�',0, 
/*�*/0x00A6,17,0, 0x00A7,'�',0, 0x00A8,'�',0, 0x00A9,'�',0, 0x00AA,'�',0, 
0x00AB,'�',0, 0x00AC,'�',0, 0x00AD,'-',0, 0x00AE,'�',0, 0x00AF,'�',0, 
0x00B0,'�',0, 0x00B1,'�',0, 0x00B2,'�',0, 0x00B3,'�',0, 0x00B4,'�',0, 
0x00B5,'�',0, 0x00B6,'�',0, 0x00B7,'�',0, /*�*/0x00B9,'\'',0, 0x00BA,'�',0, 
0x00BB,'�',0, 0x00BC,'�',0, 0x00BD,'�',0, 0x00BE,' ','3','/','4',0, 
0x00BF,'�',0, 0x00C0,'�',0, /*�*/0x00C1,'A',0, /*�*/0x00C2,'A',0, 0x00C3,'�',0, 
0x00C4,'�',0, 0x00C5,'�',0, 0x00C6,'�',0, 0x00C7,'�',0, /*�*/0x00C8,'E',0, 
0x00C9,'�',0, /*�*/0x00CA,'E',0, /*�*/0x00CB,'E',0, /*�*/0x00CC,'I',0, 
/*�*/0x00CD,'I',0, /*�*/0x00CE,'I',0, /*�*/0x00CF,'I',0, /*�*/0x00D0,'D',0, 
0x00D1,'�',0, /*�*/0x00D2,'O',0, /*�*/0x00D3,'O',0, /*�*/0x00D4,'O',0, 
0x00D5,'�',0, 0x00D6,'�',0, /*�*/0x00D7,'x',0, 0x00D8,'�',0, /*�*/0x00D9,'U',0, 
/*�*/0x00DA,'U',0, /*�*/0x00DB,'U',0, 0x00DC,'�',0, /*�*/0x00DD,'Y',0, 
0x00DF,'�',0, 0x00E0,'�',0, 0x00E1,'�',0, 0x00E2,'�',0, 0x00E3,'�',0, 
0x00E4,'�',0, 0x00E5,'�',0, 0x00E6,'�',0, 0x00E7,'�',0, 0x00E8,'�',0, 
0x00E9,'�',0, 0x00EA,'�',0, 0x00EB,'�',0, 0x00EC,'�',0, 0x00ED,'�',0, 
0x00EE,'�',0, 0x00EF,'�',0, /*�*/0x00F0,'�',0, 0x00F1,'�',0, 0x00F2,'�',0, 
0x00F3,'�',0, 0x00F4,'�',0, 0x00F5,'�',0, 0x00F6,'�',0, 0x00F7,'�',0, 
0x00F8,'�',0, 0x00F9,'�',0, 0x00FA,'�',0, 0x00FB,'�',0, 0x00FC,'�',0, 
/*�*/0x00FD,'y',0, 0x00FF,'�',0, /*�*/0x0108,'C','h',0, /*�*/0x0109,'c','h',0, 
0x010C,'C',0, 0x010D,'c',0, 0x010F,'d','\'',0, /*�*/0x011C,'G','h',0, 
/*�*/0x011D,'g','h',0, /*�*/0x0124,'H','h',0, /*�*/0x0125,'h','h',0, 
0x0132,'�',0, 0x0133,'�',0, /*�*/0x0134,'J','h',0, /*�*/0x0135,'j','h',0, 
0x013E,'l','\'',0, 0x013F,'L','�',0, 0x0140,'l','�',0, 0x0149,'\'','n',0, 
0x0152,'�',0, 0x0153,'�',0, /*�*/0x015C,'S','h',0, /*�*/0x015D,'s','h',0, 
0x0160,'S',0, 0x0161,'s',0, /*�*/0x016D,'u',0, 0x0178,'Y',0, 0x017D,'Z',0, 
0x017E,'z',0, /*�*/0x017F,'�',0, 0x01C0,'|',0, 0x01C1,'|','|',0, 0x01C3,'!',0, 
0x01C7,'L','J',0, 0x01C8,'L','j',0, 0x01C9,'l','j',0, 0x01CA,'N','J',0, 
0x01CB,'N','j',0, 0x01CC,'n','j',0, 0x01DD,26,0, 0x0259,26,0, 0x02A3,'d','z',0, 
0x02A6,'t','s',0, 0x02AA,'l','s',0, 0x02AB,'l','z',0, 0x02B9,'\'',0, 
0x02BA,'"',0, 0x02BC,'\'',0, 0x02C2,'<',0, 0x02C3,'>',0, 0x02C6,'^',0, 
0x02C8,'\'',0, 0x02C9,'�',0, 0x02CA,'�',0, 0x02CB,'`',0, 0x02CD,'_',0, 
0x02D0,':',0, 0x02D1,'�',0, 0x02D6,'+',0, 0x02D7,'-',0, 0x02DA,'�',0, 
0x02DC,'~',0, 0x02EE,'"',0, /*3.2*/0x034F,0, 0x0374,'�',0, 0x037E,';',0, 
0x0391,'A',0, 0x0392,'B',0, 0x0393,'�',0, 0x0394,127,0, 0x0395,'E',0, 
0x0396,'Z',0, 0x0397,'H',0, 0x0398,'�',0, 0x0399,'I',0, 0x039A,'K',0, 
0x039C,'M',0, 0x039D,'N',0, 0x039E,'�',0, 0x039F,'O',0, 0x03A0,'�',0, 
0x03A1,'P',0, 0x03A3,'�',0, 0x03A4,'T',0, 0x03A5,'Y',0, 0x03A6,'�',0, 
0x03A7,'X',0, 0x03A9,'�',0, 0x03B1,'�',0, 0x03B2,'�',0, 0x03B4,'�',0, 
0x03B5,'�',0, 0x03BC,'�',0, 0x03BD,'v',0, 0x03BF,'o',0, 0x03C0,'�',0, 
0x03C1,'p',0, 0x03C2,'s',0, 0x03C3,'�',0, 0x03C4,'�',0, 0x03C6,'�',0, 
0x03D5,'�',0, 0x03DC,'F',0, 0x03F2,'c',0, 0x03F3,'j',0, 0x03F4,'�',0, 
0x03F5,'�',0, 0x05BE,'�',0, 0x05C0,'|',0, 0x05C3,':',0, 0x05D0,'�',0, 
0x05D1,'�',0, 0x05D2,'�',0, 0x05D3,'�',0, 0x05D4,'�',0, 0x05D5,'�',0, 
0x05D6,'�',0, 0x05D7,'�',0, 0x05D8,'�',0, 0x05D9,'�',0, 0x05DA,'�',0, 
0x05DB,'�',0, 0x05DC,'�',0, 0x05DD,'�',0, 0x05DE,'�',0, 0x05DF,'�',0, 
0x05E0,'�',0, 0x05E1,'�',0, 0x05E2,'�',0, 0x05E3,'�',0, 0x05E4,'�',0, 
0x05E5,'�',0, 0x05E6,'�',0, 0x05E7,'�',0, 0x05E8,'�',0, 0x05E9,'�',0, 
0x05EA,'�',0, 0x05F0,'�','�',0, 0x05F1,'�','�',0, 0x05F2,'�','�',0, 
0x05F3,'\'',0, 0x05F4,'"',0, 0x0660,'0',0, 0x0661,'1',0, 0x0662,'2',0, 
0x0663,'3',0, 0x0664,'4',0, 0x0665,'5',0, 0x0666,'6',0, 0x0667,'7',0, 
0x0668,'8',0, 0x0669,'9',0, 0x066A,'%',0, 0x066B,',',0, 0x066C,'\'',0, 
0x066D,'*',0, 0x070F,0, /*�*/0x09F3,'I','N','R',0, /*�*/0x0E3F,'T','H','B',0, 
0x10FB,':','�',0, /*�*/0x17DB,'K','H','R',0, 0x180B,0, 0x180C,0, 0x180D,0, 
0x180E,0,
0x2000,' ',0, 0x2001,' ',' ',0, 0x2002,' ',0, 0x2003,' ',' ',0, 0x2004,' ',0, 
0x2005,' ',0, 0x2006,' ',0, 0x2007,' ',0, 0x2008,' ',0, 0x2009,' ',0, 0x200A,0, 
0x200B,0, 0x200C,0, 0x200D,0, 0x2010,'-',0, 0x2011,'-',0, 0x2012,'-',0, 
0x2013,'-',0, 0x2014,'-','-',0, 0x2015,'-','-',0, 0x2016,'|','|',0, 
0x2018,'\'',0, 0x2019,'\'',0, 0x201A,'\'',0, 0x201B,'\'',0, 0x201C,'"',0, 
0x201D,'"',0, 0x201E,'"',0, 0x201F,'"',0, 0x2020,'�',0, 0x2021,'�',0, 
0x2022,'�',0, /*�*/0x2023,'�',0, 0x2024,'.',0, 0x2025,'.','.',0, 
0x2026,'.','.','.',0, 0x2027,'�',0, 0x202F,' ',0, 
/*�*/0x2030,'�','/','o','o',0, 0x2032,'\'',0, 0x2333,'"',0, 0x2039,'<',0, 
0x203A,'>',0, 0x203C,'!','!',0, 0x203E,'�',0, 0x2043,'-',0, 0x2044,'/',0, 
/*3.2*/0x2047,'?','?',0, /*�*/0x204A,'7',0, 0x204C,'�',0, 0x204D,'�',0, 
/*3.2*/0x204E,'*',0, /*3.2*/0x2052,'%',0, /*3.2*/0x2057,'"','"',0, 
/*3.2*/0x205F,' ',0, /*3.2*/0x2060,0, /*3.2*/0x2061,0, /*3.2*/0x2062,' ',0, 
/*3.2*/0x2063,' ',0, 0x207F,'�',0, /*�*/0x20A4,'�',0, 0x20A7,'P','t','s',0, 
0x20A8,'R','s',0, /*�*/0x20AA,'I','L','S',0, /*�*/0x20AC,'�',0, 
/*3.2�*/0x20B0,'P','f',0, 0x2100,'a','/','c',0, 0x2101,'a','/','s',0, 
0x2103,'�','C',0, 0x2105,'c','/','o',0, 0x2106,'c','/','u',0, 0x2109,'�','F',0, 
0x2113,'l',0, /*�*/0x2114,'l','b',0, 0x2116,'N','�',0, 0x2122,'�',0, 
0x2126,'�',0, /*�*/0x2127,'S',0, 0x212A,'K',0, 0x212B,'�',0, /*�*/0x212E,'e',0, 
/*�*/0x2133,'M',0, 0x2135,'�',0, 0x2136,'�',0, 0x2137,'�',0, 0x2138,'�',0, 
0x2139,'i',0, 0x2180,'�',0, 0x2190,4,0, 0x2191,1,0, 0x2192,3,0, 0x2193,2,0, 
0x21E6,4,0, 0x21E7,1,0, 0x21E8,3,0, 0x21E9,2,0, 0x2205,'�',0, 0x2206,127,0, 
0x2208,'�',0, /*�*/0x220A,'�',0, 0x2211,'�',0, 0x2212,'-',0, 0x2215,'/',0, 
0x2216,'\\',0, 0x2217,'*',0, 0x2219,'�',0, 0x221A,'�',0, 0x221D,'�',0, 
0x221E,'�',0, 0x2223,'|',0, 0x2225,'|','|',0, 0x2227,'�',0, 0x2229,'�',0, 
0x222A,'U',0, 0x222E,'�',0, 0x2236,':',0, 0x223C,'~',0, /*�*/0x223F,'~',0, 
0x2248,'�',0, 0x2261,'�',0, 0x2264,'�',0, 0x2265,'�',0, 
/*�*/0x2295,'(','+',')',0, /*�*/0x2297,'(','x',')',0, 
/*�*/0x2299,'(','�',')',0, 0x22BA,'T',0, 0x22C0,'�',0, 0x22C2,'�',0, 
0x22C3,'U',0, 0x22C5,'�',0, 0x22EF,'�','�','.',0, /*3.2*/0x22FF,'E',0, 
0x2310,'�',0, 0x2314,8,0, 0x231A,9,0, 0x2320,'�',0, 0x2321,'�',0, 0x2329,'<',0, 
0x232A,'>',0, /*3.2*/0x23B7,'�',0, 0x240C,12,0, 0x240D,13,0, 0x241B,27,0, 
0x266A,11,0, /*3.2�*/0x2680,'[','�',']',0, /*3.2�*/0x2681,'[','�','�',']',0, 
/*3.2�*/0x2682,'[','�','�','�',']',0, /*3.2�*/0x2683,'[',':',':',']',0, 
/*3.2�*/0x2684,'[',':','�',':',']',0, /*3.2�*/0x2685,'[',':',':',':',']',0, 
0x2713,8,0, /*�*/0x2714,8,0, /*3.2�*/0x27E8,'<',0, /*3.2�*/0x27E9,'>',0, 
/*3.2*/0x29F2,'�',0, /*3.2*/0x2A0D,'�',0, /*3.2�*/0x2A2F,'x',0,
0x3000,' ',' ',0, /*HW*/0xF8F0,'j',0, 0xFB00,'f','f',0, 0xFB01,'f','i',0, 
0xFB02,'f','l',0, 0xFB03,'f','f','i',0, 0xFB04,'f','f','l',0, 
/*�*/0xFB05,'�','t',0, 0xFB06,'s','t',0, 0xFB20,'�',0, 0xFB21,'�',0, 
0xFB22,'�',0, 0xFB23,'�',0, 0xFB24,'�',0, 0xFB25,'�',0, 0xFB26,'�',0, 
0xFB27,'�',0, 0xFB28,'�',0, /*�*/0xFB29,'+',0, /*�*/0xFB4F,'�','�',0, 
/*�*/0xFD3E,'(',0, /*�*/0xFD3F,')',0, /*3.2*/0xFE00,0, /*3.2*/0xFE01,0, 
/*3.2*/0xFE02,0, /*3.2*/0xFE03,0, /*3.2*/0xFE04,0, /*3.2*/0xFE05,0, 
/*3.2*/0xFE06,0, /*3.2*/0xFE07,0, /*3.2*/0xFE08,0, /*3.2*/0xFE09,0, 
/*3.2*/0xFE0A,0, /*3.2*/0xFE0B,0, /*3.2*/0xFE0C,0, /*3.2*/0xFE0D,0, 
/*3.2*/0xFE0E,0, /*3.2*/0xFE0F,0, 0xFEFF,0, 
/*This_MUST_be_the_last_entry!*/0xFFFD,6,0};

char *
unicode_to_atari (WCHAR uni, char * dst)
{
	if (uni < 0x0080u) {
		*(dst++) = (char)uni;

	} else {
		const WCHAR * arr = Unicode_to_Atari;
		while (uni != *(arr++)) {
			while (*(arr++));
			if (*arr == 0xFFFDu) { /* value wasn't found in table */
				arr++;              /* U+FFFD REPLACEMENT CHARACTER */
				break;
			}
		}
		while (*arr) {
			*(dst++) = (char)*(arr++);
		}
	}
	return dst;
}


/*----------------------------------------------------------------------------*/
static char *
windows1252_to_atari (const char ** src, char * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= 128) {
		dst = unicode_to_atari (ch, dst);
	} else {
		if (ch >= 32 && ch < 127) {
			*(dst++) = ch;
		} /* else ignore control characters */
	}
	return dst;
}


/*----------------------------------------------------------------------------*/
static char *
iso8859_2_to_atari (const char ** src, char * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_ISO8859_2_to_Unicode) {
		ch = ISO8859_2_to_Unicode[ch - BEG_ISO8859_2_to_Unicode];
	}
	return unicode_to_atari (ch, dst);
}


/*----------------------------------------------------------------------------*/
static char *
iso8859_15_to_atari (const char ** src, char * dst)
{
	WCHAR ch = *((*src)++);

	if      (ch == 0xA4) ch = 0x20AC;
	else if (ch == 0xA6) ch = 0x0160;
	else if (ch == 0xA8) ch = 0x0161;
	else if (ch == 0xB4) ch = 0x017D;
	else if (ch == 0xB8) ch = 0x017E;
	else if (ch == 0xBC) ch = 0x0152;
	else if (ch == 0xBD) ch = 0x0153;
	else if (ch == 0xBE) ch = 0x0178;
	if (ch >= 32 && ch < 127 || ch >= 160) {
		dst = unicode_to_atari (ch, dst);
	} /* else ignore control characters */

	return dst;
}


/*----------------------------------------------------------------------------*/
static char *
utf8_to_atari (const char ** src, char * dst)
{
	WCHAR ch = **src;

	if (ch >= BEG_UTF8) {
		ch  = utf8_to_unicode (src);
		dst = unicode_to_atari (ch, dst);
	} else {
		if (ch >= 32 && ch < 127) {
			*(dst++) = ch;
		} /* else ignore control characters */
		(*src)++;
	}
	return dst;
}


/*----------------------------------------------------------------------------*/
static char *
macintosh_to_atari (const char ** src, char * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_macintosh_to_Unicode) {
		ch = macintosh_to_Unicode[ch - BEG_macintosh_to_Unicode];
	}
	return unicode_to_atari (ch, dst);
}


/*----------------------------------------------------------------------------*/
static char *
atari_to_atari (const char ** src, char * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= 32) {
		*(dst++) = ch;
	} /* else ignore control characters */

	return dst;
}


/* Translation table for Atari NVDI 4 Euro / Style Fonts characters to Atari.
 */
static const WORD AtariNVDI_to_Atari[] = {
	/*       .0  .1  .2   .3   .4  .5  .6  .7  .8   .9  .A  .B  .C  .D  .E  .F*/
	/* C. */ 'A','A','E', 'E', 'E','I','I','I','I', 'O','O','O','U','U','U','"',
	/* D. */ '"','"','\'','\'','<','>','-','-','\'','','','','','�','�','�',
	/* E. */ '�','�','�', '�', '�','�','�','�','�', '�','�','�','�'
};
#define BEG_AtariNVDI_to_Atari 0xC0

static char *
atarinvdi_to_atari (const char ** src, char * dst)
{
	WCHAR ch = *((*src)++);

	if (ch >= BEG_AtariNVDI_to_Atari && ch <= 0xEC)
		ch = AtariNVDI_to_Atari[ch - BEG_AtariNVDI_to_Atari];
	if (ch >= 32) {
		*(dst++) = ch;
		if (ch == 0xDE) {
			*(dst++) = '/';
			*(dst++) = 'o';
			*(dst++) = 'o';
		}
	} /* else ignore control characters */

	return dst;
}


/*==============================================================================
 * Select encoder function according to ENCODING to read one (possible
 * multibyte) character from 'src' and write 0 to 4 characters of 8 bit width
 * to 'dst'.  The 'src' content will be set behind the read character and the
 * address behind the written character.
 */
ENCODER_C
encoder_char (ENCODING encoding)
{
	switch (encoding) {
		case ENCODING_WINDOWS1252: return windows1252_to_atari;
		case ENCODING_ISO8859_2:   return iso8859_2_to_atari;
		case ENCODING_ISO8859_15:  return iso8859_15_to_atari;
		case ENCODING_UTF8:        return utf8_to_atari;
		case ENCODING_MACINTOSH:   return macintosh_to_atari;
		case ENCODING_ATARIST:     return atari_to_atari;
		case ENCODING_ATARINVDI:   return atarinvdi_to_atari;
		default: /* error */ ;
	}
	errprintf ("encoder_char(): invalid %i\n", encoding);
	return windows1252_to_atari;
}
