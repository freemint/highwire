/* @(#)highwire/global.h
 */
#include "defs.h"


/* To compile a version with a GEM menu bar uncomment the following line.
 */

/*#define GEM_MENU 1*/


#ifdef GEM_MENU
#include "highwire.h"
#endif


/* for printf for testing */
#include <stdio.h>


/* ******** Variable Definitions ******************* */

/* Globals */
extern VDI_Workstation vdi_dev;
extern BOOL ignore_colours;
#ifdef _GEMLIB_X_H_
extern VDI_GDOS vdi_gdos;
#endif

extern WORD aes_max_window_title_length;

extern WORD number_of_frames_left_to_load;

/* To be in-program settings */
extern WORD fonts[4][2][2];
extern WORD font_size;
extern WORD link_colour;
extern WORD highlighted_link_colour;
extern WORD text_colour;

extern WORD page_margin;

extern WORD slider_bkg;
extern WORD slider_col;

extern BOOL alternative_text_is_on;

extern char	*va_helpbuf;  /* [HW_PATH_MAX] GLOBAL memory buffer for AV */

extern char help_file[HW_PATH_MAX];


/* ****************** Function Defs ******************************** */

/* in Nice_VDI.c */

WORD V_Opnvwk(VDI_Workstation *);
WORD V_Opnwk(WORD, VDI_Workstation *);

/* in font.c */
void font_init(void);
BOOL font_get_id_by_face(char *face, WORD font[2][2]);
void font_reinit(void);

/* in HighWire.c */

void set_mouse_watch (WORD leaveNenter, const GRECT * watch);

/* in Mouse_R.c */

void button_clicked (WORD , WORD , WORD );
void check_mouse_position (WORD , WORD );

/* in AEI.c */

void rpopup_open (WORD, WORD);
void update_menu (void);
BOOL process_messages (const WORD msg[8], PXY, UWORD state);
void    menu_open     (BOOL fsel);
void    menu_reload   (ENCODING);
void    menu_info     (void);
void    menu_source(FRAME frame);
#define menu_quit()   exit(EXIT_SUCCESS)
void    menu_fontsize (char plus_minus);
void    menu_logging(void);
void    menu_alt_text(void);
void    menu_help(void);

/* in Redraws.c */

void frame_draw    (FRAME, const GRECT *, void * highlight);
void draw_hbar     (FRAME, BOOL complete);
void draw_vbar     (FRAME, BOOL complete);
void draw_contents (CONTENT *, long x, long y, const GRECT *, void * highlight);
void draw_border   (const GRECT *, short lu, short rd, short width);

/* in Config.c */

WORD read_config(char *fn);

/* in Frame.c */

FRAME new_frame    (LOCATION, MIMETYPE, ENCODING, short margin_w, short margin_h);
void  delete_frame (FRAME *);
void     frame_calculate (FRAME, const GRECT *);
BOOL     frame_slider    (struct slider *, long max_scroll);
OFFSET * frame_anchor    (FRAME, const char * name);
PARAGRPH frame_paragraph (FRAME, long x, long y, long area[4]);
FRAME frame_next (FRAME frame);

/* in keyinput.c */

void key_pressed (WORD key, UWORD state);

/* in Loader.c */

void init_load(const char *file);
BOOL page_load(void);
void init_paths(void);
BOOL getcookie(long cookie, void *value);  /* value can be NULL */
WORD identify_AES(void);

/* in render.c */

BOOL parse_text (const char *symbol, FRAME);
BOOL parse_html (const char *symbol, FRAME);

/* in O_Struct.c */

struct font_step * new_step     (WORD size, WORD color);
struct font_step * add_step     (struct font_step *);
struct font_step * destroy_step (struct font_step *);
struct list_stack_item *remove_stack_item   (struct list_stack_item *);
struct list_stack_item *new_stack_list_item (void);

ANCHOR new_named_location (const char * address, OFFSET *);
void   destroy_named_location_structure (ANCHOR);
CLICKABLE new_clickable_area (void);
void      destroy_clickable_area_structure (CLICKABLE);
struct url_link * new_url_link (WORDITEM start,
                                char * address, BOOL is_href, char * target);

/* in color.c */

void save_colors(void);
WORD remap_color (long value);

/* in Paragrph.c */

void     destroy_paragraph_structure (PARAGRPH);
PARAGRPH new_paragraph               (TEXTBUFF);
PARAGRPH add_paragraph               (TEXTBUFF);
WORDITEM paragrph_word    (PARAGRPH, long x, long y, long area[4]);
GRECT    paragraph_extend (WORDITEM);
void     content_setup     (CONTENT *, TEXTBUFF, short margins, short backgnd);
void     content_destroy   (CONTENT *);
long     content_minimum   (CONTENT *);
long     content_maximum   (CONTENT *);
long     content_calc      (CONTENT *, long width, CLICKABLE **);
void     content_stretch   (CONTENT *, long height, V_ALIGN);
PARAGRPH content_paragraph (CONTENT *, long x, long y, long area[4]);

/* in image.c */

IMAGE new_image    (CONTAINR, short w, short h, short vspace, short hspace, const char * src, LOCATION);
void  delete_image (IMAGE*);
void image_calculate (IMAGE, short par_width);

/* in W_Struct.c */

void               destroy_word_structure (struct word_item *);
struct word_item * new_word   (TEXTBUFF, BOOL do_link);
void               word_store (TEXTBUFF);
void word_set_bold      (TEXTBUFF, BOOL onNoff);
void word_set_italic    (TEXTBUFF, BOOL onNoff);
void word_set_strike    (TEXTBUFF, BOOL onNoff);
void word_set_underline (TEXTBUFF, BOOL onNoff);
#define word_set_color(textbuff, color) {TA_Color((textbuff)->word->attr)=color;}
#define word_set_point(textbuff, point) {TA_Size ((textbuff)->word->attr)=point;}
#define word_set_font( textbuff, font)  {TAsetFont((textbuff)->word->attr,font);}
long word_offset (WORDITEM);

/* in av_prot.c */

void Init_AV_Protocol(void);
void Exit_AV_Protocol(void);
BOOL Send_AV(short to_ap_id, short message, const char *data1, const char *data2);
BOOL Receive_AV(const short msg[8]);
