/* @(#)highwire/keyinput.c
 *
 * This file should contain the keyboard handler
 * routines.  ie. Input to forms, URL address etc
 *
 * baldrick July 10, 2001
 */
#include <ctype.h>
#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif
#ifdef LATTICE
#include <dos.h>
#endif
#ifdef __GNUC__
#include <osbind.h>
#endif
#include <gem.h>

#include "global.h"
#include "Loader.h"
#include "Containr.h"
#include "Location.h"
#include "Logging.h"
#include "window.h"


FRAME
frame_next (FRAME frame)
{
	CONTAINR cont = (frame ? frame->Container : NULL);
	BOOL     b    = FALSE;

	while (cont) {
		if (b) {
			if (cont->Mode == CNT_FRAME) {
				if (cont->u.Frame) {
					return cont->u.Frame;
				}
			} else if (cont->Mode) {
				cont = cont->u.Child;
				continue;
			}
		}
		if (cont->Sibling) {
			cont = cont->Sibling;
			b    = TRUE;
			continue;
		}
		cont = cont->Parent;
		b    = FALSE;
	}
	/* After the last frame start from the first. */
	cont = containr_Base(frame);
	while (cont) {
		if (cont->Mode == CNT_FRAME) {
			if (cont->u.Frame) {
				return cont->u.Frame;
			}
		} else if (cont->Mode) {
			cont = cont->u.Child;
		}
	}
	/* If nothing found return the same frame. */
	return frame;
}


void
key_pressed (WORD key, UWORD state)
{
	extern char prev_location[HW_PATH_MAX];
	extern ENCODING prev_encoding;

	/* If Alternate is pressed, restore ASCII value of the key.
	 * This is neccessary to be independant from national keyboard layouts.
	 */
	if (state & K_ALT) {
		UWORD scan;
		char c;
		static KEYTAB *keytable = NULL;

		if (keytable == NULL)
			keytable = Keytbl((void*)-1, (void*)-1, (void*)-1);

		scan = (UWORD)key >> 8;
		if (scan < 128)
			c = ((state & (K_RSHIFT|K_LSHIFT))? keytable->unshift : keytable->shift)[scan];
		else
			c = 0;
		key = (key & 0xFF00) | c;
	}

	switch (key & 0xFF00)  /* scan code */
	{
	case 0x0F00:  /* Tab: change window_list->active_frame for keyboard */
		window_cycle_frames();
		key = 0;  /* prevent ^I */
		break;
	case 0x3F00:  /* F5 (Internet Explorer), CTRL+R: reload */
		menu_reload (ENCODING_Unknown);
		break;
	case 0x4100:  /* F7: toggle logging */
		menu_logging();
		break;
	case 0x4200:  /* F8: toggle pictures or alternative text */
		menu_alt_text();
		break;
	case 0x4700:  /* home */
		if (!(state & (K_RSHIFT|K_LSHIFT))) {
			wind_scroll (window_list->handle, window_list->active_frame->Container,
			             -window_list->active_frame->Page.Width,
			             -window_list->active_frame->Page.Height);
			break;
		}
		/* else fall through */
	case 0x4F00:  /* end */
		wind_scroll (window_list->handle, window_list->active_frame->Container,
		             -window_list->active_frame->Page.Width,
		             +window_list->active_frame->Page.Height);
		break;
	case 0x4800:  /* /|\ */
		if (!(state & (K_RSHIFT|K_LSHIFT))) {
			wind_scroll (window_list->handle, window_list->active_frame->Container,
			             0, -scroll_step);
			break;
		}
		/* else fall through */
	case 0x4900:  /* page up */
		wind_scroll (window_list->handle, window_list->active_frame->Container,
		             0, -(window_list->active_frame->clip.g_h - scroll_step));
		break;
	case 0x5000:  /* \|/ */
		key = 0;  /* this key has character '2' */
		if (!(state & (K_RSHIFT|K_LSHIFT))) {
			wind_scroll (window_list->handle, window_list->active_frame->Container,
			             0, +scroll_step);
			break;
		}
		/* else fall through */
	case 0x5100:  /* page down */
		wind_scroll (window_list->handle, window_list->active_frame->Container,
		             0, +(window_list->active_frame->clip.g_h - scroll_step));
		break;
	case 0x4B00:  /* <- */
		if (state & (K_LSHIFT|K_RSHIFT))
			wind_scroll(window_list->handle, window_list->active_frame->Container,
			            -window_list->active_frame->clip.g_w, 0);
		else
			wind_scroll(window_list->handle, window_list->active_frame->Container,
			            -scroll_step, 0);
		break;
	case 0x4D00:  /* -> */
		if (state & (K_LSHIFT|K_RSHIFT))
			wind_scroll(window_list->handle, window_list->active_frame->Container,
			            window_list->active_frame->clip.g_w, 0);
		else
			wind_scroll(window_list->handle, window_list->active_frame->Container,
			            scroll_step, 0);
		break;
	case 0x6100:  /* Undo */
		/* BUG: active_frame->Location is not in any case usefull! */
		new_loader_job (prev_location, window_list->active_frame->Location,
		                window_list->active_frame->Container, MIME_Unknown,
		                prev_encoding, window_list->active_frame->Page.MarginLft,
		                window_list->active_frame->Page.MarginTop);
		break;
	case 0x3B00:  /* F1 (defined in DIN 2137-6, Nr 6.2.4 (ISO/IEC 9995-6?)) */
	case 0x6200:  /* Help */
		menu_help();
		break;
	}

	switch (toupper(key & 0xFF))  /* character */
	{
	case ')':  /* Alt+) (Netscape Navigator): increase font size and reload */
		if (!(state & K_ALT))
			break;
		key = '+';
		/* else fall through */
	case '+':  /* +: increase font size and reload */
	case '-':  /* -: decrease font size and reload */
		menu_fontsize (key & 0xFF);
		break;
	case '1':  /* 1: reload with default encoding windows-1252 */
		menu_reload (ENCODING_WINDOWS1252);
		break;
	case '2':  /* 2: reload with default encoding ISO-8859-2 */
		menu_reload (ENCODING_ISO8859_2);
		break;
	case 'A':  /* A: reload with default encoding Atari system font */
		menu_reload (ENCODING_ATARIST);
		break;
	case 'F':  /* F: reload with default encoding ISO-8859-15 */
		menu_reload (ENCODING_ISO8859_15);
		break;
	case 'M':  /* M: reload with default encoding Apple Macintosh Roman */
		menu_reload (ENCODING_MACINTOSH);
		break;
	case 'N':  /* N: reload with default encoding Atari NVDI 4 Euro */
		menu_reload (ENCODING_ATARINVDI);
		break;
	case 'U':  /* U: reload with default encoding UTF-8 */
		menu_reload (ENCODING_UTF8);
		break;
	case 'V':  /* Alt+V: view source */
		if (state & K_ALT)
			menu_source(window_list->active_frame);
		break;
	case 0x0012:  /* CTRL+R, F5 (Internet Explorer): reload */
		menu_reload (ENCODING_Unknown);
		break;
	case 0x0009:  /* CTRL+I */
		menu_info();
		break;
	case 0x000F:  /* CTRL+O */
		menu_open (!(state & (K_RSHIFT|K_LSHIFT)));
		break;
	case 0x0011:  /* CTRL+Q */
		menu_quit();
		break;
	case 0x0015:  /* CTRL+U */
		delete_window(window_list->handle);
		break;
	case 0x0017:  /* CTRL+W */
		window_cycle();
		break;
	}
}
