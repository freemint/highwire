/* @(#)highwire/keyinput.c
 *
 * This file should contain the keyboard handler
 * routines.  ie. Input to forms, URL address etc
 *
 * right now it just handles hot key for UNDO - back up a page
 * baldrick July 10, 2001
 */


#include <ctype.h>
#include <stdlib.h>

#include "global.h"
#include "Loader.h"


void
key_pressed (struct frame_item *first_frame, WORD key)
{
/*	struct frame_item *current_frame;*/

	extern char last_location[HW_PATH_MAX];
	extern char prev_location[HW_PATH_MAX];
	extern ENCODING prev_encoding;

/*	printf("key = %d\n", key);
*/

/* Doesn't handle forms yet so just skip down to hotkeys
	current_frame = first_frame;

	while (current_frame != NULL)
	{
		if (mx < current_frame->clip.x + current_frame->clip.w + scroll_bar_width
		    && mx > current_frame->clip.x
		    && my < current_frame->clip.y + current_frame->clip.h + scroll_bar_width
		    && my > current_frame->clip.y)
		{
			frame_clicked (first_frame, current_frame, mx, my);
			return;
		}
		current_frame = frame_next (current_frame);
	}
*/

	/* nothing else so process hotkeys */

	switch (key & 0xFF00)  /* scan code */
	{
	case 24832:  /* Undo */
		new_loader_job (prev_location, prev_encoding, first_frame->Container);
		break;
	}

	switch (toupper(key & 0xFF))  /* character */
	{
	case 0x0031:  /* 1 */
		new_loader_job(last_location, ENCODING_WINDOWS1252, first_frame->Container);
		break;
	case 0x0032:  /* 2 */
		new_loader_job(last_location, ENCODING_ISO8859_2, first_frame->Container);
		break;
	case 0x0041:  /* A */
		new_loader_job(last_location, ENCODING_ATARIST, first_frame->Container);
		break;
	case 0x0055:  /* U */
		new_loader_job(last_location, ENCODING_UTF8, first_frame->Container);
		break;

#ifdef GEM_MENU
	/* change 12-22-01 mj. */
	case 0x0009:  handle_menu(M_ABOUT, NULL); break;
	case 0x000F:  handle_menu(M_OPEN, NULL); break;
	case 0x0011:  handle_menu(M_QUIT, NULL); break;
#else
	case 0x0009:  /* CTRL+I */
		do_info_dialog();
		break;
	case 0x000F:  /* CTRL+O */
		page_load();
		break;
	case 0x0011:  /* CTRL+Q */
		exit(EXIT_SUCCESS);
		break;
#endif

	default:
		break;
	}
}
