/* **********************  message system ***********************
These functions are only executed under MultiTOS, and are linked
to the parent program (only).  Drivers access functions via the
MSG_TABLE, which is copied into their DRV_TABLE structures.

The parms.busy flag is used to prevent calling processes from
interfering with each other.  While several processes can call
wait(&parms.busy), only one will execute until it sets parms.busy=0
again.
************************************************************* */

#include <tos.h>
#include <stdlib.h>
#include <string.h>

#include "driver.h"

/* from wait.s */

void cdecl wait(char *pflag);	/* uses test-and-set instruction */
long get_bp(void);	/* Supexec(get_bp) returns current bagepage */

/* static variables */

static MSG_TABLE vec = {msg_send, msg_status, msg_wait, msg_get};

typedef struct list {
	struct list *next;
	short opcode;
	long size;
	char msg[2];	/* space reserved between structures for messages */
 } QUEUE;

typedef struct ports {
	struct ports *next;
	long basepage;
	QUEUE *start;
 } PORT;

static volatile struct {
	PORT *start;	/* start of port list */
	PORT *free;	/* free list */
	QUEUE *msg;	/* free message list */
	short wait;	/* debug - number of ports waiting to send */
	short max;	/* debug - max ports waiting to send */
	char busy;	/* used to lock out other processes */
	char full;	/* used when queue full */
 } parms = {0L,0L,0L,0L,0,0,-1};

static long parent = 0L;
static void *ram = 0L;

/* *********************** msg_init() **************************
Initialize message system.  Open parent's message port,
Returns error code.
************************************************************* */

short cdecl msg_init (void) {
	PORT *p;
	QUEUE *link,*next;
	long size, queue_size;
	short i;

	if(ram) return(0);	/* already initialized */

	parent = Supexec(get_bp);	/* parent basepage */

/* allocate RAM for linked lists */

	queue_size = sizeof(QUEUE) - 2 + DRV_SIZE;
	if(queue_size & 1) queue_size++;	/* must be even*/
	size = DRV_PORTS * sizeof(PORT) + DRV_QUEUE * queue_size;
	ram = Malloc(size);
	if(ram == 0L) return(MSG_RAM);

/* initialize free port list */

	p = (PORT*) ram;
	p->next = 0L;
	for(i=1; i < DRV_PORTS; i++) {
		p++;
		p->next = p-1;
	 }
	parms.free = p;

/* initialize free message list */

	link = (QUEUE*) (p+1);
	link->next = 0L;
	for(i=1; i < DRV_QUEUE; i++) {
		next = (QUEUE*) ((long) link + queue_size);
		next->next = link;
		link = next;
	 }
	parms.msg = link;

	parms.busy = 0;	/* turn on message system */

	return(msg_open(0L));
 }

/* *********************** msg_term() **************************
Frees RAM and turns off message system.
Returns maximum number of ports waiting to send messages at the
same time due to a full queue (debug - adjust DRV_QUEUE).
************************************************************* */

short cdecl msg_term(void)
 {
	if(!ram) return(0);	/* message system not initialized */

	wait(&parms.busy);	/* turn off message system */
	Mfree(ram);
	ram = 0L;

	return(parms.max);
 }

/* ********************** msg_open() ***************************
Opens a message port for specified driver (or parent);
Automatically loads msg vector into driver's DRV_TABLE.

basepage is returned by Pexec(3) and is used to identify
drivers.  (0L used for parent.)

Returns error code (0 = no error);
************************************************************* */

short cdecl msg_open (long basepage)
 {
	PORT *p;
	DRV_HEADER *hdr;
	DRV_TABLE *drv;

	if(basepage) {
		hdr = (DRV_HEADER*) (basepage + 256);	/* load driver table */
		drv = hdr->table;
		drv->msg = &vec;
	 }

	wait(&(parms.busy));	/* lock out other processes */

	p = parms.free;
	if(!p) {
		parms.busy = 0;
		return(MSG_FULL);
	 }
	parms.free = parms.free->next;
	p->next = parms.start;
	p->basepage = basepage;
	p->start = 0L;
	parms.start = p;

	parms.busy = 0;	/* unblock other processes */
	return(0);
 }

/* ********************** msg_close() **************************
Closes a message port for specified driver;
Returns 0 normally, 1=port not open, 3=message driver terminated.
************************************************************* */

short cdecl msg_close (long basepage)
 {
	DRV_HEADER *hdr;
	PORT *p,**from;
	QUEUE *link,*next;
	short pid;

	wait(&(parms.busy));	/* lock out other processes */

	from = &parms.start;	/* find message port */
	p = *from;
	while(p) {
		if(p->basepage == basepage) break;
		from = &(p->next);
		p = *from;
	 }
	if(!p) {	/* port not open */
		parms.busy = 0;
		return(MSG_PORT);
	 }

	*from = p->next;	/* remove port from list */
	p->next = parms.free;
	parms.free = p;
	p->basepage = -1L;

	link = p->start;	/* clear message queue */
	while(link) {
		next = link->next;
		link->next = parms.msg;
		parms.msg = link;
		link = next;
	 }

	if(basepage) {	/* kill driver */
		hdr = (DRV_HEADER*) (basepage + 245);
		pid = hdr->table->pid;
		hdr->table->pid = 0;
		if(pid > 0) Pkill(pid,SIGTERM);
		Mfree((void*) basepage);
	 }

	parms.busy = 0;	/* unblock other processes */
	return(0);
 }

/* ********************** msg_send() ***************************
Sends a variable length message to driver with specified basepage.
The contents of msg will be copied, so msg buffer is not tied up.
Returns 0 or error code.
************************************************************* */

short cdecl msg_send (
	long basepage,	/* destination id - use 0L for parent */
	short opcode,	/* must be > 0 */
	long size,	/* must be <= DRV_SIZE */
	void* msg)	/* message */
 {
	PORT *p;
	QUEUE *link,**from;

	if(opcode <= 0) return(MSG_CODE);
	if(size > DRV_SIZE) return(MSG_SIZE);

	wait(&(parms.busy));	/* lock out other processes */

	for(p = parms.start; p; p = p->next)
	 if(p->basepage == basepage) break;
	if(!p) {parms.busy = 0; return(MSG_PORT);}

	from = &(p->start);	/* get end of queue */
	link = *from;
	while(link) {
		from = &(link->next);
		link = *from;
	 }

	if(parms.msg == 0L) {	/* message queue full */
		parms.wait++;
		if(parms.wait > parms.max) parms.max++;
		parms.busy = 0;
		wait(&parms.full);	/* lock out msg_send() only */
		while(parms.msg == 0L) Syield();
		wait(&parms.busy);
		parms.full = 0;
		parms.wait--;
	 }
	*from = link = parms.msg;
	parms.msg = link->next;
	link->next = 0L;
	link->opcode = opcode;
	link->size = size;
	memcpy(link->msg, msg, size);

	parms.busy = 0;	/* unblock other processes */
	return(0);
 }

/* ********************** msg_wait() ***************************
Waits for message to arrive.
Returns error code (0 = no error).
************************************************************* */

short cdecl msg_wait (void)
 {
	long basepage;
	PORT *p;

	basepage = Supexec(get_bp);
	if(basepage == parent) basepage = 0L;

	for(p = parms.start; p; p = p->next)	/* find message port */
	 if(p->basepage == basepage) break;
	if(!p) return(MSG_PORT);

	while(p->start == 0L) Syield();
	return(0);
 }

/* ********************** msg_status() *************************
Returns 0 if no message waiting, 1 if message waiting, or a
negative error code.
************************************************************* */

short cdecl msg_status (void)
 {
	PORT *p;
	long basepage;

	basepage = Supexec(get_bp);
	if(basepage == parent) basepage = 0L;

	for(p = parms.start; p; p = p->next)	/* find message port */
	 if(p->basepage == basepage) break;
	if(!p) return(MSG_PORT);

	if(p->start == 0) return(0);
	else return(1);
 }

/* ********************** msg_get() ***************************
Copies and removes next message from queue.
Returns a positive opcode, 0 if no message in queue, or a negative
error code.
************************************************************* */

short cdecl msg_get (
	long size,	/* buffer size (use DRV_SIZE to be safe) */
	void *msgbuf)	/* message buffer */
 {
	PORT *p;
	QUEUE *link;
	long basepage;
	short opcode;

	basepage = Supexec(get_bp);
	if(basepage == parent) basepage = 0L;

	wait(&parms.busy);	/* lock out other processes */

	for(p = parms.start; p; p = p->next)
	 if(p->basepage == basepage) break;
	if(!p) {parms.busy = 0; return(MSG_PORT);}

	if(p->start == 0) {parms.busy = 0; return(0);}
	link = p->start;
	if(link->size > size) {parms.busy = 0; return(MSG_SIZE);}

	opcode = link->opcode;
	memcpy(msgbuf, link->msg, link->size);

	p->start = link->next;	/* remove message from queue */
	link->next = parms.msg;
	parms.msg = link;

	parms.busy = 0;	/* unblock other processes */
	return(opcode);
 }
