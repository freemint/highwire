#include <stdio.h>
#include <string.h>
#include <tos.h>

#include "test_drv.h"
#include "driver.h"

static CHILD child = {test};
static PARENT parent = {alert};

DRV_TABLE table = {1,DRV_VERSION,4096,&child,&parent,0L,0};	/* used by stub.s */

/* main program - only used under MultiTOS */

char errmsg[128];

main()
 {
	short err;
	struct {short opcode; long index;} msgbuf;

	while(table.msg == 0L) return(1);	/* message port not open */
	table.pid = Pgetpid();

	while(-1) {
		err = table.msg->msg_wait();
		if(err) return(1);	/* message port closed - kill yourself */

		err = table.msg->msg_get(sizeof(msgbuf), &msgbuf);
		if(err) {
			sprintf(errmsg,"[1][Child received bad message! |msg_get() returned %d ][Eeek!]",err);
			alert(errmsg);
			continue;
		 }
		switch(msgbuf.opcode) {
		 case C_TEST:
			test(msgbuf.index);
			break;

		 default:
			sprintf(errmsg,"[1][Child received bad message! |opcode = %d ][Eeek!]",msgbuf.opcode);
			alert(errmsg);
		 }
	 }
 }

/* child functions - used under both SingleTOS and MultiTOS */

void cdecl test(long index)
 {
	PARENT *vec;

	vec = (PARENT*) table.parent;	/* redirected under SingleTOS */

	sprintf(errmsg,"[0][Driver %ld resonding ][OK]",index);
	vec->alert(errmsg);
 }

/* parent functions (message interface) */

void cdecl alert(char *form)
 {
	long size;

	size = strlen(form) + 1;
	table.msg->msg_send(0L,P_ALERT,size,form);
 }

/* **********************************************************
Note that I copied the entire string into the message.
While one could just send a string pointer, one could not re-use
the string buffer until the parent had processed the message,
and there is no way to guarentee that this will happen before
the parent calls another child function.
********************************************************** */

	