#include <tos.h>
#include <aes.h>
#include <stdio.h>

#include "test.h"
#include "test_drv.h"
#include "driver.h"

static EVENT multi = {MU_MESAG, 0,0,0, 0,0,0,0,0, 0,0,0,0,0,
	1,0, 0,0,0,0,0,0,0, {0,0,0,0,0,0,0,0}};

static CHILD child = {test};
static PARENT parent = {alert};

typedef struct list {	/* linked list of drivers */
	struct list *next;
	long basepage;
	CHILD *child;
 } LIST;

static LIST drivers[DRV_PORTS - 1];

static long dest;	/* message destination */

char errmsg[128];

/* used to set MiNT_flag - Copied from old version of loader.c */

#define	_cookies	((long **) 0x5A0L)
#define	AES_single	0
#define	AES_MagiC	1
#define	AES_Geneva	2
#define	AES_MTOS	3
#define	AES_nAES	4

short MiNT_flag = 0;

short
identify_AES(void)
{	
	void	*old_SSP;
	long	search_id;
	long	*search_p;
	short	retv = AES_single;

/* cookie search is made in Super mode to access any RAM */

	old_SSP = (void *) Super(0L);
	search_p = *_cookies;
	if (search_p != NULL)	while(-1) {
		search_id = *search_p;
		if( search_id == 0L )	break; /* search completed */
		if( search_id == 0x4D674D63L  ||  search_id == 0x4D616758L ) retv = AES_MagiC;
		if( search_id == 0x6E414553L ) retv = AES_nAES;
		if( search_id == 0x476E7661L ) retv = AES_Geneva;
		if( search_id == 0x4D694E54L ) MiNT_flag = 1;
		search_p += 2;
	 }
	Super(old_SSP);

	return( retv );
}

/* *********************** decode_msg() ************************
Converts messages into calls to functions in parent.
In this case there is only one function in the list.
************************************************************* */

void decode_msg(void)
 {
	short opcode;
	char msgbuf[DRV_SIZE];

	opcode = msg_get(DRV_SIZE,msgbuf);

	switch(opcode) {
	 case P_ALERT:
		alert(msgbuf);
		break;

	 default:
		sprintf(errmsg,"[1][Bad message from child! |opcode = %d ][Eeek!]",opcode);
		form_alert(0,errmsg);
	 }
	return;
 }

/* *******************  test program  **********************
Menu driven program allows user to load and unload drivers
from a FIFO queue.

It is a bit unusual in that it loads the same driver over and
over, instead of once per driver.  Consequently the global
variable dest (message destination) has to be reset each time.
Usually, one would need one global data structure for the
driver destinations which is set once when they are loaded.
********************************************************* */

main()
 {
	LIST *start,*free,*p,**from;
	OBJECT *menu;
	int button,event;
	long size,msg_base;
	short i,err;

	identify_AES();	/* set MiNT_flag */

	free = drivers;	/* initialize linked list */
	free->next = 0L;
	free->child = &child;
	for(i=2; i < DRV_PORTS; i++) {
		free++;
		free->next = free - 1;
		free->child = &child;
	 }
	start = 0L;

	appl_init();
	rsrc_load("test.rsc");
	rsrc_gaddr(R_TREE,MENU,&menu);

	if(MiNT_flag) {
		button = form_alert(1,"[2][Do you want to test |SingleTOS or MultiTOS |parameter passing? ][Single|Multi]");
		if(button == 1) MiNT_flag = 0;
	 }

	if(MiNT_flag) {
		err = msg_init();
		if(err) {
			sprintf(errmsg,"[3][msg_open() failed |Error code %d ][Abort]",err);
			form_alert(1,errmsg);
			appl_exit();
			return(0);
		 }
		multi.ev_mflags |= MU_TIMER;	/* activate timer events */
	 }
	menu_bar(menu,1);

main_loop:
	event = EvntMulti(&multi);

	if(event & MU_TIMER) decode_msg();	/* process messages */

	if(event & MU_MESAG) switch(multi.ev_mmgpbuf[0]) {	/* message type */
	 case MN_SELECTED:
		switch(multi.ev_mmgpbuf[4]) {	/* menu object selected */
		 case M_QUIT:
			while(start) {
				dest = start->basepage;
				unload_drv(MiNT_flag, start->basepage);
				start = start->next;
			 }
			menu_bar(menu,0);
			appl_exit();
			return(0);

		 case M_LOAD:
			if(!free) {
				form_alert(0,"[1][Max drivers loaded! ][Oops!]");
				break;
			 }
			from = &start;
			p = *from;
			while(p) {from = &(p->next); p = *from;}	/* find end of list */
			p = free;
			p->basepage = load_drv(MiNT_flag, "test_drv.drv",1,&parent,&((void*) p->child));
			if(p->basepage <= 0L) {
				sprintf(errmsg,"[1][Unable to load driver! |error %ld ][Eeek!]",p->basepage);
				form_alert(0,errmsg);
				break;
			 }
			sprintf(errmsg,"[0][Driver loaded at %ld ][OK]",p->basepage);
			form_alert(0,errmsg);
			free = p->next;
			*from = p;
			p->next = 0;
			break;

		 case M_UNLOAD:
			if(!start) {
				form_alert(0,"[1][No drivers loaded! ][Oops!]");
				break;
			 }
			p = start;
			start = p->next;
			p->next = free;
			free = p;
			unload_drv(MiNT_flag, p->basepage);
			sprintf(errmsg,"[0][Driver at %ld unloaded ][OK]",p->basepage);
			form_alert(0,errmsg);
			break;

		 case M_COUNT:			
			if(!start) {
				form_alert(0,"[1][No drivers loaded! ][Oops!]");
				break;
			 }
			p = start;
			while(p) {
				if(MiNT_flag) dest = p->basepage;
				p->child->test(p->basepage);
				p = p->next;
			 }
		 }	/* end of switch(multi.ev_mmgpbuf[4]) */

		menu_tnormal(menu, multi.ev_mmgpbuf[3], 1);
		break;

	 }	/* end of switch(multi.ev_mmgpbuf[0]) */
	goto main_loop;
 }

/* *********************** alert() *****************************
Function in parent to be called by child - form_alert().

Note, this isn't quite as trivial as it seems, since the AES
interface uses global variable which are NOT passed to the driver.
************************************************************* */

void cdecl alert(char *form)
 {
	form_alert(0,form);
 }

/* *********************** test() ******************************
Function in child to be called by parent.  Or more exactly, this
function converts the call into a message.
It will only be executed if MiNT_flag is set.
Destination basepage passed by global variable dest.
************************************************************* */

void cdecl test(long index)
 {
	long msgbuf;

	msgbuf = index;
	msg_send(dest, C_TEST, sizeof(msgbuf), &msgbuf);
 }
