#include <tos.h>

#include "driver.h"


/* ********************** load_drv *****************************
Returns basepage, GEMDOS error code, or 0L if invalid driver (or
out of RAM).
************************************************************ */
long cdecl load_drv(
	short flag,	/* 0 = SingleTOS, else MultiTOS */
	char* fname,	/* filename for driver */
	short type,	/* driver type (see drivers.h) */
	void *parent,	/* function pointer array from parent */
	void **child)	/* returns a function pointer array */
 {
	BASPAG *p;
	DRV_HEADER *hdr;
	DRV_TABLE *table;
	long basepage,size;

	basepage = Pexec(3,fname,"",0L);	/* load into RAM */
	if(basepage <= 0) return(basepage);

	hdr = (DRV_HEADER*) (basepage + 256);	/* check driver */
	if(hdr->magic != DRV_MAGIC) goto abort;
	table = hdr->table;
	if((table->type != type) || (table->version != DRV_VERSION)) goto abort;

	p = (BASPAG*) basepage;
	size = 256 + p->p_tlen + p->p_dlen + p->p_blen;
	if(flag) size += table->stack;
	Mshrink(0,p,size);

	if(flag) {
		if(msg_open(basepage)) goto abort;
		Pexec(104,fname,p,0L);
	 }
	else {
		*child = table->child;
		table->parent = parent;
	 }
	return(basepage);

abort:
	Mfree((void*) basepage);
	return(0L);
 }

/* ********************** unload_drv **************************
Parent must keep track of which drivers are loaded.
************************************************************ */
void cdecl unload_drv(
	short flag,	/* 0 = SingleTOS, else MultiTOS */
	long basepage)	/* returned from load_drv() */
 {
	if(flag) msg_close(basepage);
	else Mfree((void*) basepage);
 }

