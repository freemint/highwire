#include <stdlib.h>

#include "token.h"
#include "global.h"
#include "scanner.h"
#include "fontbase.h"


/* calculate end of paragraph space, eop_space */
#define EOP(a) ((a) * 2 / 3)


/*============================================================================*/
void
list_start (TEXTBUFF current, BULLET bullet, short counter)
{
	LSTSTACK list = malloc (sizeof (struct list_stack_item));
	PARAGRPH par  = current->paragraph;
	
	if (!current->lst_stack) {
		par->eop_space = EOP(current->font_size);
	}
	par = add_paragraph (current);

	list->next_stack_item = current->lst_stack;
	current->lst_stack    = list;
	
	list->BulletStyle = bullet;
	list->Counter     = counter;
	list->Spacer      = current->word->word_height *2 /3;
	list->Hanging     = list->Spacer *4;
	list->Indent      = par->Indent + list->Hanging;
	
	par->alignment = ALN_LEFT;
	par->Indent    = list->Indent;
}

/*============================================================================*/
void
list_finish (TEXTBUFF current)
{
	LSTSTACK list = current->lst_stack;
	current->lst_stack = list->next_stack_item;
	if (!current->lst_stack) {
		current->paragraph->eop_space += current->font_size / 3;
	}
	add_paragraph (current)->Indent = list->Indent - list->Hanging;
	
	free (list);
}


/*------------------------------------------------------------------------------
 * Recursively converts a positive long to a decimal number wide string.
 * Rainer Seitel, 2002-03-11
*/
static void long2decimal (char **p_ws, long l)
{
	if (l >= 10)
		long2decimal(p_ws, l / 10);

	*((*p_ws)++) = (char)((l % 10) + '0');
}


/*------------------------------------------------------------------------------
 * Recursively converts a positive long to an alphabet number wide string.
 * Rainer Seitel, 2002-03-11
*/
static void long2alpha (char **p_ws, long l, BOOL upper)
{
	if (l > 26)
		long2alpha(p_ws, l / 26, upper);

	*((*p_ws)++) = (char)(((l - 1) % 26) + (upper? 'A' : 'a'));
}


/*============================================================================*/
void
list_marker (TEXTBUFF current, BULLET bullet, short counter)
{
	char buffer[80]  = "", * text = buffer;
	WORD mapping     = current->word->font->Base->Mapping;
	WORD count       = current->lst_stack->Counter;

	switch (bullet)
	{
		case disc:
			current->text = unicode_to_wchar (0x2022,   /* BULLET */
			                                  current->text, mapping);
			break;
		case square:
			current->text = unicode_to_wchar (0x25AA,   /* BLACK SMALL SQUARE */
			                                  current->text, mapping);
			break;
		case circle:
			current->text = unicode_to_wchar (0x25E6,  /* WHITE BULLET */
			                                  current->text, mapping);
			break;
		
		case Number:
			current->lst_stack->Counter = counter +1;
			if (count < 0) {
				current->text = unicode_to_wchar (0x2212,  /* MINUS SIGN */
				                                  current->text, mapping);
				count = -count;
			}
			long2decimal (&text, count);
			break;
		
		case alpha:
			if (count != 0) {
				current->lst_stack->Counter = counter +1;
				if (count < 0) {
					current->text = unicode_to_wchar (0x2212,  /* MINUS SIGN */
					                                  current->text, mapping);
					count = -count;
				}
				long2alpha (&text, count, FALSE);
				break;
			}
			/* else use @ as small alphabet zero */
		
		case Alpha:
			current->lst_stack->Counter = counter +1;
			if (count < 0) {
				current->text = unicode_to_wchar (0x2212,  /* MINUS SIGN */
				                                  current->text, mapping);
				count = -count;
			}
			long2alpha (&text, count, TRUE);
			break;
		
		case roman:
			current->lst_stack->Counter = counter +1;
			if (count > 0 && count < 3000) {
				switch (count / 1000 * 1000) {
				case 2000:
					*(text++) = 'm';
				case 1000:
					*(text++) = 'm';
					break;
				}
				switch ((count % 1000) / 100 * 100) {
				case 300:
					*(text++) = 'c';
				case 200:
					*(text++) = 'c';
				case 100:
					*(text++) = 'c';
					break;
				case 400:
					*(text++) = 'c';
				case 500:
					*(text++) = 'd';
					break;
				case 600:
					*(text++) = 'd';
					*(text++) = 'c';
					break;
				case 700:
					*(text++) = 'd';
					*(text++) = 'c';
					*(text++) = 'c';
					break;
				case 800:
					*(text++) = 'd';
					*(text++) = 'c';
					*(text++) = 'c';
					*(text++) = 'c';
					break;
				case 900:
					*(text++) = 'c';
					*(text++) = 'm';
					break;
				}
				switch ((count % 100) / 10 * 10) {
				case 30:
					*(text++) = 'x';
				case 20:
					*(text++) = 'x';
				case 10:
					*(text++) = 'x';
					break;
				case 40:
					*(text++) = 'x';
				case 50:
					*(text++) = 'l';
					break;
				case 60:
					*(text++) = 'l';
					*(text++) = 'x';
					break;
				case 70:
					*(text++) = 'l';
					*(text++) = 'x';
					*(text++) = 'x';
					break;
				case 80:
					*(text++) = 'l';
					*(text++) = 'x';
					*(text++) = 'x';
					*(text++) = 'x';
					break;
				case 90:
					*(text++) = 'x';
					*(text++) = 'c';
					break;
				}
				switch (count % 10) {
				case 3:
					*(text++) = 'i';
				case 2:
					*(text++) = 'i';
				case 1:
					*(text++) = 'i';
					break;
				case 4:
					*(text++) = 'i';
				case 5:
					*(text++) = 'v';
					break;
				case 6:
					*(text++) = 'v';
					*(text++) = 'i';
					break;
				case 7:
					*(text++) = 'v';
					*(text++) = 'i';
					*(text++) = 'i';
					break;
				case 8:
					*(text++) = 'v';
					*(text++) = 'i';
					*(text++) = 'i';
					*(text++) = 'i';
					break;
				case 9:
					*(text++) = 'i';
					*(text++) = 'x';
					break;
				}
			} else {  /* BUG: small Roman numerals >= 3000 not implemented! */
				long2decimal (&text, count);
			}
			break;
		
		case Roman:
			/* Sources:
			 * Friedlein, Gottfried: Die Zahlzeichen und das elementare Rechnen
			 * der Griechen und R�mer und des christlichen Abendlandes vom 7.
			 * bis 13. Jahrhundert. - unver�nderter Neudruck der Ausgabe von
			 * 1869. - Wiesbaden : Dr. Martin S�ndig oHG, 1968.
			 * Ifroh, Georges: Universalgeschichte der Zahlen. - Frankfurt am
			 * Main ; New York : Campus, 1986. - ISBN 3-593-33666-9. - Kapitel
			 * 9. (Histoire Universelle des Chiffres. - Paris : Seghers, 1981.)
			 * Rainer Seitel, 2002-03-11
			 */
			current->lst_stack->Counter = counter +1;
			if (count > 0 && count < 20000) {
				if (count >= 10000) {
					*(text++) = '(';
					*(text++) = '(';
					*(text++) = '|';
					*(text++) = ')';
					*(text++) = ')';
				}
				switch ((count % 10000) / 1000 * 1000) {
				case 9000:
					*(text++) = '|';
					*(text++) = ')';
					*(text++) = ')';
					*(text++) = 'M';
					*(text++) = 'M';
					*(text++) = 'M';
					*(text++) = 'M';
					break;
				case 8000:
					*(text++) = '|';
					*(text++) = ')';
					*(text++) = ')';
					*(text++) = 'M';
					*(text++) = 'M';
					*(text++) = 'M';
					break;
				case 7000:
					*(text++) = '|';
					*(text++) = ')';
					*(text++) = ')';
					*(text++) = 'M';
					*(text++) = 'M';
					break;
				case 6000:
					*(text++) = '|';
					*(text++) = ')';
					*(text++) = ')';
					*(text++) = 'M';
					break;
				case 5000:
					*(text++) = 'M';
				case 4000:
					*(text++) = 'M';
				case 3000:
					*(text++) = 'M';
				case 2000:
					*(text++) = 'M';
				case 1000:
					*(text++) = 'M';
					break;
				}
				switch ((count % 1000) / 100 * 100) {
				case 300:
					*(text++) = 'C';
				case 200:
					*(text++) = 'C';
				case 100:
					*(text++) = 'C';
					break;
				case 400:
					*(text++) = 'C';
				case 500:
					*(text++) = 'D';
					break;
				case 600:
					*(text++) = 'D';
					*(text++) = 'C';
					break;
				case 700:
					*(text++) = 'D';
					*(text++) = 'C';
					*(text++) = 'C';
					break;
				case 800:
					*(text++) = 'D';
					*(text++) = 'C';
					*(text++) = 'C';
					*(text++) = 'C';
					break;
				case 900:
					*(text++) = 'C';
					*(text++) = 'M';
					break;
				}
				switch ((count % 100) / 10 * 10) {
				case 30:
					*(text++) = 'X';
				case 20:
					*(text++) = 'X';
				case 10:
					*(text++) = 'X';
					break;
				case 40:
					*(text++) = 'X';
				case 50:
					*(text++) = 'L';
					break;
				case 60:
					*(text++) = 'L';
					*(text++) = 'X';
					break;
				case 70:
					*(text++) = 'L';
					*(text++) = 'X';
					*(text++) = 'X';
					break;
				case 80:
					*(text++) = 'L';
					*(text++) = 'X';
					*(text++) = 'X';
					*(text++) = 'X';
					break;
				case 90:
					*(text++) = 'X';
					*(text++) = 'C';
					break;
				}
				switch (count % 10) {
				case 3:
					*(text++) = 'I';
				case 2:
					*(text++) = 'I';
				case 1:
					*(text++) = 'I';
					break;
				case 4:
					*(text++) = 'I';
				case 5:
					*(text++) = 'V';
					break;
				case 6:
					*(text++) = 'V';
					*(text++) = 'I';
					break;
				case 7:
					*(text++) = 'V';
					*(text++) = 'I';
					*(text++) = 'I';
					break;
				case 8:
					*(text++) = 'V';
					*(text++) = 'I';
					*(text++) = 'I';
					*(text++) = 'I';
					break;
				case 9:
					*(text++) = 'I';
					*(text++) = 'X';
					break;
				}
			} else {  /* BUG: Roman numerals >= 20000 not implemented! */
				long2decimal (&text, count);
			}
			break;
	}
	
	if (text > buffer) {
		*(text++) = '.';
		*(text)   = '\0';
		scan_string_to_16bit (buffer, ENCODING_ATARIST,
		                      &current->text, mapping);
	}
}
