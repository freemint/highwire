#include <stdlib.h>
#include <string.h>
#include <gemx.h>

#include "global.h"


static struct {
	UWORD Space, Empty;
} fixed = {
	Space_Code, 0
};


void
destroy_word_structure (struct word_item *current_word)
{
	while (current_word) {
		struct word_item * next = current_word->next_word;
		if ((char*)current_word->item < (char*)&fixed ||
		    (char*)current_word->item > (char*)&fixed + sizeof(fixed))
			free (current_word->item);
		if (current_word->link)
			free (current_word->link);
		if (current_word->image)
			delete_image (&current_word->image);
	/*	if (current_word->input)
			delete_input (&current_word->input)*/;
		free (current_word);
		current_word = next;
	}
}


/* new_word()
 *
 * creates a new word_item object.  if the 'copy_from' is not NULL it is
 * taken as a source to copy attributes from.  the flag 'changed' determines
 * if the members of the changed struct shall be set or cleared.
 * AltF4 - Jan. 20, 2002
 *
 * modified to take frame_item * for inheritance from frame
 * Baldrick - Feb 28, 2002
 */
 
struct word_item *
new_word (TEXTBUFF current, BOOL do_link)
{
	struct word_item * copy_from = current->word;
	struct word_item * word      = NULL;
	
	current->prev_wrd = copy_from;
	
	if (!copy_from) {
		word = malloc (sizeof (struct word_item));
		word->attr.packed    = TEXTATTR (font_size, text_colour);
		word->word_height    = 0;
		word->word_tail_drop = 0;
		word->space_width    = 0;
		word->vertical_align = ALN_BOTTOM;
		word->link           = NULL;
	
	} else /*if (current->text > current->buffer)*/ {
		word_store (current);
		word = malloc (sizeof (struct word_item));
		word->attr.packed    = copy_from->attr.packed;
		word->word_height    = copy_from->word_height;
		word->word_tail_drop = copy_from->word_tail_drop;
		word->space_width    = copy_from->space_width;
		word->vertical_align = copy_from->vertical_align;
		word->link           = copy_from->link;
		if (do_link) {
			copy_from->next_word = word;
		}
	}
	if (word) {
		word->item       = &fixed.Empty;
		word->length     = 0;
		word->line_brk   = BRK_NONE;
		word->word_width = 0;
		word->image      = NULL;
		word->input      = NULL;
		word->next_word  = NULL;
		current->word    = word;
	}
	return current->word;
}


void
word_store (TEXTBUFF current)
{
	size_t length = current->text - current->buffer;
	
	if (length > 0) {
		struct word_item * word = current->word;
		WORD pts[8];
		
		if ((word->length = length) == 1 && current->text[0] == Space_Code) {
			word->item = &fixed.Space;
			pts[2] = word->space_width;
		
		} else {
			size_t size = (length +1) *2;
			word->item = malloc (size);
			memcpy (word->item, current->buffer, size);
			word->item[length] = 0;
			
	#if (__GEMLIB_MINOR__<42)||((__GEMLIB_MINOR__==42)&&(__GEMLIB_REVISION__<2))
			vqt_f_extent16 (vdi_handle, word->item, pts);
	#else
			vqt_f_extent16n (vdi_handle, word->item, length, pts);
	#endif
			pts[2] -= pts[0];
		}
		
		if (word->image) {
			word->image->alt_w = pts[2];
		
		} else {
			word->word_width = pts[2];
		}
	}
	current->text = current->buffer;
}


/* word_set_bold()
 *
 * changes the value of the BOLD status of the current word
*/
void
word_set_bold (TEXTBUFF current, BOOL onNoff)
{
	if (onNoff) {
		if (!current->styles.bold++) {
			TAsetBold (current->word->attr, TRUE);
		}
	} else if (current->styles.bold) {
		if (!--current->styles.bold) {
			TAsetBold (current->word->attr, FALSE);
		}
	}
}


/* word_set_italic()
 *
 * changes the value of the ITALIC status of the current word
*/
void
word_set_italic (TEXTBUFF current, BOOL onNoff)
{
	if (onNoff) {
		if (!current->styles.italic++) {
			TAsetItalic (current->word->attr, TRUE);
		}
	} else if (current->styles.italic) {
		if (!--current->styles.italic) {
			TAsetItalic (current->word->attr, FALSE);
		}
	}
}


/* word_set_strike()
 *
 * changes the value of the STRIKE status of the current word
*/
void
word_set_strike (TEXTBUFF current, BOOL onNoff)
{
	if (onNoff) {
		if (!current->styles.strike++) {
			TAsetStrike (current->word->attr, TRUE);
		}
	} else if (current->styles.strike) {
		if (!--current->styles.strike) {
			TAsetStrike (current->word->attr, FALSE);
		}
	}
}


/* word_set_underline()
 *
 * changes the value of the UNDERLINED status of the current word
*/
void
word_set_underline (TEXTBUFF current, BOOL onNoff)
{
	if (onNoff) {
		if (!current->styles.underlined++) {
			TAsetUndrln (current->word->attr, TRUE);
		}
	} else if (current->styles.underlined) {
		if (!--current->styles.underlined) {
			TAsetUndrln (current->word->attr, FALSE);
		}
	}
}


long
word_offset (WORDITEM word)
{
	WORDLINE line = word->line;
	return (line->OffsetY + line->Paragraph->Offset.Y - word->word_height);
}


#if 0 /***** REPLACED *****/

/* word_set_color()
 *
 * changes the text colour of the current word
*/
void
word_set_color (TEXTBUFF current, WORD color)
{
	if (color != current->word->colour) {
		current->word->colour         = color;
		current->word->changed.colour = TRUE;
	}
	TA_Color (current->word->attr) = color;
}


/* word_set_point()
 *
 * changes the text height in points of the current word
*/
void
word_set_point (TEXTBUFF current, WORD point)
{
	if (point != current->word->styles.font_size) {
		current->word->styles.font_size = point;
		current->word->changed.font     = TRUE;
	}
	TA_Size (current->word->attr) = point;
}


/* word_set_font()
 *
 * changes the font face of the current word
*/
void
word_set_font (TEXTBUFF current, WORD font)
{
	if (font != current->word->styles.font) {
		current->word->styles.font  = font;
		current->word->changed.font = TRUE;
	}
	TAsetFont (current->word->attr, font);
}

#endif /***** REPLACED *****/
