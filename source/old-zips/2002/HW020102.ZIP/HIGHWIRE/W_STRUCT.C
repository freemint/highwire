#include <stdlib.h>
#include <string.h>
#include <gemx.h>

#include "global.h"

void
destroy_word_structure (struct word_item *current_word)
{
	struct word_item *temp;

	while (current_word != 0)
	{
		if (current_word->item != 0)
			free (current_word->item);
		if (current_word->link != 0)
			free (current_word->link);
		temp = current_word->next_word;
		free (current_word);
		current_word = temp;
	}
}


/* new_word()
 *
 * creates a new word_item object.  if the 'copy_from' is not NULL it is
 * taken as a source to copy attributes from.  the flag 'changed' determines
 * if the members of the changed struct shall be set or cleared.
 * AltF4 - Jan. 20, 2002
 */
struct word_item *
new_word (const struct word_item * copy_from, BOOL changed)
{
	struct word_item *temp = malloc (sizeof (struct word_item));

	if (copy_from) {
		temp->styles            = copy_from->styles;
		temp->word_height       = copy_from->word_height;
		temp->word_tail_drop    = copy_from->word_tail_drop;
		temp->colour            = copy_from->colour;
		temp->space_width       = copy_from->space_width;
		temp->vertical_align    = copy_from->vertical_align;
		temp->link              = copy_from->link;
	} else {
		temp->styles.bold       = 0;
		temp->styles.italic     = 0;
		temp->styles.underlined = 0;
		temp->styles.strike     = 0;
		temp->styles.font       = normal_font;
		temp->styles.font_size  = POINT_SIZE;
		temp->word_height       = 0;
		temp->word_tail_drop    = 0;
		temp->colour            = text_colour;
		temp->space_width       = 0;
		temp->vertical_align    = bottom;
		temp->link              = NULL;
	}
	temp->item           = NULL;
	temp->changed.font   = changed;
	temp->changed.style  = changed;
	temp->changed.colour = changed;
	temp->word_code      = none;
	temp->word_width     = 0;
	temp->next_word      = NULL;
	
	return (temp);
}


struct word_item *
add_word (struct frame_item *p_frame, struct word_item *current_word, WORD *active_word_buffer, WORD *active_word)
{
	word_store (p_frame, active_word_buffer,active_word);

	if (p_frame->frame_page_width < (current_word->word_width + p_frame->current_indent_distance))
		p_frame->frame_page_width = current_word->word_width + p_frame->current_indent_distance;

	/* are we in a table */
	if (p_frame->current_table != 0)
		if (p_frame->current_table->current_child != 0)
		{
/*			printf("active_word = %s               \r\n",active_word);
			printf("active_word_buffer = %s        \r\n",active_word_buffer);
*/			
			if (p_frame->current_table->current_child->min_width < (current_word->word_width + p_frame->current_indent_distance))
				p_frame->current_table->current_child->min_width = (current_word->word_width + p_frame->current_indent_distance);
		}
		
	current_word->next_word = new_word (current_word, FALSE);
	
	return current_word->next_word;
}


void
word_store (struct frame_item *p_frame, WORD *active_word_buffer, WORD *active_word)
{
	WORD pts[8], string_length;

	*active_word = 0;
	for (string_length = 0; active_word_buffer[string_length] != 0; string_length++) ;
	string_length++;
	p_frame->current_word->item = malloc (string_length * 2);
	memcpy (p_frame->current_word->item, active_word_buffer, string_length * 2);

	vqt_f_extent16 (vdi_handle, p_frame->current_word->item, pts);

	p_frame->current_word->word_width += pts[2] - pts[0];
}
