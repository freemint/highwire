#include <stdlib.h>
#include <string.h>

#include <gemx.h>

#include "global.h"

#ifndef LATTICE
#include "stptok.h"
#endif

#include <ctype.h>

RGB1000 screen_colortab[256]; /* used to save colors */


/* Saves colors in global array screen_colortab[] 
 *
 * Really for us this should be loading the standard palette
 * I'm just grabbing whatever the system has set
 */
void
save_colors(void)
{
	int i;
	WORD coltab[3];
	int res_colors;
	
	res_colors = (1 << planes); /* Doesn't work in truecolor modes, only planar */
  
	if (planes > 8)
  		res_colors = 256;
 
	for (i=0;i<res_colors;i++)
	{
		vq_color(vdi_handle,i,0,coltab);

		screen_colortab[i].red = coltab[0];
		screen_colortab[i].green = coltab[1];
		screen_colortab[i].blue = coltab[2];			
	}
}

WORD 
remap_color(long value)
{
	int ii = 0;
	int hit_color = 0;
	RGB1000 best; /* used to temp hold the difference best color match */
	int best_no = 0;   /* color index for best match */
	int res_colors = (1 << planes); /* Doesn't work in truecolor modes, only planar */
  
	unsigned char * rgb = (char*)&value;
	RGB1000  color;
	
	/* adjust color by 1000/256 */
	color.red   = ((short)rgb[1] *125) /32;
	color.green = ((short)rgb[2] *125) /32;
	color.blue  = ((short)rgb[3] *125) /32;

	if (planes > 8)
		res_colors = 256;
  	
/*printf("image red %d green %d blue %d\r\n",color.red,color.green,color.blue);
*/

	do
  	{
  		if ((color.red == screen_colortab[ii].red)&&
			(color.green == screen_colortab[ii].green)&&
			(color.blue == screen_colortab[ii].blue))
			{
				best_no = ii;
				hit_color = 1;
				break;
			}
				
		ii++;
  	}while(ii < res_colors);
	
	/* We didn't get an exact match, so approximate */
  	if(hit_color == 0)
  	{
		/* set best color match to 0*/
		best_no = 0;

		/* set initial differences to 1000, ensures that initial value is worst possible */
		best.red = 1000;
		best.green = 1000;
		best.blue = 1000;

		ii = 0;

		do
	  	{

			if (color.red > screen_colortab[ii].red)
			{
				if((color.red - screen_colortab[ii].red) <= best.red)
				{
					if (color.green > screen_colortab[ii].green)
					{
						if((color.green - screen_colortab[ii].green) <= best.green)
						{
							if (color.blue > screen_colortab[ii].blue)
							{
								if((color.blue - screen_colortab[ii].blue) <= best.blue)
								{
									best_no = ii;
									best.red = (color.red - screen_colortab[ii].red);
									best.green = (color.green - screen_colortab[ii].green);
									best.blue = (color.blue - screen_colortab[ii].blue);
								}
							}
							else
							{
								if((screen_colortab[ii].blue - color.blue) <= best.blue)
								{
									best_no = ii;
									best.red = (color.red - screen_colortab[ii].red);
									best.green = (color.green - screen_colortab[ii].green);
									best.blue = (screen_colortab[ii].blue - color.blue);
								}							
							}
						}
					}
					else
					{
						if((screen_colortab[ii].green - color.green) <= best.green)
						{
							if (color.blue > screen_colortab[ii].blue)
							{
								if((color.blue - screen_colortab[ii].blue) <= best.blue)
								{
									best_no = ii;
									best.red = (color.red - screen_colortab[ii].red);
									best.green = (screen_colortab[ii].green - color.green);
									best.blue = (color.blue - screen_colortab[ii].blue);
								}
							}
							else
							{
								if((screen_colortab[ii].blue - color.blue) <= best.blue)
								{
									best_no = ii;
									best.red = (color.red - screen_colortab[ii].red);
									best.green = (screen_colortab[ii].green - color.green);
									best.blue = (screen_colortab[ii].blue - color.blue);
								}							
							}
						}
					}
				}

			}
			else
			{
				if((screen_colortab[ii].red - color.red) <= best.red)
				{
					if (color.green > screen_colortab[ii].green)
					{
						if((color.green - screen_colortab[ii].green) <= best.green)
						{
							if (color.blue > screen_colortab[ii].blue)
							{
								if((color.blue - screen_colortab[ii].blue) <= best.blue)
								{
									best_no = ii;
									best.red = (screen_colortab[ii].red - color.red);
									best.green = (color.green - screen_colortab[ii].green);
									best.blue = (color.blue - screen_colortab[ii].blue);
								}
							}
							else
							{
								if((screen_colortab[ii].blue - color.blue) <= best.blue)
								{
									best_no = ii;
									best.red = (screen_colortab[ii].red - color.red);
									best.green = (color.green - screen_colortab[ii].green);
									best.blue = (screen_colortab[ii].blue - color.blue);
								}							
							}
						}
					}
					else
					{
						if((screen_colortab[ii].green - color.green) <= best.green)
						{
							if (color.blue > screen_colortab[ii].blue)
							{
								if((color.blue - screen_colortab[ii].blue) <= best.blue)
								{
									best_no = ii;
									best.red = (screen_colortab[ii].red - color.red);
									best.green = (screen_colortab[ii].green - color.green);
									best.blue = (color.blue - screen_colortab[ii].blue);
								}
							}
							else
							{
								if((screen_colortab[ii].blue - color.blue) <= best.blue)
								{
									best_no = ii;
									best.red = (screen_colortab[ii].red - color.red);
									best.green = (screen_colortab[ii].green - color.green);
									best.blue = (screen_colortab[ii].blue - color.blue);
								}							
							}
						}
					}
				}
			}

			ii++;
	  	}while(ii < res_colors);		

  	}	

/*printf("best red %d green %d blue %d\r\n",screen_colortab[best_no].red,screen_colortab[best_no].green,screen_colortab[best_no].blue);
*/
  return( best_no);
}
