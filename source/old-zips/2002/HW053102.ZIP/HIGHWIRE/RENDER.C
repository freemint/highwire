/* @(#)highwire/render.c
 */
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h> 

#include "token.h" /* must be included before gem/gemx.h */
#include <gemx.h>

#include "global.h"
#include "scanner.h"
#include "parser.h"
#include "Containr.h"
#include "Loader.h"
#include "Location.h"
#include "Logging.h"
#include "Table.h"


/* calculate end of paragraph space, eop_space */
#define EOP(a) ((a) * 2 / 3)

static WORD
convert_to_number (const char *text)
{
	char *next;
	long value;

	if (*text == '"')
		text++;

	value = strtol (text, &next, 0);

	/* XXX */
	if (next && *next == '%')
		value = -value;

	return value;
}


static UWORD
map (char symbol)
{
	if (symbol == ' ')
		return (Space_Code);

	return ((WORD) (symbol - 32));
}


static WORD
list_indent (WORD type)
{
	switch (type)
	{
		case 0:
			return (font_size * 2);
		case 1:
			return (font_size * 3);
		case 2:
			return (font_size * 4);
	}
	return (0);
}

/* obj_font_step()
 * 
 * bad name, handles reseting the font info when entering
 * and exiting an object like a table
 *
 * baldrick  May 31, 2002
 */

static void
obj_font_step(struct frame_item *p_frame, WORD font_step, BOOL start_tag)
{
	if (start_tag)
	{
		p_frame->current_font_step = add_step (p_frame->current_font_step);

		p_frame->current_font_step->step = font_size/3;

		p_frame->current.font_size = font_size;
		p_frame->current.word->styles.font_size = p_frame->current.font_size;
		p_frame->current.word->changed.font = TRUE;
		p_frame->current_font_step->colour 	  = p_frame->text_colour;
	}
	else
	{
		p_frame->current_font_step = destroy_step(p_frame->current_font_step);
		p_frame->current.font_size = p_frame->current_font_step->step * font_step;
		p_frame->current.word->styles.font_size = p_frame->current.font_size;
		p_frame->current.word->colour = p_frame->current_font_step->colour; /*p_frame->text_colour;*/
		p_frame->current.word->changed.colour = TRUE;
		p_frame->current.word->changed.font = TRUE;
	}
}


/* set_pre_font()
 *
 * just a couple of lines that modify the current font to being 
 * the PRE font.
 * Used in numerous places
 *
 *  current_word is the current_word
 */

static void
set_pre_font(struct word_item *current_word, BOOL start_tag)
{
	if (start_tag)
		current_word->styles.font = pre_font;
	else
		current_word->styles.font = normal_font;

	current_word->changed.font = TRUE;
}


/* set_font_bold
 *
 * changes the value of the BOLD status of a word
 *
 * current_word  = current word
 * start_tag determines operation
 *    if TRUE add to bold
 *    if not TRUE subtract from bold
 */

static void
set_font_bold(struct word_item *current_word, BOOL start_tag)
{
	if (start_tag)
	{
		current_word->styles.bold++;

		if (current_word->styles.bold == 1)
			current_word->changed.font = TRUE;
	}
	else
	{
		if (current_word->styles.bold > 0)
			current_word->styles.bold--;

		if(current_word->styles.bold == 0)
			current_word->changed.font = TRUE;
	}
}


/* set_font_italic()
 *
 * changes the value of the Italic status of a word
 *
 * current_word = current word
 * start_tag determines operation
 *    if TRUE add to italic
 *    if not TRUE subtract from italic
 */

static void
set_font_italic(struct word_item *current_word, BOOL start_tag)
{
	if (start_tag)
	{
		current_word->styles.italic++;

		if (current_word->styles.italic == 1)
			current_word->changed.font = TRUE;
	}
	else
	{
		if (current_word->styles.italic > 0)
			current_word->styles.italic--;

		if (current_word->styles.italic == 0)
			current_word->changed.font = TRUE;
	}
}


/* set_font_strike()
 *
 * changes the value of the Strike status of a word
 *
 * current_word = current word
 * start_tag determines operation
 *    if TRUE add to strike
 *    if not TRUE subtract from strike
 */

static void
set_font_strike(struct word_item *current_word, BOOL start_tag)
{
	if (start_tag)
	{
		current_word->styles.strike++;
		current_word->changed.style = TRUE;
	}
	else
	{
		if (current_word->styles.strike != 0)
			current_word->styles.strike--;

		current_word->changed.style = TRUE;
	}
}


/* set_font_underline()
 *
 * changes the value of the underlined status of a word
 *
 * current_word = current word
 * start_tag determines operation
 *    if TRUE add to underline
 *    if not TRUE subtract from underline
 */

static void
set_font_underline(struct word_item *current_word, BOOL start_tag)
{
	if (start_tag)
	{
		current_word->styles.underlined++;
		current_word->changed.style = TRUE;
	}
	else
	{
		if (current_word->styles.underlined != 0)
			current_word->styles.underlined--;

		current_word->changed.style = TRUE;
	}
}


/* set_center_text()
 *
 * changes the value of paragraphs alignment
 *
 * start_tag determines operation
 *    if TRUE center text
 *    if not TRUE left justify text
 */

static void
set_center_text(struct frame_item *p_frame, BOOL start_tag)
{
	add_paragraph (&p_frame->current);

	if (start_tag)
		p_frame->current.paragraph->alignment = ALN_CENTER;
	else
	{
		if (p_frame->TableStack)
			p_frame->current.paragraph->alignment = p_frame->TableStack->WorkCell->Paragraph->alignment;
		else
			p_frame->current.paragraph->alignment   = ALN_LEFT;
	}
}


/* parse_blockquote_tag()
 *
 * A block quotation is a special paragraph, that consists of citated text.
 * A HTML browser can indent, surround with quotation marks, or use italic for
 * this paragraph.
 * http://purl.org/ISO+IEC.15445/Users-Guide.html#blockquote
 */

static void
parse_blockquote_tag(struct frame_item *p_frame, BOOL start_tag)
{
	p_frame->current.paragraph->eop_space = EOP(p_frame->current.font_size);
	add_paragraph (&p_frame->current);

	if (start_tag)
	{
		#if 1
		/* BUG: TITLE support not ready.  This try leads to another problem:
		 * We need the entity and encoding conversion as a separate function.
		 * Or we do it complete before parsing.  But then PLAINTEXT is not
		 * possible.  It seems, this is this the reason, why it's deprecated. */
		char output[100];
		WORD u, distances[5], effects[3];
		#endif

		p_frame->current.paragraph->alignment = ALN_LEFT;
		p_frame->current.paragraph->Indent += list_indent (2);
		p_frame->current.paragraph->Rindent += list_indent (2);

		#if 1
		if (get_value(KEY_TITLE, output, sizeof(output))) {
			set_font_bold(p_frame->current.word, TRUE);
			if (p_frame->current.word->changed.font) {
				vst_font(vdi_handle,
				         fonts[p_frame->current.word->styles.font]
				         [p_frame->current.word->styles.bold != FALSE]
				         [p_frame->current.word->styles.italic != FALSE]);
				vst_arbpt(vdi_handle, p_frame->current.word->styles.font_size, &u, &u, &u, &u);
				vqt_fontinfo(vdi_handle, &u, &u, distances, &u, effects);
				vqt_advance(vdi_handle, Space_Code,
				            &p_frame->current.word->space_width, &u, &u, &u);
				p_frame->current.word->word_height = distances[3];
				p_frame->current.word->word_tail_drop = distances[1];
			}
			scan_string_to_16bit(output, p_frame->Location->encoding, &p_frame->current.text);
			p_frame->current.paragraph->eop_space = EOP(p_frame->current.font_size);
			add_paragraph(&p_frame->current);
			set_font_bold(p_frame->current.word, FALSE);
		}
		#endif
	}
	else
	{
		p_frame->current.paragraph->Indent -= list_indent(2);
		p_frame->current.paragraph->Rindent -= list_indent(2);
	}
}


/* parse anchor
 * ideally you drop the input on this routine
 * and it parses and processes the anchor tag information
 * baldrick - December 3, 2001
 */

static void
parse_anchor (struct frame_item *p_frame, BOOL start_tag)
{
	struct word_item * word = p_frame->current.word;

	if (start_tag)
	{
		char * output;

		if ((output = get_value_str (KEY_HREF)) != NULL)
		{
			char out2[30];
			
			char * target = get_value_str (KEY_TARGET);
			if (!target && p_frame->base_target) {
				target = strdup (p_frame->base_target);
			}
			word->colour = p_frame->link_colour;
			word->changed.colour = TRUE;
			set_font_underline (word, TRUE);

			word->link = new_url_link (output, TRUE, target);
			
			/* Asume ENCODING_WINDOWS1252, which is commen practice. */
			word->link->encoding = ENCODING_WINDOWS1252;
			if (get_value(KEY_CHARSET, out2, sizeof(out2))) {
				if (stricmp(out2, "ISO-8859-2") == 0)
					word->link->encoding = ENCODING_ISO8859_2;
				else if (stricmp(out2, "UTF-8") == 0)
					word->link->encoding = ENCODING_UTF8;
				else if (stricmp(out2, "atarist") == 0)
					word->link->encoding = ENCODING_ATARIST;
			}
		}
		else if ((output = get_value_str (KEY_NAME)) != NULL
		         || (output = get_value_str (KEY_ID)) != NULL)
		{
			word->link = new_url_link (output, FALSE, NULL);
			word->link->u.anchor = new_named_location (word->link->address,
			                            p_frame->current.paragraph->Offset.Origin);
			*p_frame->current.anchor = word->link->u.anchor;
			p_frame->current.anchor  = &word->link->u.anchor->next_location;
		}	
	}
	else if (word->link && word->link->isHref)
	{
		/* only the closing tag of a href=link need to be handled */
		
		word->colour = p_frame->current_font_step->colour;
		word->changed.colour = TRUE;
		set_font_underline (word, FALSE);
		word->link = NULL;
	}
}


static void
parse_base (struct frame_item *p_frame)
{
	p_frame->base_target = get_value_str (KEY_TARGET);
}


/* parse body tag
 * ideally you drop the input on this routine
 * and it parses and processes the body tag information
 *
 * baldrick - December 3, 2001
 *
 * modifications for new color routines
 * AltF4 - December 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 */

static void
parse_body (struct frame_item *p_frame)
{
	if (!ignore_colours)
	{
		WORD color;

		if ((color = get_value_color (KEY_TEXT)) >= 0)
		{
			p_frame->text_colour = p_frame->current_font_step->colour = color;
			p_frame->current.word->colour = p_frame->current_font_step->colour; 
		}
		if ((color = get_value_color (KEY_BGCOLOR)) >= 0)
		{
			p_frame->background_colour = p_frame->current.backgnd = color;
		}
		if ((color = get_value_color (KEY_LINK)) >= 0)
		{
			p_frame->link_colour = color;
		}
	}
}



/* parse_d_tags()
 *
 * processes the d tags DL, DT, DD
 *
 * type determines the type of d tag
 *    0 = DL tag
 *    1 = DT tag
 *    2 = DD tag
 */


static void
parse_d_tags (struct frame_item *p_frame, WORD type, BOOL start_tag)
{
	PARAGRPH paragraph = add_paragraph (&p_frame->current);
	static WORD dd_indent;

	paragraph->alignment = ALN_LEFT;

	if (start_tag)
	{
		if (type == 0)       /* dl tag start */
			dd_indent = paragraph->Indent += list_indent (2);
		else if (type == 1)  /* dt tag start */
		{
			if (paragraph->Indent > 0)
				paragraph->Indent -= list_indent (2);
		}
		else if (type == 2)  /* dd tag start */
			paragraph->Indent = dd_indent;
	}
	else
	{
		if (type == 0) /* dl tag end */
		{
			paragraph->eop_space = p_frame->current.font_size;

			paragraph->Indent -= list_indent(2);
		}
	}
}


/* parse DIV tag
 * ideally you drop the input on this routine
 * and it parses and processes the DIV tag information
 *
 * DIV is only partially implemented from my understanding
 * baldrick - December 14, 2001
 */

static void
parse_div_tag(struct frame_item *p_frame, BOOL start_tag)
{
	if (start_tag)
	{
		PARAGRPH paragraph = p_frame->current.paragraph;

		paragraph->eop_space = EOP(p_frame->current.font_size);

		paragraph = add_paragraph (&p_frame->current);

		switch (toupper (get_value_char (KEY_ALIGN)))
		{
			case 'R': paragraph->alignment = ALN_RIGHT;  break;
			case 'C': paragraph->alignment = ALN_CENTER; break;
			case 'L': paragraph->alignment = ALN_LEFT;   break;
		}
	}
	else
	{
		add_paragraph(&p_frame->current)->alignment = ALN_LEFT;
	}
}


/* parse font tag
 * ideally you drop the input on this routine
 * and it parses and processes the font tag information
 *
 * baldrick - December 14, 2001
 *
 * color handling modified to new routines
 * AltF4 - Dec 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 *
 * Baldrick - March 1, 2002: modifications to always store a font step
 *            so that we don't loose our size on complex sites
 */


static void
parse_font_tag(struct frame_item *p_frame, WORD fontstep, BOOL start_tag)
{
	char output[100];
	struct font_step *old;

	if (start_tag)
	{
		old = p_frame->current_font_step;

		p_frame->current_font_step = add_step (p_frame->current_font_step);

		if (get_value (KEY_SIZE, output, sizeof(output)))
		{
			if (*output == '+' || *output == '-')
			{
				p_frame->current_font_step->step += convert_to_number (output);
			}
			else
			{
				p_frame->current_font_step->step = convert_to_number (output);
			}

			if (p_frame->current_font_step->step < 3)                        
				p_frame->current.font_size = (p_frame->current_font_step->step * 3)
				                           + (6 - p_frame->current_font_step->step);
			else
				p_frame->current.font_size = (p_frame->current_font_step->step * 3)
				                           + 3;
			p_frame->current.word->styles.font_size = p_frame->current.font_size;
			p_frame->current.word->changed.font = TRUE;
		}
		else
		{
			/* no font size here, so copy last or we will lose it */

			p_frame->current_font_step->step = old->step;
		}

		if (!ignore_colours)
		{
			WORD color = get_value_color (KEY_COLOR);
			if (color >= 0)
			{
				p_frame->current.word->colour         = color;
				p_frame->current_font_step->colour 	  = color;
				p_frame->current.word->changed.colour = TRUE;
			}
			else
				p_frame->current_font_step->colour 	  = p_frame->text_colour;
		}
		else
			p_frame->current_font_step->colour 	  = p_frame->text_colour;
	}
	else
	{
		p_frame->current_font_step = destroy_step(p_frame->current_font_step);
		p_frame->current.font_size = p_frame->current_font_step->step * fontstep;
		p_frame->current.word->styles.font_size = p_frame->current.font_size;
		p_frame->current.word->colour = p_frame->current_font_step->colour; /*p_frame->text_colour;*/
		p_frame->current.word->changed.colour = TRUE;
		p_frame->current.word->changed.font = TRUE;
	}
}

#if 0
static void
parse_font_tag(struct frame_item *p_frame, WORD fontstep, BOOL start_tag)
{
	char output[100];

	if (start_tag)
	{
		p_frame->current_font_step = add_step (p_frame->current_font_step);

		if (get_value (KEY_SIZE, output, sizeof(output)))
		{
			if (*output == '+' || *output == '-')
			{
				p_frame->current_font_step->step += convert_to_number (output);
			}
			else
			{
				p_frame->current_font_step->step = convert_to_number (output);
			}
			p_frame->current.font_size = p_frame->current_font_step->step * fontstep;
			p_frame->current.word->styles.font_size = p_frame->current.font_size;
			p_frame->current.word->changed.font = TRUE;
		}

		if (!ignore_colours)
		{
			WORD color = get_value_color (KEY_COLOR);
			if (color >= 0)
			{
				p_frame->current.word->colour         = color;
				p_frame->current_font_step->colour 	  = color;
				p_frame->current.word->changed.colour = TRUE;
			}
			else
				p_frame->current_font_step->colour 	  = p_frame->text_colour;
		}
		else
			p_frame->current_font_step->colour 	  = p_frame->text_colour;
	}
	else
	{
		p_frame->current_font_step = destroy_step(p_frame->current_font_step);
		p_frame->current.font_size = p_frame->current_font_step->step * fontstep;
		p_frame->current.word->styles.font_size = p_frame->current.font_size;
		p_frame->current.word->colour = p_frame->current_font_step->colour; /*p_frame->text_colour;*/
		p_frame->current.word->changed.colour = TRUE;
		p_frame->current.word->changed.font = TRUE;
	}
}
#endif

/* parse header tag
 * ideally you drop the input on this routine
 * and it parses and processes the header tag information
 *
 * baldrick - August 20, 2001
 * mj - added strupr and 'j' - 10-01-01
 */

static void
parse_header_tag(struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current = &p_frame->current;
	WORD     size    = 0;

	if (start_tag)
	{
		if ((!p_frame->current_list)||(p_frame->current.paragraph->item->word_width > 0))
		{
			current->paragraph->eop_space = EOP(current->font_size);

			add_paragraph (current);

			switch (toupper (get_value_char (KEY_ALIGN)))
			{
				case 'R':
					current->paragraph->alignment = ALN_RIGHT;
					break;
				case 'C':
					current->paragraph->alignment = ALN_CENTER;
					break;
				case 'J':
				case 'L':
					current->paragraph->alignment = ALN_LEFT;
			}
		}
		
		current->word->styles.font = header_font;

		switch (get_value_char (KEY_H_HEIGHT))
		{
			case '1':
				size = current->font_size * 2;
				break;
			case '2':
				size = current->font_size + (current->font_size / 2);
				break;
			case '3':
				size = current->font_size + (current->font_size / 4);
				break;
			case '4':
				size = current->font_size;
				break;
			case '5':
				size = current->font_size - (current->font_size / 5);
				break;
			case '6':
				size = current->font_size - (current->font_size / 3);
				break;
		}
		current->word->styles.font_size = size;
		current->word->styles.bold++;
		current->word->changed.font = TRUE;
	}
	else
	{
		add_paragraph (current);
		
		if (p_frame->TableStack)
			current->paragraph->alignment = p_frame->TableStack->WorkCell->Paragraph->alignment;
		else
			current->paragraph->alignment   = ALN_LEFT;
		current->word->styles.font      = normal_font;
		current->word->styles.font_size = current->font_size;
		current->word->styles.bold      = 0;
		current->word->changed.font     = TRUE;
	}
}


/* parse MENU tag
 * ideally you drop the input on this routine
 * and it parses and processes the MENU tag information
 *
 * it's also possible that we could map this onto parse_ul
 * baldrick - December 13, 2001
 */

static void
parse_menu_tag (struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current = &p_frame->current;
	struct list_stack_item *temp_list_holder;

	if (start_tag)
	{
		/* detect if this becomes a nested list just behind a <li> tag
		 * to apply a negative offset to the actual paragraph of the
		 * nesting (outer) list.
		*/
		if (p_frame->current_list
		    && p_frame->current_list->line_start == p_frame->current.word)
			current->paragraph->eop_space = -current->word->word_height;
		else
			current->paragraph->eop_space = EOP(current->font_size);

		add_paragraph (current);

		current->paragraph->alignment = ALN_LEFT;
		current->paragraph->Indent += list_indent (0);

		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item =	p_frame->current_list;

		if (p_frame->current_list)
			temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;

		temp_list_holder->Indent = current->paragraph->Indent;

		p_frame->current_list = temp_list_holder;
	}
	else if (p_frame->current_list)
	{
		current->paragraph->eop_space += current->font_size / 3;

		add_paragraph (current);

		current->paragraph->Indent = p_frame->current_list->Indent;

		p_frame->current_list = p_frame->current_list->next_stack_item;
		current->paragraph->Indent -= list_indent(0);
	}

}


/* Parse META tag in <HEAD>...</HEAD>.
 * Ideally you drop the input on this routine
 * and it parses and processes the META tag information.
 *
 * Rainer Seitel, 2002-03-18
 */
static void
parse_meta_tag(struct frame_item *p_frame)
{
	char output[100];
	char *p;
	extern ENCODING last_encoding;  /* from Loader.c */

	/* Note: KEY_HTTP_EQUIV corresponds to "HTTP-EQUIV"! */
	if (get_value(KEY_HTTP_EQUIV, output, sizeof(output))) {
		if (stricmp(output, "Content-Type") == 0) {
			if (get_value(KEY_CONTENT, output, sizeof(output))
			   && (p = strstr(strupr(output), "CHARSET=")) != NULL) {
				p += 8;
				if (stricmp(p, "ISO-8859-1") == 0 || stricmp(p, "windows-1252") == 0)
					p_frame->Location->encoding = ENCODING_WINDOWS1252;
				else if (stricmp(p, "ISO-8859-2") == 0)
					p_frame->Location->encoding = ENCODING_ISO8859_2;
				else if (stricmp(p, "UTF-8") == 0)
					p_frame->Location->encoding = ENCODING_UTF8;
				else if (stricmp(p, "atarist") == 0)
					p_frame->Location->encoding = ENCODING_ATARIST;
				last_encoding = p_frame->Location->encoding;  /* used for Undo key */
				/* http://www.iana.org/assignments/character-sets */
			}
		}
	}
}


/* parse P tag
 * ideally you drop the input on this routine
 * and it parses and processes the P tag information
 *
 * baldrick - December 14, 2001
 *
 * BUG: We must ignore empty paragraphs. Else <LI><P>...</P><P>...</P></LI>
 * looks bad. Vertical space is made by <P>&nbsp;</P>.
 * Rainer Seitel, 2002-03-16
 *
 * don't add new paragraph and ignore alignment if we have a <P>
 * at the start of a list item
 */

static void
parse_p_tag(struct frame_item *p_frame)
{
	PARAGRPH par = p_frame->current.paragraph;
	char     buf[8];

	if ((!p_frame->current_list)||(p_frame->current.paragraph->item->word_width > 0))
	{
		par->eop_space = EOP(p_frame->current.font_size);

		par = add_paragraph (&p_frame->current);

		if (get_value (KEY_ALIGN, buf, sizeof(buf))) {
			if      (stricmp (buf, "right")   == 0) par->alignment = ALN_RIGHT;
			else if (stricmp (buf, "center")  == 0) par->alignment = ALN_CENTER;
			else if (stricmp (buf, "justify") == 0) par->alignment = ALN_JUSTIFY;
			else 									par->alignment = ALN_LEFT;
		}
	}
}


/* parse Q tag
 * Language dependent quotation marks.
 * Source: The Unicode Standard Version 3.0, section 6.1.
 * BUG: Should work for nested quotes, alternating double and single.
 * BUG: Must use LANG set elsewere as default.
 *
 * Rainer Seitel, 2002-03-29
 */
static void parse_q_tag(UWORD **text, BOOL start_tag)
{
	static LANGUAGE language = LANG_EN;
	char buf[6];

	if (get_value(KEY_LANG, buf, sizeof(buf))) {
		strlwr(buf);
		language = *((UWORD *)buf);
	}
	switch (language) {
		case LANG_CS:  /* Czech, German, Slovak */
		case LANG_DE:
		case LANG_SK:
			if (start_tag) {
				**text = 107;  /* U+201E DOUBLE LOW-9 QUOTATION MARK */
				++*text;
			} else {
				**text = 104;  /* U+201C LEFT DOUBLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_FR:  /* French, Greek, Russian */
		case LANG_EL:
		case LANG_RU:
			if (start_tag) {
				**text = 125;  /* U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			} else {
				**text = 126;  /* U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_HU:  /* Hungarian, Polish */
		case LANG_PL:
			if (start_tag) {
				**text = 107;  /* U+201E DOUBLE LOW-9 QUOTATION MARK */
				++*text;
			} else {
				**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_SL:  /* Slovenian */
			if (start_tag) {
				**text = 126;  /* U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			} else {
				**text = 125;  /* U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_DA:  /* Danish, Finnish, Norwegian, Swedish */
		case LANG_FI:
		case LANG_NO:
		case LANG_SV:
			**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
			++*text;
			break;
		default:  /* else Dutch, English, Italian, Portuguese, Spanish, Turkish quotes */
			if (start_tag) {
				**text = 104;  /* U+201C LEFT DOUBLE QUOTATION MARK */
				++*text;
			} else {
				**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
				++*text;
			}
	}
}


/* Recursively converts a positive long to a decimal number wide string.
 * Rainer Seitel, 2002-03-11
 */
static void long2decimal(UWORD **p_ws, long l)
{
	if (l >= 10)
		long2decimal(p_ws, l / 10);

	**p_ws = map((l % 10) + '0');
	(*p_ws)++;
}


/* Recursively converts a positive long to an alphabet number wide string.
 * Rainer Seitel, 2002-03-11
 */
static void long2alpha(UWORD **p_ws, long l, BOOL upper)
{
	if (l > 26)
		long2alpha(p_ws, l / 26, upper);

	**p_ws = map(((l - 1) % 26) + (upper? 'A' : 'a'));
	(*p_ws)++;
}


static struct word_item *
list_marker (struct frame_item *p_frame)
{
	UWORD * active_word = p_frame->current.text;
	WORD indent_type = 0;
	WORD               count   = p_frame->current_list->current_list_count;
	struct word_item * li_word = p_frame->current.word;

	switch (p_frame->current_list->bullet_style)
	{
		case disc:
			*(active_word++) = 342;  /* U+2022 BULLET */
			indent_type = 0;
			break;
		case square:
			*(active_word++) = 507;  /* U+25AA BLACK SMALL SQUARE */
			indent_type = 0;
			break;
		case circle:
			*(active_word++) = 499;  /* U+25E6 WHITE BULLET */
			indent_type = 0;
			break;
		case Number:
			if (count < 0) {
				*(active_word++) = 283;  /* U+2212 MINUS SIGN */
				count = -count;
			}
			long2decimal(&active_word, count);
			*(active_word++) = 14;  /* U+002E . */
			*(active_word++) = 562;  /* U+2002 EM SPACE */
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case alpha:
			if (count != 0) {
				if (count < 0) {
					*(active_word++) = 283;  /* U+2212 MINUS SIGN */
					count = -count;
				}
				long2alpha(&active_word, count, FALSE);
				*(active_word++) = 14;  /* U+002E . */
				*(active_word++) = 562;  /* U+2002 EM SPACE */
				p_frame->current_list->current_list_count++;
				indent_type = 1;
				break;
			}
			/* else use @ as small alphabet zero */
		case Alpha:
			if (count < 0) {
				*(active_word++) = 283;  /* U+2212 MINUS SIGN */
				count = -count;
			}
			long2alpha(&active_word, count, TRUE);
			*(active_word++) = 14;  /* U+002E . */
			*(active_word++) = 562;  /* U+2002 EM SPACE */
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case roman:
			if (count > 0 && count < 3000) {
				switch (count / 1000 * 1000) {
				case 2000:
					*(active_word++) = map('m');
				case 1000:
					*(active_word++) = map('m');
					break;
				}
				switch ((count % 1000) / 100 * 100) {
				case 300:
					*(active_word++) = map('c');
				case 200:
					*(active_word++) = map('c');
				case 100:
					*(active_word++) = map('c');
					break;
				case 400:
					*(active_word++) = map('c');
				case 500:
					*(active_word++) = map('d');
					break;
				case 600:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					break;
				case 700:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					break;
				case 800:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					break;
				case 900:
					*(active_word++) = map('c');
					*(active_word++) = map('m');
					break;
				}
				switch ((count % 100) / 10 * 10) {
				case 30:
					*(active_word++) = map('x');
				case 20:
					*(active_word++) = map('x');
				case 10:
					*(active_word++) = map('x');
					break;
				case 40:
					*(active_word++) = map('x');
				case 50:
					*(active_word++) = map('l');
					break;
				case 60:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					break;
				case 70:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					break;
				case 80:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					break;
				case 90:
					*(active_word++) = map('x');
					*(active_word++) = map('c');
					break;
				}
				switch (count % 10) {
				case 3:
					*(active_word++) = map('i');
				case 2:
					*(active_word++) = map('i');
				case 1:
					*(active_word++) = map('i');
					break;
				case 4:
					*(active_word++) = map('i');
				case 5:
					*(active_word++) = map('v');
					break;
				case 6:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					break;
				case 7:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					break;
				case 8:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					break;
				case 9:
					*(active_word++) = map('i');
					*(active_word++) = map('x');
					break;
				}
			} else {  /* BUG: small Roman numerals >= 3000 not implemented! */
				long2decimal(&active_word, count);
			}
			*(active_word++) = 14;  /* U+002E . */
			*(active_word++) = 562;  /* U+2002 EM SPACE */
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case Roman:
			/* Sources:
			 * Friedlein, Gottfried: Die Zahlzeichen und das elementare Rechnen
			 * der Griechen und R�mer und des christlichen Abendlandes vom 7.
			 * bis 13. Jahrhundert. - unver�nderter Neudruck der Ausgabe von
			 * 1869. - Wiesbaden : Dr. Martin S�ndig oHG, 1968.
			 * Ifroh, Georges: Universalgeschichte der Zahlen. - Frankfurt am
			 * Main ; New York : Campus, 1986. - ISBN 3-593-33666-9. - Kapitel
			 * 9. (Histoire Universelle des Chiffres. - Paris : Seghers, 1981.)
			 * Rainer Seitel, 2002-03-11
			 */
			if (count > 0 && count < 20000) {
				if (count >= 10000) {
					*(active_word++) = map('(');
					*(active_word++) = map('(');
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
				}
				switch ((count % 10000) / 1000 * 1000) {
				case 9000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 8000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 7000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 6000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					break;
				case 5000:
					*(active_word++) = map('M');
				case 4000:
					*(active_word++) = map('M');
				case 3000:
					*(active_word++) = map('M');
				case 2000:
					*(active_word++) = map('M');
				case 1000:
					*(active_word++) = map('M');
					break;
				}
				switch ((count % 1000) / 100 * 100) {
				case 300:
					*(active_word++) = map('C');
				case 200:
					*(active_word++) = map('C');
				case 100:
					*(active_word++) = map('C');
					break;
				case 400:
					*(active_word++) = map('C');
				case 500:
					*(active_word++) = map('D');
					break;
				case 600:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					break;
				case 700:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					break;
				case 800:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					break;
				case 900:
					*(active_word++) = map('C');
					*(active_word++) = map('M');
					break;
				}
				switch ((count % 100) / 10 * 10) {
				case 30:
					*(active_word++) = map('X');
				case 20:
					*(active_word++) = map('X');
				case 10:
					*(active_word++) = map('X');
					break;
				case 40:
					*(active_word++) = map('X');
				case 50:
					*(active_word++) = map('L');
					break;
				case 60:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					break;
				case 70:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					break;
				case 80:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					break;
				case 90:
					*(active_word++) = map('X');
					*(active_word++) = map('C');
					break;
				}
				switch (count % 10) {
				case 3:
					*(active_word++) = map('I');
				case 2:
					*(active_word++) = map('I');
				case 1:
					*(active_word++) = map('I');
					break;
				case 4:
					*(active_word++) = map('I');
				case 5:
					*(active_word++) = map('V');
					break;
				case 6:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					break;
				case 7:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					break;
				case 8:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					break;
				case 9:
					*(active_word++) = map('I');
					*(active_word++) = map('X');
					break;
				}
			} else {  /* BUG: Roman numerals >= 20000 not implemented! */
				long2decimal(&active_word, count);
			}
			*(active_word++) = 14;  /* U+002E . */
			*(active_word++) = 562;  /* U+2002 EM SPACE */
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
	}

	p_frame->current.text = active_word;
	add_word (&p_frame->current);
	/* a tabular width, but at least enough space for large numbers */
	if (li_word->word_width < list_indent (indent_type))
		li_word->word_width = list_indent (indent_type);

	return p_frame->current.word;
}


/* parse LI tag
 * ideally you drop the input on this routine
 * and it parses and processes the LI tag information
 *
 * baldrick - December 12, 2001
 */

static void
parse_li_tag(struct frame_item *p_frame, WORD fontstep)
{
	WORD u;
	WORD value = get_value_unum (KEY_VALUE, -1); /* BUG: long! */
	WORD temp_eop;
	TEXTBUFF current   = &p_frame->current;
	PARAGRPH old_p;
	struct word_item *old_word = current->word;

	/* this basically just catches that it's not the first LI in a list */
	if (p_frame->current.paragraph->Indent != p_frame->current_list->Indent)
	{
		add_paragraph (&p_frame->current);

		p_frame->current.paragraph->Indent = p_frame->current_list->Indent;
	}

	if  (value >= 0)
		p_frame->current_list->current_list_count = value;

	switch (get_value_char (KEY_TYPE))
	{
		case 'a':
			p_frame->current_list->bullet_style = alpha;
			break;
		case 'A':
			p_frame->current_list->bullet_style = Alpha;
			break;
		case 'i':
			p_frame->current_list->bullet_style = roman;
			break;
		case 'I':
			p_frame->current_list->bullet_style = Roman;
			break;
		case '1':
			p_frame->current_list->bullet_style = Number;
			break;
		case 'd':
		case 'D':
			p_frame->current_list->bullet_style = disc;
			break;
		case 'c':
		case 'C':
			p_frame->current_list->bullet_style = circle;
			break;
		case 's':
		case 'S':
			p_frame->current_list->bullet_style = square;
			break;
	}

	temp_eop = p_frame->current.word->styles.font_size = 2 * fontstep;
	vst_arbpt (vdi_handle, p_frame->current.word->styles.font_size, &u, &u, &u, &u);
	p_frame->current.word->changed.font = TRUE;

	old_word = p_frame->current.word;

	p_frame->current_list->line_start = list_marker (p_frame);

	p_frame->current.paragraph->eop_space =  -((2 * temp_eop) + EOP(temp_eop) );

	old_p = p_frame->current.paragraph;

	add_paragraph (&p_frame->current);

	p_frame->current.paragraph->alignment = ALN_LEFT;

	p_frame->current.paragraph->Indent = old_p->Indent + old_word->word_width;

	p_frame->current.word->styles.font_size = p_frame->current_font_step->step * fontstep;
	vst_arbpt (vdi_handle, p_frame->current.word->styles.font_size, &u, &u, &u, &u);
	p_frame->current.word->changed.font = TRUE;

}

/* parse OL tag
 * ideally you drop the input on this routine
 * and it parses and processes the OL tag information
 *
 * baldrick - December 12, 2001
 */

static void
parse_ol_tag (struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current   = &p_frame->current;
	PARAGRPH paragraph = current->paragraph;
	struct list_stack_item *temp_list_holder;

	if (start_tag)
	{
		/* detect if this becomes a nested list just behind a <li> tag
		 * to apply a negative offset to the actual paragraph of the
		 * nesting (outer) list.
		*/
		if (p_frame->current_list
		    && p_frame->current_list->line_start == p_frame->current.word)
			paragraph->eop_space = -current->word->word_height;
		else
			paragraph->eop_space = EOP(current->font_size);

		paragraph = add_paragraph (current);

		if (p_frame->current_list)
			paragraph->Indent = p_frame->current_list->Indent;

		paragraph->alignment = ALN_LEFT;
		paragraph->Indent += list_indent(1);
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = p_frame->current_list;

		temp_list_holder->Indent = paragraph->Indent;

		p_frame->current_list = temp_list_holder;

		switch (get_value_char (KEY_TYPE))
		{
			case 'a':
				p_frame->current_list->bullet_style = alpha;
				break;
			case 'A':
				p_frame->current_list->bullet_style = Alpha;
				break;
			case 'i':
				p_frame->current_list->bullet_style = roman;
				break;
			case 'I':
				p_frame->current_list->bullet_style = Roman;
				break;
			default:
				p_frame->current_list->bullet_style = Number;
		}

		p_frame->current_list->current_list_count = get_value_unum (KEY_START, 1);  /* BUG: long! */
	}
	else if (p_frame->current_list)
	{
		paragraph->eop_space += current->font_size / 3;

		paragraph = add_paragraph (current);

		paragraph->Indent = p_frame->current_list->Indent;

		p_frame->current_list = remove_stack_item (p_frame->current_list);
		paragraph->Indent -= list_indent(1);
	}
}


/* parse UL tag
 * ideally you drop the input on this routine
 * and it parses and processes the UL tag information
 * baldrick - December 12, 2001
 */

static void
parse_ul_tag (struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current   = &p_frame->current;
	PARAGRPH paragraph = current->paragraph;
	struct list_stack_item *temp_list_holder;

	if (start_tag)
	{
		/* detect if this becomes a nested list just behind a <li> tag
		 * to apply a negative offset to the actual paragraph of the
		 * nesting (outer) list.
		*/
		if (p_frame->current_list
		    && p_frame->current_list->line_start == p_frame->current.word)
			paragraph->eop_space = -current->word->word_height;
		else
			paragraph->eop_space = EOP(current->font_size);

		paragraph = add_paragraph (current);

if (p_frame->current_list)
	paragraph->Indent = p_frame->current_list->Indent;

		paragraph->alignment = ALN_LEFT;
		paragraph->Indent += list_indent (0);

		temp_list_holder = new_stack_list_item();
		temp_list_holder->next_stack_item = p_frame->current_list;

		switch (get_value_char (KEY_TYPE))
		{
			case 'S':
			case 's':
				temp_list_holder->bullet_style = square;
				break;
			case 'c':
			case 'C':
				temp_list_holder->bullet_style = circle;
				break;
			case 'd':
			case 'D':
				temp_list_holder->bullet_style = disc;
			default:
				if (p_frame->current_list)
					temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;
		}

/* test */
temp_list_holder->Indent = paragraph->Indent;

		p_frame->current_list = temp_list_holder;
	}
	else if (p_frame->current_list)
	{
		paragraph->eop_space += current->font_size / 3;

		paragraph = add_paragraph (&p_frame->current);

/* test */
paragraph->Indent = p_frame->current_list->Indent;

		p_frame->current_list = remove_stack_item (p_frame->current_list);
		paragraph->Indent -= list_indent(0);
	}
}


/* parse hr tag
 * ideally you drop the input on this routine
 * and it parses and processes the hr tag information
 *
 * baldrick - December 5, 2001
 */

static void
parse_hr_tag (struct frame_item *p_frame)
{
	TEXTBUFF current = &p_frame->current;
	char output[100];

	p_frame->current.paragraph->eop_space = EOP(current->font_size);
	add_paragraph(current)->paragraph_code = PAR_HR;

	switch (toupper (get_value_char (KEY_ALIGN)))
	{
		case 'R':
			current->paragraph->eop_space = 2;
			break;
		case 'C':
			current->paragraph->eop_space = 1;
			break;
		default:
			current->paragraph->eop_space = 0;
	}

	if (get_value (KEY_WIDTH, output, sizeof(output)))
		current->word->word_width = convert_to_number(output);
	else
		current->word->word_width = -100;

	if (get_value (KEY_SIZE, output, sizeof(output)))
		current->word->word_height = convert_to_number(output);
	else
		current->word->word_height = 2;

	if (get_value (KEY_NOSHADE, NULL,0))
		current->word->word_height = -p_frame->current.word->word_height;

	add_paragraph (current);

	current->word->changed.font = TRUE;
}


/* parse img tag
 * ideally you drop the input on this routine
 * and it parses and processes the img tag information
 *
 * baldrick - Dec 4, 2001
 */

static void
parse_img_tag(struct frame_item *p_frame)
{
	TEXTBUFF current = &p_frame->current;
	struct word_item * word;
	short align;
	short word_height, word_tail_drop;
	char output[100];
	char img_file[HW_PATH_MAX];

	if (alternative_text_is_on) {
		if (get_value(KEY_ALT, output, sizeof(output))) {
			scan_string_to_16bit(output, p_frame->Location->encoding, &current->text);
		}
		return;
	}

	if (get_value (KEY_ALIGN, output, sizeof(output))) {
		PARAGRPH par = add_paragraph (current);
		align = par->alignment;
		if      (stricmp (output, "right")  == 0) par->alignment = ALN_RIGHT;
		else if (stricmp (output, "center") == 0) par->alignment = ALN_CENTER;
		else                                      par->alignment = ALN_LEFT;
	} else {
		align = -1;
	}
	word = current->word;
	word_height    = word->word_height;
	word_tail_drop = word->word_tail_drop;

	get_value (KEY_SRC, img_file, sizeof(img_file));
	
	new_image (p_frame->Container,
	           get_value_size (KEY_WIDTH), get_value_size (KEY_HEIGHT),
	           img_file, p_frame->Location);

	if (get_value (KEY_ALT, output, sizeof(output))) {
		char * text = output;
		while (isspace (*text)) text++;
		if (*text) {
			scan_string_to_16bit (text, p_frame->Location->encoding,
			                      &current->text);
			word->image->alt_h = word_height;
		}
	}
	if (current->text == current->buffer) {
		/* we need to fill in something to not have an empty word here
		 */
		*(current->text++) = map('.');
	}
	
	if (align < 0) {
		add_word (current);
	} else {
		add_paragraph (current)->alignment = align;
	}
	current->word->word_height    = word_height;
	current->word->word_tail_drop = word_tail_drop;
}


/* parse_title
 *
 * parses a title tag from a file 
 * and sets the window's title to this value
 * also watches for ISO Latin entities in the Title string
 * Baldrick Dec. 6, 2001
 *
 * Modified to use new ISO scanning routines
 * AltF4 Dec. 19, 2001
 */

static const char *
parse_title (FRAME p_frame, const char *symbol, const ENCODING source_encoding)
{
	char window_title[129];
	BOOL ready = FALSE;

	window_title[0] = '\0';

	while (!ready)
	{
		switch(*symbol)
		{
			case '\0':
				ready = TRUE;
				break;
			case '\t':
			case '\r':
			case '\n':
				/* BUG: Replace contiguous white space by exact one space! */
				symbol++;
				break;
			case '&':
				/* the 'symbol' pointer will be set by the scanner function
				 * to the expression end, ';' or '\0'.
				 */
				if (strlen(window_title) < aes_max_window_title_length) {
					char chr = (char)scan_namedchar(&symbol, NULL, ENCODING_ATARIST);
					strncat(window_title, &chr, 1);
				}
				symbol++;
				break;
			case '<':
				if (symbol[1] == '/')
				{
					const char * sym = symbol + 2;
					if (parse_tag (&sym) == TAG_TITLE)
					{
						symbol = sym;
						ready  = TRUE;
						break;
					}
				}
			default:
				if (strlen(window_title) < aes_max_window_title_length - 4)
					symbol = scan_char_to_Atari8bit(symbol, source_encoding, window_title);
				else
					symbol++;
				break;
		}
	}

	if (strlen(window_title) > 0)
	/*	wind_set_str(window_handle, WF_NAME, window_title);
	*/
		containr_notify (p_frame->Container, HW_SetTitle, window_title);

	return(symbol);
}


/* parse_embed()
 *
 * Processes embedded multi media objects.
 * Currently it simply fires up a new loader job and lets
 * the loader find out what to do.
 *
 * AltF4 - Mar. 01, 2002
 */
static void
parse_embed (LOCATION base)
{
	char snd_file[HW_PATH_MAX];

	if (get_value (KEY_SRC, snd_file, sizeof(snd_file))) {
		new_loader_job (snd_file, base, ENCODING_WINDOWS1252, NULL);
	}
}


/* parse frameset()
 *
 * ideally you drop the input on this routine
 * and it parses and processes the frameset information
 * until done and then returns to the main parser with
 * a pointer to the end of the frameset
 * baldrick - August 8, 2001
 *
 * at the moment there is a hard coded limit of 10 frames.
 * Could or should be changed in the future.
 *
 * There are some printf's in this section that are rem'd out
 * they are useful checks on the frame parsing and I'm not
 * certain that it's 100% correct yet.  So I have left them
 * baldrick - August 14, 2001
 *
 * Major reworks by AltF4 in late January - early Feb 2002
 */

static const char *
parse_frameset (const char *symbol, CONTAINR container, LOCATION base)
{
	HTMLTAG tag   = TAG_FRAMESET;
	BOOL    slash = FALSE;
	int     depth = 0;

	if (!container) {
		errprintf ("parse_frameset(): NO CONTAINER in '%s'!\n", base->File);
		exit(EXIT_FAILURE);
	} else if (container->Mode) {
		errprintf ("parse_frameset(): container not cleared in '%s'!\n", base->File);
		exit(EXIT_FAILURE);
	}

	do
	{
		if (!slash) {

			/* only work on an empty container.  if not empty there was either a
			 * forgotten </framset> or more tags than defined in the frameset.
			 */
			if (!container->Mode) {

				if (tag == TAG_FRAMESET) {

					char output[100];
					BOOL border = (container->Parent
					               ? container->Parent->Border : TRUE);
					container->Border = (get_value_unum (KEY_FRAMEBORDER, border) > 0);

					/* ok the first thing we do is look for ROWS or COLS
					 * since when we are dumped here we are looking at a
					 * beginning of a FRAMESET tag
					 */

					if (get_value (KEY_COLS, output, sizeof(output))) {
						containr_fillup (container, output, TRUE);
						container = container->u.Child;
						depth++;
					}

					else /* at the moment settings of either COLS _and_ ROWS aren't
					      * working yet, so we make it mutual exlusive for now   */

					if (get_value (KEY_ROWS, output, sizeof(output))) {
						containr_fillup (container, output, FALSE);
						container = container->u.Child;
						depth++;
					}

				} else if (tag == TAG_FRAME) {

					char  frame_file[HW_PATH_MAX];

					container->Mode   = CNT_FRAME;
					container->Name   = get_value_str (KEY_NAME);
					container->Border = container->Parent->Border;

					if (get_value (KEY_SRC, frame_file, sizeof(frame_file))) {
						/* BUG: is there a CHARSET attribute? */
						new_loader_job (frame_file, base,
						                ENCODING_WINDOWS1252, container);
					} else {
						containr_calculate (container, NULL);
						containr_notify (container,
						                 HW_PageFinished, &container->Area);
					}

					if (container->Sibling) {
						container = container->Sibling;
					}
				}
			} /* endif (!container->Mode) */

		} else if (tag == TAG_FRAMESET) { /* && slash */

			container = container->Parent;

			if (--depth <= 0) break;

			if (container->Sibling) {
				container = container->Sibling;
			}
		}

		/* skip junk until the next <...> */

		while (*symbol && *(symbol++) != '<');
		if (*symbol) {
			slash = (*symbol == '/');
			if (slash) symbol++;
			tag = parse_tag (&symbol);
			continue;
		}
	}
	while (*symbol);

	#if 0
	{
		extern void containr_debug (CONTAINR);
		containr_debug (container);
	}
	#endif

	return symbol;
}


/* skip everything until </STYLE> tag
 */
static void
skip_style (const char ** pptr)
{
	const char * line = *pptr;
	do {
		BOOL slash;
		while (*line && *(line++) != '<');
		slash = (*line == '/');
		if (slash) line++;
		if (parse_tag (&line) == TAG_STYLE && slash) {
			break;
		}
	} while (*line);

	*pptr = line;
}


/* skip everything until </SCRIPT> or <NOSCRIPT> tag
 */
static BOOL
skip_script (const char ** pptr)
{
	const char * line = *pptr, * save = NULL;
	BOOL   noscript = FALSE;
	do {
		BOOL    slash;
		HTMLTAG tag;
		while (*line && *(line++) != '<');
		slash = (*line == '/');
		if (slash) line++;
		else       save = line +1;
		tag = parse_tag (&line);
		if (slash) {
			if (tag == TAG_SCRIPT) break;
		} else if (tag == TAG_NOSCRIPT) {
			noscript = TRUE;
			break;
		} else {
			line = save;
		}
	} while (*line);

	*pptr = line;

	return noscript;
}


/* calculate_frame
 * this is the main parsing routine
 *
 * AltF4 - Feb. 04, 2002: renamed to parse_html() because that matches more its
 *                        functionality, corresponding to parse_text().
 */
struct paragraph_item *
parse_html (const char *symbol, struct frame_item *p_frame)
{
	time_t start_clock = clock();
	struct paragraph_item *start;
	WORD u, fontstep;
	WORD prev_sm_size, prev_su_size; /* one for before small and one for before sub/p */
	char output[50];
	UWORD active_word_buffer[500];  /* 500 is enough for 124 UTF-8 characters,
	                                 * if the encoding is unrecognized, parsed
	                                 * as single byte characters in PRE mode. */
	BOOL space_found = TRUE;  /* skip leading spaces */
	BOOL in_pre      = FALSE;
	BOOL in_script = FALSE; /* if this is TRUE we have to wait for a </noscript>
	                         * tag to reenter the skip_script() function   */
	BOOL linetoolong = FALSE;  /* "line too long" error printed? */
	WORD distances[5], effects[3];
	struct word_item * stored_word = p_frame->current.word;

	if (symbol == NULL)
		return (p_frame->current.paragraph);

	start = p_frame->current.paragraph;
	p_frame->current.text = p_frame->current.buffer = active_word_buffer;

	vst_font (vdi_handle, fonts[0][0][0]);
	prev_su_size = prev_sm_size = p_frame->current.font_size;
	p_frame->current_font_step = new_step(3);
	p_frame->current_font_step->colour 	  = p_frame->text_colour;
	fontstep = p_frame->current.font_size / p_frame->current_font_step->step;
	vst_arbpt (vdi_handle, p_frame->current.font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &p_frame->current.word->space_width, &u, &u, &u);

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	p_frame->current.word->word_height = distances[3];
	p_frame->current.word->word_tail_drop = distances[1];

	while (*symbol != '\0')
	{
		if (*symbol == '<')
		{
			BOOL start_tag = (*(++symbol) != '/');
			if (!start_tag) symbol++;

			if (p_frame->current.text > p_frame->current.buffer) {
				stored_word = p_frame->current.word;
				add_word (&p_frame->current);
			}
			switch (parse_tag (&symbol))
			{
				case TAG_A:
					parse_anchor (p_frame, start_tag);
					break;
				case TAG_B: /* (bold text) */
					set_font_bold (p_frame->current.word, start_tag);
					break;
				case TAG_BASE:
					if (start_tag)
						parse_base (p_frame);
					break;
				case TAG_BASEFONT:
					if (start_tag && get_value (KEY_SIZE, output, sizeof(output)))
					{
						p_frame->current_font_step = add_step (p_frame->current_font_step);
						p_frame->current_font_step->step = convert_to_number (output);
						p_frame->current.font_size = p_frame->current_font_step->step * fontstep;
						p_frame->current.word->styles.font_size = p_frame->current.font_size;
						p_frame->current.word->changed.font = TRUE;
					}
					break;
				case TAG_BGSOUND:
				case TAG_EMBED:
					if (start_tag) parse_embed (p_frame->Location);
					break;
				case TAG_BIG:
					if (start_tag)
					{
						p_frame->current_font_step = add_step (p_frame->current_font_step);
						p_frame->current_font_step->step = (p_frame->current.font_size * 3 / 2) / fontstep;
						p_frame->current.font_size = p_frame->current_font_step->step * fontstep;
					}
					else
					{
						p_frame->current_font_step = destroy_step(p_frame->current_font_step);
						p_frame->current.font_size = p_frame->current_font_step->step * fontstep;
					}
					p_frame->current.word->styles.font_size = p_frame->current.font_size;
					p_frame->current.word->changed.font = TRUE;
					break;
				case TAG_BLOCKQUOTE:
					parse_blockquote_tag (p_frame, start_tag);
					break;
				case TAG_BODY:
					if (start_tag)
						parse_body (p_frame);
					break;
				case TAG_BR:
					if (start_tag && p_frame->current.word != stored_word)
					{
						stored_word->line_brk = TRUE;
						space_found = TRUE;
					}
					break;
				case TAG_C: case TAG_CENTER:
					set_center_text (p_frame, start_tag);
					break;
				case TAG_CITE:
					set_font_italic (p_frame->current.word, start_tag);
					break;
				case TAG_CODE:
					set_pre_font (p_frame->current.word, start_tag);
					break;
				case TAG_DFN: /* (instance definition) */
					set_font_italic (p_frame->current.word, start_tag);
					break;
				case TAG_DIR:
					parse_menu_tag (p_frame, start_tag);
					break;
				case TAG_DIV: /* (generic language style container) */
					parse_div_tag (p_frame, start_tag);
					break;
				case TAG_DL: /* (definition list) */
					parse_d_tags (p_frame, 0, start_tag);
					break;
				case TAG_DT: /* (definition term) */
					if (start_tag)
						parse_d_tags (p_frame, 1, TRUE);
					break;
				case TAG_DD: /* (definition description) */
					if (start_tag)
						parse_d_tags (p_frame, 2, TRUE);
					break;
				case TAG_EM: /* (emphasis tag) */
					set_font_italic (p_frame->current.word, start_tag);
					break;
				case TAG_FONT:
					parse_font_tag (p_frame, fontstep, start_tag);
					break;
				case TAG_FRAMESET: /* frame processing */
					if (start_tag)
						symbol = parse_frameset (symbol, p_frame->Container,
						                         p_frame->Location);
					break;
				case TAG_H: /* header tag <H1>..<H6> */
					parse_header_tag (p_frame, start_tag);
					break;
				case TAG_HR:
					if (start_tag)
						parse_hr_tag (p_frame);
					break;
				case TAG_I: /* (italic text style) tag */
					set_font_italic (p_frame->current.word, start_tag);
					break;
				case TAG_IMG:
					if (start_tag)
					{
						parse_img_tag (p_frame);
						if (stored_word->next_word) {
							stored_word = stored_word->next_word;
						} else {
							stored_word = p_frame->current.word;
						}
						space_found = FALSE;
					}
					break;
				case TAG_KBD: /* keyboard input text style */
					set_pre_font (p_frame->current.word, start_tag);
					break;
				case TAG_LI: /* (list item) */
					if (start_tag) {
						if (p_frame->current.word != stored_word)
							stored_word->line_brk = TRUE;
						if (p_frame->current_list)
							parse_li_tag (p_frame, fontstep);
						space_found = TRUE;
					}
					break;
				case TAG_MENU:
					parse_menu_tag (p_frame, start_tag);
					break;
				case TAG_META:
					parse_meta_tag (p_frame);
					break;
				case TAG_OL:
					parse_ol_tag (p_frame, start_tag);
					break;
				case TAG_P: /* (paragraph) */
					if (start_tag)
					{
						parse_p_tag (p_frame);
						space_found = TRUE;
					}
					break;
				case TAG_PLAINTEXT:
					if (start_tag)
					{
						p_frame->current.paragraph->eop_space = EOP(p_frame->current.font_size);
						add_paragraph (&p_frame->current);
						/* from now on plain text, never ending */
						parse_text(symbol, p_frame);
						symbol = strchr(symbol, '\0');
					}
					break;
				case TAG_PRE:
					if (start_tag)
					{
						p_frame->current.paragraph->eop_space = EOP(p_frame->current.font_size);
						add_paragraph (&p_frame->current);
						p_frame->current.paragraph->alignment = ALN_LEFT;
					}
					set_pre_font (p_frame->current.word, start_tag);
					in_pre = start_tag;
					break;
				case TAG_Q:  /* quotes, in-paragraph citation  */
					parse_q_tag(&p_frame->current.text, start_tag);
					break;
				case TAG_S: case TAG_STRIKE: /* (strike through text style) */
					set_font_strike (p_frame->current.word, start_tag);
					break;
				case TAG_SAMP: /* (sample code or script) */
					set_pre_font (p_frame->current.word, start_tag);
					break;
				case TAG_SCRIPT:
					if (start_tag) in_script = skip_script (&symbol);
					break;
				case TAG_NOSCRIPT:
					if (!start_tag && in_script) in_script = skip_script (&symbol);
					break;
				case TAG_SMALL:
					if (start_tag)
					{
						prev_sm_size = p_frame->current.word->styles.font_size;
						p_frame->current.word->styles.font_size = prev_sm_size * 2 / 3;
					}
					else
					{
						p_frame->current.word->styles.font_size = prev_sm_size;
					}
					p_frame->current.word->changed.font = TRUE;
					break;
				case TAG_STRONG:
					set_font_bold (p_frame->current.word, start_tag);
					break;
				case TAG_STYLE:
					skip_style (&symbol);
					break;
				case TAG_SUB:
					if (start_tag)
					{
						prev_su_size = p_frame->current.word->styles.font_size;
						p_frame->current.word->styles.font_size = prev_su_size * 2 / 3;
						p_frame->current.word->vertical_align = ALN_BELOW;
					}
					else
					{
						p_frame->current.word->styles.font_size = prev_su_size;
						p_frame->current.word->vertical_align = ALN_MIDDLE; /*bottom; baldrick - July 19, 2001 */
					}
					p_frame->current.word->changed.font = TRUE;
					break;
				case TAG_SUP:
					if (start_tag)
					{
						prev_su_size = p_frame->current.word->styles.font_size;
						p_frame->current.word->styles.font_size = prev_su_size * 2 / 3;
						p_frame->current.word->vertical_align = ALN_ABOVE;
					}
					else
					{
						p_frame->current.word->styles.font_size = prev_su_size;
						p_frame->current.word->vertical_align = ALN_MIDDLE; /*bottom; baldrick - July 19, 2001 */
					}
					p_frame->current.word->changed.font = TRUE;
					break;
				case TAG_TABLE:
					/* reset font size on entering or exiting a table..
					 * this might be a bad method of doing this and is definately
					 * an area for more investigation.
					 * baldrick May 24, 2002
					 */
					obj_font_step(p_frame, fontstep, start_tag);

/*					p_frame->current.font_size = p_frame->current.word->styles.font_size = font_size;
*/
					if (start_tag) {
						table_start (p_frame);
					} else if (p_frame->TableStack) {
						table_finish (p_frame);
					}
					break;
				case TAG_TR: /* (table row) */
					if (p_frame->TableStack) {
						table_row (p_frame, start_tag);
					}
					break;
				case TAG_TD: /* (table data cell) */
					if (start_tag && p_frame->TableStack) {
						p_frame->current.paragraph = table_cell (p_frame, FALSE);
					}
					break;
				case TAG_TH: /* (table header cell) */
					if (start_tag && p_frame->TableStack) {
						p_frame->current.paragraph = table_cell (p_frame, TRUE);
						set_font_bold (p_frame->current.word, TRUE);
					}
					break;
				case TAG_TEXTAREA:
					if (start_tag)
					{
						p_frame->current.paragraph->eop_space = EOP(p_frame->current.font_size);
						add_paragraph (&p_frame->current);
						p_frame->current.paragraph->alignment = ALN_LEFT;
					}
					set_pre_font (p_frame->current.word, start_tag);
					in_pre = start_tag;
					break;
				case TAG_TITLE:
					if (start_tag)
						symbol = parse_title (p_frame, symbol, p_frame->Location->encoding);
					break;
				case TAG_TT:
					set_pre_font (p_frame->current.word, start_tag);
					break;
				case TAG_U: /* (underlined text) */
					set_font_underline (p_frame->current.word, start_tag);
					break;
				case TAG_UL: /* (unordered list) */
					parse_ul_tag (p_frame, start_tag);
					break;
				case TAG_VAR: /* (variable tag) */
					set_font_italic (p_frame->current.word, start_tag);
					break;

				case TAG_HTML:
					if (start_tag)
						break;
					symbol = strchr (symbol, '\0');
					p_frame->current.paragraph->eop_space = 20;
				
				/* we don't set a 'default:' directive here because at least gcc
				 * can tell us if we have forgotten a TAG this way   */

				 case TAG_FRAME:
				 case TAG_Unknown: ;
			}
			if (p_frame->current.word->changed.font)
			{
				vst_font (vdi_handle,
					  fonts[p_frame->current.word->styles.font]
					  [p_frame->current.word->styles.bold != FALSE]
					  [p_frame->current.word->styles.italic != FALSE]);
				vst_arbpt (vdi_handle, p_frame->current.word->styles.font_size, &u, &u, &u, &u);
				vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
				vqt_advance (vdi_handle, Space_Code,
					     &p_frame->current.word->space_width, &u, &u, &u);

				p_frame->current.word->word_height = distances[3];
				p_frame->current.word->word_tail_drop = distances[1];
			}

			continue;
		}

		if (!in_pre && isspace (*symbol))
		{
			if (!space_found) {
				add_word (&p_frame->current);
				*(p_frame->current.text++) = Space_Code;
			}
			while (isspace (*(++symbol)))
				;
			space_found = TRUE;
			
			continue;
		}
		
		switch (*symbol)
		{
			case '&':
				/* the 'symbol' pointer will be set by the scanner function
				 * to the expression end, ';' or '\0'.
				 * AltF4 Dec 19, 2001
				 */

				scan_namedchar (&symbol, &p_frame->current.text, ENCODING_BICS);
				space_found = FALSE;
				break;
			case 9:  /* HT HORIZONTAL TABULATION */
				if (in_pre) {
					if (p_frame->current.text < &active_word_buffer[numberof(active_word_buffer) - 7])
						do {
							*(p_frame->current.text++) = 560;  /* U+2007 FIGURE SPACE */
						} while (((p_frame->current.text - active_word_buffer) & 7) != 0);
					else if (linetoolong == FALSE) {
						errprintf("parse_html(): Line too long in '%s'!\n", p_frame->Location->File);
						linetoolong = TRUE;
					}
					break;
				}
				goto white_space;
			case 13: /* CR CARRIAGE RETURN */
				if (*(symbol + 1) == 10)  /* HTTP, TOS, or DOS text file */
					break;
				/* else Macintosh text file */
			case 10: /* LF LINE FEED */
			case 11: /* VT VERTICAL TABULATION */
			case 12: /* FF FORM FEED */
				if (in_pre)
				{
					/* BUG: empty paragrahps were ignored otherwise */
					*(p_frame->current.text++) = 560;  /* U+2007 FIGURE SPACE */

					add_paragraph(&p_frame->current);
					break;
				}
				/* else fall through */
			case ' ':
			white_space:
				if (!in_pre)
				{
					if (space_found)
						break;

					add_word (&p_frame->current);
					space_found = TRUE;
				}
			default:
				if (*symbol < 32 || *symbol == 127)
					break;
				if (*symbol != ' ')
					space_found = FALSE;

				if (p_frame->current.text < &active_word_buffer[numberof(active_word_buffer) - 7])
					scan_char_to_16bit(&symbol, p_frame->Location->encoding, &p_frame->current.text);
				else if (linetoolong == FALSE) {
					errprintf("parse_html(): Line too long in '%s'!\n", p_frame->Location->File);
					linetoolong = TRUE;
				}
		}
		symbol++;
	}

	word_store (&p_frame->current);
	while (p_frame->TableStack) {
		table_finish (p_frame);
	}
	p_frame->page_minimum = content_minimum (start) + 5;

	logprintf(LOG_BLUE, "%ld ms for '%s'\n", (clock() - start_clock) * 1000 / CLK_TCK, p_frame->Location->FullName);

	return (start);
}


/* parse_text
 * this is the text parsing routine
 * for use with non formatted text files
 *
 * Nothing exciting just maps lines to paragraphs
 */

struct paragraph_item *
parse_text (const char *symbol, struct frame_item *p_frame)
{
	time_t start_clock = clock();
	struct paragraph_item *start;
	WORD u;
	UWORD active_word_buffer[500];  /* 500 is enough for 124 UTF-8 characters
	                                 * parsed as single byte characters. */
	WORD distances[5], effects[3];
	BOOL linetoolong = FALSE;  /* "line too long" error printed? */

	if (symbol == NULL)
		return (p_frame->current.paragraph);

	start = p_frame->current.paragraph;
	p_frame->current.text = p_frame->current.buffer = active_word_buffer;

	vst_font (vdi_handle, fonts[0][0][0]);
	vst_arbpt (vdi_handle, p_frame->current.font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &p_frame->current.word->space_width, &u, &u, &u);

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	p_frame->current.word->word_height = distances[3];
	p_frame->current.word->word_tail_drop = distances[1];

	p_frame->current.word->styles.font = pre_font;

	while (*symbol != '\0')
	{
		switch (*symbol)
		{
			case 9:  /* HT HORIZONTAL TABULATION */
				if (p_frame->current.text < &active_word_buffer[numberof(active_word_buffer) - 10])
					do {
						*(p_frame->current.text++) = 560;  /* U+2007 FIGURE SPACE */
					} while (((p_frame->current.text - active_word_buffer) & 7) != 0);
				else if (linetoolong == FALSE) {
					errprintf("parse_text(): Line too long in '%s'!\n", p_frame->Location->File);
					linetoolong = TRUE;
				}
				break;
			case 13: /* CR CARRIAGE RETURN */
				if (*(symbol + 1) == 10)  /* HTTP, TOS, or DOS text file */
					break;
				/* else Macintosh text file */
			case 10: /* LF LINE FEED */
			case 11: /* VT VERTICAL TABULATION */
			case 12: /* FF FORM FEED */
				/* BUG: empty paragrahps were ignored otherwise */
				*(p_frame->current.text++) = 560;  /* U+2007 FIGURE SPACE */

				add_paragraph(&p_frame->current);
				break;
			default:
				if (*symbol < 32 || *symbol == 127)
					break;

				if (p_frame->current.text < &active_word_buffer[numberof(active_word_buffer) - 7])
					scan_char_to_16bit(&symbol, p_frame->Location->encoding, &p_frame->current.text);
				else if (linetoolong == FALSE) {
					errprintf("parse_text(): Line too long in '%s'!\n", p_frame->Location->File);
					linetoolong = TRUE;
				}
		}

		symbol++;
	}

	word_store (&p_frame->current);
	p_frame->page_minimum = content_minimum (start) + 5;

#ifndef __GNUC__
	#if sizeof(time_t) != sizeof(long)
	#error "sizeof(time_t) != sizeof(long), needed for printf("%ld", ...)"
	#endif
#endif

	logprintf(LOG_BLUE, "%ld ms for '%s'\n", (clock() - start_clock) * 1000 / CLK_TCK, p_frame->Location->FullName);

	return (start);
}
