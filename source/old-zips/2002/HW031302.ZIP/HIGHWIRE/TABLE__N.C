#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <ctype.h>

#include <gem.h>

#include "global.h"
#include "token.h"
#include "parser.h"
#include "Table.h"


#ifdef _NEW_TABLES


long content_calc (PARAGRPH, long width);


typedef struct s_table_stack * TABLE_STACK;
typedef struct s_table       * TABLE;
typedef struct s_table_row   * TAB_ROW;
typedef struct s_table_cell  * TAB_CELL;


struct s_table_stack {
	TABLE       Table;
	TAB_ROW     PrevRow;  /* previous row, to be copied from for rowspan */
	TAB_ROW     WorkRow;  /* actual row to work on */
	TAB_CELL    WorkCell; /* actual cell to work on */
	unsigned    NumCells; /* number of used cells in the actual row */
	TABLE_STACK Previous;
	
	char _debug;
};

struct s_table {
	PARAGRPH Paragraph;
	short    Color;
	short    Border;
	short    Spacing;
	short    Padding;
	short    SetWidth;
	short    SetHeight;
	TAB_ROW  Rows;
	unsigned NumCols;
	unsigned NumRows;
	long   * Minimum;
	long   * Maximum;
	long   * ColWidth;
};
#define t_Width      Paragraph->area.w
#define t_Height     Paragraph->area.h
#define t_MinWidth   Paragraph->min_width
#define t_MaxWidth   Paragraph->max_width


struct s_table_row {
	short    Color;
	TAB_CELL Cells;
	TAB_ROW  NextRow;
	long     MinHeight;
	long     Height;
};

struct s_table_cell {
	short    Color;
	TAB_CELL DummyFor;
	TAB_CELL RightCell;
	TAB_CELL BelowCell;
	short    ColSpan;
	short    RowSpan;
	PARAGRPH Paragraph;
	long     Width;
	long     Height;
	
	char _debug;
};


/*==============================================================================
*/
PARAGRPH
table_start (FRAME frame)
{
	char        buf[8];
	PARAGRPH    par   = frame->current_paragraph;
	TABLE       table = malloc (sizeof (struct s_table));
	TABLE_STACK stack = malloc (sizeof (struct s_table_stack));
	/*puts("table_start");*/
	stack->Table    = table;
	stack->PrevRow  = NULL;
	stack->WorkRow  = NULL;
	stack->WorkCell = NULL;
	stack->NumCells = 0;
	stack->Previous = frame->TableStack;
	stack->_debug = 'A';
	
	frame->TableStack = stack;
	par->Table          = table;
	par->paragraph_code = PAR_TABLE;
	
	table->Paragraph = par;
	table->Rows      = NULL;
	table->NumCols   = 0;
	table->NumRows   = 0;
	
	table->Color   = get_value_color (KEY_BGCOLOR);
	table->Border  = get_value_unum  (KEY_BORDER, 1);
	table->Spacing = get_value_unum  (KEY_CELLSPACING, (table->Border ? 2 : 0));
	table->Padding = get_value_unum  (KEY_CELLPADDING, (table->Border ? 2 : 0));
	
	table->SetWidth   = table->SetHeight  = 0;
	table->t_MinWidth = table->t_MaxWidth = table->Border *2 + table->Spacing;
	
	if (get_value (KEY_WIDTH, buf, sizeof(buf))) {
		char * end = buf;
		long   val = strtol (buf, &end, 10);
		if (val > 0 && val < 10000) {
			if (*end != '%') {
				table->SetWidth = val;
			} else if (val < 99) {
				table->SetWidth = -((val *1024 +50) /100);
			} else {
				table->SetWidth = -1024;
			}
		}
	}
	
	if (get_value (KEY_HEIGHT, buf, sizeof(buf))) {
		char * end = buf;
		long   val = strtol (buf, &end, 10);
		if (val > 0 && val < 10000 && *end != '%') {
			table->SetHeight = val;
		}
	}
	
	return par;
}

/*==============================================================================
*/
void
table_row (FRAME frame)
{
	TABLE_STACK stack = frame->TableStack;
	TABLE       table;
	TAB_ROW     row;
	char        buf[8];
	
	if (!stack) {
		printf ("table_row(): no table stack!\n");
		return;
	}
/*	printf("table_row(%i)\n", stack->Table->NumRows);*/
	
	table = stack->Table;
	
	row = malloc (sizeof (struct s_table_row));
	row->Cells     = NULL;
	row->NextRow   = NULL;
	row->Color     = get_value_color (KEY_BGCOLOR);
	row->MinHeight = row->Height = table->Padding *2;
	
	if (get_value (KEY_HEIGHT, buf, sizeof(buf))) {
		char * end = buf;
		long   val = strtol (buf, &end, 10);
		if (val > row->MinHeight && val < 10000 && *end != '%') {
			row->MinHeight = val;
		}
	}
	
	if (!stack->WorkRow) {
		table->Rows = row;
	
	} else {
		stack->WorkRow->NextRow = row;
		stack->PrevRow  = stack->WorkRow;
		stack->WorkCell = NULL;
		stack->NumCells = 0;
	}
	stack->WorkRow = row;
	table->NumRows++;
}

/*----------------------------------------------------------------------------*/
static TAB_CELL
new_cell (TAB_CELL left_side)
{
	TAB_CELL cell = malloc (sizeof (struct s_table_cell));
	
	if (left_side) {
		left_side->RightCell = cell;
	}
	cell->DummyFor  = NULL;
	cell->RightCell = NULL;
	cell->BelowCell = NULL;
	cell->ColSpan   = 1;
	cell->RowSpan   = 1;
	cell->Paragraph = NULL;
	cell->Width     = 0;
	cell->Height    = 0;
	
	cell->_debug = '.';
	
	return cell;
}

/*==============================================================================
*/
PARAGRPH
table_cell (FRAME frame)
{
	TABLE_STACK stack = frame->TableStack;
	TABLE       table;
	TAB_ROW     row;
	TAB_CELL    cell;
	short       span;
	
	if (!stack) {
		printf ("table_cell(): no table stack!\n");
		return NULL;
	
	} else if (!stack->WorkRow) {
		table_row (frame);
		printf ("table_cell(): missing row inserted.\n");
	}
/*	printf("table_cell('%c')\n", stack->_debug);*/
	
	table = stack->Table;
	row   = stack->WorkRow;
	
	if (!stack->WorkCell) {
		/*
		 * the first cell of the row, so we create a new row of cells with
		 * respect of the previous row's (if any) rowspan information.
		 */
		if (stack->PrevRow) {
			TAB_CELL prev = stack->PrevRow->Cells;
			if (!prev) {
				prev = stack->PrevRow->Cells = new_cell (NULL);
			}
			cell = NULL;
			do {
				prev->BelowCell = cell = new_cell (cell);
				if (prev->RowSpan > 1) {
					cell->DummyFor = prev;
					cell->RowSpan  = 2 - prev->RowSpan;
					cell->ColSpan  = prev->ColSpan;
				} else if (prev->RowSpan < 0) {
					cell->DummyFor = prev->DummyFor;
					cell->RowSpan  = 1 + prev->RowSpan;
					cell->ColSpan  = prev->ColSpan;
				}
			} while ((prev = prev->RightCell) != NULL);
			row->Cells = stack->PrevRow->Cells->BelowCell;
		}
		cell            = row->Cells;
		stack->NumCells = 1;
	
	} else {
		cell = stack->WorkCell->RightCell;
		stack->NumCells++;
	}
	
	/* now search the next cell that isn't a dummy of a row/colspan
	 */
	while (cell && cell->DummyFor) {
		stack->WorkCell = cell;
		cell            = cell->RightCell;
		stack->NumCells++;
	}
	
	/* if we haven't a cell here we need to create a new one
	 */
	if (!cell) {
		cell = new_cell (stack->WorkCell);
		if (!row->Cells) {
			row->Cells = cell;
		}
	}
	stack->WorkCell = cell;
	
	cell->Paragraph = new_paragraph (frame);
	cell->Color     = get_value_color (KEY_BGCOLOR);
	cell->Width     = get_value_unum  (KEY_WIDTH,  0);
	cell->Height    = get_value_unum  (KEY_HEIGHT, 0);
	cell->_debug = stack->_debug++;
	
	if ((span = get_value_unum (KEY_ROWSPAN, 0)) > 1) {
		cell->RowSpan = span;
	}
	if ((span = get_value_unum (KEY_COLSPAN, 0)) > 1) {
		cell->ColSpan = span;
		span = 2 - span;
		do {
			if (!stack->WorkCell->RightCell) {
				stack->WorkCell = new_cell (stack->WorkCell);
			} else {
				stack->WorkCell = stack->WorkCell->RightCell;
			}
			if (!stack->WorkCell->DummyFor) {
				stack->WorkCell->DummyFor = cell;
				stack->WorkCell->ColSpan  = span;
			}
			stack->NumCells++;
		} while (span++);
	}
	
	if (!stack->PrevRow) {
		table->NumCols = stack->NumCells;
	
	} else if (table->NumCols < stack->NumCells) {
		/*
		 * if this row has more cells than the previous rows we have to expand
		 * all other rows
		 */
		TAB_CELL last = table->Rows->Cells;
		while (last->RightCell) last = last->RightCell;
		do {
			TAB_CELL prev = last->BelowCell;
			cell          = new_cell (last);
			while (!prev->RightCell) {
				cell = cell->BelowCell = new_cell (prev);
				prev = prev->BelowCell;
			}
			cell->BelowCell = prev->RightCell;
			last            = last->RightCell;
		} while (++table->NumCols < stack->NumCells);
	}
	
	return cell->Paragraph;
}


/*----------------------------------------------------------------------------*/
static void
adjust_rowspans (TAB_CELL column, int num_rows)
{
	do if (column->RowSpan > num_rows) {
		TAB_CELL cell = column;
		short    span = 2 - num_rows;
		column->RowSpan = num_rows;
		while ((cell = cell->BelowCell) != NULL) {
			cell->RowSpan = span;
			if (!span++) break;
		}
	} while ((column = column->RightCell) != NULL);
}

/*==============================================================================
*/
void
table_finish (FRAME frame)
{
	TABLE_STACK stack = frame->TableStack;
	TABLE       table;
	TAB_ROW     row;
	TAB_CELL    column;
	short       padding;
	long      * minimum, * maximum;
	int         i;
	
	if (!stack) {
		printf ("table_finish(): no table stack!\n");
		return;
	} else if (!stack->Table->Rows) {
		printf ("table_finish(): no rows!\n");
		return;
	} else if (!stack->Table->NumCols) {
		printf ("table_finish(): no columns!\n");
		return;
	}
/*	puts("table_finish");*/
	
	table   = stack->Table;
	padding = table->Padding *2;
	table->Minimum = malloc (sizeof (*table->Minimum) * table->NumCols);
	for (i = 0; i < table->NumCols; table->Minimum[i++] = padding);
	table->Maximum = malloc (sizeof (*table->Maximum) * table->NumCols);
	for (i = 0; i < table->NumCols; table->Maximum[i++] = 0);
	table->ColWidth = malloc (sizeof (*table->ColWidth) * table->NumCols);
	for (i = 0; i < table->NumCols; table->ColWidth[i++] = padding);
	
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 * Step 1:  walk over all table cells and set the column's minimum/maximum
	 *          width for cells with single colspan and the row's minimum height
	 *          for cells with single rowspan.
	 */
	row = table->Rows;
	i   = table->NumRows;
	do {
		TAB_CELL cell = row->Cells;
		minimum = table->Minimum;
		maximum = table->Maximum;
		
		adjust_rowspans (cell, i--);
		do {
			if (cell->Paragraph) {
				if (cell->ColSpan == 1) {
					short width = content_minimum (cell->Paragraph) + padding;
					if (*minimum < width) *minimum = width;
					width = content_maximum (cell->Paragraph) + padding;
					if (*maximum < width) *maximum = width;
				}
				if (cell->RowSpan == 1) {
					if (row->MinHeight < cell->Height) row->MinHeight = cell->Height;
				}
			}
			minimum++;
			maximum++;
		} while ((cell = cell->RightCell) != NULL);
	} while ((row = row->NextRow) != NULL);

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 * Step 2:  walk over all table columns and spread the minimum/maximum width
	 *          of cells with multiple colspan.
	 */
	column  = table->Rows->Cells;
	minimum = table->Minimum;
	maximum = table->Maximum;
	do {
		TAB_CELL cell = column;
		do {
			if (cell->Paragraph && cell->ColSpan > 1) {
				short span  = cell->ColSpan;
				short width = content_minimum (cell->Paragraph) + padding
				            - *minimum;
				while (--span && (width -= minimum[span] + table->Spacing) > 0);
				if (width > 0) {
					span = cell->ColSpan;
					do {
						short w = width / span;
						minimum[--span] += w;
						width           -= w;
					} while (span > 1);
					*minimum += width;
				}
				span  = cell->ColSpan;
				width = content_maximum (cell->Paragraph) + padding
				      - *maximum;
				while (--span && (width -= maximum[span] + table->Spacing) > 0);
				if (width > 0) {
					span = cell->ColSpan;
					do {
						short w = width / span;
						maximum[--span] += w;
						width           -= w;
					} while (span > 1);
					*maximum += width;
				}
			}
		} while ((cell = cell->BelowCell) != NULL);
		if (*maximum < *minimum) {
			 *maximum = *minimum;
		}
		table->t_MinWidth += *(minimum++) + table->Spacing;
		table->t_MaxWidth += *(maximum++) + table->Spacing;
	} while ((column = column->RightCell) != NULL);
	
	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 * Step 3:  walk over all table rows and spread the minimum height
	 *          of cells with multiple rowspan.
	 */
	row = table->Rows;
	do {
		TAB_CELL cell = row->Cells;
		do {
			if (cell->Paragraph && cell->RowSpan > 1) {
				short span   = cell->RowSpan -1;
				short height = cell->Height + padding - row->MinHeight;
				TAB_ROW r    = row->NextRow;
				while ((height -= r->MinHeight + table->Spacing) > 0 && --span) {
					r = r->NextRow;
				}
				if (height > 0) {
					span = cell->RowSpan;
					r    = row;
					do {
						short h = height / span;
						r->MinHeight += h;
						height    -= h;
						r = r->NextRow;
					} while (--span > 1);
					r->MinHeight += height;
				}
			}
		} while ((cell = cell->RightCell) != NULL);
	} while ((row = row->NextRow) != NULL);
	
#if 0
{
	int y = table->NumRows;
	row = table->Rows;
	puts("---------------------");
	do {
		TAB_CELL cell = row->Cells;
		int x = table->NumCols;
		y--;
		do {
			printf ("%c ", (cell->DummyFor ? tolower (cell->DummyFor->_debug) : cell->_debug));
			if ((!--x && cell->RightCell) || (x && !cell->RightCell)) {
				puts ("BOINK");
				exit(1);
			}
			if ((!y && cell->BelowCell) || (y && !cell->BelowCell)) {
				puts ("BOINK");
				exit(1);
			}
		} while ((cell = cell->RightCell) != NULL);
		puts("");
	} while ((row = row->NextRow) != NULL);
}
#endif
	
	frame->current_paragraph = table->Paragraph;
	frame->TableStack        = stack->Previous;
	free (stack);
}


/*==============================================================================
 */
long
table_calc (TABLE table, long max_width)
{
	TAB_ROW row;
	long    set_width;
	short   padding = table->Padding *2;
	
	if (!table->NumCols) {
		printf ("table_calc(): no columns!\n");
		return table->t_Height;
	}
	/*printf ("table_calc(%li) %i\n", max_width, table->SetWidth);*/
	
	/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 * Step 1:  adjust the given width to the table's boundarys.
	 */
	if (table->SetWidth > 0) {
		set_width = table->SetWidth;
	} else if (table->SetWidth) {
		set_width = (max_width * -table->SetWidth + 512) / 1024;
	} else {
		set_width = max_width;
	}
	if (set_width < table->t_MinWidth) {
		 set_width = table->t_MinWidth;
	}
	
	if (set_width == table->t_Width) {
	/*	return table->t_Height; */
	}
	
	/*- - - - - - - - - - - - - - - - - - - -
	 * Step 2:  calculate the column widths.
	 */
	if (set_width == table->t_MinWidth) {
		/*
		 * Step 2.a:  for a minimum table width the stored column minimums
		 *            are used.
		 */
		long * col_width = table->ColWidth;
		long * minimum   = table->Minimum;
		int    i         = table->NumCols;
		do {
			*(col_width++) = *(minimum++);
		} while (--i);
	
	} else if (table->SetWidth) {
		/*
		 * Step 2.b:  for a defined width policy spread the extra size evenly
		 *            over all columns.
		 */
		long * col_width = table->ColWidth;
		long * minimum   = table->Minimum;
		int    i         = table->NumCols;
		short  spread    = set_width - table->t_MinWidth;
		do {
			short w = spread / i;
			*(col_width++) = w + *(minimum++);
			spread        -= w;
		} while (--i);
	
	} else {
		/*
		 * Step 2.c:
		 */
		long * col_width = table->ColWidth;
		long * maximum   = table->Maximum;
		long * minimum   = table->Minimum;
		short  spread    = set_width - table->t_MinWidth;
		short  rest      = table->NumCols;
		int    i         = table->NumCols;
		do {
			*(col_width++) = *(minimum++) - *(maximum++);
		} while (--i);
		do {
			short width = -(spread / rest);
			BOOL  found = FALSE;
			col_width = table->ColWidth;
			maximum   = table->Maximum;
			minimum   = table->Minimum;
			i = table->NumCols;
			do {
				if (*col_width <= 0 && width <= *col_width) {
					spread    += *col_width;
					*col_width = *maximum;
					found      = TRUE;
					if (!--rest) break;
				}
				col_width++;
				maximum++;
				minimum++;
			} while (--i);
			if (!found) {
				col_width = table->ColWidth;
				minimum   = table->Minimum;
				i = table->NumCols;
				do {
					if (*col_width <= 0) {
						width      = spread / rest;
						spread    -= width;
						*col_width = width + *minimum;
						if (!--rest) break;
					}
					col_width++;
					minimum++;
				} while (--i);
			}
		} while (rest);
		set_width -= spread;
	}
	
	table->t_Width = set_width;
	
	
	row = table->Rows;
	do {
		long   * col_width = table->ColWidth;
		TAB_CELL cell      = row->Cells;
		row->Height = row->MinHeight;
		while (cell) {
			cell->Width = *(col_width++);
			if (cell->Paragraph) {
				short span = cell->ColSpan -1;
				while (span--) cell->Width += col_width[span] + table->Spacing;
				cell->Height = content_calc (cell->Paragraph, cell->Width - padding)
				             + padding;
				if (cell->RowSpan == 1 && row->Height < cell->Height) {
					row->Height = cell->Height;
				}
			}
			cell = cell->RightCell;
		}
	} while ((row = row->NextRow) != NULL);
	
	
	table->t_Height = table->Border *2 + table->Spacing;
	row = table->Rows;
	do {
		TAB_CELL cell = row->Cells;
		while (cell) {
			if (cell->Paragraph && cell->RowSpan > 1) {
				short span   = cell->RowSpan -1;
				short height = cell->Height - row->Height;
				TAB_ROW r    = row->NextRow;
				while ((height -= r->Height + table->Spacing) > 0 && --span) {
					r = r->NextRow;
				}
				if (height > 0) {
					span = cell->RowSpan;
					r    = row;
					do {
						short h = height / span;
						r->Height += h;
						height    -= h;
						r = r->NextRow;
					} while (--span > 1);
					r->Height += height;
				}
			}
			cell = cell->RightCell;
		}
		table->t_Height += row->Height + table->Spacing;
	} while ((row = row->NextRow) != NULL);
	
	
	row = table->Rows;
	while (row) {
		TAB_CELL cell = row->Cells;
		while (cell) {
			cell->Height = row->Height;
			if (cell->DummyFor && cell->RowSpan <= 0) {
				cell->DummyFor->Height += row->Height + table->Spacing;
			}
			cell = cell->RightCell;
		}
		row = row->NextRow;
	}
	return table->t_Height;
}


/*==============================================================================
 */
long
table_draw (TABLE table, short x, short y)
{
	TAB_ROW row = table->Rows;
	/*puts("table_draw");*/
	
	if (table->Border) {
		GRECT b;
		b.g_x = x;
		b.g_y = y;
		b.g_w = table->t_Width;
		b.g_h = table->t_Height;
		draw_border (&b, G_WHITE, G_LBLACK, table->Border);
		x += table->Border;
		y += table->Border;
	}
	if (table->Color >= 0) {
		PXY p[2];
		p[1].p_x = (p[0].p_x = x) + table->t_Width  - table->Border *2 -1;
		p[1].p_y = (p[0].p_y = y) + table->t_Height - table->Border *2 -1;
		vsf_color (vdi_handle, table->Color);
		v_bar     (vdi_handle, (short*)p);
	}
	x += table->Spacing;
	y += table->Spacing;
	
	while (row) {
		long   * width = table->ColWidth;
		TAB_CELL cell  = row->Cells;
		short    c_x   = x;
		while (cell) {
			if (cell->Paragraph) {
				short color = (cell->Color < 0 ? row->Color : cell->Color);
				if (color >= 0) {
					PXY p[2];
					p[1].p_x = (p[0].p_x = c_x) + cell->Width  -1;
					p[1].p_y = (p[0].p_y = y)   + cell->Height -1;
					vsf_color (vdi_handle, color);
					v_bar     (vdi_handle, (short*)p);
				}
				if (table->Border) {
					GRECT b;
					b.g_x = c_x;
					b.g_y = y;
					b.g_w = cell->Width;
					b.g_h = cell->Height;
					draw_border (&b, G_LBLACK, G_WHITE, 1);
					vsl_color (vdi_handle, G_BLACK);
				}
				draw_contents (cell->Paragraph,
				               c_x + table->Padding, y + table->Padding,
				               cell->Width  - table->Padding *2 +1,
				               cell->Height - table->Padding *2 +y, y);
			}
			c_x += *(width++) + table->Spacing;
			cell = cell->RightCell;
		}
		y += row->Height + table->Spacing;
		row = row->NextRow;
	}
	
	return (y + table->Border);
}


/*==============================================================================
 */
long
content_calc (PARAGRPH paragraph, long max_width)
{
	long height = 0;
	
	while (paragraph) {
		paragraph->area.y = height;
		
		if (paragraph->paragraph_code == PAR_HR) {
			
			
		} else if (paragraph->paragraph_code == PAR_IMG) {
			
			
		} else if (paragraph->paragraph_code == PAR_TABLE) {
			table_calc (paragraph->Table, max_width);
			
		} else {   /* normal text */
			struct word_item * word = paragraph->item;
			long  width   = 0;
			short max_asc = 0;
			short max_dsc = 0;
			paragraph->area.h = 0;
			while (word) {
				BOOL ln_brk;
				if (word->item[0] == Space_Code && !word->item[1]) {
					ln_brk = (width && word->line_brk);
					word   = word->next_word;
				} else {
					long w = width + word->word_width;
					if (w <= max_width || !width) {
						width = w;
						if (max_asc < word->word_height)
							 max_asc = word->word_height;
						if (max_dsc < word->word_tail_drop)
							 max_dsc = word->word_tail_drop;
						ln_brk = word->line_brk;
						word   = word->next_word;
					} else {
						ln_brk = TRUE;
					}
				}
				if (ln_brk || !word) {
					paragraph->area.h += max_asc + max_dsc;
					width   = 0;
					max_asc = 0;
					max_dsc = 0;
				}
			}
		}
		height   += paragraph->area.h;
		paragraph = paragraph->next_paragraph;
	}
	return height;
}


#endif _NEW_TABLES
