
#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

struct table_step *
new_table_step (struct paragraph_item *p_table, struct table_item *parent)
{
	struct table_step *temp;
	temp = malloc (sizeof (struct table_step));

	temp->entry = p_table;

	temp->parent = parent;

	temp->previous_table_step = 0;

	return (temp);
}

struct table_step *
add_table_step (struct table_step *old, struct paragraph_item *p_table, struct table_item *parent)
{
	struct table_step *temp;

	temp = new_table_step (p_table,parent);
	temp->previous_table_step = old;

	return (temp);
}

struct table_step *
destroy_table_step (struct table_step *current)
{
	struct table_step *temp;

	if (current->previous_table_step != 0)
	{
		temp = current->previous_table_step;
		free (current);

		return (temp);
	}
	else
	{
		free(current);
		return(0);
	}
}

/* ****************************** */

void
destroy_table_structure (struct table_item *current_table)
{
	struct table_child *temp_child;
	struct table_child *current_child;
	struct paragraph_item *current_paragraph;
	
	current_child = current_table->children;
	
	while (current_child != 0)
	{
		current_paragraph = current_child->item;

		destroy_paragraph_structure (current_paragraph);

		temp_child = current_child->next_child;
		free(current_child);
		current_child = temp_child;
	}
			
	free(current_table);
}


struct table_child *
new_table_child (void)
{
	struct table_child *temp;
	
	temp = malloc (sizeof (struct table_child));

	temp->height = 0;
	temp->width = 0;
	temp->actual_height = 0;
	temp->actual_width = 0;
	temp->min_width = 0;
	temp->alignment = left;
	temp->valignment = bottom;
	temp->colspan = 1;
	temp->rowspan = 1;
	temp->bgcolor = 0;
	temp->item = new_paragraph();
	temp->next_child = 0;
	
	return (temp);
}

/* insert empty child
 *
 * the idea of this is to insert an empty child
 * into a tables children list to fill the empty
 * spaces used by colspan and rowspan
 *
 * it should just link a new child into prev->next_child with
 * a pointer to temp->next_child = old prev->next child
 * 
 * baldrick January 31, 2002
 */

struct table_child *
insert_empty_child (struct table_child *prev)
{
	struct table_child *temp;

/*printf("calling empty child\r\n");
*/
	
	temp = malloc (sizeof (struct table_child));

	temp->height = 0;
	temp->width = 0;
	temp->actual_height = 0;
	temp->actual_width = 0;
	temp->min_width = 0;
	temp->alignment = left;
	temp->valignment = bottom;
	temp->colspan = 0;  /* it's empty just a place holder */
	temp->rowspan = 0;
	temp->bgcolor = 0;
	temp->item = 0;
	temp->next_child = prev->next_child;

	prev->next_child = temp;
		
	return (temp);
}

struct table_item *
new_table (void)
{
	WORD i;
	
	struct table_item *temp;

	temp = malloc (sizeof (struct table_item));

	temp->num_cols = 0;
	temp->num_rows = 1;
	temp->table_height = 0;
	temp->table_width = 0;
	temp->actual_width = 0;
	temp->min_width = 0;
	temp->alignment = left;
	temp->border = 0;
	temp->cell_spacing = 0;
	temp->cell_padding = 0;
	temp->num_children = 0;
	temp->children = new_table_child();
	
	/* clear out col_widths array */
	for (i=0;i<50;i++)
		temp->col_widths[i] = 0;

	return (temp);
}

/*
 * determines the height of a table by walking it's paragraph list
 */
long calculate_subtable_height (struct table_item *current_table, struct frame_item *frame,long top);
WORD calculate_subtable_width (struct table_item *current_table, struct frame_item *frame,long top);


long
calculate_table_height (struct table_item *current_table, struct frame_item *frame,long tab_top)
{
	struct word_item *line_start;
	struct url_link *current_link;
	WORD left_indent, right_indent, current_line_width, line_tail = 0, line_height;
	WORD alignment_spacer = 0; /* height_spacer, * unused */
	WORD frame_w;
/*	WORD previous_word_height = 0; * unused */
	long temp_height = 0L;
	long temp_row_height = 0L;
	enum bool clickable_area_exists = false;
	struct clickable_area *current_clickable_area;
	struct named_location *current_named_location;
/*	WORD temp_rows = 0; * unused */
	
	WORD left_border = 0; /* , bottom_border = 0, right_border = 0; * unused */
	WORD temp_left = 0;
	WORD i;

	current_table->temp_long = 0L;
	current_table->actual_width = calculate_table_width(current_table,frame, current_table->temp_long);
	current_table->temp_val = 0;

	if (current_table->actual_width > frame->frame_page_width)
	{
		/* don't let percentage width tables grow the size of the frame
		 */
		if (current_table->table_width >= 0)
			frame->frame_page_width = current_table->actual_width;
		else /* percentage width */
			frame->frame_page_width = current_table->min_width;
	}
	
	current_clickable_area = frame->first_clickable_area;
	current_named_location = frame->first_named_location;
	current_link = 0;

	frame_w = frame->frame.w;

	/* reset our paragraph pointer from calc_width above */
	current_table->current_child = current_table->children;
	current_table->current_paragraph = current_table->current_child->item;

	if (current_table->current_paragraph == 0)
	{
/*		printf("exiting calc table height with no paragraph\r\n");*/
		return(0);
	}


	current_line_width = current_table->actual_width;
			
	switch (current_table->alignment)
	{
		case center:
			left_border = (frame_w - current_line_width) / 2;
			break;
		case right:
			left_border = (frame_w - current_line_width) - 2;
			break;
		case left:
			left_border = 3;
			break;
		default: /* just assume it's left */
			left_border = 3;
	}

	left_border += frame->clip.x;

	if (current_table->border)
		left_border -= 1;

	left_border += 1;

	temp_left = left_border;
	
	while (current_table->current_child != 0)
	{
		/* check if it's an empty child */
		if (current_table->current_child->colspan == 0)
		{
			current_table->temp_val += 1;
			
			/* if we have finished a ROW advance reset values and advance height */
		
			if (current_table->temp_val >= current_table->num_cols)
			{
				current_table->temp_val = 0;
				current_table->temp_long += temp_row_height;
	
				temp_height = 0;
				temp_row_height = 0;
				temp_left = left_border;
			}

			current_table->current_child = current_table->current_child->next_child;	
			continue;
		}
		/* first walk the paragraphs */

		current_table->current_paragraph = current_table->current_child->item ;
		frame->current_word = current_table->current_paragraph->item;

		current_table->current_child->actual_height = 0;

		while (current_table->current_paragraph != 0)
		{
			current_table->current_paragraph->current_paragraph_height = 0;

			frame->current_word = current_table->current_paragraph->item;
		
			/* hr = horizontal ruler */
			if (current_table->current_paragraph->paragraph_code == hr)
			{
				current_table->current_child->actual_width = frame->current_word->word_width;

				current_table->current_paragraph->current_paragraph_height = abs (frame->current_word->word_height) + 20;
	
				current_table->current_paragraph->area.x = current_table->current_paragraph->left_border + left_border;
				current_table->current_paragraph->area.y = (WORD)current_table->temp_long;
				current_table->current_paragraph->area.w = frame->current_word->word_width;
				current_table->current_paragraph->area.h = (WORD)(current_table->current_paragraph->current_paragraph_height);

				current_table->current_child->actual_height = current_table->current_paragraph->current_paragraph_height;

/*				temp_height += current_table->current_paragraph->current_paragraph_height;
*/
				temp_left += frame->current_word->word_width;
				
				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}
			else if (current_table->current_paragraph->paragraph_code == img)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 */

				if (current_table->current_child->actual_width == 0)
					current_table->current_child->actual_width = frame->current_word->word_width;

				current_table->current_paragraph->current_paragraph_height = abs (frame->current_word->word_height);

				current_table->current_paragraph->area.x = current_table->current_paragraph->left_border + left_border;

				current_table->current_paragraph->area.y = (WORD)current_table->temp_long + temp_height;
				current_table->current_paragraph->area.w = frame->current_word->word_width;
				current_table->current_paragraph->area.h = (WORD)(current_table->current_paragraph->current_paragraph_height);

				current_table->current_child->actual_height += current_table->current_paragraph->current_paragraph_height;


/*				temp_height += current_table->current_paragraph->current_paragraph_height;
*/
				temp_left += frame->current_word->word_width;

				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}
			else if (current_table->current_paragraph->paragraph_code == table)
			{
				current_table->current_paragraph->table->table_height = calculate_subtable_height (current_table->current_paragraph->table, frame,current_table->temp_long);
				current_table->current_child->actual_height = current_table->current_paragraph->table->table_height;


				current_table->current_paragraph->current_paragraph_height = current_table->current_paragraph->table->table_height;

				current_table->current_paragraph->area.x = current_table->current_paragraph->left_border + left_border;

				current_table->current_paragraph->area.y = (WORD)current_table->temp_long + temp_height;
/*				current_table->current_paragraph->area.w = frame->current_word->word_width; */
				current_table->current_paragraph->area.h = (WORD)(current_table->current_paragraph->current_paragraph_height);


/*				temp_height += current_table->current_paragraph->table->table_height;*/
				temp_left += frame->current_word->word_width;

				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}

			left_indent = current_table->current_paragraph->left_border + left_border + temp_left;
			right_indent = current_table->current_paragraph->right_border; /* + right_border;*/

			/* Now walk the words */
			while (frame->current_word != 0)
			{
				current_line_width = 0;
				line_start = frame->current_word;
				line_height = 0;
				line_tail = 0;
				clickable_area_exists = false;

				while (frame->current_word != 0 
			       && (current_line_width + frame->current_word->word_width) < (current_table->actual_width))/* - left_indent - right_indent))*/
				{
					if (frame->current_word->word_code == br && frame->current_word != line_start)
						break;

					current_line_width += frame->current_word->word_width;

					if (line_height < frame->current_word->word_height)
						line_height = frame->current_word->word_height;
					if (line_tail < frame->current_word->word_tail_drop)
						line_tail = frame->current_word->word_tail_drop;
					if (frame->current_word->link != 0)
					{
						if (frame->current_word->link->mode == lnk_href)
						{
							clickable_area_exists = true;

							if (current_link != 0 && frame->current_word->link == 0)
							{
								current_link = 0;
							}
							else if (current_link == 0 && frame->current_word->link != 0)
							{
								current_link = frame->current_word->link;
	
								if (frame->first_clickable_area == 0)
								{
									current_clickable_area = frame->first_clickable_area = new_clickable_area();
								}
								else
								{
									if (current_clickable_area->next_area == 0)
										current_clickable_area->next_area = new_clickable_area();
									current_clickable_area = current_clickable_area->next_area;
								}
	
								current_clickable_area->x = left_border + current_line_width + alignment_spacer + temp_left;
/*								current_clickable_area->x = current_line_width + alignment_spacer;*/
								current_clickable_area->y = (WORD)(current_table->temp_long + current_table->current_paragraph->current_paragraph_height)+(WORD)top;
								current_clickable_area->h =	line_height + line_tail;
								current_clickable_area->w = frame->current_word->word_width;
								current_clickable_area->link = current_link;
							}
							else if (current_link == frame->current_word->link)
								current_clickable_area->w += frame->current_word->word_width;
							else if (current_link != 0  && frame->current_word->link != 0)
							{
								if (current_clickable_area->next_area == 0)
									current_clickable_area->next_area = new_clickable_area ();
	
								current_clickable_area = current_clickable_area->next_area;
								current_link = frame->current_word->link;
	
								if (current_clickable_area == 0)
									current_clickable_area = new_clickable_area ();

								current_clickable_area->x = left_border + current_line_width + alignment_spacer + temp_left;
							
/*								current_clickable_area->y = (WORD)(current_table->temp_long + current_table->current_paragraph->current_paragraph_height) + (WORD)top;*/
								current_clickable_area->y = (WORD)(current_table->temp_long) + current_table->current_child->actual_height + (WORD)top;
								
								current_clickable_area->h = line_height + line_tail;
								current_clickable_area->w = frame->current_word->word_width;
								current_clickable_area->link = current_link;
							}
						}
						else
						{
							if (frame->first_named_location == 0)
							{
								current_named_location = frame->first_named_location = 	new_named_location ();
								current_named_location->link = frame->current_word->link;
								current_named_location->position = current_table->temp_long + current_table->current_paragraph->current_paragraph_height + temp_height;
							}
							else
							{
								if (current_named_location->link != frame->current_word->link)
								{
									if (current_named_location->next_location == 0)
										current_named_location->next_location = new_named_location();

									current_named_location = current_named_location->next_location;
									current_named_location->link = frame->current_word->link;
									current_named_location->position = current_table->temp_long + current_table->current_paragraph->current_paragraph_height + temp_height;
								}
							}
						}
					}

					frame->current_word = frame->current_word->next_word;
				}


				current_table->current_paragraph->current_paragraph_height += line_height + line_tail;		
			}

			temp_height += current_table->current_paragraph->current_paragraph_height;

			current_table->current_paragraph->left_border = (temp_left - left_border);
			
			/* we need to set the y here or it gets modified */
			current_table->current_paragraph->area.y = (WORD)current_table->temp_long + current_table->current_child->actual_height;

/*			if (current_table->temp_val >= current_table->num_cols)
			{
*/
				if (current_table->current_paragraph->eop_space > 0)
					current_table->current_paragraph->current_paragraph_height += current_table->current_paragraph->eop_space;
				else
					current_table->temp_long += current_table->current_paragraph->eop_space;
/*			}
*/			


			current_table->current_paragraph->area.x = current_table->current_paragraph->left_border;
			current_table->current_paragraph->area.w = current_line_width;
			current_table->current_paragraph->area.h = (WORD)(current_table->current_paragraph->current_paragraph_height);

/*printf("area.w = %d  \r\n",current_line_width);		*/

			/* only advance height if we have finished a row */

			current_table->current_child->actual_height += current_table->current_paragraph->current_paragraph_height;		

			temp_left += current_line_width;
		
			current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
		}

		/* test if the html gives a larger size than the data would
		 * warrant.   Baldrick Dec 20, 2001
		 */
		 
		if (current_table->current_child->height > current_table->current_child->actual_height)
			current_table->current_child->actual_height = current_table->current_child->height;

		/* Now check our row height */
		if (current_table->current_child->actual_height > temp_row_height)
			temp_row_height = current_table->current_child->actual_height;

/*		current_table->temp_val = current_table->temp_val + current_table->current_child->colspan; */

		current_table->temp_val += 1;

		/* if we have finished a ROW advance reset values and advance height */
		
		if (current_table->temp_val >= current_table->num_cols)
		{
			current_table->temp_val = 0;
			current_table->temp_long += temp_row_height;

			temp_height = 0;
			temp_row_height = 0;
			temp_left = left_border;
		}

		current_table->current_child = current_table->current_child->next_child;
	}

	/* Ok now resort the whole mess, could probably be done better, but I'm mentally exhausted - baldrick 11/27/01 */

	current_table->temp_val = 0;

	current_table->current_child = current_table->children;
	current_table->current_paragraph = current_table->current_child->item;
	
	while (current_table->current_child != 0)
	{
		/* first walk the paragraphs */
		current_table->current_paragraph = current_table->current_child->item ;
	
		temp_left = 0;

		for (i = 0; i < current_table->temp_val; i++)
			temp_left += current_table->col_widths[i];

		while (current_table->current_paragraph != 0)
		{
			current_table->current_paragraph->left_border = temp_left;
			current_table->current_paragraph->area.x = current_table->current_paragraph->left_border;

			current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
		}

		if ( current_table->num_cols > 1)
		{
/*			current_table->temp_val = current_table->temp_val + current_table->current_child->colspan;*/
			current_table->temp_val += 1;

			if (current_table->temp_val >= current_table->num_cols)
				current_table->temp_val = 0;
		}
		
		current_table->current_child = current_table->current_child->next_child;
	}

/*printf("calc table height returning %ld         \r\n",current_table->temp_long);
*/

	return (current_table->temp_long);
}

/* walk_table_children()
 *
 * table_item.temp_val is used to count the current column that the routine
 * is walking.
 */
 
static void
walk_table_children(struct table_item *current_table, struct frame_item *frame,long tab_top )
{
	struct word_item *line_start;
	WORD current_line_width = 0;

	current_table->current_child = current_table->children;
	current_table->current_paragraph = current_table->current_child->item;

	if (current_table->current_paragraph == 0)
	{
/*		printf("exiting walk table children with no paragraph\r\n");*/
		return;
	}

	/* reset the numer of columns to the start */
	current_table->temp_val = 0;
	
	while (current_table->current_child != 0)
	{
		/* check if it's an empty child */
		if (current_table->current_child->colspan == 0)
		{
			if ( current_table->num_cols > 1)
			{
				current_table->temp_val += 1;

				if (current_table->temp_val >= current_table->num_cols)
					current_table->temp_val = 0;
			}

			current_table->current_child = current_table->current_child->next_child;	
			continue;
		}

		/* first walk the paragraphs */
		current_table->current_paragraph = current_table->current_child->item ;
		frame->current_word = current_table->current_paragraph->item;
	
		while (current_table->current_paragraph != 0)
		{
			frame->current_word = current_table->current_paragraph->item;

			/* hr = horizontal ruler */
			if (current_table->current_paragraph->paragraph_code == hr)
			{
				current_table->current_child->actual_width = frame->current_word->word_width;

				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}
			else if (current_table->current_paragraph->paragraph_code == img)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 */

				/* if the width isn't predefined */
				if (current_table->current_child->actual_width == 0)
					current_table->current_child->actual_width = frame->current_word->word_width;

				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}
			else if (current_table->current_paragraph->paragraph_code == table)
			{
				current_table->current_paragraph->table->actual_width = calculate_subtable_width(current_table->current_paragraph->table,frame, top);
				
				current_table->current_child->actual_width = current_table->current_paragraph->table->actual_width;
				
				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}

			/* Now walk the words */
			while (frame->current_word != 0)
			{
				current_line_width = 0;
				line_start = frame->current_word;
	

				while ((frame->current_word != 0 )
			       && (current_line_width + frame->current_word->word_width) < (frame->frame.w))/* - left_indent - right_indent))*/
				{
					if (frame->current_word->word_code == br && frame->current_word != line_start)
						break;

					current_line_width += frame->current_word->word_width;

					frame->current_word = frame->current_word->next_word;
				}
			}

			if ((current_line_width + current_table->cell_padding) > current_table->current_child->actual_width)
				current_table->current_child->actual_width = (current_line_width + current_table->cell_padding);

			current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
		}

		/* test if the html gives a larger size than the data would
		 * warrant.   Baldrick Dec 20, 2001
		 */
		 
		if (current_table->current_child->width > current_table->current_child->actual_width)
			current_table->current_child->actual_width = current_table->current_child->width;

		if (current_table->current_child->actual_width > current_table->col_widths[current_table->temp_val])
			current_table->col_widths[current_table->temp_val] = current_table->current_child->actual_width;

		if ( current_table->num_cols > 1)
		{
/*			current_table->temp_val = current_table->temp_val + current_table->current_child->colspan; */

			current_table->temp_val += 1;

			if (current_table->temp_val >= current_table->num_cols)
				current_table->temp_val = 0;
		}

		current_table->current_child = current_table->current_child->next_child;
	}
}

/*
 * determines the width of a table by walking it's paragraph list
 */

WORD
calculate_table_width (struct table_item *current_table, struct frame_item *frame,long tab_top)
{
	WORD current_width = 0, max_width = 0, padding = 0;
	
	current_table->current_child = current_table->children;

	/* is this a forced width table? */
	if (current_table->table_width > 0)
	{
		/* we still need to walk the childrent to get the col_widths */
		
		while (current_table->current_child != 0)
		{
			if (current_table->current_child->actual_width > current_table->col_widths[current_table->temp_val])
				current_table->col_widths[current_table->temp_val] = current_table->current_child->actual_width;
		

			if ( current_table->num_cols > 1)
			{
/*				current_table->temp_val = current_table->temp_val + current_table->current_child->colspan;*/
			current_table->temp_val += 1;
	
				if (current_table->temp_val >= current_table->num_cols)
					current_table->temp_val = 0;
			}

			current_table->current_child = current_table->current_child->next_child;
		}

/*		for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
			printf("col[ %d ] = %d   \r\n",current_table->temp_val,current_table->col_widths[current_table->temp_val]);
*/		

		return(current_table->table_width);
	}
	

	/* Is the table size relative to frame width? */
	if (current_table->table_width < 0)
	{
		/* reset the col_widths array to keep tables from growing */
		
		for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
			current_table->col_widths[current_table->temp_val] = 0;

		/* get the child widths */
		
		walk_table_children(current_table, frame, top);

		/* set current width after the children incase we ran through
		 * subtables
		 */
		 
		current_width = (WORD)((long)current_table->table_width * (frame->clip.w / 10L) / -10L) - 10;

		/* reset min width */
		
		current_table->min_width = 0;
		
		/* get the minimum width for the table */

		for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
			current_table->min_width += current_table->col_widths[current_table->temp_val];

		/* is the minimum table width larger than frame.clip width? */

		if (current_table->min_width > current_width)
			return(current_table->min_width);
		else
		{
			/* Ok clip area viewport is larger than the minimum width
			 * so we will now get the diference between the two areas
			 * and divide it out across the columns to even up the
			 * up the presentation.
			 */

			max_width = current_width - current_table->min_width;
			
			padding = max_width/current_table->num_cols;
					
			for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
				current_table->col_widths[current_table->temp_val] += padding;

			return(current_width);
		}
	}

	walk_table_children(current_table, frame, top);

	for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
		max_width += current_table->col_widths[current_table->temp_val];
	
	return (max_width);
}

/*
 * calculate_subtable_width()
 *
 * hopefully this can be fully re entrant when finished
 */

WORD
calculate_subtable_width (struct table_item *current_table, struct frame_item *frame,long tab_top)
{
	WORD current_width = 0, max_width = 0, padding = 0;
	
	current_table->current_child = current_table->children;

	/* is this a forced width table? */
	if (current_table->table_width > 0)
	{
		/* we still need to walk the childrent to get the col_widths */
		
		while (current_table->current_child != 0)
		{
			if (current_table->current_child->actual_width > current_table->col_widths[current_table->temp_val])
				current_table->col_widths[current_table->temp_val] = current_table->current_child->actual_width;
		
			if ( current_table->num_cols > 1)
			{
/*				current_table->temp_val = current_table->temp_val + current_table->current_child->colspan;*/
			current_table->temp_val += 1;
	
				if (current_table->temp_val >= current_table->num_cols)
					current_table->temp_val = 0;
			}
			
			current_table->current_child = current_table->current_child->next_child;
		}

/*		for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
			printf("col[ %d ] = %d   \r\n",current_table->temp_val,current_table->col_widths[current_table->temp_val]);
*/		

		return(current_table->table_width);
	}
	

	/* Is the table size relative to frame width? */
	if (current_table->table_width < 0)
	{
		/* reset the col_widths array to keep tables from growing */
		
		for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
			current_table->col_widths[current_table->temp_val] = 0;

		/* get the child widths */
		
		walk_table_children(current_table, frame, top);

		/* set current width after the chilren incase we ran through
		 * subtables
		 */
		 
		current_width = (WORD)((long)current_table->table_width * (frame->clip.w / 10L) / -10L) - 10;

		/* reset min width */
		
		current_table->min_width = 0;
		
		/* get the minimum width for the table */

		for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
			current_table->min_width += current_table->col_widths[current_table->temp_val];

		/* is the minimum table width larger than frame.clip width? */

		if (current_table->min_width > current_width)
			return(current_table->min_width);
		else
		{
			/* Ok clip area viewport is larger than the minimum width
			 * so we will now get the diference between the two areas
			 * and divide it out across the columns to even up the
			 * up the presentation.
			 */

			max_width = current_width - current_table->min_width;
			
			padding = max_width/current_table->num_cols;
					
			for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
				current_table->col_widths[current_table->temp_val] += padding;

			return(current_width);
		}
	}

	walk_table_children(current_table, frame, top);

	for (current_table->temp_val = 0; current_table->temp_val < current_table->num_cols; current_table->temp_val++)
		max_width += current_table->col_widths[current_table->temp_val];
	
	return (max_width);
}

long
calculate_subtable_height (struct table_item *current_table, struct frame_item *frame,long tab_top)
{
	struct word_item *line_start;
	struct url_link *current_link;
	WORD current_line_width, line_tail = 0, line_height;
	WORD alignment_spacer = 0;
	WORD frame_w;
	long temp_height = 0L;
	long temp_row_height = 0L;
	struct clickable_area *current_clickable_area;
	struct named_location *current_named_location;
/*	WORD temp_rows = 0; * unused */
	
	WORD left_border = 0;
	WORD temp_left = 0;
	WORD i;

	current_table->temp_long = 0L;
/*	current_table->actual_width = calculate_table_width(current_table,frame, current_table->temp_long);
*/
	current_table->temp_val = 0;


	current_clickable_area = frame->first_clickable_area;
	current_named_location = frame->first_named_location;
	current_link = 0;

	frame_w = frame->frame.w;

	/* reset our paragraph pointer from calc_width above */

	current_table->current_child = current_table->children;
	current_table->current_paragraph = current_table->current_child->item;

	if (current_table->current_paragraph == 0)
	{
/*		printf("exiting subtable height with no paragarph\r\n");*/
		return (0);
	}
	
	current_line_width = current_table->actual_width;
			
	switch (current_table->alignment)
	{
		case center:
			left_border = (frame_w - current_line_width) / 2;
			break;
		case right:
			left_border = (frame_w - current_line_width) - 2;
			break;
		case left:
			left_border = 3;
			break;
		default: /* just assume it's left */
			left_border = 3;
	}

	left_border += frame->clip.x;

	if (current_table->border)
		left_border -= 1;

	left_border += 1;

	temp_left = left_border;
	
	while (current_table->current_child != 0)
	{
		/* check if it's an empty child */
		if (current_table->current_child->colspan == 0)
		{
			current_table->temp_val += 1;

			if (current_table->temp_val >= current_table->num_cols)
			{
				current_table->temp_val = 0;
				current_table->temp_long += temp_row_height;
	
				temp_height = 0;
				temp_row_height = 0;
				temp_left = left_border;
			}
			
			current_table->current_child = current_table->current_child->next_child;	
			continue;
		}

		/* first walk the paragraphs */

		current_table->current_paragraph = current_table->current_child->item ;
		frame->current_word = current_table->current_paragraph->item;

		current_table->current_child->actual_height = 0;

		while (current_table->current_paragraph != 0)
		{
			current_table->current_paragraph->current_paragraph_height = 0;

			frame->current_word = current_table->current_paragraph->item;
		
			/* hr = horizontal ruler */
			if (current_table->current_paragraph->paragraph_code == hr)
			{
				current_table->current_child->actual_width = frame->current_word->word_width;

				current_table->current_paragraph->current_paragraph_height = abs (frame->current_word->word_height) + 20;
	
				current_table->current_paragraph->area.x = current_table->current_paragraph->left_border + left_border;
				current_table->current_paragraph->area.y = (WORD)current_table->temp_long;
				current_table->current_paragraph->area.w = frame->current_word->word_width;
				current_table->current_paragraph->area.h = (WORD)(current_table->current_paragraph->current_paragraph_height);

				current_table->current_child->actual_height = current_table->current_paragraph->current_paragraph_height;

/*				temp_height += current_table->current_paragraph->current_paragraph_height;
*/
				temp_left += frame->current_word->word_width;
				
				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}
			else if (current_table->current_paragraph->paragraph_code == img)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 */

				if (current_table->current_child->actual_width == 0)
					current_table->current_child->actual_width = frame->current_word->word_width;

				current_table->current_paragraph->current_paragraph_height = abs (frame->current_word->word_height);

				current_table->current_paragraph->area.x = current_table->current_paragraph->left_border + left_border;

				current_table->current_paragraph->area.y = (WORD)current_table->temp_long + temp_height;
				current_table->current_paragraph->area.w = frame->current_word->word_width;
				current_table->current_paragraph->area.h = (WORD)(current_table->current_paragraph->current_paragraph_height);

				current_table->current_child->actual_height += current_table->current_paragraph->current_paragraph_height;


/*				temp_height += current_table->current_paragraph->current_paragraph_height;
*/
				temp_left += frame->current_word->word_width;

				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}
			else if (current_table->current_paragraph->paragraph_code == table)
			{
				current_table->current_child->actual_height = current_table->current_paragraph->table->table_height;

				current_table->current_paragraph->area.y = (WORD)current_table->temp_long + current_table->current_child->actual_height;

/*				temp_height += current_table->current_paragraph->table->table_height;*/
				temp_left += frame->current_word->word_width;

				current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
				continue;
			}

#if 0
			left_indent = current_table->current_paragraph->left_border + left_border + temp_left;
			right_indent = current_table->current_paragraph->right_border; /* + right_border;*/
#endif
			/* Now walk the words */
			while (frame->current_word != 0)
			{
				current_line_width = 0;
				line_start = frame->current_word;
				line_height = 0;
				line_tail = 0;

				while (frame->current_word != 0 
			       && ((current_line_width + frame->current_word->word_width) < (current_table->actual_width)))
				{
					if (frame->current_word->word_code == br && frame->current_word != line_start)
						break;

					current_line_width += frame->current_word->word_width;

					if (line_height < frame->current_word->word_height)
						line_height = frame->current_word->word_height;
					if (line_tail < frame->current_word->word_tail_drop)
						line_tail = frame->current_word->word_tail_drop;
					if (frame->current_word->link != 0)
					{
						if (frame->current_word->link->mode == lnk_href)
						{

							if (current_link != 0 && frame->current_word->link == 0)
							{
								current_link = 0;
							}
							else if (current_link == 0 && frame->current_word->link != 0)
							{
								current_link = frame->current_word->link;
	
								if (frame->first_clickable_area == 0)
								{
									current_clickable_area = frame->first_clickable_area = new_clickable_area();
								}
								else
								{
									if (current_clickable_area->next_area == 0)
										current_clickable_area->next_area = new_clickable_area();
									current_clickable_area = current_clickable_area->next_area;
								}
	
								current_clickable_area->x = left_border + current_line_width + alignment_spacer + temp_left;
/*								current_clickable_area->x = current_line_width + alignment_spacer;*/
								current_clickable_area->y = (WORD)(current_table->temp_long + current_table->current_paragraph->current_paragraph_height)+(WORD)top;
								current_clickable_area->h =	line_height + line_tail;
								current_clickable_area->w = frame->current_word->word_width;
								current_clickable_area->link = current_link;
							}
							else if (current_link == frame->current_word->link)
								current_clickable_area->w += frame->current_word->word_width;
							else if (current_link != 0  && frame->current_word->link != 0)
							{
								if (current_clickable_area->next_area == 0)
									current_clickable_area->next_area = new_clickable_area ();
	
								current_clickable_area = current_clickable_area->next_area;
								current_link = frame->current_word->link;
	
								if (current_clickable_area == 0)
									current_clickable_area = new_clickable_area ();

								current_clickable_area->x = left_border + current_line_width + alignment_spacer + temp_left;
							
/*								current_clickable_area->y = (WORD)(current_table->temp_long + current_table->current_paragraph->current_paragraph_height) + (WORD)top;*/
								current_clickable_area->y = (WORD)(current_table->temp_long) + current_table->current_child->actual_height + (WORD)top;
								
								current_clickable_area->h = line_height + line_tail;
								current_clickable_area->w = frame->current_word->word_width;
								current_clickable_area->link = current_link;
							}
						}
						else
						{
							if (frame->first_named_location == 0)
							{
								current_named_location = frame->first_named_location = 	new_named_location ();
								current_named_location->link = frame->current_word->link;
								current_named_location->position = current_table->temp_long + current_table->current_paragraph->current_paragraph_height + temp_height;
							}
							else
							{
								if (current_named_location->link != frame->current_word->link)
								{
									if (current_named_location->next_location == 0)
										current_named_location->next_location = new_named_location();

									current_named_location = current_named_location->next_location;
									current_named_location->link = frame->current_word->link;
									current_named_location->position = current_table->temp_long + current_table->current_paragraph->current_paragraph_height + temp_height;
								}
							}
						}
					}

					frame->current_word = frame->current_word->next_word;
				}


				current_table->current_paragraph->current_paragraph_height += line_height + line_tail;		
			}

			temp_height += current_table->current_paragraph->current_paragraph_height;

			current_table->current_paragraph->left_border = (temp_left - left_border);
			
			/* we need to set the y here or it gets modified */
			current_table->current_paragraph->area.y = (WORD)current_table->temp_long + current_table->current_child->actual_height;

/*			if (current_table->temp_val >= current_table->num_cols)
			{
*/
				if (current_table->current_paragraph->eop_space > 0)
					current_table->current_paragraph->current_paragraph_height += current_table->current_paragraph->eop_space;
				else
					current_table->temp_long += current_table->current_paragraph->eop_space;
/*			}
*/			
			current_table->current_paragraph->area.x = current_table->current_paragraph->left_border;
			current_table->current_paragraph->area.w = current_line_width;
			current_table->current_paragraph->area.h = (WORD)(current_table->current_paragraph->current_paragraph_height);

/*printf("area.w = %d  \r\n",current_line_width);		*/

			/* only advance height if we have finished a row */

			current_table->current_child->actual_height += current_table->current_paragraph->current_paragraph_height;		

/*			if (current_table->current_paragraph->current_paragraph_height > temp_row_height)
			{
				temp_height = current_table->current_paragraph->current_paragraph_height;
				temp_row_height = current_table->current_paragraph->current_paragraph_height;
			}
*/
			temp_left += current_line_width;
		
			current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
		}

		/* test if the html gives a larger size than the data would
		 * warrant.   Baldrick Dec 20, 2001
		 */

		if (current_table->current_child->height > current_table->current_child->actual_height)
			current_table->current_child->actual_height = current_table->current_child->height;

		if (current_table->current_child->actual_height > temp_row_height)
			temp_row_height = current_table->current_child->actual_height;

		/* if we have finished a ROW advance reset values and advance height */

/*		current_table->temp_val = current_table->temp_val + current_table->current_child->colspan; */
	current_table->temp_val += 1;

		if (current_table->temp_val >= current_table->num_cols)
		{
			current_table->temp_val = 0;
			current_table->temp_long += temp_row_height;
	
			temp_height = 0;
			temp_row_height = 0;
			temp_left = left_border;
		}

		current_table->current_child = current_table->current_child->next_child;
	}

	/* Ok now resort the whole mess, could probably be done better, but I'm mentally exhausted - baldrick 11/27/01 */

	current_table->temp_val = 0;

	current_table->current_child = current_table->children;
	current_table->current_paragraph = current_table->current_child->item;
	
	while (current_table->current_child != 0)
	{
		/* first walk the paragraphs */
		current_table->current_paragraph = current_table->current_child->item ;
	
		temp_left = 0;

		for (i = 0; i < current_table->temp_val; i++)
			temp_left += current_table->col_widths[i];

		while (current_table->current_paragraph != 0)
		{
			current_table->current_paragraph->left_border = temp_left;
			current_table->current_paragraph->area.x = current_table->current_paragraph->left_border;

			current_table->current_paragraph = current_table->current_paragraph->next_paragraph;
		}

		if ( current_table->num_cols > 1)
		{
/*			current_table->temp_val = current_table->temp_val + current_table->current_child->colspan;*/
			current_table->temp_val += 1;

			if (current_table->temp_val >= current_table->num_cols)
				current_table->temp_val = 0;
		}
			
		current_table->current_child = current_table->current_child->next_child;
	}

	return (current_table->temp_long);
}


#if 0
/* I just like these for dumping output to the screen so I've stuck
   them down here in case I need them again
   */
		v_ftext16 (vdi_handle, 10, 10, frame->current_word->item);

		vswr_mode(vdi_handle,1);
		v_ftext16 (vdi_handle, 10, current_height + 30, frame->current_word->item);
#endif
