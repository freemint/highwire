
#include <stdlib.h>

#include <gemx.h>

#include "global.h"

#ifdef __GNUC__

static inline int
max (int a, int b)
{
	return (a > b) ? a : b;
}

static inline int
min (int a, int b)
{
	return (a < b) ? a : b;
}

#endif

void
blit_block (struct frame_item *frame, WORD distance, enum direction direction_of_scroll)
{
	MFDB screen;
	WORD pts[8], x, y, w, h;

	frame->frame.x = frame->clip.x - frame->horizontal_scroll;
	frame->frame.y = (WORD)((long)frame->clip.y - frame->vertical_scroll);
	vsf_color (vdi_handle, frame->background_colour);
	wind_get (window_handle, WF_FIRSTXYWH, &x, &y, &w, &h);
	do
	{
		if (x < frame->clip.x + frame->clip.w && y < frame->clip.y + frame->clip.h
		    && frame->clip.x < x + w && frame->clip.y < y + h)
		{
			pts[4] = pts[0] = max (x, frame->clip.x);
			pts[5] = pts[1] = max (y, frame->clip.y);
			pts[6] = pts[2] = min (x + w, frame->clip.x + frame->clip.w) - 1;
			pts[7] = pts[3] = min (y + h, frame->clip.y + frame->clip.h) - 1;
			screen.fd_addr = 0;
			vs_clip (vdi_handle, 1, pts);
			switch (direction_of_scroll)
			{
				case d_up:
					if (pts[3] - distance > pts[1])
					{
						pts[3] -= distance;
						pts[5] += distance;
						vro_cpyfm (vdi_handle, 3, pts, &screen, &screen);
						pts[3] = pts[5];
					}
					vr_recfl (vdi_handle, pts);

					/* turn off old clip for entire window */
					vs_clip (vdi_handle, 0, pts);
					
					/* turn on new clip for just redraw area */
					vs_clip (vdi_handle, 1, pts);
					
					draw_frame_contents (frame, frame->item, frame->frame.x,
							     frame->frame.y, frame->frame.w,
							     pts[3], pts[1]);


/*							     pts[3] - pts[1], pts[1]);*/
					break;
				case d_down:
					if (pts[1] + distance < pts[3])
					{
						pts[1] += distance;
						pts[7] -= distance;
						vro_cpyfm (vdi_handle, 3, pts, &screen, &screen);
						pts[1] = pts[7];
					}
					vr_recfl (vdi_handle, pts);

					/* turn off old clip for entire window */
					vs_clip (vdi_handle, 0, pts);

					/* turn on new clip for just redraw area */
					vs_clip (vdi_handle, 1, pts);

					draw_frame_contents (frame, frame->item, frame->frame.x,
							     frame->frame.y, frame->frame.w,
							     pts[3], pts[1]);
/*							     pts[3] - pts[1], pts[1]);*/
					break;
				case d_left:
					if (pts[2] - distance > pts[0])
					{
						pts[2] -= distance;
						pts[4] += distance;
						vro_cpyfm (vdi_handle, 3, pts, &screen, &screen);
						pts[2] = pts[4];
					}
					vr_recfl (vdi_handle, pts);

					/* turn off old clip for entire window */
					vs_clip (vdi_handle, 0, pts);
					
					/* turn on new clip for just redraw area */
					vs_clip (vdi_handle, 1, pts);

					draw_frame_contents (frame, frame->item, frame->frame.x,
							     frame->frame.y, frame->frame.w,
							     pts[3], pts[1]);
/*							     pts[3] - pts[1], pts[1]);*/
					break;
				case d_right:
					if (pts[0] + distance < pts[2])
					{
						pts[0] += distance;
						pts[6] -= distance;
						vro_cpyfm (vdi_handle, 3, pts, &screen, &screen);
						pts[0] = pts[6];
					}
					vr_recfl (vdi_handle, pts);

					/* turn off old clip for entire window */
					vs_clip (vdi_handle, 0, pts);
					
					/* turn on new clip for just redraw area */
					vs_clip (vdi_handle, 1, pts);

					draw_frame_contents (frame, frame->item, frame->frame.x,
							     frame->frame.y, frame->frame.w,
							     pts[3], pts[1]);
/*							     pts[3] - pts[1], pts[1]);*/
					break;
			}
			/* This had been a 0 instead of pts
			 * caused it to crash on my TT
			 * baldrick July 14, 2001
			 */
			vs_clip (vdi_handle, 0, pts);

		}
		wind_get (window_handle, WF_NEXTXYWH, &x, &y, &w, &h);
	}
	while (w + h > 0);
}

/*printf("current frame x = %d y = %d w = %d h = %d\r\n",current_frame->frame_left,
current_frame->frame_top,current_frame->frame_width,current_frame->frame_height);
*/

void
redraw (WORD handle, WORD rx, WORD ry, WORD rw, WORD rh, struct frame_item *current_frame)
{
	vsf_color (vdi_handle, 0);

	if (frames_recalculated == true)
		wind_get (window_handle, WF_WORKXYWH, &rx, &ry, &rw, &rh);

	while (current_frame != 0)
	{
		redraw_frame (handle, rx, ry, rw, rh, current_frame);

		draw_frame_borders (current_frame, 0);

		current_frame = current_frame->next_frame;
	}

	frames_recalculated = false;
}

void
redraw_frame (WORD handle, WORD rx, WORD ry, WORD rw, WORD rh,
	      struct frame_item *current_frame)
{
	WORD pts[4], x, y, w, h;

	if (current_frame->frame_named_location != 0)
	{
		current_frame->vertical_scroll = search_for_named_location (current_frame->frame_named_location, current_frame->first_named_location);
		current_frame->frame_named_location = 0;

/* we are missing an assignment of frame->frame.h somewhere.  Without that this test is junk and causes
   problems elsewhere in the system.  So until it's fixed it's been rem'd out.  Baldrick Dec 17 2001)
		if (current_frame->vertical_scroll > current_frame->current_page_height - current_frame->frame.h)
			current_frame->vertical_scroll = current_frame->current_page_height - current_frame->frame.h;
*/
	}

	current_frame->frame.x = current_frame->clip.x - current_frame->horizontal_scroll;
	current_frame->frame.y = (WORD)((long)current_frame->clip.y - current_frame->vertical_scroll);

	wind_get (window_handle, WF_FIRSTXYWH, &x, &y, &w, &h);
	vsf_color (vdi_handle, current_frame->background_colour);

	if (current_frame->clip.x < rx + rw && current_frame->clip.y < ry + rh
	    && rx < current_frame->clip.x + current_frame->clip.w
	    && ry < current_frame->clip.y + current_frame->clip.h)
	{
		wind_get (window_handle, WF_FIRSTXYWH, &x, &y, &w, &h);
		graf_mouse (M_OFF, 0);
		wind_update (BEG_UPDATE);

		do
		{
			if (x < rx + rw && y < ry + rh && rx < x + w && ry < y + h
			    && x < current_frame->clip.x + current_frame->clip.w
			    && y < current_frame->clip.y + current_frame->clip.h
			    && current_frame->clip.x < x + w && current_frame->clip.y < ry + rh)
			{
				pts[0] = max (current_frame->clip.x, max (x, rx));
				pts[1] = max (current_frame->clip.y, max (y, ry));
				pts[2] = min (current_frame->clip.x + current_frame->clip.w, min (x + w, rx + rw)) - 1;
				pts[3] = min (current_frame->clip.y + current_frame->clip.h, min (y + h, ry + rh)) - 1;


				vs_clip (vdi_handle, 1, pts); 

				vr_recfl (vdi_handle, pts);

				draw_frame_contents (current_frame, current_frame->item, current_frame->frame.x,
						     current_frame->frame.y, current_frame->frame.w,
						     pts[3], pts[1]);

				/* this was a 0 instead of pts, this caused it
				 * to crash on my machine - Baldrick July 14, 2001
				 */
				vs_clip (vdi_handle, 0, pts);
			}
			wind_get (window_handle, WF_NEXTXYWH, &x, &y, &w, &h);
		}
		while (w + h > 0);

		wind_update (END_UPDATE);
		graf_mouse (M_ON, 0);
	}
}


static void
draw_sliders (struct frame_item *frame)
{
	WORD pts[4];
	long slider_length, slider_pos, scroll_length;

	if (frame->v_scroll_on == true)
	{
		scroll_length = frame->clip.h - 1 - scroll_bar_width * 2;
		slider_length = frame->clip.h * scroll_length / frame->current_page_height;
		if (slider_length < scroll_bar_width)
			slider_length = scroll_bar_width;
		slider_pos =
			((scroll_length - slider_length) * frame->vertical_scroll /
			 (frame->current_page_height - frame->clip.h)) + frame->clip.y +
			scroll_bar_width + 1;

		pts[2] = pts[0] = frame->clip.x + frame->clip.w + 1;
		pts[2] += scroll_bar_width - 3;
		pts[3] = pts[1] = (WORD)slider_pos + 1;
		pts[3] += (WORD)slider_length - 3;
		vsf_color (vdi_handle, slider_col);
		vr_recfl (vdi_handle, pts);
		vsf_color (vdi_handle, slider_bkg); 
		pts[1] = frame->clip.y + scroll_bar_width + 1;
		pts[3] = (WORD)slider_pos - 1;
		if (pts[1] < pts[3])
			vr_recfl (vdi_handle, pts);
		pts[1] = ++pts[3];
		v_pline (vdi_handle, 2, pts);
		pts[3] = pts[1] = (WORD)(slider_pos + slider_length - 1);
		v_pline (vdi_handle, 2, pts);
		pts[1]++;
		pts[3] = frame->clip.y + frame->clip.h - 1 - scroll_bar_width;
		if (pts[1] < pts[3])
			vr_recfl (vdi_handle, pts);
	}

	if (frame->h_scroll_on == true)
	{
		scroll_length = frame->clip.w - 1 - scroll_bar_width * 2;
		slider_length = frame->clip.w * scroll_length / frame->frame.w;
		if (slider_length < scroll_bar_width)
			slider_length = scroll_bar_width;
		slider_pos =
			((scroll_length - slider_length) * frame->horizontal_scroll /
			 (frame->frame.w - frame->clip.w)) + frame->clip.x + scroll_bar_width + 1;

		pts[3] = pts[1] = frame->clip.y + frame->clip.h + 1;
		pts[3] += scroll_bar_width - 3;
		pts[2] = pts[0] = (WORD)slider_pos + 1;
		pts[2] += (WORD)slider_length - 3;
		vsf_color (vdi_handle, slider_col);
		vr_recfl (vdi_handle, pts);
		vsf_color (vdi_handle, slider_bkg);
		pts[0] = frame->clip.x + scroll_bar_width + 1;
		pts[2] = (WORD)slider_pos - 1;
		if (pts[0] < pts[2])
			vr_recfl (vdi_handle, pts);
		pts[0] = ++pts[2];
		v_pline (vdi_handle, 2, pts);
		pts[2] = pts[0] = (WORD)(slider_pos + slider_length - 1);
		v_pline (vdi_handle, 2, pts);
		pts[0]++;
		pts[2] = frame->clip.x + frame->clip.w - 1 - scroll_bar_width;
		if (pts[0] < pts[2])
			vr_recfl (vdi_handle, pts);
	}
}

void
draw_frame_borders (struct frame_item *current_frame, WORD flag)
{
	WORD pts[8], clip[4], x, y, w, h;

	wind_get (window_handle, WF_FIRSTXYWH, &x, &y, &w, &h);
	graf_mouse (M_OFF, 0);
	wind_update (BEG_UPDATE);
	do
	{
		clip[0] = x;
		clip[1] = y;
		clip[2] = x + w - 1;
		clip[3] = y + h - 1;
		vs_clip (vdi_handle, 1, clip);

		draw_sliders (current_frame);

		if (flag == 1)
		{
			/* This next was a 0 instead of clip
			 * again it caused a crash on my TT
			 * baldrick July 14, 2001
			 */
			vs_clip (vdi_handle, 0, clip);
			wind_get (window_handle, WF_NEXTXYWH, &x, &y, &w, &h);
			continue;
		}

		if (current_frame->border == true)
		{
			pts[2] = pts[0] = current_frame->clip.x - 1;
			pts[3] = pts[1] = current_frame->clip.y - 1;
			pts[3] += current_frame->clip.h + 2;
			if (current_frame->h_scroll_on == true)
				pts[3] += scroll_bar_width - 1;
			v_pline (vdi_handle, 2, pts);
			pts[3] = pts[1];
			pts[2] += current_frame->clip.w + 2;
			if (current_frame->v_scroll_on == true)
				pts[2] += scroll_bar_width - 1;
			v_pline (vdi_handle, 2, pts);
		}

		if (current_frame->h_scroll_on == true || current_frame->border == true)
		{
			pts[2] = pts[0] = current_frame->clip.x;
			pts[2] += current_frame->clip.w - 1;
			pts[3] = pts[1] = current_frame->clip.y + current_frame->clip.h;
			v_pline (vdi_handle, 2, pts);
			if (current_frame->h_scroll_on == true)
			{
				pts[1] = pts[3] += scroll_bar_width - 1;
				v_pline (vdi_handle, 2, pts);

				pts[1] -= scroll_bar_width - 2;
				pts[3]--;
				pts[2] = pts[0];
				v_pline (vdi_handle, 2, pts);

				pts[0]++;
				pts[2] += scroll_bar_width - 1;
				vsf_color (vdi_handle, slider_col);
				vr_recfl (vdi_handle, pts);
				pts[0] = ++pts[2];
				v_pline (vdi_handle, 2, pts);

				pts[0] = pts[2] = current_frame->clip.x + current_frame->clip.w -	scroll_bar_width;
				v_pline (vdi_handle, 2, pts);

				pts[2] += scroll_bar_width - 1;
				pts[0]++;
				vr_recfl (vdi_handle, pts);
				pts[0] = ++pts[2];
				v_pline (vdi_handle, 2, pts);

				/*left arrow*/
				pts[5] = pts[3] = pts[1] = current_frame->clip.y + current_frame->clip.h;
				pts[6] = pts[2] = pts[0] = current_frame->clip.x + scroll_bar_width / 3;
				pts[7] = pts[1] += scroll_bar_width / 2;
				pts[3] += scroll_bar_width / 4;
				pts[5] += scroll_bar_width * 3 / 4;
				pts[4] = pts[2] += scroll_bar_width / 2;
				v_pline (vdi_handle, 4, pts);

				/* right arrow */
				pts[6] = pts[2] = pts[0] = current_frame->clip.x + current_frame->clip.w - scroll_bar_width / 3;
				pts[4] = pts[2] -= scroll_bar_width / 2;
				v_pline (vdi_handle, 4, pts);
			}
		}

		if (current_frame->v_scroll_on == true || current_frame->border == true)
		{
			pts[3] = pts[1] = current_frame->clip.y;
			pts[3] += current_frame->clip.h - 1;
			pts[2] = pts[0] = current_frame->clip.x + current_frame->clip.w;
			v_pline (vdi_handle, 2, pts);
			if (current_frame->v_scroll_on == true)
			{
				pts[0] = pts[2] += scroll_bar_width - 1;
				v_pline (vdi_handle, 2, pts);
				vsf_color (vdi_handle, slider_col);
				pts[0] -= scroll_bar_width - 2;
				pts[2]--;
				pts[3] = pts[1];
				v_pline (vdi_handle, 2, pts);
				pts[1]++;
				pts[3] += scroll_bar_width - 1;
				vr_recfl (vdi_handle, pts);
				pts[1] = ++pts[3];
				v_pline (vdi_handle, 2, pts);
				pts[1] = pts[3] = current_frame->clip.y + current_frame->clip.h - scroll_bar_width;
				v_pline (vdi_handle, 2, pts);
				pts[3] += scroll_bar_width - 1;
				pts[1]++;
				vsf_color (vdi_handle, slider_col);
				vr_recfl (vdi_handle, pts);
				pts[1] = ++pts[3];
				v_pline (vdi_handle, 2, pts);

				/* up arrow */
				pts[4] = pts[2] = pts[0] = current_frame->clip.x + current_frame->clip.w;
				pts[7] = pts[3] = pts[1] = current_frame->clip.y + scroll_bar_width / 3;
				pts[6] = pts[0] += scroll_bar_width / 2;
				pts[2] += scroll_bar_width / 4;
				pts[4] += scroll_bar_width * 3 / 4;
				pts[5] = pts[3] += scroll_bar_width / 2;
				v_pline (vdi_handle, 4, pts);

				/* down arrow */
				pts[7] = pts[3] = pts[1] = current_frame->clip.y + current_frame->clip.h -
					scroll_bar_width / 3;
				pts[5] = pts[3] -= scroll_bar_width / 2;
				v_pline (vdi_handle, 4, pts);
			}
		}

		if (current_frame->v_scroll_on == true && current_frame->h_scroll_on == true)
		{
			pts[2] = pts[0] = current_frame->clip.x + current_frame->clip.w + 1;
			pts[3] = pts[1] = current_frame->clip.y + current_frame->clip.h + 1;
			pts[2] += scroll_bar_width - 3;
			pts[3] += scroll_bar_width - 3;
			vr_recfl (vdi_handle, pts);
			pts[0] = ++pts[2];
			pts[3]++;
			v_pline (vdi_handle, 2, pts);
			pts[1] = pts[3];
			pts[0] -= scroll_bar_width - 2;
			v_pline (vdi_handle, 2, pts);
		}

		/* This next was a 0 instead of clip
		 * again it caused a crash on my TT
		 * baldrick July 14, 2001
		 */
		vs_clip (vdi_handle, 0, clip);

		wind_get (window_handle, WF_NEXTXYWH, &x, &y, &w, &h);
	}
	while (w + h > 0);
	wind_update (END_UPDATE);
	graf_mouse (M_ON, 0);
}

/* draw_box
 * 
 * draws a bounding box around an item
 * pts[4] is the object coordinates
 * border_color - is just that the border color
 */
static void
draw_box(WORD pts[4], WORD border_color)
{
	WORD pts2[4];
	
	vsl_color(vdi_handle, border_color);
	
	pts2[0] = pts2[2] = pts[0];
	pts2[1] = pts[1];
	pts2[3] = pts[3];
	v_pline (vdi_handle, 2, pts2);

	pts2[0] = pts2[2] = pts[2];
	pts2[1] = pts[1];
	pts2[3] = pts[3];
	v_pline (vdi_handle, 2, pts2);

	pts2[1] = pts2[3] = pts[1];
	pts2[0] = pts[0];
	pts2[2] = pts[2];
	v_pline (vdi_handle, 2, pts2);

	pts2[1] = pts2[3] = pts[3];
	pts2[0] = pts[0];
	pts2[2] = pts[2];
	v_pline (vdi_handle, 2, pts2);

	vsl_color(vdi_handle, 1);
}

/* draw_hr
 *
 * current_paragraph - our paragraph descriptor for the hr tag
 * x,y and w - the location and restraining width for the hr tag
 */
static void
draw_hr(struct paragraph_item *current_paragraph, WORD x, WORD y, WORD w)
{
	struct word_item *current_word;
	WORD current_line_width;
	WORD pts[4];
	
	current_word = current_paragraph->item;

	/* I changed the line below to frame_w, with
	 * the old code the horizontal rulers didn't not
	 * cover the frame as they are supposed to
	 * baldrick - July 13, 2001
	 *
	 * Alright I made another modification it now substracts
	 * 10 from the length and starts at 5 on a default
	 * This gives it that slight offset that you might be
	 * used to with other browsers
	 * baldrick - July 18, 2001
	 */

	if (current_word->word_width < 0)
		current_line_width = (WORD)((long)current_word->word_width * ((long)w / 10L) / -10L) - 10;
	else
		current_line_width = current_word->word_width;
				
	switch (current_paragraph->eop_space)
	{
		case center:
			pts[0] = (w - current_line_width) / 2;
			pts[2] = w - pts[0];
			break;
		case right:
			pts[0] = (w - current_line_width);
			pts[2] = w;
			break;
		default:
			pts[0] = 5;
			pts[2] = current_line_width;
	}

	pts[0] += x;
	pts[2] += (x - 1);
	pts[1] = pts[3] = y;/* + 10; what is 10 for ? baldrick*/
			
	if (current_word->word_height < 1)
	{
		pts[3] -= current_word->word_height;
		vsf_color (vdi_handle, 1);
		vr_recfl (vdi_handle, pts);
	}
	else
	{
		pts[3] += current_word->word_height - 1;
		vsf_color (vdi_handle, 9);
		vr_recfl (vdi_handle, pts);
		vsf_color (vdi_handle, 8);
		pts[0]++;
		pts[1]++;
		pts[2]++;
		pts[3]++;
		vr_recfl (vdi_handle, pts);
	}
}

/* draw_img
 *
 * current_paragraph - our paragraph descriptor for the IMG tag
 * x,y and w - the location and restraining width for the IMG tag
 */
static void
draw_img(struct paragraph_item *current_paragraph, WORD x, WORD y, WORD w)
{
	struct word_item *current_word;
	WORD current_line_width;
	WORD pts[4];
	
	current_word = current_paragraph->item;

	/* this section is for displaying an IMG
	 * 
	 * baldrick august 28, 2001
	 */

	current_line_width = current_word->word_width;

	switch (current_paragraph->eop_space)
	{
		case center:
			pts[0] = (w - current_line_width) / 2;
			pts[2] = w - pts[0];
			break;
		case right:
			pts[0] = (w - current_line_width) - 2;
			pts[2] = w - 2;
			break;
		case left:
			pts[0] = 3;
			pts[2] = current_line_width + 3;
			break;
		default: /* just assume it's left */
			pts[0] = 3;
			pts[2] = current_line_width + 3;
	}

	pts[0] += x;
	pts[2] += (x - 1);
	pts[1] = pts[3] = y;
			
	pts[3] += current_word->word_height - 1;

	vsf_color (vdi_handle, 9);
	v_bar(vdi_handle, pts);

	draw_box(pts,1);

}

/* draw_paragraph
 *
 * This handles any text sort of paragraph rendering
 *
 * current_paragraph - our paragraph descriptor
 * x,y,w and h - the location and restraining width
 * top_of_page ->start of drawing area
 * l_border, r_border and b_border are borders for the text to avoid
 * alignment any default alignment for the paragraph
 */
static WORD
draw_paragraph(struct paragraph_item *current_paragraph, WORD x, WORD y, WORD w, WORD h, WORD top_of_page, WORD l_border, WORD r_border, WORD b_border, WORD alignment)
{
	struct word_item *current_word, *line_start, *line_end;
	WORD left_indent, right_indent, line_height, current_line_width, line_tail = 0;
	WORD u, alignment_spacer, height_spacer;
	WORD previous_word_height = 0, pts[4];
	
	current_word = current_paragraph->item;

	left_indent = current_paragraph->left_border + l_border; /* baldrick August 28, 2001 modified to offset for pics */
	right_indent = current_paragraph->right_border + r_border;

	while (current_word != 0)
	{
		current_line_width = 0;
		line_start = current_word;
		line_height = 0;
		line_tail = 0;

		/* if past the object reset the borders */
		if (b_border)
		{
			if (y >= b_border)
			{
				left_indent = current_paragraph->left_border;
				right_indent = current_paragraph->right_border;	
				b_border = 0;
				l_border = 0;
			}
		}

		/* if we have a border we have an object to work around */

		if (l_border)
		{
			if ((current_line_width + current_word->word_width)
				>= (w - left_indent - right_indent))
			{

				/* watch for b_border or else tables will not print
				 */
				 
				if (b_border > 0)
					y = b_border;
					
				left_indent = current_paragraph->left_border;
				l_border = 0;
				b_border = 0;
			}
		}

		if (r_border)
		{
			if ((current_line_width + current_word->word_width)
				>= (w - left_indent - right_indent))
			{
				y = b_border;
				right_indent = current_paragraph->right_border;
				r_border = 0;
				b_border = 0;
			}
		}

/* Under some circumstances 'w' get a too small value and this loop runs
 * infinite and causes a system freeze due to wind_update (BEG_UPDATE)
 * without an END_UPDATE.  The following workaround cures this symptome
 * even if I don't know the failure reason yet. -- AltF4 Jan 02, 2002
 *
		while (current_word != 0
	       && (current_line_width + current_word->word_width) <
	       (w - left_indent - right_indent))
		{
			if (current_word->word_code == br && current_word != line_start)
				break;
*/
		while (current_word != 0)
		{
			if (current_word != line_start  &&
			    (current_word->word_code == br  ||
	           (current_line_width + current_word->word_width)
	            >= (w - left_indent - right_indent)))
				break;

			current_line_width += current_word->word_width;

			if (line_height < current_word->word_height)
				line_height = current_word->word_height;
			if (line_tail < current_word->word_tail_drop)
				line_tail = current_word->word_tail_drop;
				
			current_word = current_word->next_word;
		}

		y += line_height;

		line_end = current_word;

		current_word = line_start;

		switch (current_paragraph->alignment)
		{
			case center:
				alignment_spacer = 	(w - current_line_width - left_indent - right_indent) / 2 + left_indent;
				break;
			case right:
				alignment_spacer = (w - current_line_width - left_indent);
				break;
			default:
				if (alignment != -1) /* check for default alignment */
				{
					switch(alignment)
					{
						case center:
							alignment_spacer = 	(w - current_line_width - left_indent - right_indent) / 2 + left_indent;
							break;
						case right:
							alignment_spacer = (w - current_line_width - left_indent);
							break;
						default:
							alignment_spacer = left_indent;
					}
				}			
				else
					alignment_spacer = left_indent;
		}

		current_line_width = 0;

		while (current_word != line_end)
		{
			if (current_word->changed.style == true)
				vst_effects (vdi_handle, 8 * (current_word->styles.underlined != 0));

			if (current_word->changed.font == true)
			{
				vst_font (vdi_handle,
				fonts[current_word->styles.font]
					[(current_word->styles.bold != 0)]
					[(current_word->styles.italic != 0)]);
					
				vst_arbpt (vdi_handle, current_word->styles.font_size, &u,
						   &u, &u, &u);
			}

			if (current_word->changed.colour == true)
			{
				if (current_highlighted_link_area != 0 && current_word->link != 0)
				{
					vst_color (vdi_handle, highlighted_link_colour);
				}
				else
				{
					vst_color (vdi_handle, current_word->colour);
				}
			}
				
			switch (current_word->vertical_align)
			{
				case below:
					height_spacer = -(current_word->word_height / 2);
					break;
				case above:
					height_spacer = previous_word_height - current_word->word_height;
					break;
				case bottom:
					previous_word_height = current_word->word_height;
				default:
					height_spacer = line_tail; /* was 0; baldrick July 19, 2001*/
			}

			if (current_line_width == 0 && *current_word->item == Space_Code)
				switch (current_paragraph->alignment)
				{
					case right:
						break;
					case center:
						alignment_spacer -= current_word->space_width / 2;
						break;
					default:
						alignment_spacer -= current_word->space_width;
				}

			if (y > top_of_page - line_tail - 2)
			{
				v_ftext16 (vdi_handle, x + current_line_width + alignment_spacer,
						   y - height_spacer, current_word->item);

				if (current_word->styles.strike != 0)
				{
					pts[0] = x + current_line_width + alignment_spacer;
					pts[1] = pts[3] = y - (current_word->word_height / 2);
					pts[2] = pts[0] + current_word->word_width;
					v_pline (vdi_handle, 2, pts);
				}
			}

			current_line_width += current_word->word_width;
			current_word = current_word->next_word;
		}
			
		y += line_tail;
			
		if (y + (current_paragraph->eop_space < 0 ? current_paragraph->eop_space : 0) > (h + top_of_page))
			return(y);

	}

	return(y);
}

/* draw_table
 *
 * current_paragraph - our paragraph descriptor for the TABLE tag
 * x,y and w - the location and restraining width for the TABLE tag
 */
static long
draw_table(struct frame_item *current_frame, struct table_item *current_table, WORD x, WORD y, WORD w, WORD h, WORD top_of_page)
{	
	struct paragraph_item *table_paragraph;
	WORD current_line_width, temp_line_width;
	WORD pts[4],pts1[4];
	long current_height, old_height;
	WORD u;
	WORD left_border = 0, bottom_border = 0, right_border = 0;
	WORD i;
	
	/* reset our counter */
	current_table->temp_val = 0;
	
	old_height = current_height = (long)y;

	current_line_width = current_table->actual_width;

	switch (current_table->alignment)
	{
		case center:
			pts[0] = (w - current_line_width) / 2;
			pts[2] = w - pts[0];
			break;
		case right:
			pts[0] = (w - current_line_width) - 2;
			pts[2] = w - 2;
			break;
		case left:
			pts[0] = 3;
			pts[2] = current_line_width + 3;
			break;
		default: /* just assume it's left */
			pts[0] = 3;
			pts[2] = current_line_width + 3;
	}

	pts[0] += x;
	pts[2] += (x - 1);
	pts[1] = pts[3] = (WORD)y;
			
	pts[3] += (WORD)current_table->table_height - 1;

	vsf_color (vdi_handle, current_table->bgcolor);

	v_bar(vdi_handle, pts);

	draw_box(pts,1);
	
	current_table->current_child = current_table->children;

	while (current_table->current_child != 0)
	{
		table_paragraph = current_table->current_child->item ;
		current_frame->current_word = table_paragraph->item;

		/* draw box */
		if (current_table->current_child->actual_height > 0)
		{
			pts1[0] = pts[0] + table_paragraph->left_border;
			 
		 	if (table_paragraph->area.y > 0)
				pts1[1] = (WORD)old_height + table_paragraph->area.y;
			else
				pts1[1] = (WORD)old_height;

			/* ok check for colspan in here */
			
			if (current_table->current_child->colspan > 1)
			{
				if ((current_table->temp_val + current_table->current_child->colspan - 1)==(current_table->num_cols - 1))
					pts1[2] = pts[0] + current_table->actual_width;
				else
				{
					pts1[2] = pts1[0] + current_table->col_widths[current_table->temp_val];
					
					for (i = 0; i < (current_table->current_child->colspan - 1); i++)
						pts1[2] += current_table->col_widths[current_table->temp_val + current_table->current_child->colspan];
				}
			}
			else /* no colspan on child */
			{
				if (current_table->temp_val == (current_table->num_cols - 1))
					pts1[2] = pts[0] + current_table->actual_width; /*table_width; */
				else
					pts1[2] = pts1[0] + current_table->col_widths[current_table->temp_val] ;
			}

			pts1[3] = pts1[1] + current_table->current_child->actual_height;

			vsf_color (vdi_handle, current_table->current_child->bgcolor);

			v_bar(vdi_handle, pts1);

			draw_box(pts1,1);
		}
				
		while (table_paragraph != 0)
		{
			/* set current height to our start height plus the vertical
			 * offset of this paragraph
			 */

			/* ok this next test shouldn't be here.  It should just be the
			 * first formula... but that is not working right now.  So this
			 * is kind of a hack that should not be needed once the root 
			 * cause is found - baldrick October 29, 2001
			 */		 	
			 
		 	if (table_paragraph->area.y > 0)
				current_height = old_height + table_paragraph->area.y;
			else
				current_height = old_height;

			/* check if the paragraph appears in the viewport
			 */

			if ((current_height + table_paragraph->area.h) > top_of_page)
			{
				current_frame->current_word = table_paragraph->item;

				/* I put this here to avoid some strange formatting problems
				 * that were appearing
				 */
				vst_effects (vdi_handle, 8 * (current_frame->current_word->styles.underlined != 0));
				vst_font (vdi_handle, fonts[current_frame->current_word->styles.font][(current_frame->current_word->styles.bold != 0)][(current_frame->current_word->styles.italic != 0)]);
				vst_arbpt (vdi_handle, current_frame->current_word->styles.font_size, &u, &u, &u, &u);
				vst_color (vdi_handle, current_frame->current_word->colour);

				if (table_paragraph->paragraph_code == hr)
				{
					draw_hr(table_paragraph, pts[0], (WORD)current_height, current_line_width);

					current_height += abs (current_frame->current_word->word_height) + 20; /* what was the + 20 for? baldrick*/
				}
				else if (table_paragraph->paragraph_code == img)
				{
					if (current_table->num_cols == 1)
						draw_img(table_paragraph, pts1[0], (WORD)current_height, current_line_width);
					else
						draw_img(table_paragraph, pts1[0], (WORD)current_height, current_table->current_child->actual_width);

					/* we now need to look for the borders and location
					 * of following paragraphs.  At some point this code
					 * will be moved or disappear
					 */

					temp_line_width = current_frame->current_word->word_width;

					switch (table_paragraph->eop_space)
					{
						case center:
							current_height += abs (current_frame->current_word->word_height);
							left_border = 0;
							right_border = 0;
							break;
						case right:
							left_border = 0;
							right_border = temp_line_width + 2;
							break;
						case left:
							left_border = temp_line_width + 2;
							right_border = 0;
							break;
						default: /* just assume it's left */
							left_border = temp_line_width + 2;
							right_border = 0;
					}

					bottom_border = (WORD)current_height + abs(current_frame->current_word->word_height);
				}
				else if (table_paragraph->paragraph_code == table)
				{
					current_height = draw_table(current_frame, table_paragraph->table, pts[0], (WORD)current_height, current_line_width, h, top_of_page);
	
					/*current_height += table_paragraph->table->table_height;*/
				}
				else
				{
					if (current_table->temp_val == (current_table->num_cols - 1))
						right_border = 0;
					else
						right_border =	current_table->actual_width - (table_paragraph->left_border + current_table->col_widths[current_table->temp_val]);

					left_border = 0; /*table_paragraph->left_border;*/
					bottom_border = 0;

					current_height = (long)draw_paragraph(table_paragraph, pts[0], (WORD)current_height, current_line_width, h, top_of_page, left_border, right_border, bottom_border,current_table->current_child->alignment);

					current_height += table_paragraph->eop_space;
				}
			}
		
			/* if we are in the first column and the height is greater than
			 * the bottom of the viewport - return
			 */
			 
			if ((current_table->temp_val == (current_table->num_cols - 1))
				&& (current_height > h))
				return(current_height);

			table_paragraph = table_paragraph->next_paragraph;
		}
	
		current_table->temp_val = current_table->temp_val + current_table->current_child->colspan;

		if (current_table->temp_val >= current_table->num_cols)
			current_table->temp_val = 0;

		current_table->current_child = current_table->current_child->next_child;
	}
	
	return(current_height);
}

/* draw_frame_contents
 *
 * current_paragraph -> start paragraph for the frame  
 * current_height -> where is top of page in relation to the real top of the page
 *     so when we start it should equal the y offset of the frame as you scroll down
 *     the page, it moves up beyond the y offset of the frame, so it's not drawn
 *     (ex current_height = -120 ... first list would be printed at 120 pixels above the frame top)
 * frame_h -> should be the height of the frame
 * top_of_page -> this should be the y offset of the frame 
 *					but it can be a different value.  This is the top of where to draw.
 *                  When scrolling a page it is just a small value at the bottom etc.
 */
void
draw_frame_contents (struct frame_item *current_frame, struct paragraph_item *current_paragraph, WORD frame_x, long current_height,
		     WORD frame_w, WORD frame_h, WORD top_of_page)
{
	struct word_item *current_word;
	WORD current_line_width;
	WORD u;
	WORD left_border = 0, bottom_border = 0, right_border = 0;
	long old_height = current_height;

	/* make certain we haven't scrolled off the page */
	if (current_paragraph == 0)
		return;

	current_word = current_paragraph->item;
	vst_effects (vdi_handle, 8 * (current_word->styles.underlined != 0));
	vst_font (vdi_handle, fonts[current_word->styles.font][(current_word->styles.bold != 0)][(current_word->styles.italic != 0)]);
	vst_arbpt (vdi_handle, current_word->styles.font_size, &u, &u, &u, &u);
	vst_color (vdi_handle, current_word->colour);

	while (current_paragraph != 0)
	{
		/* set current height to our start height plus the vertical
		 * offset of this paragraph
		 */
		 
		current_height = old_height + current_paragraph->area.y;

		/* check if the paragraph appears in the viewport
		 */

		if ((current_height + current_paragraph->area.h) > top_of_page)
		{
			current_word = current_paragraph->item;

			/* I put this here to avoid some strange formatting problems
			 * that were appearing
			 */
			vst_effects (vdi_handle, 8 * (current_word->styles.underlined != 0));
			vst_font (vdi_handle, fonts[current_word->styles.font][(current_word->styles.bold != 0)][(current_word->styles.italic != 0)]);
			vst_arbpt (vdi_handle, current_word->styles.font_size, &u, &u, &u, &u);
			vst_color (vdi_handle, current_word->colour);

/*			current_height = old_height + current_paragraph->area.y;
*/
			if (current_paragraph->paragraph_code == hr)
			{
				draw_hr(current_paragraph, frame_x, (WORD)current_height, frame_w);

				current_height += abs (current_word->word_height) + 20; /* what was the + 20 for? baldrick*/
			}
			else if (current_paragraph->paragraph_code == img)
			{
				draw_img(current_paragraph, frame_x, (WORD)current_height, frame_w);

				/* we now need to look for the borders and location
				 * of following paragraphs.  At some point this code
				 * will be moved or disappear
				 */

				current_line_width = current_word->word_width;

				switch (current_paragraph->eop_space)
				{
					case center:
						current_height += abs (current_word->word_height);
						left_border = 0;
						right_border = 0;
						break;
					case right:
						left_border = 0;
						right_border = current_line_width + 2;
						break;
					case left:
						left_border = current_line_width + 2;
						right_border = 0;
						break;
					default: /* just assume it's left */
						left_border = current_line_width + 2;
						right_border = 0;
				}

				bottom_border = (WORD)current_height + abs(current_word->word_height);
			}
			else if (current_paragraph->paragraph_code == table)
			{
				current_height = draw_table(current_frame, current_paragraph->table, frame_x, (WORD)current_height, frame_w, frame_h, top_of_page);

				/*current_height += current_paragraph->table->table_height;*/
			}
			else
			{
				current_height = (long)draw_paragraph(current_paragraph, frame_x, (WORD)current_height, frame_w, frame_h, top_of_page, left_border, right_border, bottom_border, -1);

				current_height += current_paragraph->eop_space;
			}
		}
/*		else
			printf("failure of match\r\n");
*/
		/* are we past the end of the page?
		 * I put this here since it was previously going way
		 * past the area that it should have stopped at.
		 * possibly not the right location etc here
		 * baldrick September 19, 2001
		 */


		if(current_height > frame_h)
			return;
					
		current_paragraph = current_paragraph->next_paragraph;		
	}
}

