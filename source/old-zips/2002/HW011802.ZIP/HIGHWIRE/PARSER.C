/*
 * parser.c -- Parser functions for HTML expressions.
 *
 * AltF4 - Jan 14, 2002
 *
 */

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

#define numberof(arr)   (sizeof(arr) / sizeof(*arr))


#include "global.h"
#include "token.h"
#include "scanner.h"
#include "parser.h"

/* Array to store KEY=VALUE pairs found while a parse() call.
 */
struct VALUE {
	HTMLKEY      Key :16;
	unsigned     Len :16;
	const char * Value;
};
static struct VALUE val_tab[16];
static int          val_num = 0;

/*==============================================================================
 * Finds the VALUE of 'key' that was read while the last parse() call.
 * If successful the VALUE will be copied to 'output' up to 'max_len' character
 * (including the trailing '\0') and a TRUE will be returned.
 * Else a FALSE will be returned.
 */
int
get_value (HTMLKEY key, char * output, size_t max_len)
{
	int found = 0;
	int i;
	
	for (i = 0; i < val_num; i++) {
		if (key == val_tab[i].Key) {
			if (!output) {
				found = 1;
			} else if (val_tab[i].Len && val_tab[i].Len < max_len) {
				memcpy (output, val_tab[i].Value, val_tab[i].Len);
				output[val_tab[i].Len] = '\0';
				found = 1;
			}
			break;
		}
	}
	return found;
}

/*==============================================================================
 * Returns the VALUE of 'key' that was read while the last parse() call as a
 * malloc'ed zero terminated character string.
 * If not successful the result is a NULL pointer.
 */
char *
get_value_str (HTMLKEY key)
{
	char * found = NULL;
	int i;
	
	for (i = 0; i < val_num; i++) {
		if (key == val_tab[i].Key) {
			found = malloc (val_tab[i].Len +1);
			memcpy (found, val_tab[i].Value, val_tab[i].Len);
			found[val_tab[i].Len] = '\0';
			break;
		}
	}
	return found;
}


/*==============================================================================
 * Returns the VDI color VALUE of 'key' that was read while the last parse()
 * call.
 * If not successful a negative number will be returned.
 */
WORD
get_value_color (HTMLKEY key)
{
	WORD color = -1;
	int i;
	
	for (i = 0; i < val_num; i++) {
		if (key == val_tab[i].Key) {
			long value = scan_color (val_tab[i].Value, val_tab[i].Len);
			if (value >= 0) {
				color = remap_color (value);
			}
			break;
		}
	}
	return color;
}


/*==============================================================================
 * Parses a html TAG expression of the forms
 *    <TAG>  |  <TAG KEY ...>  |  <TAG KEY=VALUE ...>
 * The 'pptr' content must point to the first character after the leading '<'
 * and a possibly '/'.  After processing it is set to first character behind the
 * expression, either behind the closing '>' or to a trailing '\0'.
 * If successful the found known KEYs are stored with their VALUEs internally
 * and a TAG enum is returned.
 * Else the symbol TAG_Unknown is returned.
 */
struct TAG {
	const char * Name;
	HTMLTAG      Tag;
};
static struct TAG tag_table[] = {
	#define __TAG_ITEM(t) { #t, TAG_##t }
	#include "token.h"
};
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
struct KEY {
	const char * Name;
	HTMLKEY      Key;
};
static struct KEY key_table[] = {
	#define __KEY_ITEM(k) { #k, KEY_##k }
	#include "token.h"
};
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
HTMLTAG
parse (char ** _line)
{
	HTMLTAG tag  = TAG_Unknown;
	char  * line = *_line;
	char  * p    = line;
	size_t  len;
	
	
	/*** first find the tag, same way as in Scanner.c */
	
	int beg = 0;
	int end = (int)numberof(tag_table) -1;
	
	val_num = 0;
	
	while (isalpha(*p)) p++;
	len = p - line;
	do {
		int i = (end + beg) /2;
		int d = strnicmp (line, tag_table[i].Name, len);
		if (d > 0) {
			beg = i +1;
		} else if (d || tag_table[i].Name[len]) {
			end = i -1;
		} else {
			if ((tag = tag_table[i].Tag) == TAG_H) {
				if (line[len] < '1' || line[len] > '6') {
					tag = TAG_Unknown;
				} else {
					val_tab[0].Key   = KEY_H_HEIGHT;
					val_tab[0].Value = p++;
					val_tab[0].Len   = 1;
					val_num = 1;
				}
			}
			break;
		}
	} while (beg <= end);

/*printf("% 2i [%.*s]\n", tag, (int)len, line);*/
	
	/*** if the tag is known or not, in every case we have to go through the list
	 *   of variabls to avoid the parser to become confused   */
	
	while (isspace(*p)) p++;
	
	while (*p  &&  *p != '>') {
		char * val = NULL;
		
		line = p;
		while (isalpha(*p) || *p == '-') p++;
		len = p - line;
		
		while (isspace(*p)) p++;
		if (*p == '=' || !len) {
			while (isspace(*(++p)));
			val = p;
			p = (*val == '"' ? strchr (++val, '"') : strpbrk (val, " >\t\r\n"));
			if (!p) p = strchr (val, '\0');
		}
		
		if (tag != TAG_Unknown  &&  len) {
			beg = 0;
			end = (int)numberof(key_table) -1;
			do {
				int i = (end + beg) /2;
				int d = strnicmp (line, key_table[i].Name, len);
				if (d > 0) {
					beg = i +1;
				} else if (d || key_table[i].Name[len]) {
					end = i -1;
				} else {
					if (val_num < numberof(val_tab)) {
						val_tab[val_num].Key = key_table[i].Key;
						if (val  &&  val < p) {
							val_tab[val_num].Value = val;
							val_tab[val_num].Len   = (unsigned)(p - val);
						} else {
							val_tab[val_num].Value = NULL;
							val_tab[val_num].Len   = 0;
						}
						val_num++;
					}
/* printf("  |%.*s=%.*s|\n", (int)len, line, (int)(p - val), val);*/
					break;
				}
			} while (beg <= end);
		}
		while (isspace(*p)) p++;
		if (*p == '"') {
			while (isspace(*++(p)));
		}
	}
	
	if (*p == '>') {
		p++;
	}
	*_line = p;
	
	return tag;
}
