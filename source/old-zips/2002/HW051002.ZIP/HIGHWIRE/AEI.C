/* @(#)highwire/AEI.c
 */
#include <stdlib.h>
#include <string.h>

#ifdef __PUREC__
#include <tos.h>

#else /* LATTICE || __GNUC__ */
#include <osbind.h>
#endif

#include <gem.h>

#include "global.h"
#include "Containr.h"

#include "Loader.h"
#include "Logging.h"


/* Der folgende Code testet, ob appl_getinfo() in der aktuellen
 * Systemumgebung zur Verf�gung steht, und ruft im positiven
 * Fall die besagte Funktion auf.
 *
 * Es bietet sich an, statt appl_getinfo() nur appl_xgetinfo()
 * in eigenen Programmen zu verwenden.
 *
 * The following code tests whether appl_getinfo() is available
 * on the system.  returns FALSE if not available, positive return
 * value if it is available.
 */
WORD appl_xgetinfo(WORD type, WORD *out1, WORD *out2, WORD *out3, WORD *out4)
{
	static BOOL has_agi = -1;/*FALSE*/

	if (has_agi < 0)/*== FALSE*/
		has_agi = gl_ap_version >= 0x400 || appl_find("?AGI") >= 0;
		          /* || (gl_ap_version == 0x399 && MagiC_version >= 0x0200) */

	if (has_agi)
		return appl_getinfo(type, out1, out2, out3, out4);
	else
		return FALSE;
}

void
wind_redraw (short hdl, const GRECT * p_clip)
{
	GRECT clip, work;
	wind_get_grect (0,   WF_WORKXYWH, &clip);
	wind_get_grect (hdl, WF_WORKXYWH, &work);
	
	if (rc_intersect (&clip, &work)
	    && (!p_clip || rc_intersect (p_clip, &work))) {
		
		wind_update (BEG_UPDATE);
		wind_get_grect (hdl, WF_FIRSTXYWH, &clip);
		while (clip.g_w > 0 && clip.g_h > 0) {
			if (rc_intersect (&work, &clip)) {
				containr_redraw (NULL, &clip);
			}
			wind_get_grect (hdl, WF_NEXTXYWH, &clip);
		}
		wind_update (END_UPDATE);
	}
}


void
wind_scroll (short hdl, CONTAINR cont, long dx, long dy)
{
	GRECT clip, work;
	wind_get_grect (0,   WF_WORKXYWH, &clip);
	wind_get_grect (hdl, WF_WORKXYWH, &work);
	
	if (containr_shift (cont, &dx, &dy)
	    && rc_intersect (&clip, &work) && rc_intersect (&cont->Area, &work)) {
		wind_update (BEG_UPDATE);
		wind_get_grect (hdl, WF_FIRSTXYWH, &clip);
		while (clip.g_w > 0 && clip.g_h > 0) {
			if (rc_intersect (&work, &clip)) {
				containr_scroll (cont, &clip, dx, dy);
			}
			wind_get_grect (hdl, WF_NEXTXYWH, &clip);
		}
		wind_update (END_UPDATE);
	}
}


static void
set_name (const char * text)
{
	static char name[256];
	size_t len = strlen (text);
	if (len >= sizeof(name)) len = sizeof(name) -1;
	if (len) memcpy (name, text, len);
	name[len] = '\0';
	wind_set_str (window_handle, WF_NAME, name);
}

static void
set_info (const char * text)
{
	static char info[256];
	if (text) {
		size_t len = strlen (text);
		if (len >= sizeof(info)) len = sizeof(info) -1;
		if (len) memcpy (info, text, len);
		info[len] = '\0';
	}
	wind_set_str (window_handle, WF_INFO, info);
}

void
wind_handler (HW_EVENT event, long arg, CONTAINR cont, void * gen_ptr)
{
	switch (event) {
		
		case HW_PageCleared:
			break;
		
		case HW_PageStarted:
			if (!number_of_frames_left_to_load++) {
				graf_mouse (BUSYBEE, NULL);
			}
		case HW_SetTitle:
			if (!cont->Parent) {
				set_name (gen_ptr);
			} else {
				set_info (gen_ptr);
			}
			break;
		
		case HW_PageFinished:
			if (gen_ptr) {
				wind_redraw (window_handle, gen_ptr);
			}
			if (!number_of_frames_left_to_load || !--number_of_frames_left_to_load) {
				short mx, my, u;
				graf_mouse (ARROW, NULL);
			/*	set_info (""); */
				graf_mkstate (&mx, &my, &u,&u);
				check_mouse_position (mx, my);
			}
			break;
			
		default:
			errprintf ("wind_handler (%i, %p)\n", event, cont);
	}
}


/* Gemscript support added
 * Matthias Jaap  December 21, 2001
 */

#define VA_START   0x4711
#define GS_REQUEST  0x1350
#define GS_REPLY    0x1351
#define GS_COMMAND  0x1352
#define GS_ACK      0x1353
#define GS_QUIT     0x1354

#define GSM_COMMAND 0x0001

#define GSACK_OK      0
#define GSACK_UNKNOWN 1
#define GSACK_ERROR   2
typedef struct
{
	long len;
	WORD  version;
	WORD  msgs;
	long ext;
} GS_INFO;

WORD gsapp = -1;
/* All GLOBAL memory is merged to one block and allocated in main(). */
char *xaccname;
char *gslongname;
GS_INFO *gsi = NULL;

/* rewrote by Rainer  May 2002 
*/
static void
vastart(const WORD pipe[8])
{
	const char *cmd = *(const char **)&pipe[3];
	/* if a parameter contains spaces then
	 *    it is enclosed with '...', and a ' is encoded as '' */
	const BOOL quoted = cmd[0] == '\'' && cmd[1] != '\0'
	                    && strrchr(&cmd[2], '\'') != NULL && strrchr(&cmd[2], '\'')[1] == '\0';

	if (!quoted)
		init_load(cmd);  /* BUG: should be some kind of new_loader_job()? */
	else {
		char filename[HW_PATH_MAX], *p = filename;

		cmd++;
		while (cmd[0] != '\0') {
			if (cmd[0] == '\'' && cmd[1] == '\'')
				cmd++;
			p++[0] = cmd++[0];
		}
		p[-1] = '\0';  /* overwrite closing ' */
		init_load(filename);  /* BUG: should be some kind of new_loader_job()? */
	}
}



static const char *
nextToken(const char *pcmd)
{
	if (!pcmd)
		return (NULL);

	pcmd += (strlen(pcmd) + 1);

	while (TRUE)
		switch (*pcmd)
		{
			case 0:
				return (NULL);

			case 1:
			case 2:
			/* Hex-Kommandos auswerten */
			case 3:
			case 4:
			case 5:
			case 6:
				pcmd += (strlen(pcmd) + 1);
				break;

			default:
				return (pcmd);
		}
}


/* Returns TRUE if HighWire shall exit. */
static BOOL
doGSCommand(const WORD pipe[8])
{
	const char *cmd = *(const char **)&pipe[3];
	WORD answ[8];
	BOOL quit = FALSE;

	answ[0] = GS_ACK;
	answ[1] = gl_apid;
	answ[2] = 0;
	answ[3] = pipe[3];
	answ[4] = pipe[4];
	answ[5] = 0;
	answ[6] = 0;
	answ[7] = GSACK_ERROR;

	if (cmd)
	{
		answ[7] = GSACK_UNKNOWN;

		if (!stricmp(cmd, "Quit"))
		{
			quit = TRUE;
			answ[7] = GSACK_OK;
		}
		else if (!stricmp(cmd, "Open"))
		{
			cmd = nextToken(cmd);
			init_load(cmd);
			answ[7] = GSACK_OK;
		}
		else if (!stricmp(cmd, "AppGetLongName"))
		{
			strcpy(gslongname, "HighWire");
			*(char **)&answ[5] = gslongname;
			answ[7] = GSACK_OK;
		}
	}

	appl_write(pipe[1], 16, answ);

	return quit;
}


/*
 * full_window
 *
 * Sets whether window is full or original size
 *
 * win is the widow_handle in this simple case
 */
 
static void full_window(WORD win)
{
	GRECT	new;

	/* realistically under some AES we should check if the
	 * window belongs to us. Before proceding with modification.
	 * I have witnessed this under MagiC with Jinnee.  I'm not
	 * certain if it's specific to those.
	 * The check won't hurt anyone else though
	 * / baldrick
	 */
	if (win == window_handle)
	{
		if (win_status == 1)
		{
			/* Shrink Window to normal */
			wind_get_grect(win, WF_PREVXYWH, &new);
			win_status = 0;
		}
		else
		{
			/* Full window */
			wind_get_grect(win, WF_FULLXYWH, &new);
			win_status = 1;
		}

		wind_set_grect(win, WF_CURRXYWH, &new);
	}
}


/*
 * Iconify.
 */
static void iconify_window(WORD win, GRECT *new)
{
	if (win == window_handle)
	{
		wind_set_grect(window_handle, WF_ICONIFY, (GRECT*)new);

		/* get the old status before overwritting it */
		pre_status = win_status;
		win_status = 2;

		wind_set (window_handle, WF_BOTTOM, 0, 0, 0, 0);
	}
}


static void uniconify_window(WORD win, GRECT *new)
{
	if (win == window_handle)
	{
		wind_set_grect(window_handle, WF_UNICONIFY, (GRECT*)new);

		win_status = pre_status;

		wind_set (window_handle, WF_TOP, 0, 0, 0, 0);
	}
}


/* Returns TRUE if HighWire shall exit. */
BOOL
process_messages (WORD msg[])
{
/*	short wx, wy, ww, wh;*/

	switch (msg[0])
	{
		case VA_START:
			vastart(msg);
			break;
		case GS_REQUEST:
			{
				GS_INFO *sender = *(GS_INFO **)&msg[3];
				WORD answ[8];

				answ[0] = GS_REPLY;
				answ[1] = gl_apid;
				answ[2] = 0;
				answ[3] = 0;
				answ[4] = 0;
				answ[5] = 0;
				answ[6] = 1;
				answ[7] = msg[7];

				gsi->len = sizeof(GS_INFO);
				gsi->version = 0x0100;
				gsi->msgs = GSM_COMMAND;
				gsi->ext = 0L;

				*(GS_INFO **)&answ[3] = gsi;

				if (sender)
				{
					if (sender->version >= 0x0070)
					{
						answ[6] = 0;
						gsapp = msg[1];
					}
				}

				appl_write(gsapp, 16, answ);
			}
			break;
		case GS_COMMAND:
			if (doGSCommand(msg))
				return TRUE;
			break;
		case WM_MOVED: {
			GRECT work;
			wind_set_grect (msg[3], WF_CURRXYWH, (GRECT*)(msg + 4));
			wind_get_grect (msg[3], WF_WORKXYWH, &work);
			containr_relocate (containr_Base (NULL), work.g_x, work.g_y);
		}	break;
		case WM_SIZED: {
			GRECT work;
			wind_set_grect (msg[3], WF_CURRXYWH, (GRECT*)(msg +4));
			wind_get_grect (msg[3], WF_WORKXYWH, &work);
			containr_calculate (containr_Base (NULL), &work);
		}
		case WM_REDRAW:
			wind_redraw (window_handle, (GRECT*)(msg + 4));
			break;
		case WM_TOPPED:
			wind_set (window_handle, WF_TOP, msg[3], 0, 0, 0);
			break;
		case WM_FULLED: {
			GRECT work;
			full_window(msg[3]);
			wind_get_grect (msg[3], WF_WORKXYWH, &work);
			containr_calculate (containr_Base (NULL), &work);
		}	break;
		case WM_BOTTOMED:
			wind_set (window_handle, WF_BOTTOM, msg[3], 0, 0, 0);
			break;
		case WM_ICONIFY:
			iconify_window(msg[3], ((GRECT *)&msg[4]));
			break;
		case WM_UNICONIFY:
			uniconify_window(msg[3], ((GRECT *)&msg[4]));
			break;
#ifdef GEM_MENU
		case MN_SELECTED:
			handle_menu(msg[4], msg);
			break;
#endif
		case WM_CLOSED:
		case AP_TERM:
			return (TRUE);
	}
	return (FALSE);
}
