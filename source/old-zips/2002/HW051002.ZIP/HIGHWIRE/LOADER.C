/* @(#)highwire/Loader.c
 *
 * Currently has ended up a junk file of initializations
 * loading routine and some assorted other routines
 * for file handling.
 */


#ifdef __PUREC__
#include <tos.h>
#include <ext.h>
#endif

#ifdef LATTICE
#include <dos.h>
#include <mintbind.h>

/* I'm certain this is in a .H somewhere, just couldn't find it - Baldrick*/
#define O_RDONLY    0x00
#define DTA struct FILEINFO
#define d_length size
#endif

#ifdef __GNUC__
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>
# include <mintbind.h>
#endif

#include <gemx.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "global.h"
#include "av_comm.h"
#include "schedule.h"
#include "Containr.h"
#include "Location.h"
#include "Loader.h"


static char *load_file (const LOCATION loc);


/*******************************************************************************
 * the following function should placed either in parse.c or render.c but
 * at the moment I have no clue where to do it best - AltF4 Feb. 4, 2002
 */

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * job function for parseing a file and attach it to the passed frame
 */
static BOOL
parser_job (void * arg)
{
	LOADER   loader = arg;
	CONTAINR cont   = loader->Target;
	FRAME    frame  = new_frame (loader->Location);

	frame->Container = cont;
	
	containr_clear (cont);
	
	switch (loader->MimeType)
	{
		case MIME_TXT_HTML:
			frame->item = parse_html (loader->Data, frame);
			break;

		default: /* pretend it's text */
			frame->item = parse_text (loader->Data, frame);
	}

	if (!cont->Mode) {
		containr_setup  (cont, frame, loader->Location->Anchor);
		containr_notify (cont, HW_PageFinished, &cont->Area);
		active_keyboard_frame = frame;
	
	} else {
		delete_frame (&frame);
		containr_calculate (cont, NULL);
		containr_notify    (cont, HW_PageFinished, NULL);
	}
	
	delete_loader (&loader);

	return FALSE;
}

/******************************************************************************/


/*============================================================================*/
const struct {
	const char * Ext;
	const MIMETYPE Type;
	const char * Appl;
}
mime_list[] = {
	{ "au",   MIME_AUDIO,      "GEMJing"  },
	{ "avr",  MIME_AUDIO,      "GEMJing"  },
	{ "dvs",  MIME_AUDIO,      "GEMJing"  },
	{ "gif",  MIME_IMG_GIF,    ""         },
	{ "hsn",  MIME_AUDIO,      "GEMJing"  },
	{ "htm",  MIME_TXT_HTML,   NULL       },
	{ "html", MIME_TXT_HTML,   NULL       },
	{ "hyp",  MIME_APPL,       "ST-Guide" },
	{ "img",  MIME_IMG_X_XIMG, ""         },
	{ "jpg",  MIME_IMG_JPEG,   ""         },
	{ "pdf",  MIME_APP_PDF,    "MyPdf"    },
	{ "php",  MIME_TXT_HTML,   NULL       },
	{ "php3", MIME_TXT_HTML,   NULL       },
	{ "php4", MIME_TXT_HTML,   NULL       },
	{ "png",  MIME_IMG_PNG,    ""         },
	{ "snd",  MIME_AUDIO,      "GEMJing"  },
	{ "txt",  MIME_TXT_PLAIN,  NULL       },
	{ "wav",  MIME_AUDIO,      "GEMJing"  }
};
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - */
LOADER
new_loader (LOCATION loc)
{
	const char * ext;
	LOADER loader = malloc (sizeof (struct s_loader));
	loader->Target   = NULL;
	loader->Data     = NULL;
	loader->Location = location_share (loc);

	/* resolve the MIME type depending on the file name extension
	 */
	loader->MimeType = MIME_TEXT;
	if ((ext = strrchr (loc->File, '.')) != NULL && *(++ext)) {
		size_t i = 0;
		do if (stricmp (ext, mime_list[i].Ext) == 0) {
			loader->MimeType = mime_list[i].Type;
			if (mime_list[i].Appl) {
				loader->Data  = strdup (mime_list[i].Appl);
			}
			break;
		} while (++i < numberof(mime_list));
	} else if (loc->File[0] == '\0')  /* directory listing or default file */
		loader->MimeType = MIME_TXT_HTML;

	return loader;
}


/*============================================================================*/
void
delete_loader (LOADER * p_loader)
{
	LOADER loader = *p_loader;
	if (loader) {
		free_location (&loader->Location);
		if (loader->Data) free (loader->Data);
		free (loader);
		*p_loader = NULL;
	}
}


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * job function for loading a file + url into memory ready for parsing
 */
static BOOL
loader_job (void * arg)
{
	LOADER loader = arg;
	
	loader->Data = load_file (loader->Location);

	if (!loader->Data) {
		loader->Data     = strdup ("<html><head><title>Error</title></head>"
		                           "<body><h1>Page not found!</h1></body></html>");
		loader->MimeType = MIME_TXT_HTML;
	}
	/* registers a parser job with the scheduler */
	sched_insert (parser_job, loader);

	return FALSE;
}


/*----------------------------------------------------------------------------*/
static short
find_application (const char * name)
{
	short id = -1;

	if (name == NULL && ((name = getenv ("AVSERVER")) == NULL || !*name)) {
		static const char * list[] = {
			"AVServer", "Jinnee", "Thing", "MagxDesk", "GEMINI",
			"StrngSrv", "DIRECT", "EASY",  "KAOS",
			NULL };
		const char ** desktop = list;
		while ((id = find_application (*desktop)) < 0 && *(++desktop));

	} else if (name && *name) {
		char buf[] = "        ", * p = buf;
		while (*name && *p) *(p++) = toupper (*(name++));
		id = appl_find (buf);
	}
	return id;
}


/*==============================================================================
 * registers a loader job with the scheduler.
 *
 * The parameters 'address', 'base' or 'target' can be NULL.
 * address == NULL: reread the file in base with default_encoding
 */
void
new_loader_job (const char *address, LOCATION base,
                const ENCODING default_encoding, CONTAINR target)
{
	LOADER loader = new_loader(address? new_location(address, base) : base);
	loader->Location->encoding = default_encoding;
	loader->Target = target;

/*printf("new_loader_job(): __refs %d, encoding %d, isTos %d\n\t'%s'\n", loader->Location->__reffs, loader->Location->encoding, loader->Location->isTos, loader->Location->FullName);*/

	if (loader->Data) {
		short           id = find_application (loader->Data);
		if (id >= 0 || (id = find_application (NULL)) >= 0) {
			short msg[8];
			msg[0] = (loader->MimeType == MIME_APP_PDF
			          ? PDF_AV_OPEN_FILE : VA_START);
			msg[1] = gl_apid;
			msg[2] = 0;
			*(char**)(msg +3) = strcpy (va_helpbuf, loader->Location->FullName);
			msg[5] = msg[6] = msg[7] = 0;
			appl_write (id, 16, msg);

			if (target && !target->Mode) {
				free (loader->Data);
				loader->Data     = strdup ("\n\tLoading application...\n");
				loader->MimeType = MIME_TXT_PLAIN;

				containr_notify (target, HW_PageStarted,
				                 loader->Location->FullName);
				sched_insert (parser_job, loader);

			} else {
				delete_loader (&loader);
			}
		}
	} else {
		containr_notify (target, HW_PageStarted, loader->Location->FullName);
		sched_insert (loader_job, loader);
	}
}


/******************************************************************************/

/* This is simply used at the moment to track the last working file */
char last_location[HW_PATH_MAX] = "\0";
ENCODING last_encoding = ENCODING_WINDOWS1252;

/* this is to store last page for backing up */
char prev_location[HW_PATH_MAX] = "\0";
ENCODING prev_encoding;


#if 0 /***** REPLACED *****/
long
search_for_named_location (char *name, struct named_location *current_location)
{
	while (current_location && strcmp (name, current_location->link->address) != 0)
		current_location = current_location->next_location;

	if (current_location)
		return current_location->offset.Y;

	return 0;
}
#endif /***** REPLACED *****/


#if 0 /***** REPLACED *****/
/*
 * get_fname - gets a file name from a full path
 *
 */

static void
get_fname(char *dest, const char *src)
{
	int i;

	for (i = (int)strlen(src); i >= 0; --i)
	{
		if (src[i] == '\\')
			break;
	}

	strcpy(dest, &src[i + 1]);
}
#endif /***** REPLACED *****/


#if 0 /***** REPLACED *****/
/*
 * get_decoder_type - tries to discover the appropriate decoder
 *         for a file based on it's extension.
 *
 * baldrick September 5, 2001
 *
 * modifications for foo.bar.htm detection and php as html
 *
 * AltF4 January 28, 2002
 */

WORD
get_decoder_type(const char *filename)
{
	WORD decoder = TEXT_DECODER;
	char temp_name[HW_PATH_MAX];
	const char *extension;

	/* first isolate the filename 
	 * just to make finding the extension easier
	 */

	get_fname(temp_name,filename);

	/* get the pointer to the extension */
	extension = strrchr(temp_name,'.');

	/* if no extension pretend it's text? */

	if (!extension)
		return(decoder);

	/* get the extension past the . */
	extension++;

	/* test for html or htm etc */
	if (!strnicmp (extension, "htm", 3) || !strnicmp (extension, "php", 3))
		decoder = HTML_DECODER;

	return(decoder);
}
#endif /***** REPLACED *****/


/*
 * get_fpath - gets a file path from a full path
 *
 * This probably should be elsewhere, but since I'm the only
 * person experimenting at the moment it sits here where I 
 * can easily find it - baldrick July 10, 2001
 */

static void
get_fpath(char *dest, const char *src)
{
	int i;

	for (i = (int)strlen(src); i >= 0; --i)
	{
		if (src[i] == '\\')
			break;
	}

	strcpy(dest, src);
	dest[i + 1] = '\0';
}


/* load_file
 * I modified the hell out of this to do local searching
 * It is probably not the prettiest.  - baldrick July 10, 2001
 */

static char *
load_file (const LOCATION loc)
{
	static const char *http_ident = "http://";
	static const char *pdf_ident=".pdf";
	const char *filename = loc->FullName;

	long size;

	/* a place to work */
	char temp_location[HW_PATH_MAX];

	char *file = NULL;

	int i;
	BOOL search_once = FALSE;

load_file_top:

	size = 0;

#ifdef DEBUG
	fprintf (stderr, "load_file: %s\n", filename);
#endif

/*printf("load file %s\n",filename);
*/
	if (strncmp (filename, http_ident, sizeof (http_ident)) == 0)
	{
		/* URL */

		request_URI(filename);
	}
	else if(strstr (filename, pdf_ident) != NULL)
	{
		Send_AV(0, PDF_AV_OPEN_FILE, (char*)filename, NULL);

		/*	This must the full path the the file */
		/*	In this part should also be recognized anothe type of file (png, jpg,
		   avi, mov...)	*/
		/*	The file extensions (like .pdf)	should be stored not in the local
		   variable !!! */

		return(NULL);
	}
	else
	{
		/* local file or directory */

	#ifndef LATTICE
		struct stat file_info;

		/* If there is no file name, try to open the default file index.htm[l].
		 */
		if (loc->File[0] == '\0') {
			strcpy(temp_location, filename);
			strcat(temp_location, "index.html");
			if (stat(temp_location, &file_info) == 0) {
				filename = temp_location;
			} else {
				temp_location[strlen(temp_location) - 1] = '\0';
				if (stat(temp_location, &file_info) == 0) {
					filename = temp_location;
				} else {
					/* Create a directory listing of 'filename' in a temporary
					 * file.  Then open it.
					 * BUG:  not implemented!
					 */
				}
			}
		}

		if (stat (filename, &file_info) == 0)
			size = file_info.st_size;

	#else
		/* for Lattice */
		struct xattr file_info;
		long r;

		r = Fxattr(0, filename, &file_info)
		if (r != EINVFN) {  /* Fxattr() exists */
			if (r == E_OK)
				size = file_info.st_size;
		} else {  /* here for TOS filenames */
			DTA *old, new;

			old = Fgetdta();
			Fsetdta(&new);

			if (Fsfirst(filename, 0) == E_OK)
				size = new.d_length;

			Fsetdta(old);
		}
	#endif

		if(size)
		{
			int fh;

			fh = open (filename, O_RDONLY);

			file = malloc (size + 1);
			if (fh > 0 && file) {
				read (fh, file, size);
				close (fh);

				file[size] = '\0';

				/* store filename locally to keep it from being eaten */
				strcpy(temp_location,filename);

				/* if not reloading, then grab old last location in case the
				 * user wishes to go back to previous page
				 */
				if (strcmp(filename, last_location) != 0) 
				{
					strcpy(prev_location,last_location);
					prev_encoding = last_encoding;

					/* store the last successful location as a base ref for next
					 * if it is needed
					 * last_encoding will be updated if exist
					 * <META HTTP-EQUIV="Content-Type" CONTENT="... charset=...">
					 */

					strcpy(last_location,temp_location);
	
					/* the window title will be changed if a TITLE tag exists */
				/*	wind_set_str(window_handle, WF_NAME, filename);
					wind_set_str(window_handle, WF_INFO, filename);
				*/
				}
				/* The last_encoding is updated for every successful loaded
				 * file, since the user can try to find the suitable encoding
				 * for a text file.  We have to use the users decision when
				 * going back to this page. */
				last_encoding = loc->encoding;
			}
		}
		else if (!search_once)
		{
			/* set search once to TRUE so that we don't loop forever */
			search_once = TRUE;

			/* file not here, but local so search? */

			get_fpath(temp_location, last_location);

			/* cat the new file onto the last location */

			strcat(temp_location,filename);

			/* Now we need to check if the have any forward
			 * slashes in their filename, since we are opening
			 * a local file, we need to convert them to backslash
			 */

			for (i = 0;i<strlen(temp_location);i++)
			{
				if (temp_location[i] == '/')
					temp_location[i] = '\\';
			}

			/* point filename to new location */
			filename = (char *)&temp_location[0];

			/* restart the loading */
			goto load_file_top;
		}
	}

	return file;
}


char *
translate_address (char *address)
{
	char *temp;

	temp = strchr (address, '#');

	if (temp)
	{
		*temp = '\0';
		return temp + 1;
	}
	else
		return NULL;
}


/* init_load(char *file)
 *
 * file ->  URI of resource to load
 *
 * Handles initialization of loader routines and opens window
 *
 * This routine just moves alot of junk out of the main() routine
 * that doesn't necessarily belong there
 *
 * Realistically this should be probably renamed, reworked
 * and expanded
 *
 * Baldrick (Feb 28, 2001)
 *
 * modifications to handle new add_load_item_to_to_do_list()
 * baldrick (sept 6, 2001)
 *
 * wind_set( ADDR) for LATTICE
 * David Leaver Dec 21, 2001
 */

void
init_load(const char *file)
{
	static CONTAINR _base_container = NULL;

	if (!_base_container) {
		extern void wind_handler (HW_EVENT, long, CONTAINR, void *);
		_base_container = new_containr (NULL);
		_base_container->Name = strdup ("-BASE-");
		containr_register (_base_container, wind_handler, 0);
/*	} else {
		containr_clear (_base_container);
*/	}
/*	the_first_frame = new_frame (NULL, NULL);
	containr_setup (_base_container, the_first_frame);
*/
	wind_set_str   (window_handle, WF_NAME, file);
	wind_set_str   (window_handle, WF_INFO, file);
	wind_open      (window_handle, 50, 50, 600, 354);
	wind_get_grect (window_handle, WF_WORKXYWH, &_base_container->Area);

	/* set our window status to normal */
	win_status = 0;
	
	new_loader_job (file, NULL, ENCODING_WINDOWS1252, _base_container);
}


/* added 10-04-01 mj. required for file selector */
#define EOS       '\0'  /* End of string */
#define BACKSLASH '\\'
static char fsel_path[HW_PATH_MAX];
char help_file[HW_PATH_MAX];

static void build_fname(char *dest, const char *s1, const char *s2)
{
	char *cptr;

	strcpy(dest, s1);  /* copy path */
	cptr = strrchr(dest, (int)BACKSLASH);  /* search last \ */
	if (cptr)
		strcpy(++cptr, s2);  /* there add the file name */
}


/* page_load
 *
 * calls the fileselector and loads the selected file
 *
 * added 10-04-01 mj.
 *
 * simplified AltF4 December 26, 2001
 *
 * return modified Rainer Seitel May 2002
 */
BOOL page_load(void)
{
	char fsel_file[HW_PATH_MAX] = "",
	     file[HW_PATH_MAX];
	WORD r, butt;  /* file selector exit button */

	if (gl_ap_version >= 0x140 && gl_ap_version < 0x200 || gl_ap_version >= 0x300 /* || getcookie(FSEL) */)
		r = fsel_exinput(fsel_path, fsel_file, &butt, "HighWire: Open HTML or text");
	else
		r = fsel_input(fsel_path, fsel_file, &butt);

	if (r && butt != FSEL_CANCEL)
	{
		build_fname(file, fsel_path, fsel_file);
		new_loader_job (file, NULL, ENCODING_WINDOWS1252, containr_Base(active_keyboard_frame));
	}
	return butt;
}

/* init_paths
 *
 * Handles the initialization of the file paths
 *
 *  Currently just sets last_location to something in the directory
 * from which HighWire was launched, so that people on certain
 * systems can get the default values
 *
 * this could be useful for config files, RSC files etc.
 *
 * baldrick (August 14, 2001)
 */

void
init_paths(void)
{
	char config_file[HW_PATH_MAX];

	config_file[0] = Dgetdrv();
	config_file[0] += (config_file[0] < 26)? 'A' : -26 + '1';
	config_file[1] = ':';
	Dgetpath(config_file + 2, 0);

	if (config_file[strlen(config_file) - 1] != '\\')
		config_file[strlen(config_file)] = '\\';

	strcpy(last_location, config_file);  /* save the start path */

	strcat(config_file, "highwire.cfg");

	/* this should be nicer than this crap test */

/*	if (read_config(config_file) == -1)
		form_alert(1, "[1][No configuration file |highwire.cfg found!][  OK  ]");
*/
	read_config(config_file);

	strcpy(fsel_path, last_location);  /* used by the first file selector call */
	strcat(fsel_path, "html\\*.HTM*");  /* uppercase is for the TOS file selector */

	strcpy(help_file, last_location);  /* used for keyboard F1 or Help */
	strcat(help_file, "html\\hwdoc.htm#Use");

	strcat(last_location, "html\\highwire.htm");
}


/* This identifies what AES you are running under.
 */

WORD
identify_AES(void)
{
	long	search_id;
	long	*search_p = (long *)Setexc(0x5A0/4, (void (*)())-1);
	WORD	retv = AES_single;

	if (search_p != NULL) {
		while ((search_id = *search_p) != 0) {
			if (search_id == 0x4D674D63L || search_id == MagX_cookie)
				retv = AES_MagiC;
			if (search_id == 0x6E414553L)
				retv = AES_nAES;
			if (search_id == 0x476E7661L)
				retv = AES_Geneva;

			search_p += 2;
		}
	}

	return retv;
}	/* Ends:	WORD identify_AES(void) */


/* Looks for MiNT or MagiC Cookies.  If found TRUE returned,
 * which indicates we can call extended Mxalloc() with GLOBAL flag.
 */

BOOL
can_extended_mxalloc(void)
{
	long	search_id;
	long	*search_p = (long *)Setexc(0x5A0/4, (void (*)())-1);
	BOOL	retv = FALSE;

	if (search_p != NULL) {
		while ((search_id = *search_p) != 0) {
			if (search_id == 0x4D674D63L || search_id == MagX_cookie
			   || search_id == 0x4D694E54L) {
				retv = TRUE;
				break;
			}
			search_p += 2;
		}
	}

	return retv;
}
