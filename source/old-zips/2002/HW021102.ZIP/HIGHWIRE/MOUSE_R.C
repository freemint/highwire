
#include <stdlib.h>
#include <string.h>

#include <gemx.h>

#include "global.h"
#include "Loader.h"

void
button_clicked (struct frame_item *first_frame, WORD mx, WORD my)
{
	struct frame_item *current_frame;

	current_frame = first_frame;

	while (current_frame != 0)
	{
		if (((current_frame->v_scroll_on == true && mx < current_frame->clip.x + current_frame->clip.w + scroll_bar_width)
			||(current_frame->v_scroll_on == false && mx < current_frame->clip.x + current_frame->clip.w))
		    && mx > current_frame->clip.x
		    && my > current_frame->clip.y)
		{

		    if ((current_frame->h_scroll_on == true && my < current_frame->clip.y + current_frame->clip.h + scroll_bar_width)
		    	|| (my < current_frame->clip.y + current_frame->clip.h))
				{
					frame_clicked (first_frame, current_frame, mx, my);
					return;
				}
		}
		current_frame = frame_next (current_frame);
	}
}

/*
 * handles mouse interaction with aframe */
void
frame_clicked (struct frame_item *first_frame, struct frame_item *current_frame, WORD mx, WORD my)
{
	WORD distance = 0, mouse_button_state, u;
	WORD slider_length, slider_pos, scroll_length;
	char *temp, *temp2;
/*	struct frame_item *t_frame;*/
	struct frame_item *search_frame;

	/* *************** Vertical scroll **************       */

	if (current_frame->v_scroll_on == true
	    && mx > current_frame->clip.x + current_frame->clip.w)
	{
		scroll_length = current_frame->clip.h - 1 - scroll_bar_width * 2;

		slider_length = (WORD)(((long)current_frame->clip.h * (long)scroll_length) /
			 current_frame->current_page_height);

		if (slider_length < scroll_bar_width)
			slider_length = scroll_bar_width;

		slider_pos =
			((scroll_length - slider_length) * current_frame->vertical_scroll /
			 (current_frame->current_page_height - current_frame->clip.h)) +
			current_frame->clip.y + scroll_bar_width + 1;

		if (my < current_frame->clip.y + scroll_bar_width)
		{
			/* up arrow */
			
			if (current_frame->vertical_scroll - scroll_step > -1)
				distance = scroll_step;
			else if (current_frame->vertical_scroll > 0)
				distance = (WORD)current_frame->vertical_scroll;

			if (distance != 0)
			{
				current_frame->vertical_scroll -= (long)distance;
				blit_block (current_frame, distance, d_up);
			}
		}
		else if (my < slider_pos)
		{	
			/* page up */

			if ((WORD)current_frame->vertical_scroll - current_frame->clip.h - scroll_step > -1)
				distance = current_frame->clip.h - scroll_step;
			else if (current_frame->vertical_scroll > 0)
				distance = (WORD)current_frame->vertical_scroll;

			if (distance != 0)
			{
				current_frame->vertical_scroll -= (long)distance;
				
				redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			}
		}
		else if (my < slider_pos + slider_length)
		{		/* slider */
			graf_mkstate (&mx, &my, &mouse_button_state, &u);
			if (mouse_button_state != 0)
			{
				graf_dragbox (scroll_bar_width, slider_length,
					      current_frame->clip.x + current_frame->clip.w,
					      slider_pos,
					      current_frame->clip.x + current_frame->clip.w,
					      current_frame->clip.y + scroll_bar_width,
					      scroll_bar_width, scroll_length, &u, &slider_pos);
				slider_pos -= current_frame->clip.y + scroll_bar_width;
				current_frame->vertical_scroll =
					(current_frame->current_page_height -
					 current_frame->clip.h) * slider_pos / (scroll_length -
										slider_length);
				distance = 1;
				redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			}
		}
		else if (my < current_frame->clip.y + current_frame->clip.h - scroll_bar_width)
		{
			/* page down */

			if (current_frame->vertical_scroll + current_frame->clip.h - scroll_step <
			    current_frame->current_page_height - current_frame->clip.h)
				distance = current_frame->clip.h - scroll_step;
			else
				if (current_frame->vertical_scroll <
				    current_frame->current_page_height - current_frame->clip.h)
				distance = (WORD)
					(current_frame->current_page_height -
					current_frame->vertical_scroll - (long)current_frame->clip.h);
			if (distance != 0)
			{
				current_frame->vertical_scroll += distance;
				redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			}
		}
		else if (my < current_frame->clip.y + current_frame->clip.h)
		{
			/* scroll down */
			if (current_frame->vertical_scroll + scroll_step <
			    current_frame->current_page_height - current_frame->clip.h)
				distance = scroll_step;
			else
				if (current_frame->vertical_scroll < (current_frame->current_page_height - (long)current_frame->clip.h))
				distance = (WORD)(current_frame->current_page_height - 
					current_frame->vertical_scroll - (long)current_frame->clip.h);

			if (distance != 0)
			{
				current_frame->vertical_scroll += distance;
				blit_block (current_frame, distance, d_down);
			}
		}
		if (distance != 0)
			draw_frame_borders (current_frame, 1);
	}
	/* ******** Horizontal Scroll *********** */

	else if (current_frame->h_scroll_on == true
		 && my > current_frame->clip.y + current_frame->clip.h)
	{
		scroll_length = current_frame->clip.w - 1 - (scroll_bar_width * 2);

		slider_length = (WORD)((long)current_frame->clip.w * (long)scroll_length / 
			(long)current_frame->frame.w);

		if (slider_length < scroll_bar_width)
			slider_length = scroll_bar_width;

		slider_pos =
			((scroll_length - slider_length) * current_frame->horizontal_scroll /
			 (current_frame->frame.w - current_frame->clip.w)) + current_frame->clip.x +
			scroll_bar_width + 1;

		if (mx < current_frame->clip.x + scroll_bar_width)
		{
			/* left arrow */
			
			if (current_frame->horizontal_scroll - scroll_step > -1)
				distance = scroll_step;
			else if (current_frame->horizontal_scroll > 0)
				distance = current_frame->horizontal_scroll;

			if (distance != 0)
			{
				current_frame->horizontal_scroll -= distance;
				blit_block (current_frame, distance, d_left);
			}
		}
		else if (mx < slider_pos)
		{
			/* page left */

			if (current_frame->horizontal_scroll - current_frame->clip.w - scroll_step > -1)
				distance = current_frame->clip.w - scroll_step;
			else if (current_frame->horizontal_scroll > 0)
				distance = current_frame->horizontal_scroll;

			if (distance != 0)
			{
				current_frame->horizontal_scroll -= distance;
				redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			}
		}
		else if (mx < (slider_pos + slider_length))
		{
			/* the horizontal slider */
			
			graf_mkstate (&mx, &my, &mouse_button_state, &u);

			if (mouse_button_state != 0)
			{
				graf_dragbox (slider_length, scroll_bar_width, slider_pos,
					      current_frame->clip.y + current_frame->clip.h,
					      current_frame->clip.x + scroll_bar_width,
					      current_frame->clip.y + current_frame->clip.h,
					      scroll_length, scroll_bar_width, &slider_pos, &u);

				slider_pos -= current_frame->clip.x + scroll_bar_width;

				current_frame->horizontal_scroll =
					(current_frame->frame.w -
					 current_frame->clip.w) * slider_pos / (scroll_length -
										slider_length);
				distance = 1;
				redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			}
		}
		else if (mx < current_frame->clip.x + current_frame->clip.w - scroll_bar_width)
		{
			/* page right */

			if (current_frame->horizontal_scroll + current_frame->clip.w - scroll_step < current_frame->frame.w - current_frame->clip.w)
				distance = current_frame->clip.w - scroll_step;
			else if (current_frame->horizontal_scroll < current_frame->frame.w - current_frame->clip.w)
				distance = current_frame->frame.w - current_frame->horizontal_scroll - current_frame->clip.w;

			if (distance != 0)
			{
				current_frame->horizontal_scroll += distance;
				redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			}
		}
		else if (mx < current_frame->clip.x + current_frame->clip.w)
		{
			/* right arrow */

			if (current_frame->horizontal_scroll + scroll_step < current_frame->frame.w - current_frame->clip.w)
				distance = scroll_step;
			else if (current_frame->horizontal_scroll < current_frame->frame.w - current_frame->clip.w)
				distance = current_frame->frame.w - current_frame->horizontal_scroll - current_frame->clip.w;
				
			if (distance != 0)
			{
				current_frame->horizontal_scroll += distance;
				blit_block (current_frame, distance, d_right);
			}
		}

		if (distance != 0)
			draw_frame_borders (current_frame, 1);
	}
	/* *********** Clickable areas ************* */

	else
	{
		if (current_highlighted_link_area != 0)
		{

			temp = strdup (current_highlighted_link_area->link->address);
			if (*temp == '#')
			{
				current_highlighted_link_frame->frame_named_location = translate_address (temp);
				frames_recalculated = true;
				redraw (window_handle, 0, 0, 0, 0, current_highlighted_link_frame); /* first_frame);*/
			}
			else
			{

				/* create temp frame */
			/*	t_frame = temp_frame(); */
		
				if(current_highlighted_link_area->link->target != 0)
				{
					search_frame = first_frame;

					temp2 = strdup(current_highlighted_link_area->link->target);

					while (search_frame != 0)
					{
						if (search_frame->frame_name != 0)
						{
							if (stricmp(search_frame->frame_name,temp2)==0)
							{
								new_loader_job (current_highlighted_link_area->link->address, search_frame->Container);
								
								break;
							}
						}
						search_frame = frame_next (search_frame);
					}
				}
				else
				{
					new_loader_job (current_highlighted_link_area->link->address, current_highlighted_link_frame->Container);
				}
			}
		}
	}
}


void
check_mouse_position (struct frame_item *current_frame, WORD mx, WORD my)
{
	struct clickable_area *current_area, *highlighted_link_area;

	if (current_highlighted_link_area != 0)
	{
		if (mx < current_highlighted_link_area->x + current_highlighted_link_frame->frame.x
		    || my <
		    current_highlighted_link_area->y + current_highlighted_link_frame->frame.y
		    || mx >
		    current_highlighted_link_area->x + current_highlighted_link_area->w +
		    current_highlighted_link_frame->frame.x
		    || my >
		    current_highlighted_link_area->y + current_highlighted_link_area->h +
		    current_highlighted_link_frame->frame.y)
		{
			graf_mouse (0, 0);
			highlighted_link_area = current_highlighted_link_area;
			current_highlighted_link_area = 0;
			redraw_frame (window_handle,
				      current_frame->frame.x + highlighted_link_area->x,
				      current_frame->frame.y + highlighted_link_area->y,
				      highlighted_link_area->w, highlighted_link_area->h,
				      current_highlighted_link_frame);
			current_highlighted_link_frame = 0;
		}
		else
		{
			return;
		}
	}

	while (current_frame->clip.x > mx || current_frame->clip.y > my
	       || current_frame->clip.x + current_frame->clip.w - 1 < mx
	       || current_frame->clip.y + current_frame->clip.h - 1 < my)
	{
		current_frame = frame_next (current_frame);
		if (current_frame == 0)
			return;
	}

	current_area = current_frame->first_clickable_area;
	if (current_area == 0)
		return;

	mx -= current_frame->frame.x;
	my -= current_frame->frame.y;
	while (current_area->x > mx || current_area->y > my
	       || current_area->x + current_area->w - 1 < mx
	       || current_area->y + current_area->h - 1 < my)
	{
		current_area = current_area->next_area;
		if (current_area == 0)
			return;
	}

	if (current_highlighted_link_area == 0 && current_area->link->mode == lnk_href)
	{
		graf_mouse (3, 0);
		current_highlighted_link_frame = current_frame;
		current_highlighted_link_area = current_area;
		redraw_frame (window_handle,
			      current_highlighted_link_area->x + current_frame->frame.x,
			      current_highlighted_link_area->y + current_frame->frame.y,
			      current_highlighted_link_area->w, current_highlighted_link_area->h,
			      current_highlighted_link_frame);
	}
}
