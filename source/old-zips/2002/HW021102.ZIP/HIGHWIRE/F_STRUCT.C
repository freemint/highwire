#include <stdlib.h>

#include "global.h"

void
destroy_frame_structure (struct frame_item *current_frame)
{
/*	struct frame_item *temp;*/

	if (current_frame != 0)
	{
		if (current_frame->item != 0)
			destroy_paragraph_structure (current_frame->item);
/* we need to kill the new_frame list if it exists */

		if (current_frame->first_clickable_area != 0)
			destroy_clickable_area_structure (current_frame->first_clickable_area);
		if (current_frame->first_named_location != 0)
			destroy_named_location_structure (current_frame->first_named_location);
	/*	temp = current_frame->next_frame;*/
		free (current_frame);
	/*	current_frame = temp;*/
	}
}

/* initializes a frame object
 * if 'frame' is NULL a new object will be malloc'ed and will be initialized
 * completely.  else it is called from reset_frame() and some attributes are
 * left unchanged.
 */
static struct frame_item *
init_frame (struct frame_item * frame)
{
	if (!frame) {
		frame = malloc (sizeof (struct frame_item));
		
		frame->Container = NULL;
		
	/*	frame->next_frame   = NULL;*/
		frame->parent_table = NULL;
		
		frame->v_scroll_on = FALSE;
		frame->h_scroll_on = FALSE;
		frame->frame.x = 0;
		frame->frame.y = 0;
		frame->frame.w = 0;
		frame->frame.h = 0;
		frame->current_list      = NULL;
		frame->current_paragraph = NULL;
		frame->current_font_step = NULL;
		frame->current_word      = NULL;
		frame->current_font_size = 0;
	}
	frame->item         = NULL;
	frame->frame_width  = 0;
	frame->frame_height = 0;
	frame->frame_left   = 0;
	frame->frame_top    = 0;
	frame->horizontal_scroll = 0;
	frame->vertical_scroll   = 0;
	frame->frame_page_width  = 0;
	frame->border      = FALSE;
	frame->current_page_height = 0;
	frame->background_colour   = 0;
	frame->text_colour         = 1;
	frame->link_colour         = link_colour;
	frame->clip.x = 0;
	frame->clip.y = 0;
	frame->clip.w = 0;
	frame->clip.h = 0;
	frame->first_clickable_area = NULL;
	frame->first_named_location = NULL;
	frame->frame_filename       = NULL;
	frame->frame_named_location = NULL;
	frame->frame_name           = NULL;
	frame->current_indent_distance = 0;
	frame->active_word   = NULL;
	frame->current_table = NULL;
	frame->current_attr  = NULL;
	
	return frame;
}

/* 
 * creates a new frame structure and initializes it's values
 * it also links previous_frame * to the new space for when
 * we create the next frame we have someplace to link it to
 */

struct frame_item *
new_frame (void)
{
	previous_frame = init_frame (NULL);
	
	return (previous_frame);
}

#if 0   /***** OBSOLETE *****/
void
reset_frame (struct frame_item *frame)
{
	if (frame->first_clickable_area != 0)
		destroy_clickable_area_structure (frame->first_clickable_area);
	if (frame->item != 0)
		destroy_paragraph_structure (frame->item);

/* we need to walk the new_frame list down here and destroy it if it exists */

	init_frame (frame);
}
#endif


#if 0   /***** OBSOLETE *****/

/* temp_frame()
 * 
 * this is used to create a temporary dummy frame to hold
 * information for the add_load_to_do() routine.
 * this routine does not touch previous_frame variable
 */

struct frame_item *
temp_frame (void)
{
	return init_frame (NULL);
}
#endif
