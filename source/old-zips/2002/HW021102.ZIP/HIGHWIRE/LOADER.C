/* loader.c
 *
 * Currently has ended up a junk file of initializations
 * loading routine and some assorted other routines
 * for file handling.
 */

#ifdef __PUREC__
#include <tos.h>
#include <ext.h>
#endif

#ifdef LATTICE
#include <dos.h>
#include <mintbind.h>

/* I'm certain this is in a .H somewhere, just couldn't find it - Baldrick*/
#define O_RDONLY    0x00
#define DTA struct FILEINFO
#define d_length size
#endif

#ifdef __GNUC__
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>
# include <mintbind.h>

#endif

#include <gemx.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "global.h"


#include "schedule.h"
#include "Loader.h"
#include "Containr.h"


/*******************************************************************************
 * the following function should placed either in parse.c or render.c but
 * at the moment I have no clue where to do it best - AltF4 Feb. 4, 2002
 */

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * job function for parseing a file and attach it to the passed frame
 */
static BOOL
parser_job (void * arg)
{
	LOADER   loader = arg;
	CONTAINR cont   = loader->Target;
	FRAME    frame  = new_frame();
	frame->Container            = cont;
	frame->frame_filename       = strdup (loader->FileName);
	frame->frame_named_location = (loader->Anchor
	                               ? strdup (loader->Anchor) : NULL);
	
	if (!cont) {
		printf ("parser_job(): target \"%s\" \"%s\" has no container!\n",
		        frame->frame_filename, frame->frame_name);
		exit(1);
	}
	
	containr_clear (cont);
	
	switch (loader->Decoder)
	{
		case HTML_DECODER:
			frame->item = parse_html (loader->Data, frame);
			break;
		
		case TEXT_DECODER:
		default: /* pretend it's text */
			frame->item = parse_text (loader->Data, frame);
	}
	
	if (!cont->Mode) {
		containr_setup (cont, frame);
		if (!the_first_frame->Container) {
	/*		delete_frame (the_first_frame); */
			the_first_frame = frame;
		}
	} else {
		containr_calculate (cont, NULL);
/*		delete_frame (frame); */
	}
	containr_redraw (cont, NULL);

	number_of_frames_left_to_load--;
	
	if (number_of_frames_left_to_load == 0)
	{
		short mx, my, u;
		graf_mkstate (&mx, &my, &u,&u);
		check_mouse_position (the_first_frame, mx, my);
	}
	return FALSE;
}

/******************************************************************************/


/*============================================================================*/
LOADER
new_loader (const char * address)
{
	size_t size   = strlen (address);
	LOADER loader = malloc (sizeof (struct s_loader) + size);
	loader->Target   = NULL;
	loader->Data     = NULL;
	loader->FileName = memcpy (loader->Address, address, size +1);
	loader->Anchor   = strchr (loader->Address, '#');
	if (loader->Anchor) {
		size = loader->Anchor - loader->Address;
		loader->FileName = memcpy (malloc (size +1), loader->Address, size);
		loader->FileName[size] = '\0';
		loader->Anchor++;
	}
	loader->Decoder = get_decoder_type (loader->FileName);
	
	return loader;
}


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * job function for loading a file + url into memory ready for parsing
 */
static BOOL
loader_job (void * arg)
{
	LOADER loader = arg;
	loader->Data  = load_file (loader->FileName);
	
	/* registers a parser job with the scheduler */
	sched_insert (parser_job, loader);
	
	return FALSE;
}

/*==============================================================================
 * registers a loader job with the scheduler.
 *
 * the parameter 'info_frame' can be NULL.
 */
void
new_loader_job (char *address, CONTAINR target)
{
	LOADER loader = new_loader (address);
	loader->Target = target;
	
	/* increment the frame counter */
	number_of_frames_left_to_load++;
	
	sched_insert (loader_job, loader);
}


/******************************************************************************/

/* This is simply used at the moment to track the last working file */
char last_location[128] = "\0";

/* this is to store last page for backing up */
char prev_location[128] = "\0";

/* are we running MiNT? */
WORD MiNT_flag = 0;

long
search_for_named_location (char *name, struct named_location *current_location)
{
	while (current_location && strcmp (name, current_location->link->address) != 0)
		current_location = current_location->next_location;

	if (current_location)
		return current_location->position;

	return 0;
}

/*
 * get_fname - gets a file name from a full path
 *
 */
 
static void
get_fname(char *dest, char *src)
{
	int i;
    
    for(i=(int)strlen(src);i>=0;--i)
    {                                    
		if(src[i] == 92)
			break;
	}
		 
	strcpy(dest,&src[i + 1]);
}

/*
 * get_decoder_type - tries to discover the appropriate decoder
 *         for a file based on it's extension.
 *
 * baldrick September 5, 2001
 *
 * modifications for foo.bar.htm detection and php as html
 *
 * AltF4 January 28, 2002
 */

WORD
get_decoder_type(char *filename)
{
	WORD decoder = TEXT_DECODER;
	char temp_name[128];
	char *extension;
		
	/* first isolate the filename 
	 * just to make finding the extension easier
	 */
	 
	get_fname(temp_name,filename);
	
	/* get the pointer to the extension */
	extension = strrchr(temp_name,'.');
	
	/* if no extension pretend it's text? */

	if (!extension)
		return(decoder);
	
	/* get the extension past the . */
	extension++;
	
	/* test for html or htm etc */
	if (!strnicmp (extension, "htm", 3) || !strnicmp (extension, "php", 3))
		decoder = HTML_DECODER;
	
	return(decoder);
}

/*
 * get_fpath - gets a file path from a full path
 *
 * This probably should be elsewhere, but since I'm the only
 * person experimenting at the moment it sits here where I 
 * can easily find it - baldrick July 10, 2001 
 */
 
static void
get_fpath(char *dest, char *src)
{
	int i;
    
    for(i=(int)strlen(src);i>=0;--i)
    {                                    
		if(src[i] == 92)
			break;
	}
		 
	strcpy(dest,src);
	dest[i + 1] = '\0';
}


/* load_file
 * I modified the hell out of this to do local searching
 * It is probably not the prettiest.  - baldrick July 10, 2001
 */

char *
load_file (const char *filename)
{
	static const char *http_ident = "http://";

	long size;

	/* a place to work */
	char temp_location[128];

	char *file = NULL;

	int i,search_once = 0;
	
load_file_top:

	size = 0;
	
#ifdef DEBUG
	fprintf (stderr, "load_file: %s\n", filename);
#endif

/*printf("load file %s\r\n",filename);
*/
	if (strncmp (filename, http_ident, sizeof (http_ident)) == 0)
	{
		/* URL */

		request_URI(filename);
	}
	else
	{
		/* lokal */

	#ifdef __GNUC__
		struct stat file_info;

		if (stat (filename, &file_info) == 0)
			size = file_info.st_size;
		
	#else
#ifdef __PUREC__		
		struct stat file_info;

		if (stat (filename, &file_info) == 0)
			size = file_info.st_size;

#else	
		if(MiNT_flag) /* here for case dependent filenames */
		{
			/* for Lattice and PureC */
			struct xattr file_info;

			if(Fxattr(0,filename,&file_info)==0)
				size = file_info.st_size;
		}
		else  /* here for TOS filenames */
		{
			DTA *old,new;
			old = Fgetdta();
			Fsetdta(&new);

			if(Fsfirst(filename,0) == 0)
				size = new.d_length;

			Fsetdta(old);
		}
	#endif
#endif

		if(size)
		{
			int fh;

			fh = open (filename, O_RDONLY);

			file = malloc (size + 1);
			read (fh, file, size);
			close (fh);

			file[size] = '\0';

			/* store filename locally to keep it from being eaten */
			strcpy(temp_location,filename);

			/* grab old last location in case the user wishes to back up a page */
			
			strcpy(prev_location,last_location);

			/* store the last successful location as a base ref for next
			 * if it is needed
			 */
			 
			strcpy(last_location,temp_location);
		}
		else if ( search_once < 1)
		{
			/* set search once to 1 so that we don't loop forever */
			search_once = 1;
			
			/* file not here, but local so search? */

			get_fpath(temp_location, last_location);
	
			/* cat the new file onto the last location */
					
			strcat(temp_location,filename);
			
			/* Now we need to check if the have any forward
			 * slashes in their filename, since we are opening
			 * a local file, we need to convert them to backslash
			 */
			 
			for (i = 0;i<strlen(temp_location);i++)
			{
				if (temp_location[i] == '/')
					temp_location[i] = '\\';
			}
			
			/* point filename to new location */
			filename = (char *)&temp_location[0];

			/* restart the loading */
			goto load_file_top;
		}
	}

	if (!file)
		file =
			strdup
			("<html><head><title>Page not found</title></head><body><h1>Page not found</h1></body></html>");

	return file;
}

char *
translate_address (char *address)
{
	char *temp;

	temp = strchr (address, '#');

	if (temp)
	{
		*temp = '\0';
		return temp + 1;
	}
	else
		return NULL;
}

/* init_load(char *file)
 *
 * file ->  URI of resource to load
 *
 * Handles initialization of loader routines and opens window
 *
 * This routine just moves alot of junk out of the main() routine
 * that doesn't necessarily belong there
 *
 * Realistically this should be probably renamed, reworked
 * and expanded
 *
 * Baldrick (Feb 28, 2001)
 *
 * modifications to handle new add_load_item_to_to_do_list()
 * baldrick (sept 6, 2001)
 *
 * wind_set( ADDR) for LATTICE 
 * David Leaver Dec 21, 2001
 */

void
init_load(char *file)
{
	static CONTAINR _base_container = NULL;
	
	if (!_base_container) {
		_base_container = new_containr (NULL);
		_base_container->Name = strdup ("-BASE-");
	} else {
		containr_clear (_base_container);
	}
	the_first_frame = new_frame();
	containr_setup (_base_container, the_first_frame);

	new_loader_job (file, _base_container);

	wind_set_str   (window_handle, WF_NAME, file);
	wind_open      (window_handle,100,100,500,300);
	wind_get_grect (window_handle, WF_WORKXYWH, &_base_container->Area);

	/* set our window status to normal */
	win_status = 0;
}

/* init_paths
 *
 * Handles the initialization of the file paths
 *
 *  Currently just sets last_location to something in the directory
 * from which Highwire was launched, so that people on certain
 * systems can get the default values
 *
 * this could be useful for config files, RSC files etc.
 *
 * baldrick (August 14, 2001)
 */
 
void
init_paths(void)
{
	char config_file[128];

 	config_file[0] = Dgetdrv() + 'A';
	config_file[1] = ':';
	Dgetpath(config_file+2, 0);

	if(config_file[strlen(config_file)-1]=='\\')
		config_file[strlen(config_file)-1]=0;

	strcat(config_file, "\\highwire.cfg");
	
	/* this should be nicer than this crap test */
	
/*	if (read_config(config_file) == -1)
	    form_alert(1,"[1][no config file found][ok]");
*/
	read_config(config_file);
 
 	last_location[0] = Dgetdrv() + 'A';
	last_location[1] = ':';
	Dgetpath(last_location+2, 0);

	if(last_location[strlen(last_location)-1]=='\\')
		last_location[strlen(last_location)-1]=0;

	strcat(last_location, "\\highwire.htm");
}

/*  This identifies what AES you are running under 
 *  based almost entirely on code by Ulf Ronald Anderson
 */
 
WORD
identify_AES(void)
{	
	void	*old_SSP;
	long	search_id;
	long	*search_p;
	WORD	retv = AES_single;

/* cookie search is made in Super mode to access any RAM */

	old_SSP = (void *) Super(0L);
	if ((search_p = *_cookies) == NULL)	goto exit_super;

search_loop:
	search_id = *search_p;
	if( search_id == 0L )	goto exit_super; /* search completed */
	if( search_id == 0x4D674D63L  ||  search_id == 0x4D616758L ) retv = AES_MagiC;
	if( search_id == 0x6E414553L ) retv = AES_nAES;
	if( search_id == 0x476E7661L ) retv = AES_Geneva;
	if( search_id == 0x4D694E54L ) MiNT_flag = 1;
	search_p += 2;
	goto	search_loop
;
exit_super:
	Super(old_SSP);

	return( retv );
}	/* Ends:	WORD identify_AES(void) */
