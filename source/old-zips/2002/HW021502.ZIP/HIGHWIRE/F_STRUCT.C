#include <stdlib.h>
#include <string.h>

#include "global.h"


/*==============================================================================
 * 
 * creates a new frame structure and initializes it's values
 */
FRAME
new_frame (const char * filename, const char * anchor)
{
	FRAME frame = malloc (sizeof (struct frame_item));
	
	frame->Container = NULL;
	
	frame->item         = NULL;
	frame->frame_width  = 0;
	frame->horizontal_scroll = 0;
	frame->vertical_scroll   = 0;
	frame->frame_page_width  = 0;
	frame->v_scroll_on = FALSE;
	frame->h_scroll_on = FALSE;
	frame->border      = FALSE;
	frame->current_page_height = 0;
	frame->background_colour   = 0;
	frame->text_colour         = 1;
	frame->link_colour         = link_colour;
	frame->clip.x = 0;
	frame->clip.y = 0;
	frame->clip.w = 0;
	frame->clip.h = 0;
	frame->frame.x = 0;
	frame->frame.y = 0;
	frame->frame.w = 0;
	frame->frame.h = 0;
	frame->first_clickable_area = NULL;
	frame->first_named_location = NULL;
	frame->frame_filename       = (filename ? strdup (filename) : NULL);
	frame->frame_named_location = (anchor   ? strdup (anchor)   : NULL);
	frame->current_list         = NULL;
	frame->current_paragraph    = new_paragraph();
	frame->current_word         = frame->current_paragraph->item;
	frame->current_indent_distance = 0;
	frame->current_font_step = NULL;
	frame->active_word       = NULL;
	frame->current_font_size = POINT_SIZE;
	frame->parent_table      = NULL;
	frame->current_table     = NULL;
	frame->current_attr      = NULL;
	
	return frame;
}

/*============================================================================*/
void
delete_frame (FRAME * p_frame)
{
	FRAME frame = *p_frame;
	if (frame->item)
		destroy_paragraph_structure (frame->item);
	if (frame->first_clickable_area)
		destroy_clickable_area_structure (frame->first_clickable_area);
	if (frame->first_named_location)
		destroy_named_location_structure (frame->first_named_location);
	if (frame->frame_filename)       free (frame->frame_filename);
	if (frame->frame_named_location) free (frame->frame_named_location);
	
	/* current_list */
	/* current_paragraph */
	/* current_font_step */
	/* current_word */
	/* active_word */
	/* parent_table */
	/* current_table */
	/* current_attr */
	
	*p_frame = NULL;
}
