/* @(#)highwire/FORM.c
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "token.h"
#include <gem.h>

#include "global.h"
#include "parser.h"

#ifdef DEBUG
	#define _DEBUG
#else
/*	#define _DEBUG */
#endif


/*============================================================================*/
PARAGRPH
form_start (FRAME frame)
{
	char     buf[10];
	PARAGRPH par   = add_paragraph (&frame->current);
	FORM    form = malloc (sizeof (struct s_form));
	FRMSTACK stack = malloc (sizeof (struct s_form_stack));
	/*puts("table_start");*/
	stack->form    = form;
	stack->form->next = NULL;
	stack->SavedStyles = frame->current.styles;
	stack->SavedFntStp = frame->current.font_step;
	stack->SavedAlign  = par->alignment;
	stack->Backgnd     = frame->current.backgnd;
	stack->Previous    = frame->FormStack;
	stack->_debug = 'A';
	
	par->Form          = form;
	par->paragraph_code = PAR_FORM;
/*	par->Offset.Origin  = (frame->FormStack && frame->TableStack->WorkCell
	                       ? &frame->TableStack->WorkCell->Offset : NULL);

	if (get_value (KEY_ALIGN, buf, sizeof(buf))) {
		if      (stricmp (buf, "right")   == 0) par->alignment = ALN_RIGHT;
		else if (stricmp (buf, "center")  == 0) par->alignment = ALN_CENTER;
		else if (stricmp (buf, "justify") == 0) par->alignment = ALN_JUSTIFY;
		else if (stricmp (buf, "left") == 0) par->alignment = ALN_FLEFT;
	}
*/
	frame->FormStack = stack;

	form->Paragraph = par;

	return par;
}

static void
free_form_stack (FRAME frame)
{
	FRMSTACK stack = frame->FormStack;
	FORM    form = stack->form;
	
	word_store (&frame->current);
	frame->current.paragraph = form->Paragraph;
	frame->current.word      = form->Paragraph->item;
	frame->current.font_step = stack->SavedFntStp;
	frame->current.styles    = stack->SavedStyles;
	add_paragraph (&frame->current)->alignment = stack->SavedAlign;
	frame->FormStack = stack->Previous;
	frame->current.backgnd = (frame->FormStack ? frame->FormStack->Backgnd
	                                            : frame->Page.Backgnd);
	free (stack);
}


/*============================================================================*/
void
form_finish (FRAME frame)
{
	free_form_stack (frame);
}
