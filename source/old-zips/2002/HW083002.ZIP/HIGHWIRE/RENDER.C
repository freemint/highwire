/* @(#)highwire/render.c
 */
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h> 

#include "token.h" /* must be included before gem/gemx.h */
#include <gemx.h>

#include "global.h"
#include "scanner.h"
#include "parser.h"
#include "Containr.h"
#include "Loader.h"
#include "Location.h"
#include "Logging.h"
#include "Table.h"
#include "http.h"


/* calculate end of paragraph space, eop_space */
#define EOP(a) ((a) * 2 / 3)


/* step2size()
 *
 * maps a font step of [0..7] to a font size.
 */
static WORD
step2size (struct font_step * fontstep, WORD step)
{
	static WORD size[8] = { 0, };
	static WORD s = 0;
	
	if (s != font_size)
	{
		WORD i;
		s = font_size;
		size[0] = s - (s / 2); /*7;*/
		size[1] = s - (s / 3); /* 8; */
		size[2] = (s + size[1]) /2;
		size[3] = s;
		for (i = 4; i <= 7; size[i++] = (s += 2));
	}
	if      (step < 0) step = 0;
	else if (step > 7) step = 7;
	if (fontstep) fontstep->step = step;
	
	return size[step];
}

static void
step_push (TEXTBUFF current, WORD step)
{
	current->font_step = add_step  (current->font_step);
	current->font_size = step2size (current->font_step, step);
}

static void
step_pop (TEXTBUFF current)
{
	current->font_step = destroy_step (current->font_step);
	current->font_size = step2size    (NULL, current->font_step->step);
}


static UWORD
map (char symbol)
{
	if (symbol == ' ')
		return (Space_Code);

	return ((WORD) (symbol - 32));
}


static WORD
list_indent (WORD type)
{
	switch (type)
	{
		case 0:
			return (font_size * 2);
		case 1:
			return (font_size * 3);
		case 2:
			return (font_size * 4);
	}
	return (0);
}


/* set_pre_font()
 *
 * just a couple of lines that modify the current font to being 
 * the PRE font.
 * Used in numerous places
 */

static void
set_pre_font (TEXTBUFF current, BOOL start_tag)
{
	word_set_font (current, (start_tag ? pre_font : normal_font));
}

/* get_align()
 *
 * retrieves the alignment of a paragraph
 * based on frame->alignment (CENTER) or if it's in a Table
 */

static H_ALIGN
get_align(struct frame_item *p_frame)
{
	if(	p_frame->Page.Alignment == ALN_CENTER &&
		p_frame->current.paragraph->alignment == ALN_CENTER)
		return(ALN_CENTER);

	if (p_frame->TableStack && p_frame->TableStack->WorkCell)
	{
		if (p_frame->TableStack->WorkCell->DummyFor)
			return(p_frame->TableStack->WorkCell->DummyFor->Content.Item->alignment);
		else
			return(p_frame->TableStack->WorkCell->Content.Item->alignment);
	}
	else
		return(p_frame->Page.Alignment);
}

/* set_center_text()
 *
 * changes the value of paragraphs alignment
 *
 * start_tag determines operation
 *    if TRUE center text
 *    if not TRUE left justify text
 */

static void
set_center_text(struct frame_item *p_frame, BOOL start_tag)
{
	add_paragraph (&p_frame->current);

	if (start_tag)
	{
		p_frame->Page.Alignment               = ALN_CENTER;
		p_frame->current.paragraph->alignment = ALN_CENTER;
	}
	else
	{
		p_frame->Page.Alignment               = ALN_LEFT;
		p_frame->current.paragraph->alignment = get_align(p_frame);
	}
}


/* parse_blockquote_tag()
 *
 * A block quotation is a special paragraph, that consists of citated text.
 * A HTML browser can indent, surround with quotation marks, or use italic for
 * this paragraph.
 * http://purl.org/ISO+IEC.15445/Users-Guide.html#blockquote
 */

static void
parse_blockquote_tag(struct frame_item *p_frame, BOOL start_tag)
{
	p_frame->current.paragraph->eop_space = EOP(p_frame->current.font_size);
	add_paragraph (&p_frame->current);

	if (start_tag)
	{
		#if 1
		/* BUG: TITLE support not ready.  This try leads to another problem:
		 * We need the entity and encoding conversion as a separate function.
		 * Or we do it complete before parsing.  But then PLAINTEXT is not
		 * possible.  It seems, this is this the reason, why it's deprecated. */
		char output[100];
		WORD u, distances[5], effects[3];
		#endif

		p_frame->current.paragraph->alignment = ALN_LEFT;
		p_frame->current.paragraph->Indent += list_indent (2);
		p_frame->current.paragraph->Rindent += list_indent (2);

		#if 1
		if (get_value(KEY_TITLE, output, sizeof(output))) {
			short font_face = TAgetFace (p_frame->current.word->attr);
			word_set_bold (&p_frame->current, TRUE);
			if (font_face != TAgetFace (p_frame->current.word->attr)) {
				vst_font (vdi_handle,
				          fonts[TAgetFont  (p_frame->current.word->attr)]
				               [TAgetBold  (p_frame->current.word->attr)]
				               [TAgetItalic(p_frame->current.word->attr)]);
				vst_arbpt (vdi_handle, TA_Size (p_frame->current.word->attr), &u,&u,&u,&u);
				vqt_fontinfo(vdi_handle, &u, &u, distances, &u, effects);
				p_frame->current.word->word_height = distances[3];
				p_frame->current.word->word_tail_drop = distances[1];
				vqt_advance(vdi_handle, Space_Code,
				            &p_frame->current.word->space_width, &u, &u, &u);
				p_frame->current.word->space_width++;
			}
			scan_string_to_16bit(output, p_frame->Encoding, &p_frame->current.text);
			p_frame->current.paragraph->eop_space = EOP(p_frame->current.font_size);
			add_paragraph(&p_frame->current);
			word_set_bold (&p_frame->current, FALSE);
		}
		#endif
	}
	else
	{
		p_frame->current.paragraph->Indent -= list_indent(2);
		p_frame->current.paragraph->Rindent -= list_indent(2);
	}
}


/* parse anchor
 * ideally you drop the input on this routine
 * and it parses and processes the anchor tag information
 * baldrick - December 3, 2001
 */

static void
parse_anchor (struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current = &p_frame->current;
	WORDITEM word    = current->word;

	if (start_tag)
	{
		char * output;

		if ((output = get_value_str (KEY_HREF)) != NULL)
		{
			char out2[30];
			
			char * target = get_value_str (KEY_TARGET);
			if (!target && p_frame->base_target) {
				target = strdup (p_frame->base_target);
			}
			
			if (!word->link) {
				word_set_underline (current, TRUE);
			}
			word_set_color (current, p_frame->link_colour);

			word->link = new_url_link (output, TRUE, target);
			
			/* Asume ENCODING_WINDOWS1252, which is commen practice. */
			word->link->encoding = ENCODING_WINDOWS1252;
			if (get_value(KEY_CHARSET, out2, sizeof(out2))) {
				if (stricmp(out2, "ISO-8859-2") == 0)
					word->link->encoding = ENCODING_ISO8859_2;
				else if (stricmp(out2, "UTF-8") == 0)
					word->link->encoding = ENCODING_UTF8;
				else if (stricmp(out2, "atarist") == 0)
					word->link->encoding = ENCODING_ATARIST;
			}
		}
		else if ((output = get_value_str (KEY_NAME)) != NULL
		         || (output = get_value_str (KEY_ID)) != NULL)
		{
			word->link = new_url_link (output, FALSE, NULL);
			word->link->u.anchor = new_named_location (word->link->address,
			                                          &current->paragraph->Offset);
			*current->anchor = word->link->u.anchor;
			current->anchor  = &word->link->u.anchor->next_location;
			
			/* prevent from getting deleted if empty */
			*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
			new_word (current, TRUE);
			current->word->link = NULL;
			word->word_width = 0;
		}	
	}
	else if (word->link)
	{
		word_set_color     (current, current->font_step->colour);
		word_set_underline (current, FALSE);
		word->link = NULL;
	}
}


static void
parse_base (struct frame_item *p_frame)
{
	p_frame->base_target = get_value_str (KEY_TARGET);
}


/* parse body tag
 * ideally you drop the input on this routine
 * and it parses and processes the body tag information
 *
 * baldrick - December 3, 2001
 *
 * modifications for new color routines
 * AltF4 - December 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 */

static void
parse_body (struct frame_item *p_frame)
{
	WORD margin;
	
	if (!ignore_colours)
	{
		WORD color;

		if ((color = get_value_color (KEY_TEXT)) >= 0)
		{
			p_frame->text_colour = p_frame->current.font_step->colour = color;
			TA_Color(p_frame->current.word->attr)                     = color;
		}
		if ((color = get_value_color (KEY_BGCOLOR)) >= 0)
		{
			p_frame->Page.Backgnd = p_frame->current.backgnd = color;
		}
		if ((color = get_value_color (KEY_LINK)) >= 0)
		{
			p_frame->link_colour = color;
		}
	}
	
	if ((margin = get_value_unum (CSS_MARGIN, -1)) >= 0) {
		p_frame->Page.MarginTop = p_frame->Page.MarginBot =
		p_frame->Page.MarginLft = p_frame->Page.MarginRgt = margin;
		
	} else {
		if ((margin = get_value_unum (KEY_MARGINHEIGHT, -1)) >= 0 ||
		    (margin = get_value_unum (KEY_TOPMARGIN, -1)) >= 0) {
			p_frame->Page.MarginTop = p_frame->Page.MarginBot = margin;
		}
		if ((margin = get_value_unum (KEY_MARGINWIDTH, -1)) >= 0 ||
		    (margin = get_value_unum (KEY_LEFTMARGIN, -1)) >= 0) {
			p_frame->Page.MarginLft = p_frame->Page.MarginRgt = margin;
		}
	}
}


/* parse_d_tags()
 *
 * processes the d tags DL, DT, DD
 *
 * type determines the type of d tag
 *    0 = DL tag
 *    1 = DT tag
 *    2 = DD tag
 */

static void
parse_d_tags (struct frame_item *p_frame, WORD type, BOOL start_tag)
{
	PARAGRPH prev_par  = p_frame->current.paragraph;
	PARAGRPH paragraph = add_paragraph (&p_frame->current);

	paragraph->alignment = ALN_LEFT;

	if (start_tag)
	{
		if (type == 0) {      /* dl tag start */
			struct list_stack_item *temp_list_holder;
			
			if (!p_frame->current_list)
				prev_par->eop_space = EOP(p_frame->current.font_size);
			else
				paragraph->Indent = p_frame->current_list->Indent;
			
			temp_list_holder = new_stack_list_item ();
			temp_list_holder->next_stack_item = p_frame->current_list;
			temp_list_holder->Spacer  = p_frame->current.word->word_height *2 /3;
			temp_list_holder->Hanging = temp_list_holder->Spacer *4;
			temp_list_holder->Indent  = paragraph->Indent
			                          + temp_list_holder->Hanging;
			p_frame->current_list = temp_list_holder;
			paragraph->Indent     = temp_list_holder->Indent;
			
		} else if (p_frame->current_list) {
		
			if (type == 1) { /* dt tag start */
				paragraph->Indent = p_frame->current_list->Indent
				                  - p_frame->current_list->Hanging;
			} else { /* (type == 2) dd tag start */
				paragraph->Indent = p_frame->current_list->Indent;
			}
		}
	}
	else if (type == 0 && p_frame->current_list) /* dl tag end */
	{
		paragraph->Indent = p_frame->current_list->Indent
		                  - p_frame->current_list->Hanging;
		p_frame->current_list = remove_stack_item (p_frame->current_list);
		if (!p_frame->current_list) {
			prev_par->eop_space += p_frame->current.font_size / 3;
		}
	}
}


/* parse DIV tag
 * ideally you drop the input on this routine
 * and it parses and processes the DIV tag information
 *
 * DIV is only partially implemented from my understanding
 * baldrick - December 14, 2001
 */

static void
parse_div_tag(struct frame_item *p_frame, BOOL start_tag)
{
	if (start_tag)
	{
		PARAGRPH paragraph = p_frame->current.paragraph;

		paragraph->eop_space = EOP(p_frame->current.font_size);

		paragraph = add_paragraph (&p_frame->current);

		switch (toupper (get_value_char (KEY_ALIGN)))
		{
			case 'R': paragraph->alignment = ALN_RIGHT;  break;
			case 'C': paragraph->alignment = ALN_CENTER; break;
			case 'L': paragraph->alignment = ALN_LEFT;   break;
		}
	}
	else
	{
		add_paragraph(&p_frame->current);/*->alignment = p_frame->alignment;*/

		p_frame->current.paragraph->alignment = get_align(p_frame);
	}
}


/* parse basefont tag
 */

static void
parse_basefont (struct frame_item *p_frame)
{
	char output[10];
	struct font_step * f_step = p_frame->current.font_step;
	
	while (f_step->previous_font_step) {
		f_step = f_step->previous_font_step;
	}
	
	if (get_value (KEY_SIZE, output, sizeof(output)))
	{
		if (*output == '+') {
			if (isdigit(output[1])) {
				f_step->step += output[1]  - '0';
			}
		} else {
			if (*output == '-') {
				if (isdigit(output[1])) {
					f_step->step -= output[1]  - '0';
				}
			} else if (isdigit(output[0])) {
				f_step->step = output[0]  - '0';
			}
			if (f_step->step < 1) f_step->step = 1;
		}
		if (f_step->step > 7) f_step->step = 7;
		
		if (f_step == p_frame->current.font_step) {
			p_frame->current.font_size = step2size (NULL, f_step->step);
			word_set_point (&p_frame->current, p_frame->current.font_size);
		}
	}
}


/* parse font tag
 * ideally you drop the input on this routine
 * and it parses and processes the font tag information
 *
 * baldrick - December 14, 2001
 *
 * color handling modified to new routines
 * AltF4 - Dec 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 *
 * Baldrick - March 1, 2002: modifications to always store a font step
 *            so that we don't loose our size on complex sites
 */

static void
parse_font_tag (struct frame_item *p_frame, BOOL start_tag)
{
	if (start_tag)
	{
		char output[10];
		WORD step = p_frame->current.font_step->step;

		if (get_value (KEY_SIZE, output, sizeof(output)))
		{
			if (*output == '+') {
				if (isdigit(output[1])) {
					step += output[1]  - '0';
				}
			} else {
				if (*output == '-') {
					if (isdigit(output[1])) {
						step -= output[1]  - '0';
					}
				} else if (isdigit(output[0])) {
					step = output[0]  - '0';
				}
				if (step < 1) step = 1;
			}
		}
		step_push (&p_frame->current, step);

		if (!ignore_colours)
		{
			WORD color = get_value_color (KEY_COLOR);

			if (color >= 0)
			{
				p_frame->current.font_step->colour = color;
				word_set_color (&p_frame->current, color);
			}
		}
	}
	else
	{
		step_pop (&p_frame->current);
		word_set_color (&p_frame->current, (p_frame->current.word->link
		                                   ? p_frame->link_colour
		                                   : p_frame->current.font_step->colour));
	}
	word_set_point (&p_frame->current, p_frame->current.font_size);
}


/* parse header tag
 * ideally you drop the input on this routine
 * and it parses and processes the header tag information
 *
 * baldrick - August 20, 2001
 * mj - added strupr and 'j' - 10-01-01
 */

static void
parse_header_tag(struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current = &p_frame->current;
	short cur_color;

	if (start_tag)
	{
		if ((!p_frame->current_list)||(p_frame->current.paragraph->item->word_width > 0))
		{
			current->paragraph->eop_space = EOP(current->font_size);

			add_paragraph (current);

			switch (toupper (get_value_char (KEY_ALIGN)))
			{
				case 'R':
					current->paragraph->alignment = ALN_RIGHT;
					break;
				case 'C':
					current->paragraph->alignment = ALN_CENTER;
					break;
				case 'J':
				case 'L':
					current->paragraph->alignment = ALN_LEFT;
			}
		}

		cur_color = p_frame->current.font_step->colour;
		
		step_push (current, 7 - (get_value_char (KEY_H_HEIGHT) - '0'));

		if (!ignore_colours) {
			short color = get_value_color (KEY_BGCOLOR);
			if (color >= 0 && color != current->backgnd) {
				current->paragraph->Backgnd   = color;
				current->paragraph->eop_space = 2;
			}
			color = get_value_color (KEY_COLOR);

			if (color == -1)	color = cur_color;
				
			current->font_step->colour = (color < 0 ? p_frame->text_colour : color);
		}
		word_set_font (current, header_font);
		word_set_bold (current, TRUE);
	}
	else
	{
		add_paragraph (current);

		current->paragraph->alignment = get_align(p_frame);

		step_pop (current);
		word_set_font (current, normal_font);
		word_set_bold (current, FALSE);
	}
	word_set_point (current, current->font_size);
	word_set_color (current, current->font_step->colour);
}


/* parse MENU tag
 * ideally you drop the input on this routine
 * and it parses and processes the MENU tag information
 *
 * it's also possible that we could map this onto parse_ul
 * baldrick - December 13, 2001
 */

static void
parse_menu_tag (struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current   = &p_frame->current;
	PARAGRPH paragraph = current->paragraph;
	struct list_stack_item *temp_list_holder;

	if (start_tag)
	{
		if (!p_frame->current_list)
			paragraph->eop_space = EOP(current->font_size);

		paragraph = add_paragraph (current);

		if (p_frame->current_list)
			paragraph->Indent = p_frame->current_list->Indent;
		
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = p_frame->current_list;
		temp_list_holder->Spacer  = current->word->word_height *2 /3;
		temp_list_holder->Hanging = temp_list_holder->Spacer *4;
		temp_list_holder->Indent  = paragraph->Indent + temp_list_holder->Hanging;
		
		p_frame->current_list = temp_list_holder;
		paragraph->alignment  = ALN_LEFT;
		paragraph->Indent     = temp_list_holder->Indent;
	}
	else if (p_frame->current_list)
	{
		WORD indent = p_frame->current_list->Indent
		            - p_frame->current_list->Hanging;
		p_frame->current_list = remove_stack_item (p_frame->current_list);
		if (!p_frame->current_list)
			paragraph->eop_space += current->font_size / 3;

		add_paragraph (current)->Indent = indent;
	}
}


/* Parse META tag in <HEAD>...</HEAD>.
 * Ideally you drop the input on this routine
 * and it parses and processes the META tag information.
 *
 * Rainer Seitel, 2002-03-18
 */
static void
parse_meta_tag(struct frame_item *p_frame)
{
	char output[100];
	extern ENCODING last_encoding;  /* from Loader.c */

	/* Note: KEY_HTTP_EQUIV corresponds to "HTTP-EQUIV"! */
	if (get_value (KEY_HTTP_EQUIV, output, sizeof(output)) &&
	    stricmp   (output, "Content-Type") == 0            &&
	    get_value (KEY_CONTENT, output, sizeof(output))) {
		
		ENCODING cset = http_charset (output, strlen(output), NULL);
		if (cset) {
			p_frame->Encoding = cset;
		}
		last_encoding = p_frame->Encoding;  /* used for Undo key */
		/* http://www.iana.org/assignments/character-sets */
	}
}

/* Parse IOD4 tag.
 * Ideally you drop the input on this routine
 * and it parses and processes the SHOUT attribute.
 *
 * Matthias Jaap, 2002-07-22
 */
static void
parse_iod4_tag(struct frame_item *p_frame, BOOL start_tag)
{
	char output[100];

	if (start_tag)
	{
		get_value (KEY_SHOUT, output, sizeof(output));
		wind_set_str   (window_handle, WF_INFO, output);
	}
}

/* parse P tag
 * ideally you drop the input on this routine
 * and it parses and processes the P tag information
 *
 * baldrick - December 14, 2001
 *
 * BUG: We must ignore empty paragraphs. Else <LI><P>...</P><P>...</P></LI>
 * looks bad. Vertical space is made by <P>&nbsp;</P>.
 * Rainer Seitel, 2002-03-16
 *
 * don't add new paragraph and ignore alignment if we have a <P>
 * at the start of a list item 
 *
 * added start_tag parameter
 * Baldrick, June 5, 2002
 */

static void
parse_p_tag(struct frame_item *p_frame, BOOL start_tag)
{
	PARAGRPH par = p_frame->current.paragraph;
	char     buf[8];

	if (start_tag)
	{
		H_ALIGN align = get_align (p_frame);

		par->eop_space = EOP(p_frame->current.font_size);

		par = add_paragraph (&p_frame->current);

		if (get_value (KEY_ALIGN, buf, sizeof(buf))) {
			if      (stricmp (buf, "right")   == 0) align = ALN_RIGHT;
			else if (stricmp (buf, "center")  == 0) align = ALN_CENTER;
			else if (stricmp (buf, "justify") == 0) align = ALN_JUSTIFY;
		}
		par->alignment = align;

		if (!ignore_colours) {
			WORD color = get_value_color (KEY_COLOR);
			if (color >= 0) {
				word_set_color (&p_frame->current, color);
			}
		}
	}
	else
	{
		par->eop_space = 0;

		par = add_paragraph (&p_frame->current);

		par->alignment = get_align(p_frame);

		if (!ignore_colours) {
			word_set_color (&p_frame->current,
			                p_frame->current.font_step->colour);
		}
	}

	p_frame->current.word->vertical_align = ALN_BOTTOM;
}

/* parse BR tag
 */

static void
parse_BR_tag (struct frame_item *p_frame, struct word_item *stored_word)
{
	char output[10];
	TEXTBUFF current   = &p_frame->current;
	L_BRK clear = BRK_LN;

	if (get_value (KEY_CLEAR, output, sizeof(output))) {
		if      (stricmp (output, "right") == 0) clear = BRK_RIGHT;
		else if (stricmp (output, "left")  == 0) clear = BRK_LEFT;
		else if (stricmp (output, "all")   == 0) clear = BRK_ALL;
	}

	stored_word->line_brk = clear;
	current->word->vertical_align = ALN_BOTTOM;
}


/* parse Q tag
 * Language dependent quotation marks.
 * Source: The Unicode Standard Version 3.0, section 6.1.
 * BUG: Should work for nested quotes, alternating double and single.
 * BUG: Must use LANG set elsewere as default.
 *
 * Rainer Seitel, 2002-03-29
 */
static void parse_q_tag(UWORD **text, BOOL start_tag)
{
	static LANGUAGE language = LANG_EN;
	char buf[6];

	if (get_value(KEY_LANG, buf, sizeof(buf))) {
		strlwr(buf);
		language = *((UWORD *)buf);
	}
	switch (language) {
		case LANG_CS:  /* Czech, German, Slovak */
		case LANG_DE:
		case LANG_SK:
			if (start_tag) {
				**text = 107;  /* U+201E DOUBLE LOW-9 QUOTATION MARK */
				++*text;
			} else {
				**text = 104;  /* U+201C LEFT DOUBLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_FR:  /* French, Greek, Russian */
		case LANG_EL:
		case LANG_RU:
			if (start_tag) {
				**text = 125;  /* U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			} else {
				**text = 126;  /* U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_HU:  /* Hungarian, Polish */
		case LANG_PL:
			if (start_tag) {
				**text = 107;  /* U+201E DOUBLE LOW-9 QUOTATION MARK */
				++*text;
			} else {
				**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_SL:  /* Slovenian */
			if (start_tag) {
				**text = 126;  /* U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			} else {
				**text = 125;  /* U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK */
				++*text;
			}
			break;
		case LANG_DA:  /* Danish, Finnish, Norwegian, Swedish */
		case LANG_FI:
		case LANG_NO:
		case LANG_SV:
			**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
			++*text;
			break;
		default:  /* else Dutch, English, Italian, Portuguese, Spanish, Turkish quotes */
			if (start_tag) {
				**text = 104;  /* U+201C LEFT DOUBLE QUOTATION MARK */
				++*text;
			} else {
				**text = 105;  /* U+201D RIGHT DOUBLE QUOTATION MARK */
				++*text;
			}
	}
}


/* Recursively converts a positive long to a decimal number wide string.
 * Rainer Seitel, 2002-03-11
 */
static void long2decimal(UWORD **p_ws, long l)
{
	if (l >= 10)
		long2decimal(p_ws, l / 10);

	**p_ws = map((l % 10) + '0');
	(*p_ws)++;
}


/* Recursively converts a positive long to an alphabet number wide string.
 * Rainer Seitel, 2002-03-11
 */
static void long2alpha(UWORD **p_ws, long l, BOOL upper)
{
	if (l > 26)
		long2alpha(p_ws, l / 26, upper);

	**p_ws = map(((l - 1) % 26) + (upper? 'A' : 'a'));
	(*p_ws)++;
}


static WORD
list_marker (struct frame_item *p_frame)
{
	UWORD * active_word = p_frame->current.text;
	WORD    indent_type = 0;
	WORD    count       = p_frame->current_list->counter;

	switch (p_frame->current_list->bullet_style)
	{
		case disc:
			*(active_word++) = 342;  /* U+2022 BULLET */
			indent_type = 0;
			break;
		case square:
			*(active_word++) = 507;  /* U+25AA BLACK SMALL SQUARE */
			indent_type = 0;
			break;
		case circle:
			*(active_word++) = 499;  /* U+25E6 WHITE BULLET */
			indent_type = 0;
			break;
		case Number:
			if (count < 0) {
				*(active_word++) = 283;  /* U+2212 MINUS SIGN */
				count = -count;
			}
			long2decimal(&active_word, count);
			*(active_word++) = 14;  /* U+002E . */
			p_frame->current_list->counter++;
			indent_type = 1;
			break;
		case alpha:
			if (count != 0) {
				if (count < 0) {
					*(active_word++) = 283;  /* U+2212 MINUS SIGN */
					count = -count;
				}
				long2alpha(&active_word, count, FALSE);
				*(active_word++) = 14;  /* U+002E . */
				p_frame->current_list->counter++;
				indent_type = 1;
				break;
			}
			/* else use @ as small alphabet zero */
		case Alpha:
			if (count < 0) {
				*(active_word++) = 283;  /* U+2212 MINUS SIGN */
				count = -count;
			}
			long2alpha(&active_word, count, TRUE);
			*(active_word++) = 14;  /* U+002E . */
			p_frame->current_list->counter++;
			indent_type = 1;
			break;
		case roman:
			if (count > 0 && count < 3000) {
				switch (count / 1000 * 1000) {
				case 2000:
					*(active_word++) = map('m');
				case 1000:
					*(active_word++) = map('m');
					break;
				}
				switch ((count % 1000) / 100 * 100) {
				case 300:
					*(active_word++) = map('c');
				case 200:
					*(active_word++) = map('c');
				case 100:
					*(active_word++) = map('c');
					break;
				case 400:
					*(active_word++) = map('c');
				case 500:
					*(active_word++) = map('d');
					break;
				case 600:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					break;
				case 700:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					break;
				case 800:
					*(active_word++) = map('d');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					*(active_word++) = map('c');
					break;
				case 900:
					*(active_word++) = map('c');
					*(active_word++) = map('m');
					break;
				}
				switch ((count % 100) / 10 * 10) {
				case 30:
					*(active_word++) = map('x');
				case 20:
					*(active_word++) = map('x');
				case 10:
					*(active_word++) = map('x');
					break;
				case 40:
					*(active_word++) = map('x');
				case 50:
					*(active_word++) = map('l');
					break;
				case 60:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					break;
				case 70:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					break;
				case 80:
					*(active_word++) = map('l');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					*(active_word++) = map('x');
					break;
				case 90:
					*(active_word++) = map('x');
					*(active_word++) = map('c');
					break;
				}
				switch (count % 10) {
				case 3:
					*(active_word++) = map('i');
				case 2:
					*(active_word++) = map('i');
				case 1:
					*(active_word++) = map('i');
					break;
				case 4:
					*(active_word++) = map('i');
				case 5:
					*(active_word++) = map('v');
					break;
				case 6:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					break;
				case 7:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					break;
				case 8:
					*(active_word++) = map('v');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					*(active_word++) = map('i');
					break;
				case 9:
					*(active_word++) = map('i');
					*(active_word++) = map('x');
					break;
				}
			} else {  /* BUG: small Roman numerals >= 3000 not implemented! */
				long2decimal(&active_word, count);
			}
			*(active_word++) = 14;  /* U+002E . */
			p_frame->current_list->counter++;
			indent_type = 1;
			break;
		case Roman:
			/* Sources:
			 * Friedlein, Gottfried: Die Zahlzeichen und das elementare Rechnen
			 * der Griechen und R�mer und des christlichen Abendlandes vom 7.
			 * bis 13. Jahrhundert. - unver�nderter Neudruck der Ausgabe von
			 * 1869. - Wiesbaden : Dr. Martin S�ndig oHG, 1968.
			 * Ifroh, Georges: Universalgeschichte der Zahlen. - Frankfurt am
			 * Main ; New York : Campus, 1986. - ISBN 3-593-33666-9. - Kapitel
			 * 9. (Histoire Universelle des Chiffres. - Paris : Seghers, 1981.)
			 * Rainer Seitel, 2002-03-11
			 */
			if (count > 0 && count < 20000) {
				if (count >= 10000) {
					*(active_word++) = map('(');
					*(active_word++) = map('(');
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
				}
				switch ((count % 10000) / 1000 * 1000) {
				case 9000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 8000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 7000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					*(active_word++) = map('M');
					break;
				case 6000:
					*(active_word++) = map('|');
					*(active_word++) = map(')');
					*(active_word++) = map(')');
					*(active_word++) = map('M');
					break;
				case 5000:
					*(active_word++) = map('M');
				case 4000:
					*(active_word++) = map('M');
				case 3000:
					*(active_word++) = map('M');
				case 2000:
					*(active_word++) = map('M');
				case 1000:
					*(active_word++) = map('M');
					break;
				}
				switch ((count % 1000) / 100 * 100) {
				case 300:
					*(active_word++) = map('C');
				case 200:
					*(active_word++) = map('C');
				case 100:
					*(active_word++) = map('C');
					break;
				case 400:
					*(active_word++) = map('C');
				case 500:
					*(active_word++) = map('D');
					break;
				case 600:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					break;
				case 700:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					break;
				case 800:
					*(active_word++) = map('D');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					*(active_word++) = map('C');
					break;
				case 900:
					*(active_word++) = map('C');
					*(active_word++) = map('M');
					break;
				}
				switch ((count % 100) / 10 * 10) {
				case 30:
					*(active_word++) = map('X');
				case 20:
					*(active_word++) = map('X');
				case 10:
					*(active_word++) = map('X');
					break;
				case 40:
					*(active_word++) = map('X');
				case 50:
					*(active_word++) = map('L');
					break;
				case 60:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					break;
				case 70:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					break;
				case 80:
					*(active_word++) = map('L');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					*(active_word++) = map('X');
					break;
				case 90:
					*(active_word++) = map('X');
					*(active_word++) = map('C');
					break;
				}
				switch (count % 10) {
				case 3:
					*(active_word++) = map('I');
				case 2:
					*(active_word++) = map('I');
				case 1:
					*(active_word++) = map('I');
					break;
				case 4:
					*(active_word++) = map('I');
				case 5:
					*(active_word++) = map('V');
					break;
				case 6:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					break;
				case 7:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					break;
				case 8:
					*(active_word++) = map('V');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					*(active_word++) = map('I');
					break;
				case 9:
					*(active_word++) = map('I');
					*(active_word++) = map('X');
					break;
				}
			} else {  /* BUG: Roman numerals >= 20000 not implemented! */
				long2decimal(&active_word, count);
			}
			*(active_word++) = 14;  /* U+002E . */
			p_frame->current_list->counter++;
			indent_type = 1;
			break;
	}

	p_frame->current.text = active_word;

	return list_indent (indent_type);
}


/* parse LI tag
 * ideally you drop the input on this routine
 * and it parses and processes the LI tag information
 *
 * baldrick - December 12, 2001
 */

static void
parse_li_tag (struct frame_item *p_frame)
{
	TEXTBUFF current  = &p_frame->current;
	PARAGRPH li_par   = current->paragraph;
	WORD     old_size = TA_Size (current->word->attr);
	WORD     indent   = p_frame->current_list->Hanging
	                  - p_frame->current_list->Spacer;
	WORD     u;

	/* this basically just catches that it's not the first LI in a list */
	if (li_par->item != current->word) {
		li_par = add_paragraph (current);
	}
	li_par->Indent = p_frame->current_list->Indent;

	switch (get_value_char (KEY_TYPE))
	{
		case 'a':
			p_frame->current_list->bullet_style = alpha;
			break;
		case 'A':
			p_frame->current_list->bullet_style = Alpha;
			break;
		case 'i':
			p_frame->current_list->bullet_style = roman;
			break;
		case 'I':
			p_frame->current_list->bullet_style = Roman;
			break;
		case '1':
			p_frame->current_list->bullet_style = Number;
			break;
		case 'd':
		case 'D':
			p_frame->current_list->bullet_style = disc;
			break;
		case 'c':
		case 'C':
			p_frame->current_list->bullet_style = circle;
			break;
		case 's':
		case 'S':
			p_frame->current_list->bullet_style = square;
			break;
	}
	p_frame->current_list->counter = get_value_unum (KEY_VALUE,
	                                             p_frame->current_list->counter);
	
	word_set_point (current, step2size (NULL, current->font_step->step -2));
	vst_arbpt (vdi_handle, TA_Size (current->word->attr), &u, &u, &u, &u);
	list_marker (p_frame);
	add_paragraph (current)->alignment = ALN_LEFT;
	
	if (li_par->item->word_width > indent) {
		current->paragraph->Indent += li_par->item->word_width - indent;
		li_par->Indent -= p_frame->current_list->Hanging;
	} else {
		li_par->Indent -= li_par->item->word_width + p_frame->current_list->Spacer;;
	}
	li_par->eop_space = -(li_par->item->word_height +
	                      li_par->item->word_tail_drop);
	
	word_set_point (current, old_size);
	vst_arbpt (vdi_handle, TA_Size (current->word->attr), &u, &u, &u, &u);
}


/* parse OL tag
 * ideally you drop the input on this routine
 * and it parses and processes the OL tag information
 *
 * baldrick - December 12, 2001
 */

static void
parse_ol_tag (struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current   = &p_frame->current;
	PARAGRPH paragraph = current->paragraph;
	struct list_stack_item *temp_list_holder;

	if (start_tag)
	{
		if (!p_frame->current_list)
			paragraph->eop_space = EOP(current->font_size);

		paragraph = add_paragraph (current);

		if (p_frame->current_list)
			paragraph->Indent = p_frame->current_list->Indent;
		
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = p_frame->current_list;
		temp_list_holder->Spacer  = current->word->word_height *2 /3;
		temp_list_holder->Hanging = temp_list_holder->Spacer *4;
		temp_list_holder->Indent  = paragraph->Indent + temp_list_holder->Hanging;
		
		p_frame->current_list = temp_list_holder;
		paragraph->alignment  = ALN_LEFT;
		paragraph->Indent     = temp_list_holder->Indent;

		switch (get_value_char (KEY_TYPE))
		{
			case 'a':
				p_frame->current_list->bullet_style = alpha;
				break;
			case 'A':
				p_frame->current_list->bullet_style = Alpha;
				break;
			case 'i':
				p_frame->current_list->bullet_style = roman;
				break;
			case 'I':
				p_frame->current_list->bullet_style = Roman;
				break;
			default:
				p_frame->current_list->bullet_style = Number;
		}

		p_frame->current_list->counter = get_value_unum (KEY_START, 1);  /* BUG: long! */
	}
	else if (p_frame->current_list)
	{
		WORD indent = p_frame->current_list->Indent
		            - p_frame->current_list->Hanging;
		p_frame->current_list = remove_stack_item (p_frame->current_list);
		if (!p_frame->current_list)
			paragraph->eop_space += current->font_size / 3;

		add_paragraph (current)->Indent = indent;
	}
}


/* parse UL tag
 * ideally you drop the input on this routine
 * and it parses and processes the UL tag information
 * baldrick - December 12, 2001
 */

static void
parse_ul_tag (struct frame_item *p_frame, BOOL start_tag)
{
	TEXTBUFF current   = &p_frame->current;
	PARAGRPH paragraph = current->paragraph;
	struct list_stack_item *temp_list_holder;

	if (start_tag)
	{
		if (!p_frame->current_list)
			paragraph->eop_space = EOP(current->font_size);

		paragraph = add_paragraph (current);

		if (p_frame->current_list)
			paragraph->Indent = p_frame->current_list->Indent;
		
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = p_frame->current_list;
		temp_list_holder->Spacer  = current->word->word_height *2 /3;
		temp_list_holder->Hanging = temp_list_holder->Spacer *4;
		temp_list_holder->Indent  = paragraph->Indent + temp_list_holder->Hanging;
		
		paragraph->alignment  = ALN_LEFT;
		paragraph->Indent     = temp_list_holder->Indent;

		switch (get_value_char (KEY_TYPE))
		{
			case 'S':
			case 's':
				temp_list_holder->bullet_style = square;
				break;
			case 'c':
			case 'C':
				temp_list_holder->bullet_style = circle;
				break;
			case 'd':
			case 'D':
				temp_list_holder->bullet_style = disc;
			default:
				if (p_frame->current_list)
					temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;
		}

		p_frame->current_list = temp_list_holder;
	}
	else if (p_frame->current_list)
	{
		WORD indent = p_frame->current_list->Indent
		            - p_frame->current_list->Hanging;
		p_frame->current_list = remove_stack_item (p_frame->current_list);
		if (!p_frame->current_list)
			paragraph->eop_space += current->font_size / 3;

		add_paragraph (current)->Indent = indent;
	}
}


/* parse hr tag
 * ideally you drop the input on this routine
 * and it parses and processes the hr tag information
 *
 * baldrick - December 5, 2001
 *
 * Completely reworked:
 * - hr_wrd->space_width:    line width (absolute or negative percent)
 * - hr_wrd->word_height:    vertical distance to the line
 * - hr_wrd->word_tail_drop: line size (height, negative for 'noshade')
 *
 * AltF4 - July 21, 2002
 */

static void
parse_hr_tag (struct frame_item *p_frame)
{
	TEXTBUFF current = &p_frame->current;
	PARAGRPH           hr_par;
	struct word_item * hr_wrd;
	char output[100];

	current->paragraph->eop_space = 0;
	hr_par = add_paragraph(current);
	hr_wrd = current->word;

	add_paragraph (current);

	hr_par->paragraph_code = PAR_HR;
	hr_par->alignment      = ALN_CENTER;
	if (get_value (KEY_ALIGN, output, sizeof(output))) {
		if      (stricmp (output, "left")  == 0) hr_par->alignment = ALN_LEFT;
		else if (stricmp (output, "right") == 0) hr_par->alignment = ALN_RIGHT;
	}
	hr_wrd->word_height   += hr_wrd->word_tail_drop;
	if ((hr_wrd->word_tail_drop = get_value_unum (KEY_SIZE, 0)) == 0 &&
	    (hr_wrd->word_tail_drop = get_value_unum (KEY_HEIGHT, 0)) == 0) {
		hr_wrd->word_tail_drop = 2;
	} else if (hr_wrd->word_tail_drop > 100) {
		hr_wrd->word_tail_drop = 100;
	}
	hr_wrd->word_height = (hr_wrd->word_height + hr_wrd->word_tail_drop) /2;
	if (get_value (KEY_NOSHADE, NULL,0)) {
		hr_wrd->word_tail_drop = -hr_wrd->word_tail_drop;
	}
	if ((hr_wrd->space_width = get_value_size (KEY_WIDTH)) == 0) {
		hr_wrd->space_width = -1024;
	}
	if (!ignore_colours) {
		WORD color = get_value_color (KEY_BGCOLOR);
		if (color >= 0 && color != current->backgnd) {
			hr_par->Backgnd = color;
		}
		color = get_value_color (KEY_COLOR);
		TA_Color(hr_wrd->attr) = (color                  >= 0 ? color    :
		                          hr_wrd->word_tail_drop <= 1 ? G_LBLACK :
		                          hr_par->Backgnd        >= 0 ? hr_par->Backgnd :
		                                                        current->backgnd);
	} else if (hr_wrd->word_tail_drop <= 1) {
		TA_Color(hr_wrd->attr) = G_BLACK;
	}
}


/* parse img tag
 * ideally you drop the input on this routine
 * and it parses and processes the img tag information
 *
 * baldrick - Dec 4, 2001
 */

static void
parse_img_tag(struct frame_item *p_frame)
{
	TEXTBUFF current = &p_frame->current;
	short word_height    = current->word->word_height;
	short word_tail_drop = current->word->word_tail_drop;
	short word_v_align   = current->word->vertical_align;
	
	struct word_item * word;
	short align = -1;
	char output[100];
	char img_file[HW_PATH_MAX];

	if (alternative_text_is_on) {
		if (get_value(KEY_ALT, output, sizeof(output))) {
			scan_string_to_16bit(output, p_frame->Encoding, &current->text);
		}
		return;
	}

	if (get_value (KEY_ALIGN, output, sizeof(output))) {
		short v_align = ALN_BOTTOM;
		short h_align = -1;

		if      (stricmp (output, "left")   == 0) h_align = ALN_LEFT;
		else if (stricmp (output, "right")  == 0) h_align = ALN_RIGHT;
		else if (stricmp (output, "center") == 0) h_align = ALN_CENTER;
		
		else if (stricmp (output, "top")    == 0) v_align = ALN_TOP;
		else if (stricmp (output, "middle") == 0) v_align = ALN_MIDDLE;
		/* else                                   v_align = ALN_BOTTOM */
		if (h_align >= 0) {
			align = current->paragraph->alignment;

			if (current->paragraph->item != current->word) {
				add_paragraph (current);
			}

			/* This is necessary to be here since sometimes an IMG is the first
			 * thing in a BODY or table cell
 	 		*/
			if ((h_align == ALN_LEFT)||(h_align == ALN_RIGHT))
				current->paragraph->paragraph_code = PAR_IMG;

			current->paragraph->alignment = h_align;
		}

		current->word->vertical_align = v_align;
	} else {
		current->word->vertical_align = ALN_BOTTOM;
	}
	word = current->word;
	
	get_value (KEY_SRC, img_file, sizeof(img_file));
	
	new_image (p_frame->Container,
	           get_value_size (KEY_WIDTH), get_value_size (KEY_HEIGHT),
				get_value_size (KEY_VSPACE),get_value_size (KEY_HSPACE),
				img_file, p_frame->Location);

	if (get_value (KEY_ALT, output, sizeof(output))) {
		char * text = output;
		while (isspace (*text)) text++;
		if (*text) {
			scan_string_to_16bit (text, p_frame->Encoding, &current->text);
		}
	}
	
	if (align < 0) {
		new_word (current, TRUE);
	} else {
		TA_Color(word->attr) = current->font_step->colour;
		add_paragraph (current)->alignment = align;
	}
	current->word->word_height    = word_height;
	current->word->word_tail_drop = word_tail_drop;
	current->word->vertical_align = word_v_align;
}

/* parse_title
 *
 * parses a title tag from a file 
 * and sets the window's title to this value
 * also watches for ISO Latin entities in the Title string
 * Baldrick Dec. 6, 2001
 *
 * Modified to use new ISO scanning routines
 * AltF4 Dec. 19, 2001
 */

static const char *
parse_title (FRAME p_frame, const char *symbol)
{
	ENCODER_C encoder = encoder_char (p_frame->Encoding);
	char   window_title[129 +5] = "";
	char * title     = window_title;
	char * watermark = window_title + aes_max_window_title_length;
	BOOL ready = FALSE;
	
	do {
		switch(*symbol)
		{
			case '\0':
				ready = TRUE;
				break;
			case '\t':
			case '\r':
			case '\n':
				/* BUG: Replace contiguous white space by exact one space! */
				symbol++;
				break;
			case '&':
				if (title < watermark)
					title = scan_namedchar (&symbol, title, FALSE);
				else
					symbol++;
				break;
			case '<':
				if (symbol[1] == '/')
				{
					const char * sym = symbol + 2;
					if (parse_tag (&sym) == TAG_TITLE)
					{
						symbol = sym;
						ready  = TRUE;
						break;
					}
				}
			default:
				if (title < watermark)
					title = (*encoder)(&symbol, title);
				else
					symbol++;
				break;
		}
	} while (!ready);
	
	*title = window_title[aes_max_window_title_length] = '\0';
	
	if (strlen(window_title) > 0)
		containr_notify (p_frame->Container, HW_SetTitle, window_title);

	return(symbol);
}


/* parse_embed()
 *
 * Processes embedded multi media objects.
 * Currently it simply fires up a new loader job and lets
 * the loader find out what to do.
 *
 * AltF4 - Mar. 01, 2002
 */
static void
parse_embed (LOCATION base)
{
	char snd_file[HW_PATH_MAX];

	if (get_value (KEY_SRC, snd_file, sizeof(snd_file))) {
		new_loader_job (snd_file, base, NULL, ENCODING_WINDOWS1252, -1,-1);
	}
}


/* parse frameset()
 *
 * ideally you drop the input on this routine
 * and it parses and processes the frameset information
 * until done and then returns to the main parser with
 * a pointer to the end of the frameset
 * baldrick - August 8, 2001
 *
 * at the moment there is a hard coded limit of 10 frames.
 * Could or should be changed in the future.
 *
 * There are some printf's in this section that are rem'd out
 * they are useful checks on the frame parsing and I'm not
 * certain that it's 100% correct yet.  So I have left them
 * baldrick - August 14, 2001
 *
 * Major reworks by AltF4 in late January - early Feb 2002
 */

static const char *
parse_frameset (const char *symbol, CONTAINR container, LOCATION base)
{
	HTMLTAG tag   = TAG_FRAMESET;
	BOOL    slash = FALSE;
	int     depth = 0;

	if (!container) {
		errprintf ("parse_frameset(): NO CONTAINER in '%s'!\n", base->File);
		exit(EXIT_FAILURE);
	} else if (container->Mode) {
		errprintf ("parse_frameset(): container not cleared in '%s'!\n", base->File);
		exit(EXIT_FAILURE);
	}

	do
	{
		if (!slash) {

			/* only work on an empty container.  if not empty there was either a
			 * forgotten </framset> or more tags than defined in the frameset.
			 */
			if (!container->Mode) {

				if (tag == TAG_FRAMESET) {

					char output[100];
					BOOL border = (container->Parent
					               ? container->Parent->Border : TRUE);
					container->Border = (get_value_unum (KEY_FRAMEBORDER, border) > 0);

					/* ok the first thing we do is look for ROWS or COLS
					 * since when we are dumped here we are looking at a
					 * beginning of a FRAMESET tag
					 */

					if (get_value (KEY_COLS, output, sizeof(output))) {
						containr_fillup (container, output, TRUE);
						container = container->u.Child;
						depth++;
					}

					else /* at the moment settings of either COLS _and_ ROWS aren't
					      * working yet, so we make it mutual exlusive for now   */

					if (get_value (KEY_ROWS, output, sizeof(output))) {
						containr_fillup (container, output, FALSE);
						container = container->u.Child;
						depth++;
					}

				} else if (tag == TAG_FRAME) {
					char output[100];
					char  frame_file[HW_PATH_MAX];

					container->Mode   = CNT_FRAME;
					container->Name   = get_value_str (KEY_NAME);
					container->Border = container->Parent->Border;

					if (get_value (KEY_SCROLLING, output, sizeof(output))) {
						if      (stricmp (output, "yes")   == 0) container->scroll = SCROLL_ALWAYS;
						else if (stricmp (output, "no")  == 0)   container->scroll = SCROLL_NEVER;
						else if (stricmp (output, "auto") == 0)  container->scroll = SCROLL_AUTO;
					}
					else
						container->scroll = SCROLL_AUTO;

					if (get_value (KEY_SRC, frame_file, sizeof(frame_file))) {
						/* BUG: is there a CHARSET attribute? */
						new_loader_job (frame_file, base, container,
						                ENCODING_WINDOWS1252,
						                get_value_unum (KEY_MARGINWIDTH,  -1),
						                get_value_unum (KEY_MARGINHEIGHT, -1));
					} else {
						containr_calculate (container, NULL);
						containr_notify (container,
						                 HW_PageFinished, &container->Area);
					}

					if (container->Sibling) {
						container = container->Sibling;
					}
				}
			} /* endif (!container->Mode) */

		} else if (tag == TAG_FRAMESET) { /* && slash */

			container = container->Parent;

			if (--depth <= 0) break;

			if (container->Sibling) {
				container = container->Sibling;
			}
		}

		/* skip junk until the next <...> */

		while (*symbol && *(symbol++) != '<');
		if (*symbol) {
			slash = (*symbol == '/');
			if (slash) symbol++;
			tag = parse_tag (&symbol);
			continue;
		}
	}
	while (*symbol);

	#if 0
	{
		extern void containr_debug (CONTAINR);
		containr_debug (container);
	}
	#endif

	return symbol;
}


/* skip everything until </STYLE> tag
 */
static void
skip_style (const char ** pptr)
{
	const char * line = *pptr;
	do {
		BOOL slash;
		while (*line && *(line++) != '<');
		slash = (*line == '/');
		if (slash) line++;
		if (parse_tag (&line) == TAG_STYLE && slash) {
			break;
		}
	} while (*line);

	*pptr = line;
}


/* skip everything until </SCRIPT> or <NOSCRIPT> tag
 */
static BOOL
skip_script (const char ** pptr)
{
	const char * line = *pptr, * save = NULL;
	BOOL   noscript = FALSE;
	do {
		BOOL    slash;
		HTMLTAG tag;
		while (*line && *(line++) != '<');
		slash = (*line == '/');
		if (slash) line++;
		else       save = line +1;
		tag = parse_tag (&line);
		if (slash) {
			if (tag == TAG_SCRIPT) break;
		} else if (tag == TAG_NOSCRIPT) {
			noscript = TRUE;
			break;
		} else {
			line = save;
		}
	} while (*line);

	*pptr = line;

	return noscript;
}


/* calculate_frame
 * this is the main parsing routine
 *
 * AltF4 - Feb. 04, 2002: renamed to parse_html() because that matches more its
 *                        functionality, corresponding to parse_text().
 */
BOOL
parse_html (const char *symbol, struct frame_item *p_frame)
{
	time_t start_clock = clock();
	
	TEXTBUFF  current = &p_frame->current;
	ENCODER_W encoder = encoder_word (p_frame->Encoding & 0x7Fu);
	UWORD active_word_buffer[500];  /* 500 is enough for 124 UTF-8 characters,
	                                 * if the encoding is unrecognized, parsed
	                                 * as single byte characters in PRE mode. */
	UWORD * watermark_1 = active_word_buffer + sizeof(active_word_buffer)
	                    - sizeof(*active_word_buffer);
	UWORD * watermark_4 = watermark_1 - sizeof(*active_word_buffer) *4;
	BOOL space_found = TRUE;  /* skip leading spaces */
	BOOL in_pre      = FALSE;
	BOOL in_script = FALSE; /* if this is TRUE we have to wait for a </noscript>
	                         * tag to reenter the skip_script() function   */
	BOOL linetoolong = FALSE;  /* "line too long" error printed? */
	WORD u, distances[5], effects[3];
	struct word_item * stored_word = current->word;
	
	ENCODING force_cset = (p_frame->Encoding & 0x80u
	                       ? p_frame->Encoding & 0x7Fu : 0);
	if (force_cset) {
		p_frame->Encoding = force_cset;
	}
	
	if (symbol == NULL) return FALSE;

	current->text = current->buffer = active_word_buffer;

	vst_font (vdi_handle, fonts[0][0][0]);
	current->font_step = new_step (3, p_frame->text_colour);
	vst_arbpt (vdi_handle, current->font_size, &u,&u,&u,&u);
	vqt_advance (vdi_handle, Space_Code, &current->word->space_width, &u,&u,&u);
	current->word->space_width++;

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	current->word->word_height = distances[3];
	current->word->word_tail_drop = distances[1];

	while (*symbol != '\0')
	{
		if (*symbol == '<')
		{
			TEXTATTR attrib = current->word->attr;
			
			BOOL start_tag = (*(++symbol) != '/');
			if (!start_tag) symbol++;

			if (current->text > current->buffer) {
				stored_word = current->word;
				new_word (current, TRUE);
			}
			switch (parse_tag (&symbol))
			{
				case TAG_A:
					parse_anchor (p_frame, start_tag);
					break;
				case TAG_B: /* (bold text) */
					word_set_bold (current, start_tag);
					break;
				case TAG_BASE:
					if (start_tag)
						parse_base (p_frame);
					break;
				case TAG_BASEFONT:
					if (start_tag)
						parse_basefont (p_frame);
					break;
				case TAG_BGSOUND:
				case TAG_EMBED:
					if (start_tag) parse_embed (p_frame->Location);
					break;
				case TAG_BIG:
					if (start_tag) {
						step_push (current, current->font_step->step +1);
					} else {
						step_pop (current);
					}
					word_set_point (current, current->font_size);
					break;
				case TAG_BLOCKQUOTE:
					parse_blockquote_tag (p_frame, start_tag);
					break;
				case TAG_BODY:
					if (start_tag)
						parse_body (p_frame);
					break;
				case TAG_BR:
					if (start_tag && current->word != stored_word) {
						parse_BR_tag (p_frame,stored_word);
						space_found = TRUE;
					}
					break;
				case TAG_C: case TAG_CENTER:
					set_center_text (p_frame, start_tag);
					break;
				case TAG_CITE:
					word_set_italic (current, start_tag);
					break;
				case TAG_CODE:
					set_pre_font (current, start_tag);
					break;
				case TAG_DFN: /* (instance definition) */
					word_set_italic (current, start_tag);
					break;
				case TAG_DIR:
					parse_menu_tag (p_frame, start_tag);
					break;
				case TAG_DIV: /* (generic language style container) */
					parse_div_tag (p_frame, start_tag);
					break;
				case TAG_DL: /* (definition list) */
					parse_d_tags (p_frame, 0, start_tag);
					break;
				case TAG_DT: /* (definition term) */
					if (start_tag)
						parse_d_tags (p_frame, 1, TRUE);
					break;
				case TAG_DD: /* (definition description) */
					if (start_tag)
						parse_d_tags (p_frame, 2, TRUE);
					break;
				case TAG_EM: /* (emphasis tag) */
					word_set_italic (current, start_tag);
					break;
				case TAG_FONT:
					parse_font_tag (p_frame, start_tag);
					break;
				case TAG_FORM:
/*					if (start_tag)
						form_start (p_frame);
					else if (p_frame->FormStack)
						form_finish (p_frame);
*/
					break;
				case TAG_H: /* header tag <H1>..<H6> */
					parse_header_tag (p_frame, start_tag);
					break;
				case TAG_HR:
					if (start_tag) {
						parse_hr_tag (p_frame);
						attrib = current->word->attr;
					}
					break;
				case TAG_I: /* (italic text style) tag */
					word_set_italic (current, start_tag);
					break;
				case TAG_IMG:
					if (start_tag) {
						stored_word = current->word;
						parse_img_tag (p_frame);
						if (!stored_word->next_word) {
							stored_word = current->word;
							space_found = TRUE;
						} else {
							space_found = FALSE;
						}
					}
					break;
				case TAG_INPUT:
					break;
				case TAG_IOD:
					parse_iod4_tag (p_frame, start_tag);
					break;
				case TAG_KBD: /* keyboard input text style */
					set_pre_font (current, start_tag);
					break;
				case TAG_LI: /* (list item) */
					if (start_tag) {
						if (current->word != stored_word)
							stored_word->line_brk = BRK_LN;
						if (p_frame->current_list)
							parse_li_tag (p_frame);
						space_found = TRUE;
					}
					break;
				case TAG_LISTING:
					set_pre_font (current, start_tag);
					break;
				case TAG_MENU:
					parse_menu_tag (p_frame, start_tag);
					break;
				case TAG_META:
					parse_meta_tag (p_frame);
					if (force_cset) {
						p_frame->Encoding = force_cset;
					} else {
						encoder = encoder_word (p_frame->Encoding);
					}
					break;
				case TAG_OL:
					parse_ol_tag (p_frame, start_tag);
					break;
				case TAG_P: /* (paragraph) */
					parse_p_tag (p_frame, start_tag);
					space_found = TRUE;
					break;
				case TAG_PLAINTEXT:
					if (start_tag) {
						current->paragraph->eop_space = EOP(current->font_size);
						add_paragraph (current);
						/* from now on plain text, never ending */
						parse_text(symbol, p_frame);
						symbol = strchr(symbol, '\0');
					}
					break;
				case TAG_PRE:
					if (start_tag) {
						current->paragraph->eop_space = EOP(current->font_size);
						add_paragraph (current);
						current->paragraph->alignment = ALN_LEFT;
					}
					set_pre_font (current, start_tag);
					in_pre = start_tag;
					break;
				case TAG_Q:  /* quotes, in-paragraph citation  */
					parse_q_tag(&current->text, start_tag);
					break;
				case TAG_S: case TAG_STRIKE: /* (strike through text style) */
					word_set_strike (current, start_tag);
					break;
				case TAG_SAMP: /* (sample code or script) */
					set_pre_font (current, start_tag);
					break;
				case TAG_SCRIPT:
					if (start_tag) in_script = skip_script (&symbol);
					break;
				case TAG_SELECT:
					break;
				case TAG_NOSCRIPT:
					if (!start_tag && in_script) in_script = skip_script (&symbol);
					break;
				case TAG_SMALL:
					if (start_tag) {
						step_push (current, current->font_step->step -1);
					} else {
						step_pop (current);
					}
					word_set_point (current, current->font_size);
					break;
				case TAG_STRONG:
					word_set_bold (current, start_tag);
					break;
				case TAG_STYLE:
					skip_style (&symbol);
					break;
				case TAG_SUB:
					if (start_tag) {
						step_push (current, current->font_step->step -1);
						current->word->vertical_align = ALN_BELOW;
					} else {
						step_pop (current);
						current->word->vertical_align = ALN_BOTTOM;
					}
					word_set_point (current, current->font_size);
					break;
				case TAG_SUP:
					if (start_tag) {
						step_push (current, current->font_step->step -1);
						current->word->vertical_align = ALN_ABOVE;
					} else {
						step_pop (current);
						current->word->vertical_align = ALN_BOTTOM;
					}
					word_set_point (current, current->font_size);
					break;
				case TAG_TABLE:
					if (start_tag) {
						table_start (p_frame);
					} else if (p_frame->TableStack) {
						table_finish (p_frame);
					}
					break;
				case TAG_TR: /* (table row) */
					if (p_frame->TableStack) {
						table_row (p_frame, start_tag);
					}
					space_found = TRUE;
					break;
				case TAG_TD: /* (table data cell) */
					if (start_tag && p_frame->TableStack) {
						table_cell (p_frame, FALSE);
						attrib.packed = 0x300uL; /* force font setting */
					}
					space_found = TRUE;
					break;
				case TAG_TH: /* (table header cell) */
					if (start_tag && p_frame->TableStack) {
						table_cell (p_frame, TRUE);
						attrib.packed = 0x300uL; /* force font setting */
					}
					space_found = TRUE;
					break;
				case TAG_TEXTAREA:
					if (start_tag) {
						current->paragraph->eop_space = EOP(current->font_size);
						add_paragraph (current);
						current->paragraph->alignment = ALN_LEFT;
					}
					set_pre_font (current, start_tag);
					in_pre = start_tag;
					break;
				case TAG_TITLE:
					if (start_tag)
						symbol = parse_title (p_frame, symbol);
					break;
				case TAG_TT:
					set_pre_font (current, start_tag);
					break;
				case TAG_U: /* (underlined text) */
					word_set_underline (current, start_tag);
					break;
				case TAG_UL: /* (unordered list) */
					parse_ul_tag (p_frame, start_tag);
					break;
				case TAG_VAR: /* (variable tag) */
					word_set_italic (current, start_tag);
					break;
				case TAG_XMP:
					set_pre_font (current, start_tag);
					break;

				case TAG_FRAMESET: /* frame processing */
					if (start_tag) {
						symbol = parse_frameset (symbol, p_frame->Container,
						                         p_frame->Location);
						start_tag = FALSE;
						/* fall through, ignore every junk that may follow */
					} else {
						break;
					}
				case TAG_HTML:
					if (start_tag)
						break;
					symbol = strchr (symbol, '\0');
					current->paragraph->eop_space = 20;
				
				/* we don't set a 'default:' directive here because at least gcc
				 * can tell us if we have forgotten a TAG this way   */

				 case TAG_FRAME:
				 case TAG_Unknown:
				 case TAG_LastDefined: ;
			}
			attrib.packed ^= current->word->attr.packed;
			if ((attrib.packed &= 0x00000FFFuL) != 0) {
				if (TAgetFace (attrib)) {
					vst_font (vdi_handle,
					          fonts[TAgetFont  (current->word->attr)]
					               [TAgetBold  (current->word->attr)]
					               [TAgetItalic(current->word->attr)]);
				}
				vst_arbpt (vdi_handle, TA_Size (current->word->attr), &u,&u,&u,&u);
				vqt_advance (vdi_handle, Space_Code,
				             &current->word->space_width, &u, &u, &u);
				current->word->space_width++;
				vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
				current->word->word_height = distances[3];
				current->word->word_tail_drop = distances[1];
			}

			continue;
		}

		switch (*symbol)
		{
			case '&':
				if (current->text < watermark_4) {
					current->text = scan_namedchar (&symbol, current->text, TRUE);
				} else if (linetoolong == FALSE) {
					errprintf("parse_html(): Line too long in '%s'!\n",
					          p_frame->Location->File);
					linetoolong = TRUE;
				}
				space_found = FALSE;
				break;
			
			case ' ':
				if (in_pre) {
					if (current->text < watermark_4) {
						*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					} else if (linetoolong == FALSE) {
						errprintf("parse_html(): Line too long in '%s'!\n",
						          p_frame->Location->File);
						linetoolong = TRUE;
					}
					symbol++;
					break;
				}
				goto white_space;
			
			case 9:  /* HT HORIZONTAL TABULATION */
				if (in_pre) {
					if (current->text < watermark_4 -8) {
						do {
							*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
						} while (((current->text - active_word_buffer) & 7) != 0);
					} else if (linetoolong == FALSE) {
						errprintf("parse_html(): Line too long in '%s'!\n",
						          p_frame->Location->File);
						linetoolong = TRUE;
					}
					symbol++;
					break;
				}
				goto white_space;
			
			case 13: /* CR CARRIAGE RETURN */
				if (*(symbol + 1) == 10)  /* HTTP, TOS, or DOS text file */
					symbol++;
				/* else Macintosh text file */
			case 10: /* LF LINE FEED */
			case 11: /* VT VERTICAL TABULATION */
			case 12: /* FF FORM FEED */
				if (in_pre) {
					/* BUG: empty paragrahps were ignored otherwise */
					*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					add_paragraph(current);
					symbol++;
					break;
				}
				/* else fall through */
				
			white_space: /* if (!in_pre) */
				if (!space_found) {
					new_word (current, TRUE);
					*(current->text++) = Space_Code;
					space_found = TRUE;
				}
				while (isspace (*(++symbol)));
				break;
			
			default:
				if (current->text < watermark_4) {
					current->text = (*encoder)(&symbol, current->text);
				} else if (linetoolong == FALSE) {
					errprintf("parse_html(): Line too long in '%s'!\n",
					          p_frame->Location->File);
					linetoolong = TRUE;
					symbol++;
				}
				space_found = FALSE;
		}
	}

	word_store (current);
	while (p_frame->TableStack) {
		table_finish (p_frame);
	}
	content_minimum (&p_frame->Page);

	logprintf(LOG_BLUE, "%ld ms for '%s%s'\n",
	          (clock() - start_clock) * 1000 / CLK_TCK,
	          location_Path (p_frame->Location, NULL), p_frame->Location->File);

	return FALSE;
}


/* parse_text
 * this is the text parsing routine
 * for use with non formatted text files
 *
 * Nothing exciting just maps lines to paragraphs
 */

BOOL
parse_text (const char *symbol, struct frame_item *p_frame)
{
	time_t start_clock = clock();
	
	TEXTBUFF current  = &p_frame->current;
	ENCODER_W encoder = encoder_word (p_frame->Encoding &= 0x7F);
	PARAGRPH previous = NULL;
	WORD     linefeed;
	UWORD active_word_buffer[500];  /* 500 is enough for 124 UTF-8 characters
	                                 * parsed as single byte characters. */
	UWORD * watermark_1 = active_word_buffer + sizeof(active_word_buffer)
	                    - sizeof(*active_word_buffer);
	UWORD * watermark_4 = watermark_1 - sizeof(*active_word_buffer) *4;
	WORD u, distances[5], effects[3];
	BOOL linetoolong = FALSE;  /* "line too long" error printed? */

	if (symbol == NULL) return FALSE;

	current->text = current->buffer = active_word_buffer;
	
	word_set_font (current, pre_font);
	
	vst_font (vdi_handle, fonts[0][0][0]);
	vst_arbpt (vdi_handle, current->font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &current->word->space_width, &u,&u,&u);
	current->word->space_width++;
	
	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	current->word->word_height    = distances[3];
	current->word->word_tail_drop = distances[1];
	
	linefeed = current->word->word_height + current->word->word_tail_drop;

	while (*symbol != '\0')
	{
		switch (*symbol)
		{
			case 9: /* HT HORIZONTAL TABULATION */
				if (current->text < watermark_4) {
					size_t pos = (current->text - active_word_buffer) /2;
					UWORD  num = 4 - ((UWORD)pos & 0x0003);
					while (num--) {
						*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					}
				} else if (!linetoolong) {
					errprintf ("parse_text(): Line too long in '%s'!\n",
					           p_frame->Location->File);
					linetoolong = TRUE;
				}
				symbol++;
				break;
			
			case 13: /* CR CARRIAGE RETURN */
				if (*(symbol +1) == 10)  /* HTTP, TOS, or DOS text file */
					symbol++;
				/* else Macintosh text file */
			case 10: /* LF LINE FEED */
			case 11: /* VT VERTICAL TABULATION */
			case 12: /* FF FORM FEED */
				if (current->text > active_word_buffer) {
					current->word->line_brk = BRK_LN;
					new_word (current, TRUE);
					previous = NULL;
				} else if (!previous) {
					*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					previous = current->paragraph;
					add_paragraph(current);
				} else {
					previous->eop_space += linefeed;
				}
				symbol++;
				break;
			
			default: {
				if (*symbol <= 32 || *symbol == 127) {
					if (current->text < watermark_1) {
						*(current->text++) = 560;  /* U+2007 FIGURE SPACE */
					} else if (!linetoolong) {
						errprintf ("parse_text(): Line too long in '%s'!\n",
						           p_frame->Location->File);
						linetoolong = TRUE;
					}
					symbol++;
				
				} else {
					if (current->text < watermark_4) {
						current->text = (*encoder)(&symbol, current->text);
					} else if (!linetoolong) {
						errprintf ("parse_text(): Line too long in '%s'!\n",
						           p_frame->Location->File);
						linetoolong = TRUE;
						symbol++;
					}
				}
			}
		}
	}
	if (current->text > active_word_buffer || !previous) {
		word_store (current);
	} else {
		previous->next_paragraph = NULL;
		destroy_paragraph_structure (current->paragraph);
	}
	content_minimum (&p_frame->Page);

	logprintf (LOG_BLUE, "%ld ms for '%s%s'\n",
	           (clock() - start_clock) * 1000 / CLK_TCK,
	          location_Path (p_frame->Location, NULL), p_frame->Location->File);

	return FALSE;
}
