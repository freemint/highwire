#include <stdlib.h>
#include <string.h> /* memcpy */
#include <time.h>
#include <gemx.h>

#include "global.h"
#include "Location.h"
#include "Containr.h"
#include "schedule.h"

#ifdef LIBGIF
#	include <gif_lib.h>
#	undef TRUE
#	undef FALSE
	static BOOL read_gif (IMAGE);
#else
#	define read_gif( i )   0
#endif

#ifdef LIBPNG
#	include <png.h>
	static BOOL read_png (IMAGE);
#else
#	define read_png( i )   0
#endif

#ifdef LIBJPG
#	include <jpeglib.h>
	static BOOL read_jpg (IMAGE);
#else
#	define read_jpg( i )   0
#endif


static short pixel_val[256];


typedef struct {
	short * PixIdx;
	long  * Palette;
	short * DthBuf;
	short   Width;
	UWORD   PixMask;
	size_t  PgSize;
	size_t  LnSize;
	size_t  IncXfx;
	size_t  IncYfx;
} RASTERINFO;

typedef void (RASTERFUNC)(UWORD *, RASTERINFO *, char *);
typedef       RASTERFUNC * RASTERIZER;
static RASTERIZER raster_color = NULL;
static BOOL       stnd_bitmap  = FALSE;
/*static BOOL       falcon_ovlay = FALSE;*/


/*============================================================================*/
IMAGE
new_image (CONTAINR cont, short w, short h, const char * file, LOCATION base)
{
	FRAME frame = cont->u.Frame; /*containr_Frame (cont);*/
	IMAGE img   = malloc (sizeof(struct s_image));
	
	img->source = new_location (file, base);
	
	if (!frame) {
		containr_notify (cont, HW_PageStarted, img->source->FullName);
		frame = new_frame (base);
		frame->item = frame->current.paragraph;
		*(frame->current.text++) = '.' -32;
	}
	
	img->set_w = (w > 0 ? w : ((long)w *1024 -50) /100);
	img->set_h = (h > 0 ? h : ((long)h *1024 -50) /100);
	if (w < 0 && h < 0) {
		img->set_h = (-(long)img->set_h * 1024 - (img->set_w -1) /2) / img->set_w;
	}
	img->disp_w = (w > 0 ? w : 16);
	img->disp_h = (h > 0 ? h : 16);
	
	img->fd_addr    = NULL;
	img->fd_w       = img->disp_w;
	img->fd_h       = 0;
	img->fd_wdwidth = (img->fd_w + 15) / 16;
	img->fd_stand   = FALSE;
	img->fd_nplanes = 1;
	img->fd_r1 = img->fd_r2 = img->fd_r3 = 0;
	
	img->container = cont;
	img->paragraph = frame->current.paragraph;
	img->word      = frame->current.word;
	img->backgnd   = frame->current.backgnd;
	img->alt_w     = 0;
	img->alt_h     = 0;
	img->fgnd      = G_BLACK;
	img->bgnd      = G_WHITE;
	img->offset.Origin = img->paragraph->Offset.Origin;
	
	if (!raster_color) {
		static RASTERFUNC raster_stnd, raster_D1, raster_D2, raster_I4, raster_I8,
		                  raster_16, raster_24, raster_32;
		short out[273] = { -1, }; out[14] = 0;
		vq_scrninfo (vdi_handle, out);
		memcpy (pixel_val, out + 16, 512);
		
		if (planes == 1) {                        /* monochrome */
			raster_color = raster_D1;
		
		} else if (out[0] == 0) switch (planes) { /* interleaved words */
			case 2: raster_color = raster_D2; break;
			case 4: raster_color = raster_I4; break;
			case 8: raster_color = raster_I8; break;
		
		} else if (out[0] == 2) switch (planes) { /* packed pixels */
			case 16: raster_color = raster_16; break;
			case 24: raster_color = raster_24; break;
			case 32: raster_color = raster_32; break;
		}
		if (!raster_color) {                     /* standard format */
			raster_color = raster_stnd;
			stnd_bitmap  = TRUE;
		}
	}
	
	frame->current.word->image          = img;
	frame->current.word->word_width     = img->disp_w;
	frame->current.word->word_height    = img->disp_h;
	frame->current.word->word_tail_drop = 0;
	
	if (!cont->u.Frame) {
		word_store (&frame->current);
		frame->page_minimum = content_minimum (frame->item) + 5;
		containr_setup  (cont, frame, NULL);
		containr_notify (cont, HW_PageFinished, &cont->Area);
		file = img->source->FullName;
	}
	if (file && *file) {
		static BOOL image_job (void *);
		sched_insert (image_job, img);
	}
	
	return img;
}

/*----------------------------------------------------------------------------*/
static BOOL
image_job (void * arg)
{
	IMAGE img   = arg;
	GRECT rec   = img->container->Area, * clip = &rec;
	FRAME frame = img->container->u.Frame; /*containr_Frame (cont);*/
	short old_w = img->set_w;
	short old_h = img->set_h;
	
	containr_notify (img->container, 10, img->source->FullName);
	
	if (read_gif (img) || read_png (img) || read_jpg (img)) {
		int calc_xy = 0;
		
		img->fd_w = img->disp_w;
		img->fd_h = img->disp_h;
		
		if (img->fd_stand) {
			MFDB mfdb = *(MFDB*)img;
			img->fd_addr = malloc (2uL * img->fd_wdwidth * img->fd_h
			                       * img->fd_nplanes);
/*			printf ("mfdb: %i (%i) * %i * %i \n",
			        img->fd_w, img->fd_wdwidth, img->fd_h, img->fd_nplanes);
*/
			vr_trnfm (vdi_handle, &mfdb, (MFDB*)img);
			free (mfdb.fd_addr);
		}
		
		if (img->disp_w != old_w || img->disp_h != old_h) {
			PARAGRPH par = img->paragraph;
			long par_x = par->Offset.X;
			long par_y = par->Offset.Y;
			long par_w = par->Width;
			long par_h = par->Height;
			img->word->word_width  = img->disp_w;
			img->word->word_height = img->disp_h;
			if (par->min_width < img->disp_w) {
				 par->min_width = img->disp_w;
				 par->max_width = 0;
			}
			frame->page_minimum = content_minimum (par) + 5;
			containr_calculate (img->container, NULL);
			if (par_w == par->Width && par_h == par->Height) {
				calc_xy = 1;
				rec.g_w = par_w;
				rec.g_h = par_h;
			} else if (par_x == par->Offset.X && par_y == par->Offset.Y) {
				calc_xy = -1;
			}
		} else {
			calc_xy = 1;
			rec.g_w = img->disp_w;
			rec.g_h = img->disp_h;
		}
		if (calc_xy) {
			OFFSET * origin = img->offset.Origin;
			short x = img->offset.X + frame->clip.x - frame->h_bar.scroll;
			short y = img->offset.Y + frame->clip.y - frame->v_bar.scroll;
			while (origin) {
				x += origin->X;
				y += origin->Y;
				origin  =  origin->Origin;
			}
			if (calc_xy > 0) {
				rec.g_x = x;
			}
			rec.g_y = y;
		}
	
	} else {
		clip = NULL;
	}
	containr_notify (img->container, 11, clip);
	
	return FALSE;
}


/*============================================================================*/
static RASTERIZER
setup (IMAGE img, short depth, short img_w, short img_h, RASTERINFO * info)
{
	static RASTERFUNC raster_mono;
	size_t pg_size;
	
	if (depth > 1) {
		img->fd_stand   = stnd_bitmap;
		img->fd_nplanes = planes;
	}
	img->fd_wdwidth = (img->disp_w + 15) / 16;
	pg_size         = (size_t)img->fd_wdwidth * img->disp_h;
	img->fd_addr    = malloc (pg_size *2 * img->fd_nplanes);
	
	if (info) {
		info->Width   = img->disp_w;
		info->PixMask = (1 << depth) -1;
		info->PgSize  = pg_size;
		info->LnSize  = img->fd_wdwidth;
		if (!img->fd_stand) {
			info->LnSize *= img->fd_nplanes;
		}
		if (planes <= 2 && depth > 1) {
			info->DthBuf = malloc ((img->disp_w +1) *2);
			memset (info->DthBuf, 0, (img->disp_w *2));
		}
		
		/* calculate scaling steps (32bit fix point)
		 */
		if (img_w != img->disp_w) {
			info->IncXfx = (((size_t)img_w <<16) + (img->disp_w /2)) / img->disp_w;
		} else {
			info->IncXfx = 0x10000L;  /* 1.00 */
		}
		if (img_h != img->disp_h) {
			info->IncYfx = (((size_t)img_h <<16) + (img->disp_h /2)) / img->disp_h;
		} else {
			info->IncYfx = 0x10000L;  /* 1.00 */
		}
/*		printf ("scale:%lX.%04lX %lX.%04lX \n",
		        info->IncXfx>>16, info->IncXfx&0xFFFF,
		        info->IncYfx>>16, info->IncYfx&0xFFFF);
*/
	}
	return (depth > 1 ? raster_color : raster_mono);
}


/*******************************************************************************
 *
 *   Line Raster Functions
 */

/*------------------------------------------------------------------------------
 * monochrome format
 */
static void
raster_mono (UWORD * dst, RASTERINFO * info, char * src)
{
#if defined(__GNUC__)
	__asm__ volatile ("
		subq.w	#1, %2 | width
		move.l	%3, d0 | scale -> index
		addq.l	#1, d0
		lsr.l		#1, d0
		0:	clr.w 	d1          | chunk
			move.w	#0x8000, d2 | pixel
		1:	swap		d0
			btst		#0, (d0.w,%1) | (src[index>>16] & 1)
			beq.b		2f
			or.w		d2, d1        | chunk |= pixel
		2:	swap		d0
			add.l		%3, d0        | index += info->IncXfx
			lsr.w		#1, d2
			dbeq		%2, 1b
		move.w	d1, (%0)+
		subq.w	#1, %2
		bpl.b		0b
		"
		:                                                      /* output */
		: "a"(dst),"a"(src),"d"(info->Width),"d"(info->IncXfx) /* input  */
		/*    %0       %1       %2               %3     */
		: "d0","d1","d2"                                    /* clobbered */
	);
	
#elif defined(__PUREC__)
	extern void pc_raster_mono (void *, void *, short, size_t);
	pc_raster_mono (dst, src, info->Width, info->IncXfx);
	
#else
	short  width = info->Width;
	size_t x     = (info->IncXfx +1) /2;
	UWORD  pixel = 0x8000;
	UWORD  chunk = 0;
	do {
		if (src[x >>16] & 1) chunk |= pixel;
		
		if (!--width || !(pixel >>= 1)) {
			*(dst++) = chunk;
			chunk    = 0;
			pixel    = 0x8000;
		}
		x += info->IncXfx;
	
	} while (width);
#endif
}

/*------------------------------------------------------------------------------
 * device independend, for unrecognized screen format.
 */
static void
raster_stnd (UWORD * dst, RASTERINFO * info, char * src)
{
	short * map   = info->PixIdx;
	UWORD   mask  = info->PixMask;
	short   width = info->Width;
	size_t  x     = (info->IncXfx +1) /2;
	UWORD   pixel = 0x8000;
	do {
		short   color = map[(UWORD)src[x >>16] & mask];
		UWORD * chunk = dst;
		short   i     = planes;
		do {
			if (color & 1) *chunk |=  pixel;
			else           *chunk &= ~pixel;
			chunk +=  info->PgSize;
			color >>= 1;
		} while (--i);
		
		if (!(pixel >>= 1)) {
			pixel = 0x8000;
			dst++;
		}
		x += info->IncXfx;
	
	} while (--width);
}

/*------------------------------------------------------------------------------
 * 1 plane, uses a simple intensity dither.
 */
static void
raster_D1 (UWORD * dst, RASTERINFO * info, char * src)
{
	short * buf   = info->DthBuf;
	long  * pal   = info->Palette;
	short   ins   = *buf;
	UWORD   mask  = info->PixMask;
	short   width = info->Width;
	size_t  x     = (info->IncXfx +1) /2;
	UWORD   pixel = 0x8000;
	UWORD   chunk = 0;
	*buf = 0;
	do {
		char * rgb = (char*)&pal[(short)src[x >>16] & mask];
		short  err;
		ins += (short)rgb[0] *5 + (short)rgb[1] *9 + (short)rgb[2] *2;
		
		if (ins < 2040) {
			chunk |= pixel;
			if ((err = ins) < 0) {
	/*			err =0;//>>= 1;*/
			}
		} else {
			if ((err = ins - 4080) > 0) {
	/*			err =0;//>>= 1;*/
			}
		}
		ins = buf[1];
		
	/*	if ((err >>= 2) != 0) {*/
	/*		buf[1] =  err;*/     /* 2/8 to next RGB of next line */
		if ((err >>= 1) != 0) {
			buf[1] =  0;     /* 2/8 to next RGB of next line */
	/*		err    += err >>1;*/
			buf[0] += err;     /* 3/8 to this RGB of next line */
			ins    += err;     /* 3/8 to next RGB of this line */
		} else {
			buf[1] = 0;
		}
		buf++;
		
		if (!--width || !(pixel >>= 1)) {
			*(dst++) = chunk;
			chunk    = 0;
			pixel    = 0x8000;
		}
		x += info->IncXfx;
		
	} while (width);
}

/*------------------------------------------------------------------------------
 * 2 planes interleaved words format, uses a simple intensity dither.
 */
static void
raster_D2 (UWORD * dst, RASTERINFO * info, char * src)
{
	short * buf   = info->DthBuf;
	long  * pal   = info->Palette;
	short   ins   = *buf;
	UWORD   mask  = info->PixMask;
	short   width = info->Width;
	size_t  x     = (info->IncXfx +1) /2;
	UWORD   pixel = 0x8000;
	UWORD   chunk = 0;
	*buf = 0;
	do {
		char * rgb = (char*)&pal[(short)src[x >>16] & mask];
		short  err;
		ins += (short)rgb[0] *5 + (short)rgb[1] *9 + (short)rgb[2] *2;
		
		if (ins < 2040) {
			chunk |= pixel;
			if ((err = ins) < 0) {
	/*			err =0;//>>= 1;*/
			}
		} else {
			if ((err = ins - 4080) > 0) {
	/*			err =0;//>>= 1;*/
			}
		}
		ins = buf[1];
		
	/*	if ((err >>= 2) != 0) {*/
	/*		buf[1] =  err;*/     /* 2/8 to next RGB of next line */
		if ((err >>= 1) != 0) {
			buf[1] =  0;     /* 2/8 to next RGB of next line */
	/*		err    += err >>1;*/
			buf[0] += err;     /* 3/8 to this RGB of next line */
			ins    += err;     /* 3/8 to next RGB of this line */
		} else {
			buf[1] = 0;
		}
		buf++;
		
		if (!--width || !(pixel >>= 1)) {
			*(dst++) = chunk;
			*(dst++) = chunk;
			chunk    = 0;
			pixel    = 0x8000;
		}
		x += info->IncXfx;
		
	} while (width);
}

/*------------------------------------------------------------------------------
 * 4 planes interleaved words format
 */
static void
raster_I4 (UWORD * dst, RASTERINFO * info, char * src)
{
	short * map   = info->PixIdx;
	UWORD   mask  = info->PixMask;
	short   width = info->Width;
	size_t  x     = (info->IncXfx +1) /2;
	UWORD   pixel = 0x8000;
	do {
		short   color = map[(short)src[x >>16] & mask];
		UWORD * chunk = dst;
		short   i     = 4;
		do {
			if (color & 1) *chunk |=  pixel;
			else           *chunk &= ~pixel;
			chunk++;
			color >>= 1;
		} while (--i);
		
		if (!(pixel >>= 1)) {
			pixel = 0x8000;
			dst += 4;
		}
		x += info->IncXfx;
		
	} while (--width);
}

/*------------------------------------------------------------------------------
 * 8 planes interleaved words format
 */
static void
raster_I8 (UWORD * dst, RASTERINFO * info, char * src)
{
	short * map   = info->PixIdx;
	UWORD   mask  = info->PixMask;
	short   width = info->Width;
	size_t  x     = (info->IncXfx +1) /2;
	UWORD   pixel = 0x8000;
	do {
		short   color = map[(short)src[x >>16] & mask];
		UWORD * chunk = dst;
		short   i     = 8;
		do {
			if (color & 1) *chunk |=  pixel;
			else           *chunk &= ~pixel;
			chunk++;
			color >>= 1;
		} while (--i);
		
		if (!(pixel >>= 1)) {
			pixel = 0x8000;
			dst += 8;
		}
		x += info->IncXfx;
		 
	} while (--width);
}

/*------------------------------------------------------------------------------
 * 16 planes packed pixels formart, the pixel index array must contain 16bit RGB
 * values.
 */
static void
raster_16 (UWORD * dst, RASTERINFO * info, char * src)
{
	short * pix   = info->PixIdx;
	UWORD   mask  = info->PixMask;
	size_t  x     = (info->IncXfx +1) /2;
	short   width = info->Width;
	do {
		*(dst++) = pix[(short)src[x >>16] & mask];
		x += info->IncXfx;
	} while (--width);
}

/*------------------------------------------------------------------------------
 * 24 planes packed pixels formart.
 */
static void
raster_24 (UWORD * _dst, RASTERINFO * info, char * src)
{
	char * dst   = (char*)_dst;
	long * pal   = info->Palette;
	UWORD  mask  = info->PixMask;
	size_t x     = (info->IncXfx +1) /2;
	short  width = info->Width;
	do {
		char * rgb = (char*)pal[(short)src[x >>16] & mask];
		*(dst++) = *(rgb++);
		*(dst++) = *(rgb++);
		*(dst++) = *(rgb);
		x += info->IncXfx;
	} while (--width);
}

/*------------------------------------------------------------------------------
 * 32 planes packed pixels formart.
 */
static void
raster_32 (UWORD * _dst, RASTERINFO * info, char * src)
{
	long * dst = (long*)_dst;
	long * pal = info->Palette;
	UWORD  mask  = info->PixMask;
	size_t x     = (info->IncXfx +1) /2;
	short  width = info->Width;
	do {
		*(dst++) = pal[(short)src[x >>16] & mask] >>8;
		x += info->IncXfx;
	} while (--width);
}


/*******************************************************************************
 *
 *   Image Decoders
 */

/*============================================================================*/
#ifdef LIBGIF
static BOOL
read_gif (IMAGE img)
{
	RASTERINFO info      = { NULL, NULL, NULL, };
	BOOL       ok        = FALSE;
	short      interlace = 0;
	short      transpar  = -1;
	short      img_w     = img->disp_w;
	short      img_h     = img->disp_h;
	ColorMapObject * map = NULL;
	GifFileType    * gif = DGifOpenFileName (img->source->FullName);
	if (gif) {
		GifRecordType    rec;
		do {
			if (DGifGetRecordType (gif, &rec) == GIF_ERROR) {
				printf ("DGifGetRecordType() ");
				PrintGifError();
				break;
			
			} else if (rec == IMAGE_DESC_RECORD_TYPE) {
				if (DGifGetImageDesc(gif) == GIF_ERROR) {
					printf ("DGifGetImageDesc() ");
					PrintGifError();
					break;
				
				} else {
					GifImageDesc * dsc = &gif->Image;
					map = (dsc->ColorMap ? dsc->ColorMap : gif->SColorMap);
					img_w = dsc->Width;
					img_h = dsc->Height;
					if (dsc->Interlace) {
						interlace = 8;
					}
				}
				break;
			
			} else if (rec == EXTENSION_RECORD_TYPE) {
				int           code;
				GifByteType * block;
				if (DGifGetExtension (gif, &code, &block) == GIF_ERROR) {
					printf ("DGifGetExtension() ");
					PrintGifError();
					break;
				
				} else while (block != NULL) {
					if (code == 0xF9 && (block[1] & 1)) {
						transpar = (short)block[4];
					}
					if (DGifGetExtensionNext (gif, &block) == GIF_ERROR) {
						printf ("DGifGetExtensionNext() ");
						PrintGifError();
						break;
					}
				}
			
			} else {
				printf ("other: %i \n", rec);
				break;
			}
		} while (rec != TERMINATE_RECORD_TYPE);
	}
	
	if (map) {
		info.Palette = (long*)map->Colors;
		
		if (gif->SColorMap->BitsPerPixel == 1) {
			img->bgnd = (transpar == 0 ? img->backgnd
			                           : remap_color (info.Palette[0] >>8));
			img->fgnd = (transpar == 1 ? img->backgnd
			                           : remap_color (info.Palette[1] >>8));
		
		} else if (planes > 2 && planes < 24) {
			short          n   = map->ColorCount;
			short        * dst = malloc (sizeof(short) * n);
			GifColorType * src = map->Colors;
			info.PixIdx = dst;
			
			if (planes == 16) {
				do {
					*(dst++) = (((short)src->Red   & 0xF8) <<8)
					         | (((short)src->Green & 0xFC) <<3)
					         | (src->Blue >> 3);
					src++;
				} while (--n);
			
			} else {
				do {
					if (!transpar--) {
						*(dst++) = pixel_val[img->backgnd];
					} else {
						long rgb = ((((long)src->Red <<8) | src->Green) <<8)
						         | src->Blue;
						*(dst++) = pixel_val[remap_color (rgb) & 0xFF];
					}
					src++;
				} while (--n);
			}
		}
		ok = TRUE;
	}
	
	if (img->set_w < 0) {
		img->disp_w = (img->paragraph->Width * -img->set_w + 512) / 1024;
	} else if (!img->set_w) {
		img->disp_w = img_w;
	}
	if (img->set_h < 0) {
		long h;
		if (img->set_w < 0) {
			long s = ((long)img->disp_w * 1024 + (img_w +1) /2) / img_w;
			h = ((long)img_h * s + 512) / 1024;
		} else {
			h = img_h;
		}
		img->disp_h = (h * -img->set_h + 512) / 1024;
		
	} else if (!img->set_h) {
		img->disp_h = img_h;
	}
	
	if (ok) {
		RASTERIZER raster = setup (img, map->BitsPerPixel, img_w, img_h, &info);
		char     * buf   = malloc (img_w);
		UWORD    * dst   = img->fd_addr;
		short      y     = 0;
		
		if (!interlace) {
			size_t scale = 0;
			while (y < img_h) {
				DGifGetLine (gif, buf, img_w);
				y++;
				while ((scale >>16) < y) {
					(*raster) (dst, &info, buf);
					dst   += info.LnSize;
					scale += info.IncYfx;
				}
			}
		
		} else {
			BOOL   first = TRUE;
			size_t y_mul = (((size_t)img->disp_h <<16) + (img_h /2)) / img_h;
			do {
				while (y < img_h) {
					size_t scale = (size_t)y * y_mul + (info.IncYfx +1) /2;
					short  y_beg =  scale          >>16;
					short  y_end = (scale + y_mul) >>16;
					DGifGetLine (gif, buf, img_w);
					y += interlace;
					if (y_beg < y_end) {
						dst = (UWORD*)img->fd_addr + info.LnSize * y_beg;
						do {
							(*raster) (dst, &info, buf);
							dst   += info.LnSize;
						} while (++y_beg < y_end);
					}
				}
				if (first) {
					first = FALSE;
				} else {
					interlace /= 2;
				}
				y = interlace /2;
			} while (interlace > 1);
		}
		free (buf);
		if (info.PixIdx) free (info.PixIdx);
		if (info.DthBuf) free (info.DthBuf);
	}
	if (gif) DGifCloseFile (gif);

	return ok;
}
#endif /* LIBGIF */
