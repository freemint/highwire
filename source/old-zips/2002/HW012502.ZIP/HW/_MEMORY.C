#include <stdlib.h>
#include <stdio.h>


static int __mem_once = 0;
static int __mem_cnt  = 0;
static int __mem_max  = 0;

static void * __mem[20000];
static int    __rng = 0;


static void _mem_exit (void)
{
	printf ("memory = %i / %i \n", __mem_cnt, __mem_max);
}


void * malloc (size_t size)
{
	void * mem;
	
	if (!__mem_once) {
		__mem_once = 1;
		atexit (_mem_exit);
	}
	
	if ((mem = __malloc (size))) {
		int n = __rng++;
		while (n  &&  __mem[n-1] > mem) {
			__mem[n] = __mem[n-1];
			n--;
		}
		__mem[n] = mem;
		__mem_cnt++;
		__mem_max++;
	}
	return mem;
}

void free (void * mem)
{
	int n;
	
	if (!__mem_once) {
		__mem_once = 1;
		atexit (_mem_exit);
	}
	
	for (n = 0; n < __rng; n++) {
		if (__mem[n] == mem) {
			__free (mem);
			__rng--;
			__mem_cnt--;
			mem = NULL;
			break;
		} else if (__mem[n] > mem) break;
	}
	if (mem) {
		printf ("memory: %p not in list! \n", mem);
//		abort();
	} else while (n <= __rng) {
		__mem[n] = __mem[n+1];
		n++;
	}
}
