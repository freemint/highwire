/* @(#)highwire/keyinput.c
 *
 * This file should contain the keyboard handler
 * routines.  ie. Input to forms, URL address etc
 *
 * baldrick July 10, 2001
 */

#include <ctype.h>
#include <stdlib.h>

/*#include <gem.h>*/

#include "global.h"
#include "Loader.h"
#include "Containr.h"
#include "Location.h"
#include "Logging.h"

static FRAME
frame_next (FRAME frame)
{
	CONTAINR cont = (frame ? frame->Container : NULL);
	BOOL     b    = FALSE;

	while (cont) {
		if (b) {
			if (cont->Mode == CNT_FRAME) {
				if (cont->u.Frame) {
					return cont->u.Frame;
				}
			} else if (cont->Mode) {
				cont = cont->u.Child;
				continue;
			}
		}
		if (cont->Sibling) {
			cont = cont->Sibling;
			b    = TRUE;
			continue;
		}
		cont = cont->Parent;
		b    = FALSE;
	}
	/* After the last frame start from the first. */
	cont = containr_Base(frame);
	while (cont) {
		if (cont->Mode == CNT_FRAME) {
			if (cont->u.Frame) {
				return cont->u.Frame;
			}
		} else if (cont->Mode) {
			cont = cont->u.Child;
		}
	}
	/* If nothing found return the same frame. */
	return frame;
}

void
key_pressed (WORD key, WORD state)
{
	extern char prev_location[HW_PATH_MAX];
	extern ENCODING prev_encoding;

	switch (key & 0xFF00)  /* scan code */
	{
	case 0x0F00:  /* Tab: change active_keyboard_frame */
		active_keyboard_frame = frame_next(active_keyboard_frame);
		key = 0;  /* this key has character HT */
		break;
	case 0x3F00:  /* F5 (Internet Explorer), CTRL+R: reload */
		new_loader_job(NULL, active_keyboard_frame->Location,
		               active_keyboard_frame->Location->encoding, active_keyboard_frame->Container);
		break;
	case 0x4100:  /* F7: toggle logging */
		logging_is_on = !logging_is_on;
		break;
	case 0x4200:  /* F8: toggle pictures or alternative text */
		alternative_text_is_on = !alternative_text_is_on;
		break;
	case 0x4700:  /* home */
		if (!(state & 3)) {
			wind_scroll(window_handle, active_keyboard_frame->Container, -active_keyboard_frame->page_width, -active_keyboard_frame->page_height);
			break;
		}
		/* else fall through */
	case 0x4F00:  /* end */
		wind_scroll(window_handle, active_keyboard_frame->Container, -active_keyboard_frame->page_width, active_keyboard_frame->page_height);
		break;
	case 0x4800:  /* /|\ */
		if (!(state & 3)) {
			wind_scroll(window_handle, active_keyboard_frame->Container, 0, -scroll_step);
			break;
		}
		/* else fall through */
	case 0x4900:  /* page up */
		wind_scroll(window_handle, active_keyboard_frame->Container, 0, -active_keyboard_frame->clip.h);
		break;
	case 0x4B00:  /* <- */
		wind_scroll(window_handle, active_keyboard_frame->Container, -scroll_step, 0);
		break;
	case 0x4D00:  /* -> */
		wind_scroll(window_handle, active_keyboard_frame->Container, scroll_step, 0);
		break;
	case 0x5000:  /* \|/ */
		key = 0;  /* this key has character '2' */
		if (!(state & 3)) {
			wind_scroll(window_handle, active_keyboard_frame->Container, 0, scroll_step);
			break;
		}
		/* else fall through */
	case 0x5100:  /* page down */
		wind_scroll(window_handle, active_keyboard_frame->Container, 0, active_keyboard_frame->clip.h);
		break;
	case 0x6100:  /* Undo */
		new_loader_job (prev_location, active_keyboard_frame->Location,
		                prev_encoding, active_keyboard_frame->Container);
		break;
	case 0x3B00:  /* F1 (defined in DIN 2137-6, Nr 6.2.4 (ISO/IEC 9995-6?)) */
	case 0x6200:  /* Help */
		new_loader_job(help_file, NULL, ENCODING_WINDOWS1252, active_keyboard_frame->Container);
		break;
	}

	switch (toupper(key & 0xFF))  /* character */
	{
	case '+':  /* +: increase font size and reload */
		if (font_size < 18)
			font_size++;
		else
			font_size += 3;
		logprintf(LOG_BLACK, "+font_size %d\n", (int)font_size);
		new_loader_job(NULL, active_keyboard_frame->Location,
		               active_keyboard_frame->Location->encoding, active_keyboard_frame->Container);
		break;
	case '-':  /* -: decrease font size and reload */
		if (font_size > 2) {
			if (font_size < 20)
				font_size--;
			else
				font_size -= 3;
			logprintf(LOG_BLACK, "-font_size %d\n", (int)font_size);
			new_loader_job(NULL, active_keyboard_frame->Location,
			               active_keyboard_frame->Location->encoding, active_keyboard_frame->Container);
		}
		break;
	case '1':  /* 1: reload with default encoding windows-1252 */
		new_loader_job(NULL, active_keyboard_frame->Location,
		               ENCODING_WINDOWS1252, active_keyboard_frame->Container);
		break;
	case '2':  /* 2: reload with default encoding ISO-8859-1 */
		new_loader_job(NULL, active_keyboard_frame->Location,
		               ENCODING_ISO8859_2, active_keyboard_frame->Container);
		break;
	case 'A':  /* A: reload with default encoding ISO-8859-2 */
		new_loader_job(NULL, active_keyboard_frame->Location,
		               ENCODING_ATARIST, active_keyboard_frame->Container);
		break;
	case 'U':  /* U: reload with default encoding UTF-8 */
		new_loader_job(NULL, active_keyboard_frame->Location,
		               ENCODING_UTF8, active_keyboard_frame->Container);
		break;
	case 0x0012:  /* CTRL+R, F5 (Internet Explorer): reload */
		new_loader_job(NULL, active_keyboard_frame->Location,
		               active_keyboard_frame->Location->encoding, active_keyboard_frame->Container);
		break;

#ifdef GEM_MENU
	/* change 12-22-01 mj. */
	case 0x0009:  handle_menu(M_ABOUT, NULL); break;
	case 0x000F:  handle_menu(M_OPEN, NULL); break;
	case 0x0011:  handle_menu(M_QUIT, NULL); break;
#else
	case 0x0009:  /* CTRL+I */
		do_info_dialog();
		break;
	case 0x000F:  /* CTRL+O */
		page_load();
		break;
	case 0x0011:  /* CTRL+Q */
		exit(EXIT_SUCCESS);
		break;
#endif
	}
}
