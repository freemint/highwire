/* @(#)highwire/Mouse_R.c
 */
#include <stdlib.h>
#include <string.h>

#include <gemx.h>

#include "global.h"
#include "Containr.h"
#include "Loader.h"


/*
 * handles mouse interaction with a frame
 */
void
button_clicked (WORD button, WORD mx, WORD my)
{
	CONTAINR cont = containr_byCoord (NULL, mx, my);
	FRAME    frame;
	
	if (!cont || (frame = containr_Frame (cont)) == NULL) {
		return;
	}
	
	mx -= frame->clip.x;
	my -= frame->clip.y;

	/* make certain it's inside our frame should have
	 * been done above - baldrick
	 */
	if (mx > frame->clip.w && my > frame->clip.h)
	{
		return;
	}

	if (button == 1) /* left mouse button */
	{
		/* *************** Vertical scroll ************** */

		if (frame->v_bar.on && mx > frame->clip.w)
		{
			long max_scroll = frame->Page.Height - frame->clip.h;
			long step       = 0;
		
			if (my < frame->v_bar.pos)
			{
				/* scroll up */
			
				if (frame->v_bar.scroll > 0)
				{
					step = -(my <= frame->v_bar.lu
					         ? scroll_step : frame->clip.h - scroll_step);
				}
			}
			else if (my >= frame->v_bar.pos + frame->v_bar.size)
			{
				/* scroll down */
				
				if (frame->v_bar.scroll < max_scroll)
				{
					step = (my >= frame->v_bar.rd
					        ? scroll_step : frame->clip.h - scroll_step);
				}
			}
			else   /*slider */
			{
				short s_x  = frame->clip.x + frame->clip.w;
				short s_y  = frame->clip.y + frame->v_bar.pos;
				short size = frame->v_bar.rd - frame->v_bar.lu +1;
				graf_dragbox (scroll_bar_width, frame->v_bar.size,
			              s_x, s_y,
			              s_x, frame->clip.y + frame->v_bar.lu,
			              scroll_bar_width, size,
			              &s_x, &s_y);
				s_y  -= frame->clip.y + frame->v_bar.lu;
				size -= frame->v_bar.size;
				step  = (max_scroll * s_y + (size /2)) / size
				      - frame->v_bar.scroll;
			}
		
			if (step)
				wind_scroll (window_handle, frame->Container, 0, step);
		}
	
		/* ******** Horizontal Scroll *********** */
	
		else if (frame->h_bar.on && my > frame->clip.h)
		{
			long max_scroll = frame->Page.Width - frame->clip.w;
			long step       = 0;
		
			if (mx < frame->h_bar.pos)
			{
				/* scroll left */
			
				if (frame->h_bar.scroll > 0)
				{
					step = -(mx <= frame->h_bar.lu
				         ? scroll_step : frame->clip.w - scroll_step);
				}
			}
			else if (mx >= frame->h_bar.pos + frame->h_bar.size)
			{
				/* scroll right */
				
				if (frame->h_bar.scroll < max_scroll)
				{
					step = (mx >= frame->h_bar.rd
					        ? scroll_step : frame->clip.w - scroll_step);
				}
			}
			else   /*slider */
			{
				short s_x  = frame->clip.x + frame->h_bar.pos;
				short s_y  = frame->clip.y + frame->clip.h;
				short size = frame->h_bar.rd - frame->h_bar.lu +1;
				graf_dragbox (frame->h_bar.size, scroll_bar_width,
			              s_x, s_y,
			              frame->clip.x + frame->h_bar.lu, s_y,
			              size, scroll_bar_width,
			              &s_x, &s_y);
				s_x  -= frame->clip.x + frame->h_bar.lu;
				size -= frame->h_bar.size;
				step  = (max_scroll * s_x + (size /2)) / size
			      - frame->h_bar.scroll;
			}
		
			if (step) 
				wind_scroll (window_handle, frame->Container, step, 0);
		}
	
		/* *********** Clickable areas ************* */

		else if (current_highlighted_link_area)
		{
			if (*current_highlighted_link_area->link->address == '#')
			{
				long dx, dy;
				char * addr = current_highlighted_link_area->link->address;
				cont        = current_highlighted_link_frame->Container;
				if (containr_Anchor (cont, addr, &dx, &dy)) {
					wind_scroll (window_handle, cont, dx, dy);
					check_mouse_position (mx + frame->clip.x, my + frame->clip.y);
				}
			}
			else
			{
				cont = (current_highlighted_link_area->link->u.target
			      ? containr_byName (current_highlighted_link_frame->Container,
			                         current_highlighted_link_area->link->u.target)
				      : NULL);

				if (!cont)
					cont = current_highlighted_link_frame->Container;

				new_loader_job (current_highlighted_link_area->link->address,
			                current_highlighted_link_frame->Location, cont,
			                current_highlighted_link_area->link->encoding, -1,-1);
			}
		}
		else
		{
			active_keyboard_frame = frame;

		#ifdef GEM_MENU
			update_menu (frame->Encoding);
		#endif
			wind_set (window_handle, WF_TOP, 0, 0, 0, 0);
		}
	} /* end of left button processing */
	else if (button == 2) /*right button processing */
	{
		mx += frame->clip.x;
		my += frame->clip.y;

		rpopup_open(mx,my);
	}
}


/* check_mouse_position()
 *
 * find the actual clickable to be highlighted.
 *
 * AltF4 - Feb. 17, 2002:  reworked to make use of container funtions and avoid
 *                         access of the global the_firt_frame and frame_next().
 */
void
check_mouse_position (WORD mx, WORD my)
{
	CONTAINR cont;
	FRAME    current_frame = current_highlighted_link_frame;

	if (current_frame && current_highlighted_link_area)
	{
		long x_abs = (long)current_frame->clip.x - current_frame->h_bar.scroll;
		long y_abs = (long)current_frame->clip.y - current_frame->v_bar.scroll;
		GRECT area;
		area.g_x = x_abs + current_highlighted_link_area->offset.X;
		area.g_y = y_abs + current_highlighted_link_area->offset.Y;
		if (mx >= area.g_x && mx < area.g_x + current_highlighted_link_area->w &&
		    my >= area.g_y && my < area.g_y + current_highlighted_link_area->h) {
			/*
			 * the mouse pointer is still inside the actual clickable area,
			 * so nothing to redraw
			 */
			return;

		} else {
			area.g_w = current_highlighted_link_area->w;
			area.g_h = current_highlighted_link_area->h,

			current_highlighted_link_frame = NULL;
			current_highlighted_link_area  = NULL;
			graf_mouse (ARROW, NULL);
			wind_redraw (window_handle, &area);
		}
	}

	if ((cont = containr_byCoord (NULL, mx, my)) != NULL &&
	    (current_frame = containr_Frame (cont))  != NULL) {

		struct clickable_area *current_area = current_frame->first_clickable_area;
		long x_abs = (long)current_frame->clip.x - current_frame->h_bar.scroll;
		long y_abs = (long)current_frame->clip.y - current_frame->v_bar.scroll;

		mx -= x_abs;
		my -= y_abs;

		while (current_area && (
		       mx < current_area->offset.X || mx >= current_area->offset.X + current_area->w ||
		       my < current_area->offset.Y || my >= current_area->offset.Y + current_area->h)) {
			current_area = current_area->next_area;
		}
		if (current_area && current_area->link->isHref)
		{
			GRECT area;
			area.g_x = x_abs + current_area->offset.X;
			area.g_y = y_abs + current_area->offset.Y;
			area.g_w = current_area->w;
			area.g_h = current_area->h,

			current_highlighted_link_frame = current_frame;
			current_highlighted_link_area  = current_area;
			graf_mouse (POINT_HAND, NULL);
			wind_redraw (window_handle, &area);
		}
	}
}
