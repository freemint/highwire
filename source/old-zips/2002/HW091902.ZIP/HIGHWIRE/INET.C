
#ifdef USE_INET
# if defined(__GNUC__)
#  define USE_MINT

# elif defined(__PUREC__)
#  define USE_STIK
# endif
#endif /* USE_INET */


#include <stddef.h>
#include <errno.h>

#include "inet.h"


/*******************************************************************************
 *
 * Basic functions
 *
 */

#if defined(USE_MINT)
# include <netdb.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <unistd.h>
# include <mintbind.h>


#elif defined(USE_STIK)
# include <stdio.h> /*printf/puts */
# include <string.h>
# include <tos.h>
# include <time.h>
# include <transprt.h>

static TPL * tpl = NULL;

/*----------------------------------------------------------------------------*/
static long find_drivers(void)
{
	struct {
		long cktag;
		long ckvalue;
	}  * jar = *((void **)0x5a0);
	long i   = 0;
	long tag = 'STiK';

	while (jar[i].cktag) {
		if (jar[i].cktag == tag) {
			return jar[i].ckvalue;
		}
		++i;
	}
	return 0;	/* Pointless return value...	*/
}

/*----------------------------------------------------------------------------*/
static int init_stick (void)
{
	if (!tpl) {
		DRV_LIST * drivers = (DRV_LIST*)Supexec (find_drivers);
		if (strcmp (MAGIC, drivers->magic) == 0) {
			tpl = (TPL*)get_dftab(TRANSPORT_DRIVER);
		}
	}
	return (tpl != NULL);
}

#endif /* USE_STIK */


/*============================================================================*/
int
inet_host_addr (const char * name, long * addr)
{
	int ret = -1;
	
#if defined(USE_MINT)
	struct hostent * host = gethostbyname (name);
	if (host) {
		*addr = *(long*)host->h_addr;
		ret   = 0;
	} else {
		ret   = -errno;
	}
	
#elif defined(USE_STIK)
	if (init_stick()) {
		if (resolve ((char*)name, NULL, (uint32*)addr, 1) > 0) {
			ret = 0;
		}
	}
#endif
	
	return ret;
}

/*============================================================================*/
int
inet_connect (long addr, short port)
{
	int fh = -1;
	
#if defined(USE_MINT)
	struct sockaddr_in s_in;
	s_in.sin_family = AF_INET;
	s_in.sin_port   = htons (port);
	s_in.sin_addr   = *(struct in_addr *)&addr;
	if ((fh = socket (PF_INET, SOCK_STREAM, 0)) < 0) {
		fh = -errno;
	} else if (connect (fh, (struct sockaddr *)&s_in, sizeof (s_in)) < 0) {
		fh = -errno;
		close (fh);
	}
	
#elif defined(USE_STIK)
	if (!tpl) {
		puts ("No STiK");
	} else {
		if ((fh = TCP_open (addr, port, 0, 2048)) < 0) {
			fh = -1;
		}
	}
#endif
	
	return fh;
}

/*============================================================================*/
long
inet_send (int fh, char * buf, size_t len)
{
	long ret = -1;

#if defined(USE_MINT)
	ret = Fwrite (fh, len, buf);
	
#elif defined(USE_STIK)
	if (!tpl) {
		puts ("No STiK");
	} else {
		ret = TCP_send (fh, buf, (int)len);
	}
#endif
	
	return ret;
}

/*============================================================================*/
long
inet_recv (int fh, char * buf, size_t len)
{
	long ret = 0;

#if defined(USE_MINT)
	while (len) {
		long n = Finstat (fh);
		if (n < 0) {
			if (!ret) ret = n;
			break;
		} else if (n == 0x7FFFFFFF) { /* connection closed */
			if (!ret) ret = -1;
			break;
		} else if (n && (n = Fread (fh, (n < len ? n : len), buf)) < 0) {
			if (!ret) ret = -errno;
			break;
		} else if (n) {
			ret += n;
			buf += n;
			len -= n;
		} else {
			if (ret) break;
		}
	}
	
#elif defined(USE_STIK)
	if (!tpl) {
		puts ("No STiK");
		ret = -1;
	} else while (len) {
		short n = CNbyte_count (fh);
		if (n < 0) {
			if (!ret) ret = -1;
			break;
		} else if (n) {
			if (n > len) n = len;
			if ((n = CNget_block (fh, buf, n)) < 0) {
				if (!ret) ret = -1;
				break;
			} else {
				ret += n;
				buf += n;
				len -= n;
			}
	
		} else {
			if (ret) break;
		}
	}

#else
	ret = -1;
#endif
	
	return ret;
}

/*============================================================================*/
void
inet_close (int fh)
{
	if (fh >= 0) {
	
	#if defined(USE_MINT)
		close (fh);
		
	#elif defined(USE_STIK)
		if (!tpl) {
			puts ("No STiK");
		} else {
			TCP_close (fh, 0);
		}
	#endif
	}
}

/*============================================================================*/
const char *
inet_info (void)
{
#if defined(USE_MINT)
	return "MiNTnet";
	
#elif defined(USE_STIK)
	return "STiK2";
	
#else
	return NULL;
#endif
}
