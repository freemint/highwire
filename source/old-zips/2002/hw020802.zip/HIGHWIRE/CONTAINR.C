#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "global.h"
#include "Loader.h"
#include "Containr.h"


/*==============================================================================
 */
CONTAINR
new_containr (CONTAINR parent)
{
	CONTAINR cont = malloc (sizeof (struct s_containr));
	memset (cont, 0, sizeof (struct s_containr));
	
	if (parent == NULL) {
		cont->ColSize = -1024;
		cont->RowSize = -1024;
		
	} else {
		cont->Parent = parent;
	}
	
	return cont;
}


/*==============================================================================
 * create children
 */
void
containr_fillup (CONTAINR parent, const char * text, BOOL colsNrows)
{
	CONTAINR * ptr = &parent->u.Child;
	int        num = 0;
	
	short perc_cnt = 0; /* number of percent values */
	long  perc_sum = 0; /* sum of all percents */
	short rest_cnt = 0; /* number of all '*','2',.. and invalid values */
	long  rest_sum = 0; /* sum of fractionals */
	
	/* go throug the text list and create children
	 */
	while (*text) {
		short val = 0;
		while (isspace(*text)) text++;
		if (*text != '*') {
			char * tail = "";
			long   tmp  = strtol (text, &tail, 10);
			if (tmp > 0 && tmp < 10000) {
				if (*tail == '%') {
					perc_cnt++;
					perc_sum += tmp;
					val      = -tmp -10000;
				} else if (*tail == '*' && tmp > 1) {
					rest_cnt++;
					rest_sum += tmp;
					val      = -tmp +1;
				} else { /* absolute value */
					val = tmp;
				}
			}
			text = tail;
		}
		if (!val) { /* either a '*', '1*' or an inalid value */
			rest_cnt++;
			rest_sum++;
		}
		*ptr = new_containr (parent);
		if (colsNrows) {
			(*ptr)->ColSize = val;
			(*ptr)->RowSize = (parent->RowSize > 0 ? parent->RowSize : -1024);
		} else {
			(*ptr)->ColSize = (parent->ColSize > 0 ? parent->ColSize : -1024);
			(*ptr)->RowSize = val;
		}
		ptr = &(*ptr)->Sibling;
		num++;
		while (*text && *(text++) != ',');
	}
	
	/* post process the percent sizes
	 */
	if (num) {
		
		short perc = 1024;
		short rest = 1024;
		
		if (rest_cnt) {
			long  sum;
			short both = perc_cnt + rest_cnt;
			if (perc_sum >= 100) {
				sum = (perc_sum * both + ((perc_cnt -1) /2)) / perc_cnt;
			} else {
				sum = 100;
			}
			if (perc_sum) {
				rest = (1024L * (sum - perc_sum) + ((sum -1) /2)) / sum;
			}
			perc_sum = sum;
			perc_cnt = both;
		}
		
		if (perc_cnt) {
			
			long p_half = (perc_sum -1) /2;
			long r_half = (rest_cnt -1) /2;
			
			CONTAINR cont = parent->u.Child;
			do {
				short * var = (colsNrows ? &cont->ColSize : &cont->RowSize);
				short   val = -*var;
				if (val >= 0) {
					if (!--perc_cnt) {
						val = perc;
					
					} else if (val > 10000) {
						val -= 10000;
						val = ((long)val * 1024 + p_half) / perc_sum;
						
					} else { /* 0 <= val <= 10000 */
						val += 1;
						val = ((long)val * rest + r_half) / rest_sum;
					}
					perc += *var = -val;
				}
			} while ((cont = cont->Sibling) != NULL);
		}
		
		parent->Mode = (colsNrows ? CNT_CLD_H : CNT_CLD_V);
	}
}

/*==============================================================================
 */
void
containr_clear (CONTAINR cont)
{
	int depth = 0;
	
	while (cont) {
		if (cont->Mode == CNT_FRAME) {
			if (cont->u.Frame) {
				/* ... delete frame ... */
				cont->u.Frame = NULL;
			}
		} else if (cont->Mode) {
			if (cont->u.Child) {
				cont = cont->u.Child;
				depth++;
				continue;
			}
		}
		
		if (!depth) {
			cont->Mode = CNT_EMPTY;
			break;
		
		} else {
			CONTAINR next = cont->Sibling;
			if (cont->Parent) {
				cont->Parent->u.Child = next;
			}
			if (!next) {
				next = cont->Parent;
				depth--;
			}
			free (cont);
			cont = next;
		}
	}
}


/*============================================================================*/
FRAME
frame_next (FRAME frame)
{
	CONTAINR cont = frame->Container;
	BOOL     b    = FALSE;
	
	while (cont) {
		if (b) {
			if (cont->Mode == CNT_FRAME) {
				if (cont->u.Frame) {
					return cont->u.Frame;
				}
			} else if (cont->Mode) {
				cont = cont->u.Child;
				continue;
			}
		}
		if (cont->Sibling) {
			cont = cont->Sibling;
			b    = TRUE;
			continue;
		}
		cont = cont->Parent;
		b    = FALSE;
	}
	return NULL;
}


/*----------------------------------------------------------------------------*/
short
C_get_percent (CONTAINR cont, BOOL colsNrows)
{
	long perc = -(colsNrows ? cont->ColSize : cont->RowSize);
	
	if (perc > 0) {
		while ((cont = cont->Parent) != NULL) {
			short size = -(colsNrows ? cont->ColSize : cont->RowSize);
			if (size > 0 && size < 1024) {
				perc = (perc * size + 511) /1024;
			} else if (size < 0) {
				return (perc * -size + 511) /1024;
			}
		}
		perc = (perc * 100 + 511) /1024;
	}
	return -perc;
}

/*----------------------------------------------------------------------------*/
void
C_get_offset (CONTAINR cont, short * x, short * y)
{
	CONTAINR prev = cont->Parent->u.Child;
	do {
		if (prev->Sibling == cont) {
			FRAME f = prev->u.Frame;
			*x = f->frame_left;
			*y = f->frame_top;
			if (prev->Parent->Mode == CNT_CLD_H) *x += f->frame_width;
			else                                 *y += f->frame_height;
			return;
		}
	} while ((prev = prev->Sibling) != NULL);
}


/*----------------------------------------------------------------------------*/
void containr_debug (CONTAINR);
void
containr_debug (CONTAINR cont)
{
	int  depth = 0;
	BOOL b = TRUE;
	
#if 01
	if (cont) while (cont->Parent) cont = cont->Parent;
#endif
	
	while (cont) {
		if (b) {
			printf ("%*s%p = %i [%i,%i] %s", depth *2, "",
			        cont, cont->Mode, cont->ColSize, cont->RowSize,
			        (cont->_debug ? cont->_debug : "???"));
			if (cont->Mode == CNT_FRAME) {
				FRAME f = cont->u.Frame;
				if (f) {
					printf (" '%s' [%i,%i/%i,%i]\n", f->frame_name, 
					        f->frame_left,f->frame_top,f->frame_width,f->frame_height);
				} else {
					printf (" ???\n");
				}
			} else if (cont->Mode && cont->u.Child) {
				printf("\n");
				cont = cont->u.Child;
				depth++;
				continue;
			}
		}
		if (cont->Sibling) {
			cont = cont->Sibling;
			b    = TRUE;
			continue;
		}
		cont = cont->Parent;
		b    = FALSE;
		depth--;
	}
}
