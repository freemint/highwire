/* @(#)highwire/AEI.c
 */
#include <stdlib.h>
#include <string.h>

#ifdef __PUREC__
#include <tos.h>

#else /* LATTICE || __GNUC__ */
#include <osbind.h>
#endif

#include <gem.h>

#include "global.h"
#include "Containr.h"


void
wind_redraw (short hdl, const GRECT * p_clip)
{
	GRECT clip, work;
	wind_get_grect (0,   WF_WORKXYWH, &clip);
	wind_get_grect (hdl, WF_WORKXYWH, &work);
	
	if (rc_intersect (&clip, &work)
	    && (!p_clip || rc_intersect (p_clip, &work))) {
		
		wind_update (BEG_UPDATE);
		wind_get_grect (hdl, WF_FIRSTXYWH, &clip);
		while (clip.g_w > 0 && clip.g_h > 0) {
			if (rc_intersect (&work, &clip)) {
				containr_redraw (NULL, &clip);
			}
			wind_get_grect (hdl, WF_NEXTXYWH, &clip);
		}
		wind_update (END_UPDATE);
	}
}


void
wind_scroll (short hdl, CONTAINR cont, long dx, long dy)
{
	GRECT clip, work;
	wind_get_grect (0,   WF_WORKXYWH, &clip);
	wind_get_grect (hdl, WF_WORKXYWH, &work);
	
	if (containr_shift (cont, &dx, &dy)
	    && rc_intersect (&clip, &work) && rc_intersect (&cont->Area, &work)) {
		wind_update (BEG_UPDATE);
		wind_get_grect (hdl, WF_FIRSTXYWH, &clip);
		while (clip.g_w > 0 && clip.g_h > 0) {
			if (rc_intersect (&work, &clip)) {
				containr_scroll (cont, &clip, dx, dy);
			}
			wind_get_grect (hdl, WF_NEXTXYWH, &clip);
		}
		wind_update (END_UPDATE);
	}
}


/* Gemscript support added
 * Matthias Jaap  December 21, 2001
 */

#define VA_START   0x4711
#define GLOBAL    0x0020
#define ALLOCMODE 3|GLOBAL
#define GS_REQUEST  0x1350
#define GS_REPLY    0x1351
#define GS_COMMAND  0x1352
#define GS_ACK      0x1353
#define GS_QUIT     0x1354

#define GSM_COMMAND 0x0001

#define GSACK_OK      0
#define GSACK_UNKNOWN 1
#define GSACK_ERROR   2
typedef struct
{
	long len;
	WORD  version;
	WORD  msgs;
	long ext;
} GS_INFO;

WORD gsapp = -1;
char *xaccname = NULL;
GS_INFO *gsi = NULL;


static void
vastart(const WORD pipe[8])
{
	const char *cmd = *(const char **)&pipe[3];

	init_load(cmd);
}


static const char *
nextToken(const char *pcmd)
{
	if (!pcmd)
		return (NULL);

	pcmd += (strlen(pcmd) + 1);

	while (TRUE)
		switch (*pcmd)
		{
			case 0:
				return (NULL);

			case 1:
			case 2:
			/* Hex-Kommandos auswerten */
			case 3:
			case 4:
			case 5:
			case 6:
				pcmd += (strlen(pcmd) + 1);
				break;

			default:
				return (pcmd);
		}
}


static WORD
doGSCommand(const WORD pipe[8])
{
	WORD answ[8], ret = 0;
	const char *cmd = *(const char **)&pipe[3];
	char *gslongname = NULL;

	answ[0] = GS_ACK;
	answ[1] = gl_apid;
	answ[2] = 0;
	answ[3] = pipe[3];
	answ[4] = pipe[4];
	answ[5] = 0;
	answ[6] = 0;
	answ[7] = GSACK_ERROR;

	if (xaccname == NULL)
	{
		xaccname = (char *)(can_extended_mxalloc()?
		           Mxalloc(96L, ALLOCMODE) : Malloc(96L));
	}

	gslongname = xaccname + 64;
	strcpy(gslongname, "HighWire");

	if (cmd)
	{
		answ[7] = GSACK_UNKNOWN;

		if (!stricmp(cmd, "Quit"))
		{
			ret = 1;
			answ[7] = GSACK_OK;
		}
		else if (!stricmp(cmd, "Open"))
		{
			cmd = nextToken(cmd);
			init_load(cmd);
			answ[7] = GSACK_OK;
		}
		else if (!stricmp(cmd, "AppGetLongName"))
		{
			if (gslongname)
			{
				answ[5] = (WORD)(((long)gslongname >> 16) & 0x0000ffffL);
				answ[6] = (WORD)((long)gslongname & 0x0000ffffL);
				answ[7] = GSACK_OK;
			}
			else
			{
				answ[7] = GSACK_ERROR;
			}
		}
	}

	appl_write(pipe[1], 16, answ);

	if (!stricmp(cmd, "Quit"))
	{
		exit (EXIT_SUCCESS);
	}

	return (ret);
}


/*
 * full_window
 *
 * Sets whether window is full or original size
 *
 * win is the widow_handle in this simple case
 */
 
static void full_window(WORD win)
{
	GRECT	new;

	/* realistically under some AES we should check if the
	 * window belongs to us. Before proceding with modification.
	 * I have witnessed this under MagiC with Jinnee.  I'm not
	 * certain if it's specific to those.
	 * The check won't hurt anyone else though
	 * / baldrick
	 */
	if (win == window_handle)
	{
		if (win_status == 1)
		{
			/* Shrink Window to normal */
			wind_get_grect(win, WF_PREVXYWH, &new);
			win_status = 0;
		}
		else
		{
			/* Full window */
			wind_get_grect(win, WF_FULLXYWH, &new);
			win_status = 1;
		}

		wind_set_grect(win, WF_CURRXYWH, &new);
	}
}


/*
 * Iconify.
 */
static void iconify_window(WORD win, GRECT *new)
{
	if (win == window_handle)
	{
		wind_set_grect(window_handle, WF_ICONIFY, (GRECT*)new);

		/* get the old status before overwritting it */
		pre_status = win_status;
		win_status = 2;

		wind_set (window_handle, WF_BOTTOM, 0, 0, 0, 0);
	}
}


static void uniconify_window(WORD win, GRECT *new)
{
/*	GRECT	r;*/

	if (win == window_handle)
	{
		wind_set_grect(window_handle, WF_UNICONIFY, (GRECT*)new);

		win_status = pre_status;

		wind_set (window_handle, WF_TOP, 0, 0, 0, 0);
	}
}


BOOL
process_messages (struct frame_item *first_frame)
{
/*	short wx, wy, ww, wh;*/

	switch (event_messages[0])
	{
		case VA_START :
			vastart(event_messages);
			break;
		case GS_REQUEST:
			{
				WORD answ[8];

				answ[0] = GS_REPLY;
				answ[1] = gl_apid;
				answ[2] = 0;
				answ[3] = 0;
				answ[4] = 0;
				answ[5] = 0;
				answ[6] = 1;
				answ[7] = event_messages[7];

				if (!gsi)
					gsi = (GS_INFO *)(can_extended_mxalloc()?
					      Mxalloc(sizeof(GS_INFO), ALLOCMODE) : Malloc(sizeof(GS_INFO)));

				if (gsi)
				{
					GS_INFO *sender = *(GS_INFO **)&event_messages[3];

					gsi->len = sizeof(GS_INFO);
					gsi->version = 0x0100;
					gsi->msgs = GSM_COMMAND;
					gsi->ext = 0L;

					answ[3] = (WORD)(((long)gsi >> 16) & 0x0000ffffL);
					answ[4] = (WORD)((long)gsi & 0x0000ffffL);

					if (sender)
					{
						if (sender->version >= 0x0070)
						{
							answ[6] = 0;
							gsapp = event_messages[1];
						}
					}
				}

				appl_write(gsapp, 16, answ);
			}
			break;
		case GS_COMMAND:
			if (doGSCommand(event_messages))
				return TRUE;
			break;
		case WM_MOVED: {
			GRECT work;
			wind_set_grect (event_messages[3],
			                WF_CURRXYWH, (GRECT*)(event_messages + 4));
			wind_get_grect (event_messages[3], WF_WORKXYWH, &work);
			containr_relocate (containr_Base (NULL), work.g_x, work.g_y);
		}	break;
		case WM_SIZED: {
			GRECT work;
			wind_set (event_messages[3], WF_CURRXYWH, event_messages[4],
				  event_messages[5], event_messages[6], event_messages[7]);
			wind_get_grect (event_messages[3], WF_WORKXYWH, &work);
			containr_calculate (containr_Base (NULL), &work);
		}
		case WM_REDRAW:
			wind_redraw (window_handle, (GRECT*)(event_messages + 4));
			break;
		case WM_TOPPED:
			wind_set (window_handle, WF_TOP, event_messages[3], 0, 0, 0);
			break;
		case WM_FULLED: {
			GRECT work;
			full_window(event_messages[3]);
			wind_get_grect (event_messages[3], WF_WORKXYWH, &work);
			containr_calculate (containr_Base (NULL), &work);
		}	break;
		case WM_BOTTOMED:
			wind_set (window_handle, WF_BOTTOM, event_messages[3], 0, 0, 0);
			break;
		case WM_ICONIFY:
			iconify_window(event_messages[3], ((GRECT *)&event_messages[4]));
			break;
		case WM_UNICONIFY:
			uniconify_window(event_messages[3], ((GRECT *)&event_messages[4]));
			break;
#ifdef GEM_MENU
		case MN_SELECTED:
			handle_menu(event_messages[4], event_messages);
			break;
#endif
		case WM_CLOSED:
		case AP_TERM:
			return (TRUE);
	}
	return (FALSE);
}
