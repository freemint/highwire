/* @(#)highwire/Location.c
 */


#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#ifdef __PUREC__
# include <tos.h>
# include <stddef.h>
#endif
#ifdef LATTICE
# include <dos.h>
#endif
#ifdef __GNUC__
# include <osbind.h>
#endif

#include "defs.h"
#include "Location.h"
#include "Logging.h"


static LOCATION __base = NULL;


/*----------------------------------------------------------------------------*/
static LOCATION
_alloc (size_t size, BOOL tos_path)
{
	LOCATION loc = malloc (sizeof (struct s_location) + size);
	loc->__reffs  = 0;
	loc->encoding = ENCODING_WINDOWS1252;
	loc->isTos    = tos_path;
	loc->Path     = loc->FullName + (tos_path ? 2 : 0);
	loc->Anchor   = NULL;
	
	return loc;
}

/*============================================================================*/
LOCATION
new_location (const char * src, LOCATION base)
{
	LOCATION loc;
	char   * p;
	size_t   path_ln, file_ln;
	BOOL     is_tos;

#ifndef USE_LIBWWW
	static LOCATION __local_web = NULL;

	if (!__local_web) {
		char   path[] = "C:\\WWW\\";
		size_t len;

		len = strlen (path);
		__local_web = _alloc (len, TRUE);
		__local_web->File  = (char*)memcpy (__local_web->FullName, path, len + 1) + len;
		__local_web->FullName[len] = '\0';
	}
#endif
	
	if (!__base) {
		char   path[HW_PATH_MAX];
		size_t len;
		path[0] = Dgetdrv();
		path[0] += (path[0] < 26)? 'A' : -26 + '1';
		path[1] = ':';
		Dgetpath (path +2, 0);
		len = strlen (path);
		if (path[len -1] != '\\') {
			path[len++] = '\\';
		}
		__base = _alloc (len, TRUE);
		__base->File  = (char*)memcpy (__base->FullName, path, len) + len;
		__base->FullName[len] = '\0';
	}
	
	if (!base) {
		base = __base;
	}
	
	if (!src || !src[0]) {
		loc = base;
		loc->__reffs++;
		
		return loc;
	}
	
/*	if (isalpha(src[0]) && src[1] == ':') { old line */

	if (src[1] == ':') {  /* TOS drive letter is A-Z[\]^_` or A-Z1-6 */
		is_tos  = TRUE;
		path_ln = 0;
	
	} else if (src[0] == '/') {
		is_tos  = FALSE;
		path_ln = 0;

#ifndef USE_LIBWWW
	} else if (strncmp(src, "ftp://", 6) == 0) {
		src += 6;
		is_tos  = TRUE;
		base = __local_web;
		path_ln = strlen(base->Path);
	} else if (strncmp(src, "http://", 7) == 0) {
		src += 7;
		is_tos  = TRUE;
		base = __local_web;
		path_ln = strlen(base->Path);
#endif
	
	} else {
		char * end = base->File -1;
		is_tos  = base->isTos;
		
		while (src[0] == '.') {
			if (src[1] == '/' || src[1] == '\\') {
				src += 2;
			} else if (src[1] == '.' && (src[2] == '/' || src[2] == '\\')) {
				while (end > base->Path && *(--end) != *base->Path);
				src += 3;
			} else {
				break;
			}
		}
		if (src[0] == '/' || src[0] == '\\') {
			src++;
		}
		path_ln = end - base->Path +1;
	}
	
	file_ln = strlen (src);
	loc     = _alloc (path_ln + file_ln, is_tos);
	if (is_tos) {
		if (path_ln) {
			if (base->isTos) {
				memcpy (loc->FullName, base->FullName, path_ln +2);
			} else {
				loc->FullName[0] = 'U';
				loc->FullName[1] = ':';
				memcpy (loc->Path, base->Path, path_ln);
			}
		} else {
			path_ln = -2;
		}
		memcpy (loc->Path + path_ln, src, file_ln +1);
		p = loc->Path;
		while ((p = strchr (p, '/')) != NULL) *(p++) = '\\';
		
	} else {
		if (path_ln) {
			memcpy (loc->Path, base->Path, path_ln);
		}
		memcpy (loc->Path + path_ln, src, file_ln +1);
		p = loc->Path;
		while ((p = strchr (p, '\\')) != NULL) *(p++) = '/';
	}
	
	if ((p = strchr (loc->Path, '#')) != NULL) {
		*(p++) = '\0';
		loc->Anchor = p;
	}
	loc->File = strrchr (loc->Path, loc->Path[0]) +1;

	loc->__reffs++;
	
	logprintf(LOG_BLACK, "new_location('%s', %hd '%s' returns %hd '%s'\n)",
	          src, base->isTos, base->FullName, is_tos, loc->FullName);
	
	return loc;
}

/*============================================================================*/
void
free_location (LOCATION * _loc)
{
	LOCATION loc = *_loc;
	if (loc) {
		if ((!loc->__reffs || !--loc->__reffs) && loc != __base) {
			free (loc);
		}
		*_loc = NULL;
	}
}


/*============================================================================*/
LOCATION
location_share  (LOCATION loc)
{
	if (loc) {
		loc->__reffs++;
	}
	return loc;
}
