#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#include "global.h"
#include "Table.h"

void
destroy_paragraph_structure (PARAGRPH current_paragraph)
{
	struct paragraph_item *temp;

	while (current_paragraph != 0)
	{
		if (current_paragraph->item != 0)
			destroy_word_structure (current_paragraph->item);
#if 0
		if (current_paragraph->table != 0)
			destroy_table_structure (current_paragraph->table);
#endif
		temp = current_paragraph->next_paragraph;
		free (current_paragraph);
		current_paragraph = temp;
	}
}


/*==============================================================================
 */
PARAGRPH
new_paragraph (TEXTBUFF current)
{
	PARAGRPH paragraph = malloc (sizeof (struct paragraph_item));
	
	current->word = NULL;
	
	paragraph->item    = new_word (current);
	paragraph->Table   = NULL;
	paragraph->Line    = NULL;
	paragraph->Indent  = 0;
	paragraph->Rindent = 0;
	paragraph->Height  = 0;
	paragraph->Offset.Origin = NULL;
	paragraph->Offset.X      = 0;
	paragraph->Offset.Y      = 0;
	
	paragraph->paragraph_code = PAR_NONE;
	paragraph->alignment      = ALN_LEFT;
	paragraph->eop_space      = 0;
	paragraph->min_width      = 0;
	paragraph->max_width      = 0;

	paragraph->next_paragraph = NULL;
	
	current->paragraph = paragraph;
	
	return paragraph;
}


/*==============================================================================
 * add_paragraph()
 * 
 * Creates a new paragraph structure and links it into list
 * also creates a new word item and links it into the new paragraph
 *
 * 12/14/01 - modified to use frame_item info and directly modify frame - baldrick
 *
 * AltF4 - Jan. 20, 2002:  replaced malloc of struct word_item by new_word().
 *
 */

PARAGRPH
add_paragraph (TEXTBUFF current)
{
	PARAGRPH paragraph = malloc (sizeof (struct paragraph_item));
	PARAGRPH copy_from = current->paragraph;
	
	current->paragraph = NULL;

	paragraph->item  = new_word (current);
	paragraph->Table = NULL;
	paragraph->Line    = NULL;
	paragraph->Indent  = copy_from->Indent;
	paragraph->Rindent = copy_from->Rindent;
	paragraph->Height  = 0;
	paragraph->Offset.Origin = copy_from->Offset.Origin;
	paragraph->Offset.X      = 0;
	paragraph->Offset.Y      = 0;
	
	paragraph->paragraph_code = PAR_NONE;
	paragraph->alignment      = copy_from->alignment;
	paragraph->eop_space = 0;
	paragraph->min_width = 0;
	paragraph->max_width = 0;
	
	paragraph->next_paragraph = NULL;
	
	copy_from->next_paragraph = paragraph;
	current->paragraph        = paragraph;
	
	return paragraph;
}


/*==============================================================================
 */
typedef struct word_item * TEXTWORD;

static void
paragraph_calc (PARAGRPH par, short width, CLICKABLE ** clck_pptr)
{
	WORDLINE * p_line = &par->Line, line;
	TEXTWORD   word   = par->item,  next, last;

	par->Height = 0;
	do {
		struct url_link * link;
		CLICKABLE      clickable = NULL;
		short count  = 1;
		short blanks = 0;
		short offset, justify, first;
		BOOL  ln_brk;

		while (word && (!word->item || !word->item[0] ||
		                (word->item[0] == Space_Code && !word->item[1]))
		            && !word->link) {
			word = word->next_word;
		}
		if (!word) break;

		if ((line = *p_line) == NULL) {
			*p_line = line = malloc (sizeof(struct word_line));
			line->NextLine = NULL;
		}
		p_line = &line->NextLine;
		first  = (word->item[0] == Space_Code ? word->space_width +1 : 0);
		offset = width - word->word_width + first;
		ln_brk = word->line_brk;
		last   = word;
		line->Word    = word;

		if (word->vertical_align == ALN_TOP)
		{
			line->Ascend  = 0;
			line->Descend = (word->word_height - word->styles.font_size);
			/* The previous line should be the height of our object minus
			   the current line Ascent, but how?*/
		}
		else if (word->vertical_align == ALN_MIDDLE)
		{
			line->Ascend  = (word->word_height/2);
			line->Descend = (word->word_height/2);
		}
		else
		{
			line->Ascend  = word->word_height;
			line->Descend = word->word_tail_drop;
		}

		while ((word = word->next_word) != NULL
		       && !ln_brk && word->word_width <= offset) {
			if (word->item && word->item[0]) {
				if (word->item[0] != Space_Code || word->item[1])
				{

					switch (word->vertical_align) {
						case ALN_TOP:
							if (line->Descend  < word->word_height)
								 line->Descend  = word->word_height;

							break;

						case ALN_MIDDLE:
							if (line->Ascend  < (word->word_height/2))
								 line->Ascend  = (word->word_height/2);
	
							if (line->Descend  < (word->word_height/2))
								 line->Descend  = (word->word_height/2);

							break;

						default: 
							if (line->Ascend  < word->word_height)
								 line->Ascend  = word->word_height;
							if (line->Descend < word->word_tail_drop)
								 line->Descend = word->word_tail_drop;
					}
				}
				offset -= word->word_width;
				blanks =  0;

			} else {
				word->word_width = 0;
				blanks++;
			}
			ln_brk = word->line_brk;
			last = word;
			count++;
		}
		next        = word;
		line->Count = count;
		count      -= blanks;

		if (par->alignment == ALN_JUSTIFY) {
			if (last->line_brk)
				justify = 0;
			else if (line->NextLine != NULL) 
				justify = (next ? offset : 0);
			else
				justify = 0;
				
			offset  = 0;
		} else if (par->alignment) {
			justify = 0;
			if (par->alignment == ALN_CENTER) {
				offset /= 2;
			}
		} else {
			justify = 0;
			offset  = 0;
		}
		offset -= first;
		word   =  line->Word;
		link   =  NULL;
		while(1) {
			if (word->image) {
				word->image->offset.X = par->Offset.X + offset;
				word->image->offset.Y = par->Offset.Y + par->Height
				                      + line->Ascend - word->word_height;
			}

			if (!word->link) {
				link = NULL;

			} else if (!word->link->isHref) {
				word->link->u.anchor->offset.Y = par->Offset.Y + par->Height;
				link = NULL;

			} else if (word->link == link) {
				clickable->w += word->word_width;

			} else {
				clickable = **clck_pptr;
				if (!clickable) {
					**clck_pptr = clickable = new_clickable_area();
				}
				*clck_pptr = &clickable->next_area;
				clickable->offset.Origin = par->Offset.Origin;
				clickable->offset.X      = par->Offset.X + offset;
				clickable->offset.Y      = par->Offset.Y + par->Height;
				clickable->w             = word->word_width;
				clickable->h             = line->Ascend + line->Descend;
				clickable->link   = link = word->link;
			}
			word->h_offset = offset;

			if (!--count) break;

			if (justify) {
				short w = justify / count;
				offset  += w;
				justify -= w;
			}
			offset += word->word_width;
			word    = word->next_word;
		}
		line->Word->h_offset += first;

		par->Height += line->Ascend + line->Descend;

	} while ((word = next) != NULL);

	if ((line = *p_line) != NULL) {
		WORDLINE next_line;
		do {
			next_line = line->NextLine;
			free (line);
		} while ((line = next_line) != NULL);
		*p_line = NULL;
	}

	par->Width = width;
}


/*==============================================================================
 * content_minimum()
 *
 * Returns the smallest width that is nedded for a list of paragraphs.
 */
WORD
content_minimum (PARAGRPH paragraph)
{
	WORD width = 0;
	while (paragraph) {
		short min_width = paragraph->min_width
		                + paragraph->Indent + paragraph->Rindent;
		if (width < min_width) {
			 width = min_width;
		}
		paragraph = paragraph->next_paragraph;
	}
	return width;
}


/*==============================================================================
 * content_maximum()
 *
 * Returns the largest width that occures in a list of paragraphs.
 */
long
content_maximum (PARAGRPH paragraph)
{
	long max_width = 0;
	while (paragraph) {
		if (!paragraph->max_width) {
			struct word_item * word = paragraph->item;
			long width = paragraph->Indent + paragraph->Rindent;
			while (word) {
				BOOL ln_brk = word->line_brk;
				if (word->item && *word->item
				    &&(word->item[0] != Space_Code || word->item[1])) {
					width += word->word_width;
				}
				word = word->next_word;
				if (ln_brk || !word) {
					if (paragraph->max_width < width) {
						 paragraph->max_width = width;
					}
					width = paragraph->Indent;
				}
			}
		}
		if (max_width < paragraph->max_width) {
			 max_width = paragraph->max_width;
		}
		paragraph = paragraph->next_paragraph;
	}
	return max_width;
}


/*==============================================================================
 */
long
content_calc (PARAGRPH paragraph, long set_width, CLICKABLE ** clck_pptr)
{
	long height = 0;
	
	while (paragraph) {
		long par_width = set_width - paragraph->Indent - paragraph->Rindent;
		paragraph->Offset.X = paragraph->Indent;
		paragraph->Offset.Y = height;
		
		if (paragraph->paragraph_code == PAR_HR) {
			paragraph->Offset.Y = height += 8;
			paragraph->Width  = paragraph->item->word_width = par_width;
			paragraph->Height = 2;
			paragraph->eop_space = 10;
		
	/*	} else if (paragraph->paragraph_code == PAR_IMG) {
			paragraph->Width  = paragraph->item->word_width;
			paragraph->Height = paragraph->item->word_height;
	*/
		} else if (paragraph->paragraph_code == PAR_TABLE) {
			table_calc (paragraph->Table, par_width, clck_pptr);
		
		} else {   /* normal text */
			paragraph_calc (paragraph, par_width, clck_pptr);
		}
		
		if (paragraph->Width < par_width && paragraph->alignment) {
			short indent = par_width - paragraph->Width;
			if (paragraph->alignment == ALN_CENTER) indent /= 2;
			paragraph->Offset.X += indent;
		}
		height   += paragraph->Height + paragraph->eop_space;
		paragraph = paragraph->next_paragraph;
	}
	return height;
}
