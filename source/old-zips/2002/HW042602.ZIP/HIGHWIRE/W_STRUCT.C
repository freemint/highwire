#include <stdlib.h>
#include <string.h>
#include <gemx.h>

#include "global.h"

void
destroy_word_structure (struct word_item *current_word)
{
	struct word_item *temp;

	while (current_word != 0)
	{
		if (current_word->item != 0)
			free (current_word->item);
		if (current_word->link != 0)
			free (current_word->link);
		temp = current_word->next_word;
		free (current_word);
		current_word = temp;
	}
}


/* new_word()
 *
 * creates a new word_item object.  if the 'copy_from' is not NULL it is
 * taken as a source to copy attributes from.  the flag 'changed' determines
 * if the members of the changed struct shall be set or cleared.
 * AltF4 - Jan. 20, 2002
 *
 * modified to take frame_item * for inheritance from frame
 * Baldrick - Feb 28, 2002
 */
struct word_item *
new_word (TEXTBUFF current, const struct word_item * copy_from, BOOL changed)
{
	struct word_item *temp = malloc (sizeof (struct word_item));

	if (copy_from) {
		temp->styles            = copy_from->styles;
		temp->word_height       = copy_from->word_height;
		temp->word_tail_drop    = copy_from->word_tail_drop;
		temp->colour            = copy_from->colour;
		temp->space_width       = copy_from->space_width;
		temp->vertical_align    = copy_from->vertical_align;
		if (copy_from->link && copy_from->link->mode == lnk_href) {
			temp->link           = copy_from->link;
		} else {
			temp->link           = NULL;
		}
	} else {
		temp->styles.bold       = 0;
		temp->styles.italic     = 0;
		temp->styles.underlined = 0;
		temp->styles.strike     = 0;
		temp->styles.font       = normal_font;
		temp->styles.font_size  = current->font_size; /*POINT_SIZE;*/
		temp->word_height       = 0;
		temp->word_tail_drop    = 0;
		temp->colour            = text_colour;
		temp->space_width       = 0;
		temp->vertical_align    = ALN_BOTTOM;
		temp->link              = NULL;
	}
	temp->item           = NULL;
	temp->changed.font   = changed;
	temp->changed.style  = changed;
	temp->changed.colour = changed;
	temp->line_brk       = FALSE;
	temp->word_width     = 0;
	temp->next_word      = NULL;

	return (temp);
}


struct word_item *
add_word (TEXTBUFF current)
{
	if (current->text > current->buffer) {
		word_store (current);

		current->word->next_word = new_word (current, current->word, FALSE);
		current->word            = current->word->next_word;
	}
	return current->word;
}


void
word_store (TEXTBUFF current)
{
	PARAGRPH paragraph = current->paragraph;
	size_t   length    = current->text - current->buffer;
	size_t   size      = (length +1) *2;
	WORD pts[8];
	
	current->word->item = malloc (size);
	memcpy (current->word->item, current->buffer, size);
	current->word->item[length] = 0;

	vqt_f_extent16 (vdi_handle, current->word->item, pts);
	pts[0] = current->word->word_width += pts[2] - pts[0];
	
	if (current->buffer[0] == Space_Code) {
		pts[0] -= current->word->space_width +1;
	}
	if (paragraph && (paragraph->min_width < pts[0])) {
		paragraph->min_width = pts[0];
	}
	
	current->text = current->buffer;
}
