#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#ifdef __PUREC__
# include <tos.h>
# include <stddef.h>
#endif
#ifdef LATTICE
# include <dos.h>
#endif
#ifdef __GNUC__
# include <osbind.h>
#endif

#include "defs.h"
#include "Location.h"


static LOCATION __base = NULL;


/*----------------------------------------------------------------------------*/
static LOCATION
_alloc (size_t size, BOOL tos_path)
{
	LOCATION loc = malloc (sizeof (struct s_location)
	               + size + (tos_path ? 0 : 2));
	loc->__reffs = 0;
	loc->isTos   = tos_path;
	loc->Path    = loc->FullName + (tos_path ? 2 : 0);
	
	return loc;
}

/*============================================================================*/
LOCATION
new_location (const char * src, LOCATION base)
{
	LOCATION loc;
	char   * p;
	size_t   path_ln, file_ln;
	BOOL     is_tos;
	
	if (!__base) {
		char   path[HW_PATH_MAX];
		size_t len;
		path[0] = Dgetdrv() + 'A';
		path[1] = ':';
		Dgetpath (path +2, 0);
		len = strlen (path);
		if (path[len -1] != '\\') {
			path[len++] = '\\';
		}
		__base = _alloc (len, TRUE);
		__base->File  = (char*)memcpy (__base->FullName, path, len) + len;
		__base->FullName[len] = '\0';
	}
	
	if (!base) {
		base = __base;
	}
	if (isalpha(src[0]) && src[1] == ':') {
		is_tos  = TRUE;
		path_ln = 0;
	
	} else if (src[0] == '/') {
		is_tos  = FALSE;
		path_ln = 0;
	
	} else {
		char * end = base->File -1;
		is_tos  = base->isTos;
		
		while (src[0] == '.') {
			if (src[1] == '/' || src[1] == '\\') {
				src += 2;
			} else if (src[1] == '.' && (src[2] == '/' || src[2] == '\\')) {
				while (end > base->Path && *(--end) != *base->Path);
				src += 3;
			} else {
				break;
			}
		}
		if (src[0] == '/' || src[0] == '\\') {
			src++;
		}
		path_ln = end - base->Path +1;
	}
	
	file_ln = strlen (src);
	loc     = _alloc (path_ln + file_ln, is_tos);
	if (is_tos) {
		if (path_ln) {
			if (base->isTos) {
				memcpy (loc->FullName, base->FullName, path_ln +2);
			} else {
				loc->FullName[0] = 'U';
				loc->FullName[1] = ':';
				memcpy (loc->Path, base->Path, path_ln);
			}
		} else {
			path_ln = -2;
		}
		memcpy (loc->Path + path_ln, src, file_ln +1);
		p = loc->Path;
		while ((p = strchr (p, '/')) != NULL) *(p++) = '\\';
		
	} else {
		if (path_ln) {
			memcpy (loc->Path, base->Path, path_ln);
		}
		memcpy (loc->Path + path_ln, src, file_ln +1);
		p = loc->Path;
		while ((p = strchr (p, '\\')) != NULL) *(p++) = '/';
	}
	
	if ((p = strchr (loc->Path, '#')) != NULL) {
		*(p++) = '\0';
		loc->Anchor = p;
	} else {
		loc->Anchor = NULL;
	}
	loc->File = strrchr (loc->Path, loc->Path[0]) +1;
	
	return loc;
}

/*============================================================================*/
void
free_location (LOCATION * _loc)
{
	LOCATION loc = *_loc;
	if (loc) {
		if (!loc->__reffs || !--loc->__reffs) {
			free (loc);
		}
		*_loc = NULL;
	}
}


/*============================================================================*/
LOCATION
location_share  (LOCATION loc)
{
	if (loc) {
		loc->__reffs++;
	}
	return loc;
}
