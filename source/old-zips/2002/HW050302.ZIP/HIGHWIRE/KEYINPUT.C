/* @(#)highwire/keyinput.c
 *
 * This file should contain the keyboard handler
 * routines.  ie. Input to forms, URL address etc
 *
 * right now it just handles hot key for UNDO - back up a page
 * baldrick July 10, 2001
 */


#include <stdlib.h>
#include <ctype.h>

#include <gem.h>

#include "global.h"
#include "Loader.h"
#include "Containr.h"


void
key_pressed (WORD key, WORD state)
{
	extern char last_location[HW_PATH_MAX];
	extern char prev_location[HW_PATH_MAX];
	extern ENCODING prev_encoding;

	switch (key)  /* scan code */
	{
	case 0x6100:  /* Undo */
		new_loader_job (prev_location, NULL,
		                prev_encoding, containr_Base(NULL));
		return;
	case 0x7800:  /* 1 */
		new_loader_job (last_location, NULL,
		                ENCODING_WINDOWS1252, containr_Base(NULL));
		return;
	case 0x7900:  /* 2 */
		new_loader_job (last_location, NULL,
		                ENCODING_ISO8859_2, containr_Base(NULL));
		return;
	case 0x1E00:  /* A */
		new_loader_job (last_location, NULL,
		                ENCODING_ATARIST, containr_Base(NULL));
		return;
	case 0x1600:  /* U */
		new_loader_job (last_location, NULL,
		                ENCODING_UTF8, containr_Base(NULL));
		return;
	}

	if (state & K_CTRL) switch (key & 0x00FF)  /* character */
	{
#ifdef GEM_MENU
	/* change 12-22-01 mj. */
	case 0x0009:  handle_menu(M_ABOUT, NULL); break;
	case 0x000F:  handle_menu(M_OPEN, NULL); break;
	case 0x0011:  handle_menu(M_QUIT, NULL); break;
#else
	case 0x0009:  /* CTRL+I */
		do_info_dialog();
		break;
	case 0x000F:  /* CTRL+O */
		page_load();
		break;
	case 0x0011:  /* CTRL+Q */
		exit(EXIT_SUCCESS);
		break;
#endif
	}
}
