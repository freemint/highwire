#include <stdlib.h>
#include <string.h> /* memcpy */
#include <time.h>
#include <gemx.h>

#include "global.h"
#include "Location.h"


IMAGE
new_image (short w, short h, const char * file, LOCATION base)
{
	IMAGE img = malloc (sizeof(struct s_image));
	
	if (w <= 0) w = 16;
	if (h <= 0) h = 16;
	
	img->fd_addr    = NULL;
	img->fd_w       = w;
	img->fd_h       = h;
	img->fd_wdwidth = (w + 15) / 16;
	img->fd_stand   = FALSE;
	img->fd_nplanes = 1;
	img->fd_r1 = img->fd_r2 = img->fd_r3 = 0;
	
	img->alt_w  = 0;
	img->alt_h  = 0;
	img->fgnd   = G_BLACK;
	img->bgnd   = G_WHITE;
	
	img->disp_w = img->fd_w;
	img->disp_h = img->fd_h;
	
	return img;
}
