#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#include "global.h"

void
destroy_paragraph_structure (PARAGRPH current_paragraph)
{
	struct paragraph_item *temp;

	while (current_paragraph != 0)
	{
		if (current_paragraph->item != 0)
			destroy_word_structure (current_paragraph->item);
#ifndef _NEW_TABLES
		if (current_paragraph->table != 0)
			destroy_table_structure (current_paragraph->table);
#endif
		temp = current_paragraph->next_paragraph;
		free (current_paragraph);
		current_paragraph = temp;
	}
}


PARAGRPH
new_paragraph (TEXTBUFF current)
{
	PARAGRPH paragraph = malloc (sizeof (struct paragraph_item));

	paragraph->item  = new_word (current, NULL, TRUE);
#ifndef _NEW_TABLES
	paragraph->table = NULL;
#else
	paragraph->Table = NULL;
#endif
	paragraph->Indent         = 0;
	paragraph->paragraph_code = PAR_NONE;
	paragraph->alignment      = left;
	paragraph->left_border    = 0;
	paragraph->right_border   = 0;
	paragraph->eop_space      = 0;
	paragraph->current_paragraph_height = 0;
	paragraph->min_width      = 0;
	paragraph->max_width      = 0;
	
	paragraph->area.x = 0;
	paragraph->area.y = 0;
	paragraph->area.w = 0;
	paragraph->area.h = 0;

	paragraph->next_paragraph = NULL;
	
	current->word = paragraph->item;
	
	return (paragraph);
}


/* add_paragraph()
 * 
 * Creates a new paragraph structure and links it into list
 * also creates a new word item and links it into the new paragraph
 *
 * 12/14/01 - modified to use frame_item info and directly modify frame - baldrick
 *
 * AltF4 - Jan. 20, 2002:  replaced malloc of struct word_item by new_word().
 *
 */

PARAGRPH
add_paragraph (TEXTBUFF current)
{
	PARAGRPH paragraph = malloc (sizeof (struct paragraph_item));

	word_store (current);

	paragraph->item  = new_word (current, current->word , FALSE);
#ifndef _NEW_TABLES
	paragraph->table = NULL;
#else
	paragraph->Table = NULL;
#endif
	paragraph->Indent         = current->paragraph->Indent;
	paragraph->paragraph_code = PAR_NONE;
	paragraph->alignment      = current->paragraph->alignment;
	paragraph->left_border    = current->paragraph->left_border;
	paragraph->right_border   = current->paragraph->right_border;
	paragraph->eop_space = 0;
	paragraph->current_paragraph_height = 0;
	paragraph->min_width = 0;
	paragraph->max_width = 0;
	paragraph->area.x = 0;
	paragraph->area.y = 0;
	paragraph->area.w = 0;
	paragraph->area.h = 0;
	
	paragraph->next_paragraph = NULL;
	
	current->paragraph->next_paragraph = paragraph;
	current->paragraph                 = paragraph;
	current->word                      = paragraph->item;
	
	return paragraph;
}


/* content_minimum()
 *
 * Returns the smallest width that is nedded for a list of paragraphs.
 */
WORD
content_minimum (PARAGRPH paragraph)
{
	WORD width = 0;
	while (paragraph) {
		short min_width = paragraph->min_width + paragraph->Indent;
		if (width < min_width) {
			 width = min_width;
		}
		paragraph = paragraph->next_paragraph;
	}
	return width;
}

/* content_maximum()
 *
 * Returns the largest width that occures in a list of paragraphs.
 */
long
content_maximum (PARAGRPH paragraph)
{
	long max_width = 0;
	while (paragraph) {
		if (!paragraph->max_width) {
			struct word_item * word = paragraph->item;
			long width = paragraph->Indent;
			while (word) {
				BOOL ln_brk = word->line_brk;
				if (word->item && (word->item[0] != Space_Code || word->item[1])) {
					width += word->word_width;
				}
				word = word->next_word;
				if (ln_brk || !word) {
					if (paragraph->max_width < width) {
						 paragraph->max_width = width;
					}
					width = paragraph->Indent;
				}
			}
		}
		if (max_width < paragraph->max_width) {
			 max_width = paragraph->max_width;
		}
		paragraph = paragraph->next_paragraph;
	}
	return max_width;
}
