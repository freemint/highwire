

#include <stdlib.h>

#ifdef __PUREC__
#include <tos.h>
#endif

#ifdef __GNUC__
#include <gemx.h>
#endif

#include "global.h"

#ifndef _NEW_TABLES

struct table_step *
new_table_step (struct paragraph_item *p_table, struct table_item *parent)
{
	struct table_step *temp;
	temp = malloc (sizeof (struct table_step));

	temp->entry = p_table;

	temp->parent = parent;

	temp->previous_table_step = 0;

	return (temp);
}

struct table_step *
add_table_step (struct table_step *old, struct paragraph_item *p_table, struct table_item *parent)
{
	struct table_step *temp;

	temp = new_table_step (p_table,parent);
	temp->previous_table_step = old;

	return (temp);
}

struct table_step *
destroy_table_step (struct table_step *current)
{
	struct table_step *temp;

	if (current->previous_table_step != 0)
	{
		temp = current->previous_table_step;
		free (current);

		return (temp);
	}
	else
	{
		free(current);
		return(0);
	}
}

/* ****************************** */

void
destroy_table_structure (struct table_item *current_table)
{
	struct table_child *temp_child;
	struct table_child *current_child;
	struct paragraph_item *current_paragraph;
	
	current_child = current_table->children;
	
	while (current_child != 0)
	{
		current_paragraph = current_child->item;

		destroy_paragraph_structure (current_paragraph);

		temp_child = current_child->next_child;
		free(current_child);
		current_child = temp_child;
	}
			
	free(current_table);
}


struct table_child *
new_table_child (struct frame_item *p_frame)
{
	struct table_child *temp;
	
	temp = malloc (sizeof (struct table_child));

	temp->height = 0;
	temp->width = 0;
	temp->actual_height = 0;
	temp->actual_width = 0;
	temp->min_width = 0;
	temp->alignment = left;
	temp->valignment = bottom;
	temp->colspan = 1;
	temp->rowspan = 1;
	temp->bgcolor = 0;
	temp->item = new_paragraph(p_frame);
	temp->next_child = 0;
	
	return (temp);
}

/* insert empty child
 *
 * the idea of this is to insert an empty child
 * into a tables children list to fill the empty
 * spaces used by colspan and rowspan
 *
 * it should just link a new child into prev->next_child with
 * a pointer to temp->next_child = old prev->next child
 * 
 * baldrick January 31, 2002
 */

struct table_child *
insert_empty_child (struct table_child *prev)
{
	struct table_child *temp;

	temp = malloc (sizeof (struct table_child));

	temp->height = 0;
	temp->width = 0;
	temp->actual_height = 0;
	temp->actual_width = 0;
	temp->min_width = 0;
	temp->alignment = left;
	temp->valignment = bottom;
	temp->colspan = 0;  /* it's empty just a place holder */
	temp->rowspan = 0;
	temp->bgcolor = 0;
	temp->item = 0;
	temp->next_child = prev->next_child;

	prev->next_child = temp;
		
	return (temp);
}

static struct table_row *
new_table_row (struct frame_item *p_frame)
{
	struct table_row *temp;
	
	temp = malloc (sizeof (struct table_row));

	temp->height = 0;
	temp->width = 0;
	temp->actual_height = 0;
	temp->actual_width = 0;
	temp->min_width = 0;
	temp->alignment = left;
	temp->valignment = bottom;
	temp->bgcolor = 0;
	temp->item = new_paragraph(p_frame);
	temp->next_row = 0;
	
	return (temp);
}

struct table_item *
new_table (struct frame_item *p_frame)
{
	WORD i;
	
	struct table_item *temp;

	temp = malloc (sizeof (struct table_item));
	
	temp->num_cols = 0;
	temp->num_rows = 1;
	temp->table_height = 0;
	temp->table_width = 0;
	temp->actual_width = 0;
	temp->min_width = 0;
	temp->alignment = left;
	temp->border = 0;
	temp->cell_spacing = 0;
	temp->cell_padding = 0;
	temp->num_children = 0;
	temp->children = new_table_child(p_frame);
	
	/* clear out col_widths array */
	for (i=0;i<50;i++)
		temp->col_widths[i] = 0;

	return (temp);
}

/*
 * determines the height of a table by walking it's paragraph list
 */
static WORD calculate_subtable_width (struct table_item *current_table, FRAME);


/* set_p_area()
 * 
 * a small routine to set a paragraphs area coordinates
 * just reduces size of code in height calculations
 *
 * baldrick  February 6, 2002
 */
static
void set_p_area(struct paragraph_item *current_paragraph, WORD x, WORD y, WORD w, WORD h)
{
	current_paragraph->area.x = x;
	current_paragraph->area.y = y;
	current_paragraph->area.w = w;
	current_paragraph->area.h = h;
}

/*==============================================================================
 * calculate_table_height()
 *
 * AltF4 - Feb. 24, 2002:  simplified and shortend by using locals instead of
 *                         current... structure members.
 */
long
calculate_table_height (struct table_item *current_table, struct frame_item *frame,long tab_top)
{
	WORD left_indent, right_indent, current_line_width, line_tail = 0, line_height;
	WORD alignment_spacer = 0; /* height_spacer, * unused */
	WORD frame_w;
	long temp_height = 0L;
	long temp_row_height = 0L;
	enum bool clickable_area_exists = false;
	
	struct clickable_area *current_clickable_area = frame->first_clickable_area;
	struct named_location *current_named_location = frame->first_named_location;
	struct url_link       *current_link           = NULL;
	
	WORD temp_val  = 0;
	WORD temp_left = 0;
	long temp_long = 0L;
	WORD i;

	struct table_child * child = current_table->children;
	
	current_table->current_borders.left = 0;
	current_table->actual_width = calculate_table_width(current_table,frame, temp_long);

	if (current_table->actual_width > frame->frame_page_width)
	{
		/* don't let percentage width tables grow the size of the frame
		 */
		if (current_table->table_width >= 0)
			frame->frame_page_width = current_table->actual_width;
		else /* percentage width */
			frame->frame_page_width = current_table->min_width;
	}
	
	frame_w = frame->frame.w;

	if (child->item == NULL)
	{
/*		printf("exiting calc table height with no paragraph\r\n");*/
		return(0);
	}

	current_line_width = current_table->actual_width;
			
	switch (current_table->alignment)
	{
		case center:
			current_table->current_borders.left = (frame_w - current_line_width) / 2;
			break;
		case right:
			current_table->current_borders.left = (frame_w - current_line_width) - 2;
			break;
		case left:
			current_table->current_borders.left = 3;
			break;
		default: /* just assume it's left */
			current_table->current_borders.left = 3;
	}

	current_table->current_borders.left += frame->clip.x;

	if (current_table->border)
		current_table->current_borders.left -= 1;

	current_table->current_borders.left += 1;

	temp_left = current_table->current_borders.left;
	
	while (child)
	{
		struct paragraph_item * paragraph = child->item;
		
		/* check if it's an empty child */
		if (child->colspan == 0)
		{
			temp_val += 1;
			
			temp_height = 0;

			/* if we have finished a ROW advance reset values and advance height */
		
			if (temp_val >= current_table->num_cols)
			{
				temp_val = 0;
				temp_long += temp_row_height;
	
				temp_row_height = 0;
				temp_left = current_table->current_borders.left;
			}

			child = child->next_child;	
			continue;
		}
		
		/* first walk the paragraphs */

		child->actual_height = 0;

		while (paragraph)
		{
			struct word_item * word = paragraph->item;
			
			paragraph->current_paragraph_height = 0;

/*printf("top of while               \r\n");
printf("current child width = %d   \r\n",child->actual_width);
*/
			/* hr = horizontal ruler */
			if (paragraph->paragraph_code == PAR_HR)
			{
				child->actual_width = word->word_width;

				paragraph->current_paragraph_height = abs (word->word_height) + 20;
	
				set_p_area(paragraph,
				  paragraph->left_border + current_table->current_borders.left,
				  (WORD)temp_long,
				  word->word_width,
				  (WORD)(paragraph->current_paragraph_height));

				child->actual_height = paragraph->current_paragraph_height;

				temp_height += paragraph->current_paragraph_height;
				temp_left   += word->word_width;
			}
			else if (paragraph->paragraph_code == PAR_IMG)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 *
				 * I believe this note is outdated and can be removed
				 * baldrick
				 */

				if (child->actual_width == 0)
					child->actual_width = word->word_width;

				paragraph->current_paragraph_height = abs (word->word_height);

				set_p_area(paragraph,
				 paragraph->left_border + current_table->current_borders.left,
				 (WORD)temp_long + temp_height,
				 word->word_width,
				 (WORD)(paragraph->current_paragraph_height));

				child->actual_height += paragraph->current_paragraph_height;

				temp_height += paragraph->current_paragraph_height;
				temp_left   += word->word_width;
			}
			else if (paragraph->paragraph_code == PAR_TABLE)
			{
				paragraph->table->table_height = calculate_table_height (paragraph->table, frame,temp_long);

				child->actual_height += paragraph->table->table_height;

				paragraph->current_paragraph_height = paragraph->table->table_height;

				set_p_area(paragraph,
				 paragraph->left_border + current_table->current_borders.left,
				 (WORD)temp_long + temp_height,
				 child->actual_width,
				 (WORD)(paragraph->current_paragraph_height));

				temp_height += paragraph->table->table_height;
				temp_left   += word->word_width;
			}
			else
			{
				left_indent  = paragraph->left_border
				             + current_table->current_borders.left + temp_left;
				right_indent = paragraph->right_border; /* + right_border;*/

/*printf("normal text tags      \r\n");
*/
				/* Now walk the words */
				
				while (word)
				{
					struct word_item * line_start = word;
					current_line_width = 0;
					line_height = 0;
					line_tail = 0;	
					clickable_area_exists = false;

/*printf("current_line_width = %d  word width = %d    \r\n",current_line_width,word->word_width);
*/
					while (word != 0 
				       && (current_line_width + word->word_width) < (current_table->actual_width)) /* - left_indent - right_indent))*/
#if 0
/* this above tests second line should be more like this but it doesn't work for some tables */
				       && (current_line_width + word->word_width) < child->actual_width) /*(current_table->actual_width))*/ /* - left_indent - right_indent))*/
#endif
					{
/*printf("current_line_width = %d  word width = %d    \r\n",current_line_width,word->word_width);
*/
						if (word->line_brk && word != line_start)
							break;

						current_line_width += word->word_width;

/*printf("current_line_width = %d  word width = %d    \r\n",current_line_width,word->word_width);
*/
						if (line_height < word->word_height)
							line_height = word->word_height;
						if (line_tail < word->word_tail_drop)
							line_tail = word->word_tail_drop;
						if (word->link != 0)
						{
							if (word->link->mode == lnk_href)
							{
								clickable_area_exists = true;
	
								if (current_link != 0 && word->link == 0)
								{
									current_link = 0;
								}
								else if (current_link == 0 && word->link != 0)
								{
									current_link = word->link;
		
									if (frame->first_clickable_area == 0)
									{
										current_clickable_area = frame->first_clickable_area = new_clickable_area();
									}
									else
									{
										if (current_clickable_area->next_area == 0)
											current_clickable_area->next_area = new_clickable_area();
										current_clickable_area = current_clickable_area->next_area;
									}
		
									current_clickable_area->x = current_table->current_borders.left + current_line_width + alignment_spacer + temp_left;
/*									current_clickable_area->x = current_line_width + alignment_spacer;*/
									current_clickable_area->y = (WORD)(temp_long + paragraph->current_paragraph_height)+(WORD)top;
									current_clickable_area->h =	line_height + line_tail;
									current_clickable_area->w = word->word_width;
									current_clickable_area->link = current_link;
								}
								else if (current_link == word->link)
									current_clickable_area->w += word->word_width;
								else if (current_link != 0  && word->link != 0)
								{
									if (current_clickable_area->next_area == 0)
										current_clickable_area->next_area = new_clickable_area ();
		
									current_clickable_area = current_clickable_area->next_area;
									current_link = word->link;
		
									if (current_clickable_area == 0)
										current_clickable_area = new_clickable_area ();
	
									current_clickable_area->x = current_table->current_borders.left + current_line_width + alignment_spacer + temp_left;
								
	/*								current_clickable_area->y = (WORD)(temp_long + paragraph->current_paragraph_height) + (WORD)top;*/
									current_clickable_area->y = (WORD)(temp_long) + child->actual_height + (WORD)top;
								
									current_clickable_area->h = line_height + line_tail;
									current_clickable_area->w = word->word_width;
									current_clickable_area->link = current_link;
								}
							}
							else
							{
								if (frame->first_named_location == 0)
								{
									current_named_location = frame->first_named_location = 	new_named_location ();
									current_named_location->link = word->link;
									current_named_location->position = temp_long + paragraph->current_paragraph_height + temp_height;
								}
								else
								{
									if (current_named_location->link != word->link)
									{
										if (current_named_location->next_location == 0)
											current_named_location->next_location = new_named_location();
	
										current_named_location = current_named_location->next_location;
										current_named_location->link = word->link;
										current_named_location->position = temp_long + paragraph->current_paragraph_height + temp_height;
									}
								}
							}
						}
/*printf("before next word  \r\n");
*/
						word = word->next_word;
					}

/*printf("after while         \r\n");
*/
					paragraph->current_paragraph_height += line_height + line_tail;
				}

/*printf("after first while     \r\n");
*/
				temp_height += paragraph->current_paragraph_height;

				paragraph->left_border = (temp_left - current_table->current_borders.left);
			
				/* we need to set the y here or it gets modified */
				paragraph->area.y = (WORD)temp_long + child->actual_height;
	
				if (paragraph->eop_space > 0)
					paragraph->current_paragraph_height += paragraph->eop_space;
				else
					temp_long += paragraph->eop_space;
	
				paragraph->area.x = paragraph->left_border;
				paragraph->area.w = current_line_width;
				paragraph->area.h = (WORD)(paragraph->current_paragraph_height);
	
/*	printf("area.w = %d  \r\n",current_line_width);		*/
	
				child->actual_height += paragraph->current_paragraph_height;		
	
				temp_left += current_line_width;
			}
			
/*printf("temp height = %ld  \r\n",temp_height);*/

			paragraph = paragraph->next_paragraph;
		}

		/* test if the html gives a larger size than the data would
		 * warrant.   Baldrick Dec 20, 2001
		 */

/*printf("after paragraph parsing\r\n");*/
		 
		if (child->height > child->actual_height)
			child->actual_height = child->height;

		/* Now check our row height */
		if (child->actual_height > temp_row_height)
			temp_row_height = child->actual_height;

		temp_height = 0;

		temp_val += 1;

		/* if we have finished a ROW advance reset values and advance height */
		
		if (temp_val >= current_table->num_cols)
		{
			temp_val = 0;
			temp_long += temp_row_height;

			temp_row_height = 0;
			temp_left = current_table->current_borders.left;
		}

		child = child->next_child;
	}

/*printf("before resort of the table   \r\n");*/

	/* Ok now resort the whole mess, could probably be done better, but I'm mentally exhausted - baldrick 11/27/01 */

	temp_val = 0;
	child    = current_table->children;
	while (child)
	{
		struct paragraph_item * paragraph = child->item;
	
		temp_left = 0;
		for (i = 0; i < temp_val; i++)
			temp_left += current_table->col_widths[i];

		/* first walk the paragraphs */

		while (paragraph)
		{
			paragraph->area.x = paragraph->left_border = temp_left;

			paragraph = paragraph->next_paragraph;
		}

		if ( current_table->num_cols > 1)
		{
			temp_val += 1;

			if (temp_val >= current_table->num_cols)
				temp_val = 0;
		}
		
		child = child->next_child;
	}

/*printf("calc table height returning %ld         \r\n",temp_long);
*/

	return (temp_long);
}

 
/*------------------------------------------------------------------------------
 * walk_table_children()
 *
 * table_item.temp_val is used to count the current column that the routine
 * is walking.
 *
 * AltF4 - Feb. 24, 2002:  simplified and shortend by using locals instead of
 *                         current... structure members.
 */
static void
walk_table_children (struct table_item *current_table, FRAME frame)
{
	struct table_child * child = current_table->children;
	
	WORD column = -1; /* set the current column just befor the start */

	if (child->item == NULL)
	{
/*		printf("exiting walk table children with no paragraph\r\n");*/
		return;
	}

	while (child)
	{
		struct paragraph_item * paragraph = child->item;
		
		if (++column >= current_table->num_cols)
			column = 0;
		
		/* check if it's an empty child */
		
		if (child->colspan == 0)
		{
			child = child->next_child;	
			continue;
		}

		/* first walk the paragraphs */
		
		while (paragraph)
		{
			struct word_item * word = paragraph->item;

			/* hr = horizontal ruler */
			if (paragraph->paragraph_code == PAR_HR)
			{
				child->actual_width = word->word_width;
			}
			else if (paragraph->paragraph_code == PAR_IMG)
			{
				/* you might think that we should add the objects
				 * height as we process it in this section...
				 *
				 * However with tests this just adds junk to the bottom
				 * of the file and messes up all the link locations
				 *
				 * baldrick August 30, 2001
				 */

				/* if the width isn't predefined */
				if (child->actual_width == 0)
					child->actual_width = word->word_width;

			}
			else if (paragraph->paragraph_code == PAR_TABLE)
			{
				paragraph->table->actual_width
				          = calculate_subtable_width (paragraph->table, frame);
				child->actual_width = paragraph->table->actual_width;
				
			}
			else /* normal text paragraph */
			{
				/* Now walk the words */
				while (word)
				{
					WORD line_width = 0;
					
					while (word && word->line_brk) {
						word = word->next_word;
					}
					while (word && (line_width + word->word_width) < frame->frame.w)/* - left_indent - right_indent))*/
					{
						if (word->line_brk)
							break;
						
						line_width += word->word_width;
						word = word->next_word;
					}
					line_width += current_table->cell_padding;
					if (line_width > child->actual_width)
						child->actual_width = line_width;
				}
			}
			
			paragraph = paragraph->next_paragraph;
		}

		/* test if the html gives a larger size than the data would
		 * warrant.   Baldrick Dec 20, 2001
		 */
		 
		if (child->width > child->actual_width)
			child->actual_width = child->width;

		if (child->actual_width > current_table->col_widths[column])
			current_table->col_widths[column] = child->actual_width;

		child = child->next_child;
	}
}

/*
 * determines the width of a table by walking it's paragraph list
 */

WORD
calculate_table_width (struct table_item *current_table, struct frame_item *frame,long tab_top)
{
	WORD current_width = 0, max_width = 0, padding = 0;
	int  i;
	
	/* is this a forced width table? */
	if (current_table->table_width > 0)
	{
		/* we still need to walk the childrent to get the col_widths */
		
		struct table_child * child = current_table->children;
		
		walk_table_children (current_table, frame);

	#if 0  /* already done by walk_table_children() */
	
		while (child)
		{
			if (child->actual_width > current_table->col_widths[i])
				current_table->col_widths[i] = child->actual_width;
		
			if ( current_table->num_cols > 1)
			{
				i += 1;
	
				if (i >= current_table->num_cols)
					i = 0;
			}

			child = child->next_child;
		}
	#endif

/*		for (i = 0; i < current_table->num_cols; i++)
			printf("col[ %d ] = %d   \r\n",i,current_table->col_widths[i]);
		
*/
		return(current_table->table_width);
	}
	

	/* Is the table size relative to frame width? */
	if (current_table->table_width < 0)
	{
		/* reset the col_widths array to keep tables from growing */
		
		for (i = 0; i < current_table->num_cols; current_table->col_widths[i++] = 0);

		/* get the child widths */
		
		walk_table_children (current_table, frame);

		/* set current width after the children incase we ran through
		 * subtables
		 */
		 
		current_width = (WORD)((long)current_table->table_width * (frame->clip.w / 10L) / -10L) - 10;

		/* reset min width */
		
		current_table->min_width = 0;
		
		/* get the minimum width for the table */

		for (i = 0; i < current_table->num_cols; i++)
			current_table->min_width += current_table->col_widths[i];

		/* is the minimum table width larger than frame.clip width? */

		if (current_table->min_width > current_width)
			return(current_table->min_width);
		else
		{
			/* Ok clip area viewport is larger than the minimum width
			 * so we will now get the difference between the two areas
			 * and divide it out across the columns to even up the
			 * up the presentation.
			 */

			max_width = current_width - current_table->min_width;
			
			padding = max_width/current_table->num_cols;
					
			for (i = 0; i < current_table->num_cols; i++)
				current_table->col_widths[i] += padding;

			return(current_width);
		}
	}

	walk_table_children (current_table, frame);

	for (i = 0; i < current_table->num_cols; i++)
		max_width += current_table->col_widths[i];
	
	return (max_width);
}

/*------------------------------------------------------------------------------
 * calculate_subtable_width()
 *
 * hopefully this can be fully re entrant when finished
 */

static WORD
calculate_subtable_width (struct table_item *current_table, FRAME frame)
{
	WORD current_width = 0, max_width = 0, padding = 0;
	WORD column = 0;
	
	/* is this a forced width table? */
	if (current_table->table_width > 0)
	{
		struct table_child * child = current_table->children;
		
		/* we still need to walk the children to get the col_widths */

		walk_table_children (current_table, frame);
		
		while (child != 0)
		{
			if (child->actual_width > current_table->col_widths[column])
				current_table->col_widths[column] = child->actual_width;
		
			if ( current_table->num_cols > 1)
			{
				column += 1;
	
				if (column >= current_table->num_cols)
					column = 0;
			}
			
			child = child->next_child;
		}

/*		for (column = 0; column < current_table->num_cols; column++)
			printf("col[ %d ] = %d   \r\n",column,current_table->col_widths[column]);
*/		

		return(current_table->table_width);
	}
	

	/* Is the table size relative to frame width? */
	if (current_table->table_width < 0)
	{
		/* reset the col_widths array to keep tables from growing */
		
		for (column = 0; column < current_table->num_cols; column++)
			current_table->col_widths[column] = 0;

		/* get the child widths */
		
		walk_table_children (current_table, frame);

		/* set current width after the chilren incase we ran through
		 * subtables
		 */
		 
		current_width = (WORD)((long)current_table->table_width * (frame->clip.w / 10L) / -10L) - 10;

		/* reset min width */
		
		current_table->min_width = 0;
		
		/* get the minimum width for the table */

		for (column = 0; column < current_table->num_cols; column++)
			current_table->min_width += current_table->col_widths[column];

		/* is the minimum table width larger than frame.clip width? */

		if (current_table->min_width > current_width)
			return(current_table->min_width);
		else
		{
			/* Ok clip area viewport is larger than the minimum width
			 * so we will now get the diference between the two areas
			 * and divide it out across the columns to even up the
			 * up the presentation.
			 */

			max_width = current_width - current_table->min_width;
			
			padding = max_width/current_table->num_cols;
					
			for (column = 0; column < current_table->num_cols; column++)
				current_table->col_widths[column] += padding;

			return(current_width);
		}
	}

	walk_table_children (current_table, frame);

	for (column = 0; column < current_table->num_cols; column++)
		max_width += current_table->col_widths[column];
	
	return (max_width);
}


#if 0
/* I just like these for dumping output to the screen so I've stuck
   them down here in case I need them again
   */
		v_ftext16 (vdi_handle, 10, 10, frame->current_word->item);

		vswr_mode(vdi_handle,1);
		v_ftext16 (vdi_handle, 10, current_height + 30, frame->current_word->item);
#endif


#endif _NEW_TABLES
