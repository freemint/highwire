/* @(#)highwire/Mouse_R.c
 */


#include <stdlib.h>
#include <string.h>

#include <gemx.h>

#include "global.h"
#include "Containr.h"
#include "Loader.h"


void
button_clicked (struct frame_item *first_frame, WORD mx, WORD my)
{
	struct frame_item *current_frame;

	current_frame = first_frame;

	while (current_frame)
	{
		if (((current_frame->v_scroll_on && mx < current_frame->clip.x + current_frame->clip.w + scroll_bar_width)
			||(current_frame->v_scroll_on == FALSE && mx < current_frame->clip.x + current_frame->clip.w))
		    && mx > current_frame->clip.x
		    && my > current_frame->clip.y)
		{

		    if ((current_frame->h_scroll_on && my < current_frame->clip.y + current_frame->clip.h + scroll_bar_width)
		    	|| (my < current_frame->clip.y + current_frame->clip.h))
				{
					frame_clicked (current_frame, mx, my);
					return;
				}
		}
		current_frame = frame_next (current_frame);
	}
}


/*
 * handles mouse interaction with a frame */
void
frame_clicked (struct frame_item *current_frame, WORD mx, WORD my)
{
	WORD distance = 0, mouse_button_state, u;
	WORD slider_length, slider_pos, scroll_length;

	/* *************** Vertical scroll **************       */

	if (current_frame->v_scroll_on
	    && mx > current_frame->clip.x + current_frame->clip.w)
	{
		scroll_length = current_frame->clip.h - 1 - scroll_bar_width * 2;

		slider_length = (WORD)(((long)current_frame->clip.h * (long)scroll_length) /
			 current_frame->page_height);

		if (slider_length < scroll_bar_width)
			slider_length = scroll_bar_width;

		slider_pos =
			((scroll_length - slider_length) * current_frame->vertical_scroll /
			 (current_frame->page_height - current_frame->clip.h)) +
			current_frame->clip.y + scroll_bar_width + 1;

		if (my < current_frame->clip.y + scroll_bar_width)
		{
			/* up arrow */

			if (current_frame->vertical_scroll - scroll_step > -1)
				distance = scroll_step;
			else if (current_frame->vertical_scroll > 0)
				distance = (WORD)current_frame->vertical_scroll;

			if (distance != 0)
			{
				current_frame->vertical_scroll -= (long)distance;
				blit_block (current_frame, distance, d_up);
			}
		}
		else if (my < slider_pos)
		{
			/* page up */

			if ((WORD)current_frame->vertical_scroll - current_frame->clip.h - scroll_step > -1)
				distance = current_frame->clip.h - scroll_step;
			else if (current_frame->vertical_scroll > 0)
				distance = (WORD)current_frame->vertical_scroll;

			if (distance != 0)
			{
				current_frame->vertical_scroll -= (long)distance;

			/*	redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			*/
				containr_redraw (current_frame->Container, NULL);
			}
		}
		else if (my < slider_pos + slider_length)
		{		/* slider */
			graf_mkstate (&mx, &my, &mouse_button_state, &u);
			if (mouse_button_state != 0)
			{
				graf_dragbox (scroll_bar_width, slider_length,
					      current_frame->clip.x + current_frame->clip.w,
					      slider_pos,
					      current_frame->clip.x + current_frame->clip.w,
					      current_frame->clip.y + scroll_bar_width,
					      scroll_bar_width, scroll_length, &u, &slider_pos);
				slider_pos -= current_frame->clip.y + scroll_bar_width;
				current_frame->vertical_scroll =
					(current_frame->page_height -
					 current_frame->clip.h) * slider_pos / (scroll_length -
										slider_length);
				distance = 1;
				
			/*	redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			*/
				containr_redraw (current_frame->Container, NULL);
			}
		}
		else if (my < current_frame->clip.y + current_frame->clip.h - scroll_bar_width)
		{
			/* page down */

			if (current_frame->vertical_scroll + current_frame->clip.h - scroll_step <
			    current_frame->page_height - current_frame->clip.h)
				distance = current_frame->clip.h - scroll_step;
			else
				if (current_frame->vertical_scroll <
				    current_frame->page_height - current_frame->clip.h)
				distance = (WORD)
					(current_frame->page_height -
					current_frame->vertical_scroll - (long)current_frame->clip.h);
			if (distance != 0)
			{
				current_frame->vertical_scroll += distance;
				
			/*	redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			*/
				containr_redraw (current_frame->Container, NULL);
			}
		}
		else if (my < current_frame->clip.y + current_frame->clip.h)
		{
			/* scroll down */
			if (current_frame->vertical_scroll + scroll_step <
			    current_frame->page_height - current_frame->clip.h)
				distance = scroll_step;
			else
				if (current_frame->vertical_scroll < (current_frame->page_height - (long)current_frame->clip.h))
				distance = (WORD)(current_frame->page_height - 
					current_frame->vertical_scroll - (long)current_frame->clip.h);

			if (distance != 0)
			{
				current_frame->vertical_scroll += distance;
				blit_block (current_frame, distance, d_down);
			}
		}
		if (distance != 0) {
			extern void draw_vbar (FRAME, BOOL complete);
			draw_vbar (current_frame, FALSE);
		}
/*			draw_frame_borders (current_frame, 1);
*/
	}
	/* ******** Horizontal Scroll *********** */

	else if (current_frame->h_scroll_on
		 && my > current_frame->clip.y + current_frame->clip.h)
	{
		scroll_length = current_frame->clip.w - 1 - (scroll_bar_width * 2);

		slider_length = (WORD)((long)current_frame->clip.w * (long)scroll_length / 
			(long)current_frame->page_width);

		if (slider_length < scroll_bar_width)
			slider_length = scroll_bar_width;

		slider_pos =
			((scroll_length - slider_length) * current_frame->horizontal_scroll /
			 (current_frame->page_width - current_frame->clip.w)) + current_frame->clip.x +
			scroll_bar_width + 1;

		if (mx < current_frame->clip.x + scroll_bar_width)
		{
			/* left arrow */

			if (current_frame->horizontal_scroll - scroll_step > -1)
				distance = scroll_step;
			else if (current_frame->horizontal_scroll > 0)
				distance = current_frame->horizontal_scroll;

			if (distance != 0)
			{
				current_frame->horizontal_scroll -= distance;
				blit_block (current_frame, distance, d_left);
			}
		}
		else if (mx < slider_pos)
		{
			/* page left */

			if (current_frame->horizontal_scroll - current_frame->clip.w - scroll_step > -1)
				distance = current_frame->clip.w - scroll_step;
			else if (current_frame->horizontal_scroll > 0)
				distance = current_frame->horizontal_scroll;

			if (distance != 0)
			{
				current_frame->horizontal_scroll -= distance;
				
			/*	redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			*/
				containr_redraw (current_frame->Container, NULL);
			}
		}
		else if (mx < (slider_pos + slider_length))
		{
			/* the horizontal slider */

			graf_mkstate (&mx, &my, &mouse_button_state, &u);

			if (mouse_button_state != 0)
			{
				graf_dragbox (slider_length, scroll_bar_width, slider_pos,
					      current_frame->clip.y + current_frame->clip.h,
					      current_frame->clip.x + scroll_bar_width,
					      current_frame->clip.y + current_frame->clip.h,
					      scroll_length, scroll_bar_width, &slider_pos, &u);

				slider_pos -= current_frame->clip.x + scroll_bar_width;

				current_frame->horizontal_scroll =
					(current_frame->page_width -
					 current_frame->clip.w) * slider_pos / (scroll_length -
										slider_length);
				distance = 1;
				
			/*	redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			*/
				containr_redraw (current_frame->Container, NULL);
			}
		}
		else if (mx < current_frame->clip.x + current_frame->clip.w - scroll_bar_width)
		{
			/* page right */

			if (current_frame->horizontal_scroll + current_frame->clip.w - scroll_step < current_frame->page_width - current_frame->clip.w)
				distance = current_frame->clip.w - scroll_step;
			else if (current_frame->horizontal_scroll < current_frame->page_width - current_frame->clip.w)
				distance = current_frame->page_width - current_frame->horizontal_scroll - current_frame->clip.w;

			if (distance != 0)
			{
				current_frame->horizontal_scroll += distance;
				
			/*	redraw_frame (window_handle, current_frame->clip.x,
					      current_frame->clip.y, current_frame->clip.w,
					      current_frame->clip.h, current_frame);
			*/
				containr_redraw (current_frame->Container, NULL);
			}
		}
		else if (mx < current_frame->clip.x + current_frame->clip.w)
		{
			/* right arrow */

			if (current_frame->horizontal_scroll + scroll_step < current_frame->page_width - current_frame->clip.w)
				distance = scroll_step;
			else if (current_frame->horizontal_scroll < current_frame->page_width - current_frame->clip.w)
				distance = current_frame->page_width - current_frame->horizontal_scroll - current_frame->clip.w;

			if (distance != 0)
			{
				current_frame->horizontal_scroll += distance;
				blit_block (current_frame, distance, d_right);
			}
		}

		if (distance != 0) {
			extern void draw_hbar (FRAME, BOOL complete);
			draw_hbar (current_frame, FALSE);
		}
/*			draw_frame_borders (current_frame, 1);
*/
	}

	/* *********** Clickable areas ************* */

	else if (current_highlighted_link_area)
	{
		if (*current_highlighted_link_area->link->address == '#')
		{
			char * temp = strdup (current_highlighted_link_area->link->address);

			current_highlighted_link_frame->frame_named_location = translate_address (temp);
			containr_redraw (current_highlighted_link_frame->Container, NULL);
		}
		else
		{
			CONTAINR cont = (current_highlighted_link_area->link->target
			        ? containr_byName (current_highlighted_link_frame->Container,
			                           current_highlighted_link_area->link->target)
			        : NULL);
			if (!cont) {
				cont = current_highlighted_link_frame->Container;
			}
			new_loader_job (current_highlighted_link_area->link->address,
			                current_highlighted_link_frame->Location,
			                current_highlighted_link_area->link->encoding, cont);
		}
	}
}


/* check_mouse_position()
 *
 * find the actual clickable to be highlighted.
 *
 * AltF4 - Feb. 17, 2002:  reworked to make use of container funtions and avoid
 *                         access of the global the_firt_frame and frame_next().
 */
void
check_mouse_position (struct frame_item *current_frame, WORD mx, WORD my)
{
	CONTAINR cont;

	current_frame = current_highlighted_link_frame;

	if (current_frame && current_highlighted_link_area)
	{
		long x_abs = (long)current_frame->clip.x - current_frame->horizontal_scroll;
		long y_abs = (long)current_frame->clip.y - current_frame->vertical_scroll;
		GRECT area;
		area.g_x = x_abs + current_highlighted_link_area->offset.X;
		area.g_y = y_abs + current_highlighted_link_area->offset.Y;
		if (mx >= area.g_x && mx < area.g_x + current_highlighted_link_area->w &&
		    my >= area.g_y && my < area.g_y + current_highlighted_link_area->h) {
			/*
			 * the mouse pointer is still inside the actual clickable area,
			 * so nothing to redraw
			 */
			return;

		} else {
			area.g_w = current_highlighted_link_area->w;
			area.g_h = current_highlighted_link_area->h,
			cont     = current_highlighted_link_frame->Container;

			current_highlighted_link_frame = NULL;
			current_highlighted_link_area  = NULL;
			graf_mouse (ARROW, NULL);
			containr_redraw (cont, &area);
		}
	}

	cont = (current_frame ? current_frame->Container : NULL);
	if ((cont = containr_byCoord (cont, mx, my)) != NULL &&
	    (current_frame = containr_Frame (cont))  != NULL) {

		struct clickable_area *current_area = current_frame->first_clickable_area;
		long x_abs = (long)current_frame->clip.x - current_frame->horizontal_scroll;
		long y_abs = (long)current_frame->clip.y - current_frame->vertical_scroll;

		mx -= x_abs;
		my -= y_abs;

		while (current_area && (
		       mx < current_area->offset.X || mx >= current_area->offset.X + current_area->w ||
		       my < current_area->offset.Y || my >= current_area->offset.Y + current_area->h)) {
			current_area = current_area->next_area;
		}
		if (current_area && current_area->link->mode == lnk_href)
		{
			GRECT area;
			area.g_x = x_abs + current_area->offset.X;
			area.g_y = y_abs + current_area->offset.Y;
			area.g_w = current_area->w;
			area.g_h = current_area->h,

			current_highlighted_link_frame = current_frame;
			current_highlighted_link_area  = current_area;
			graf_mouse (POINT_HAND, NULL);
			containr_redraw (cont, &area);
		}
	}
}
