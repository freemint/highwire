/* @(#)highwire/F_Struct.c
 */
#include <stdlib.h>
#include <string.h>

#include <gem.h>

#include "global.h"
#include "Table.h"
#include "Location.h"


/*==============================================================================
 *
 * creates a new frame structure and initializes it's values
 */
FRAME
new_frame (const char * anchor)
{
	FRAME frame = malloc (sizeof (struct frame_item));

	frame->Container    = NULL;
	frame->Location     = NULL;
	frame->item         = NULL;
	frame->page_minimum = 0;
	frame->page_width   = 0;
	frame->page_height  = 0;
	frame->horizontal_scroll = 0;
	frame->vertical_scroll   = 0;
	frame->v_scroll_on = FALSE;
	frame->h_scroll_on = FALSE;
	frame->border      = FALSE;
	frame->background_colour   = (ignore_colours ? G_WHITE : G_LWHITE);
	frame->text_colour         = G_BLACK;
	frame->link_colour         = link_colour;
	frame->clip.x = 0;
	frame->clip.y = 0;
	frame->clip.w = 0;
	frame->clip.h = 0;
	frame->first_clickable_area = NULL;
	frame->first_named_location = NULL;
	frame->frame_named_location = (anchor   ? strdup (anchor)   : NULL);
	frame->current_list         = NULL;
	frame->encoding = ENCODING_WINDOWS1252; /* common practice instead of ISO-8859-1 */
	frame->current_font_step = NULL;
	frame->current_attr      = NULL;
	frame->TableStack        = NULL;

	frame->current.buffer    = NULL;
	frame->current.text      = NULL;
	frame->current.font_size = POINT_SIZE;
	frame->current.word      = NULL;
	frame->current.paragraph = new_paragraph (&frame->current);

	return frame;
}


/*============================================================================*/
void
delete_frame (FRAME * p_frame)
{
	FRAME frame = *p_frame;
	if (frame->item)
		destroy_paragraph_structure (frame->item);
	if (frame->first_clickable_area)
		destroy_clickable_area_structure (frame->first_clickable_area);
	if (frame->first_named_location)
		destroy_named_location_structure (frame->first_named_location);
	if (frame->frame_named_location) free (frame->frame_named_location);
	free_location (&frame->Location);

	/* current_list */
	/* current_paragraph */
	/* current_font_step */
	/* current_word */
	/* active_word */
	/* parent_table */
	/* current_table */
	/* current_attr */

	if (frame == current_highlighted_link_frame) {
		current_highlighted_link_frame = NULL;
		current_highlighted_link_area  = NULL;
	}

	free (frame);

	*p_frame = NULL;
}


/*============================================================================*/
void
frame_calculate (FRAME frame, const GRECT * clip)
{
   CLICKABLE * clck_ptr = &frame->first_clickable_area, clickable;
   ANCHOR    * anch_ptr = &frame->first_named_location, anchor;
	long  old_width      = (frame->h_scroll_on
	                        ? frame->page_width  - frame->clip.w : 0);
	long  old_height     = (frame->v_scroll_on
	                        ? frame->page_height - frame->clip.h : 0);
	short scrollbar_size = scroll_bar_width;
	
	*(GRECT*)&frame->clip = *clip;
	
	if (frame->border) {
		frame->clip.x++;
		frame->clip.y++;
		frame->clip.w -= 2;
		frame->clip.h -= 2;
		scrollbar_size--;
	}
	
	if (frame->page_minimum <= frame->clip.w) {
		frame->page_width  = frame->clip.w;
		frame->h_scroll_on = FALSE;
	} else {
		frame->page_width  = frame->page_minimum;
		frame->h_scroll_on = TRUE;
		frame->clip.h     -= scrollbar_size;
	}
   frame->page_height = content_calc (frame->item, frame->page_width,
                                      NULL, &clck_ptr, &anch_ptr);
	if (frame->page_height <= frame->clip.h) {
		frame->v_scroll_on = FALSE;
	} else {
		frame->v_scroll_on = TRUE;
		frame->clip.w     -= scrollbar_size;
		
		if (!frame->h_scroll_on) {
			if (frame->page_minimum >= frame->clip.w) {
				frame->page_width  = frame->page_minimum;
				frame->h_scroll_on = TRUE;
				frame->clip.h     -= scrollbar_size;
			} else {
				frame->page_width  = frame->clip.w;
			   clck_ptr = &frame->first_clickable_area;
			   anch_ptr = &frame->first_named_location;
			   frame->page_height = content_calc (frame->item, frame->page_width,
			                                      NULL, &clck_ptr, &anch_ptr);
			}
		}
	}
	*clck_ptr = NULL;
	clickable = frame->first_clickable_area;
	while (clickable) {
		OFFSET * offset = clickable->offset.Origin;
		while (offset) {
			clickable->offset.X += offset->X;
			clickable->offset.Y += offset->Y;
			offset = offset->Origin;
		}
		clickable = clickable->next_area;
	}
	*anch_ptr = NULL;
	anchor    = frame->first_named_location;
	while (anchor) {
		OFFSET * offset = anchor->offset.Origin;
		while (offset) {
			anchor->offset.Y += offset->Y;
			offset = offset->Origin;
		}
		anchor = anchor->next_location;
	}
	
	if (!frame->h_scroll_on) {
		frame->horizontal_scroll = 0;
	
	} else {
		long new_width = frame->page_width - frame->clip.w;
		if (old_width) {
			long scroll = (frame->horizontal_scroll * 1024 + old_width /2)
			            / old_width;
			frame->horizontal_scroll = (scroll * new_width + 512) / 1024;
		}
		if (frame->horizontal_scroll > new_width) {
			 frame->horizontal_scroll = new_width;
		}
	}
	if (!frame->v_scroll_on) {
		frame->vertical_scroll = 0;
	
	} else {
		long new_height = frame->page_height - frame->clip.h;
		if (old_height) {
			long scroll = (frame->vertical_scroll * 1024 + old_height /2)
			            / old_height;
			frame->vertical_scroll = (scroll * new_height + 512) / 1024;
		}
		if (frame->vertical_scroll > new_height) {
			 frame->vertical_scroll = new_height;
		}
	}
}
