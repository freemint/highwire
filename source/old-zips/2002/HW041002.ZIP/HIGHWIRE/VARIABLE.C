
#include "global.h"

/* ******** Variable Definitions ******************* */

/* To be in-program settings */
WORD link_colour = 12;
WORD highlighted_link_colour = 10;
WORD text_colour = 1;
WORD background_colour = 0;

WORD slider_bkg = 9;
WORD slider_col = 8;

/* ignore colors will track whether the user has selected
 * to ignore page level color modifications.
 * It is currently used to track monochrome resolutions.
 */
WORD ignore_colours = 0;


/* Globals */
WORD vdi_handle, window_handle;
WORD win_status; /* 0 normal, 1 Fulled, 2 iconified */
WORD pre_status; /* status before this action */

WORD fonts[3][2][2] = { 
	{ {5031, 5032}, {5033, 5034} },
#ifndef __GNUC__
	{ {5031, 5032}, {5033, 5034} },
	{ {5031, 5032}, {5033, 5034} }
#else
	{ {5993, 5994}, {5995, 5996} },
	{ {5419, 5582}, {5583, 5611} }
#endif
};

/* ok there are 3 font families and these have 2 different effects
   
   What I know so far...

   [font family][bold face][italic face]
   
   font families
     0 - normal font
     1 - header font
     2 - pre font
     
    So you can have
   	header , bold, italic
   	header , bold, normal
   	header , normal, italic
   	...

   
*/

WORD event_messages[8];
WORD number_of_frames_left_to_load = 0;
struct frame_item *the_first_frame;


struct clickable_area *current_highlighted_link_area;
struct frame_item *current_highlighted_link_frame;
