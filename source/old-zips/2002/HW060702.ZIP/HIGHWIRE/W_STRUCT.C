#include <stdlib.h>
#include <string.h>
#include <gemx.h>

#include "global.h"

void
destroy_word_structure (struct word_item *current_word)
{
	struct word_item *temp;

	while (current_word != 0)
	{
		if (current_word->item != 0)
			free (current_word->item);
		if (current_word->link != 0)
			free (current_word->link);
		temp = current_word->next_word;
		free (current_word);
		current_word = temp;
	}
}


/* new_word()
 *
 * creates a new word_item object.  if the 'copy_from' is not NULL it is
 * taken as a source to copy attributes from.  the flag 'changed' determines
 * if the members of the changed struct shall be set or cleared.
 * AltF4 - Jan. 20, 2002
 *
 * modified to take frame_item * for inheritance from frame
 * Baldrick - Feb 28, 2002
 */
 
struct word_item *
new_word (TEXTBUFF current)
{
	struct word_item * copy_from = current->word;
	struct word_item * word      = NULL;

	if (!copy_from) {
		word = malloc (sizeof (struct word_item));
		word->styles.bold       = 0;
		word->styles.italic     = 0;
		word->styles.underlined = 0;
		word->styles.strike     = 0;
		word->styles.font       = normal_font;
		word->styles.font_size  = font_size;
		word->changed.font      = TRUE;
		word->changed.style     = TRUE;
		word->changed.colour    = TRUE;
		word->word_height       = 0;
		word->word_tail_drop    = 0;
		word->colour            = text_colour;
		word->space_width       = 0;
		word->vertical_align    = ALN_BOTTOM;
		word->link              = NULL;
	} else /*if (current->text > current->buffer)*/ {
		word_store (current);
		word = malloc (sizeof (struct word_item));
		word->styles            = copy_from->styles;
		word->changed.font      = FALSE;
		word->changed.style     = FALSE;
		word->changed.colour    = FALSE;
		word->word_height       = copy_from->word_height;
		word->word_tail_drop    = copy_from->word_tail_drop;
		word->colour            = copy_from->colour;
		word->space_width       = copy_from->space_width;
		word->vertical_align    = copy_from->vertical_align;
		if (copy_from->link && copy_from->link->isHref) {
			word->link           = copy_from->link;
		} else {
			word->link           = NULL;
		}
		if (current->paragraph) {
			copy_from->next_word = word;
		}
	}
	if (word) {
		word->item       = NULL;
		word->image      = NULL;
		word->line_brk   = FALSE;
		word->word_width = 0;
		word->next_word  = NULL;
		current->word    = word;
	}
	return current->word;
}


void
word_store (TEXTBUFF current)
{
	PARAGRPH paragraph = current->paragraph;
	size_t   length    = current->text - current->buffer;
	size_t   size      = (length +1) *2;
	WORD pts[8];
	
	current->word->item = malloc (size);
	memcpy (current->word->item, current->buffer, size);
	current->word->item[length] = 0;

	vqt_f_extent16 (vdi_handle, current->word->item, pts);
	pts[2] -= pts[0];
	
	if (current->word->image) {
		current->word->image->alt_w = pts[2];
		pts[2] = current->word->word_width;
	
	} else {
		current->word->word_width = pts[2];
		if (current->buffer[0] == Space_Code) {
			pts[2] -= current->word->space_width +1;
		}
	}
	if (paragraph && (paragraph->min_width < pts[2])) {
		paragraph->min_width = pts[2];
	}
	
	current->text = current->buffer;
}


/* word_set_bold()
 *
 * changes the value of the BOLD status of the current word
*/
void
word_set_bold (TEXTBUFF current, BOOL onNoff)
{
	if (onNoff) {
		if (!current->word->styles.bold++) {
			current->word->changed.font = TRUE;
		}
	} else if (current->word->styles.bold) {
		if (!--current->word->styles.bold) {
			current->word->changed.font = TRUE;
		}
	}
}


/* word_set_italic()
 *
 * changes the value of the ITALIC status of the current word
*/
void
word_set_italic (TEXTBUFF current, BOOL onNoff)
{
	if (onNoff) {
		if (!current->word->styles.italic++) {
			current->word->changed.font = TRUE;
		}
	} else if (current->word->styles.italic) {
		if (!--current->word->styles.italic) {
			current->word->changed.font = TRUE;
		}
	}
}


/* word_set_strike()
 *
 * changes the value of the STRIKE status of the current word
*/
void
word_set_strike (TEXTBUFF current, BOOL onNoff)
{
	if (onNoff) {
		if (!current->word->styles.strike++) {
			current->word->changed.style = TRUE;
		}
	} else if (current->word->styles.strike) {
		if (!--current->word->styles.strike) {
			current->word->changed.style = TRUE;
		}
	}
}


/* word_set_underline()
 *
 * changes the value of the UNDERLINED status of the current word
*/
void
word_set_underline (TEXTBUFF current, BOOL onNoff)
{
	if (onNoff) {
		if (!current->word->styles.underlined++) {
			current->word->changed.style = TRUE;
		}
	} else if (current->word->styles.underlined) {
		if (!--current->word->styles.underlined) {
			current->word->changed.style = TRUE;
		}
	}
}


/* word_set_color()
 *
 * changes the text colour of the current word
*/
void
word_set_color (TEXTBUFF current, WORD color)
{
	if (color != current->word->colour) {
		current->word->colour         = color;
		current->word->changed.colour = TRUE;
	}
}


/* word_set_point()
 *
 * changes the text height in points of the current word
*/
void
word_set_point (TEXTBUFF current, WORD point)
{
	if (point != current->word->styles.font_size) {
		current->word->styles.font_size = point;
		current->word->changed.font     = TRUE;
	}
}


/* word_set_font()
 *
 * changes the font face of the current word
*/
void
word_set_font (TEXTBUFF current, WORD font)
{
	if (font != current->word->styles.font) {
		current->word->styles.font  = font;
		current->word->changed.font = TRUE;
	}
}

