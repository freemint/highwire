/* @(#)highwire/av_prot.c
 */


#include <string.h>
#include <stdlib.h>

#include <gem.h>

#include	"global.h"
#include	"av_comm.h"


int	av_shell_id = -1,					/* Desktop's ID 										*/
		av_shell_status = 0;			/* What AV Commands can desktop do?	*/

/* All GLOBAL memory is merged to one block and allocated in main(). */
char *va_helpbuf;


static short get_avserver(void)
{
	short ret;
	char *av_env;

	if ((av_env = getenv("AVSERVER")) != NULL)
	{
		ret = appl_find(av_env);

		if (ret >= 0)
			return ret;
	}
	else if((ret = appl_find("AVSERVER")) >= 0)
		return ret;
	else if((ret = appl_find("JINNEE  ")) >= 0)
		return ret;
	else if((ret = appl_find("THING   ")) >= 0)
		return ret;
	else if((ret = appl_find("MAGXDESK")) >= 0)
		return ret;
	else if((ret = appl_find("GEMINI  ")) >= 0)
		return ret;
	else if((ret = appl_find("STRNGSRV")) >= 0)
		return ret;
	else if((ret = appl_find("DIRECT  ")) >= 0)
		return ret;
	else if((ret = appl_find("EASY    ")) >= 0)
		return ret;
	else if((ret = appl_find("KAOS    ")) >= 0)
		return ret;

	return -100;
}


BOOL Send_AV(int to_ap_id, int message, const char *data1, const char *data2)
{
	short msg[8];

	#ifdef __PUREC__
		data2 = data2;
	#endif

	/* - 100 to ap id would be no AV server */
	if (to_ap_id == -100)
		return FALSE;

	msg[0] = message;
	msg[1] = gl_apid;

	switch (message)
	{
		case PDF_AV_OPEN_FILE:
			strcpy(va_helpbuf, data1);

			to_ap_id = appl_find("MYPDF   ");
			msg[2] = 0;

			*(char **)&msg[3] = va_helpbuf;
			break;
		case AV_EXIT:
			msg[2] = 0;
			msg[3] = gl_apid;
			break;
		case AV_PROTOKOLL:
		    strcpy(va_helpbuf, "HIGHWIRE");
			msg[2] = 0;
			msg[3] = (2|16);		/* VA_START, Quoting */
			msg[4] = 0;
			msg[5] = 0;
			*(char **)&msg[6] = va_helpbuf;
			break;
		default:
			msg[2] = 0;
			msg[3] = 0;
			break;
	}

	return (appl_write(to_ap_id, 16, msg) != 0);
}

BOOL
Receive_AV(void)
{
	return FALSE;
}

void Init_AV_Protocol(void)
{
	va_helpbuf[0] = 0;

	av_shell_id = get_avserver();

	Send_AV(av_shell_id, AV_PROTOKOLL, NULL, NULL);
}


void Exit_AV_Protocol(void)
{
	if ((av_shell_id >= 0) && (av_shell_status & 1024))
		Send_AV(av_shell_id, AV_EXIT, NULL, NULL);
}


#if 0

BOOL send_vastart(char *path, char *cmdline)
{
	int i;
	char progname[9];
	char *dummy;

	strncpy(progname, path, 8);
	progname[8] = '\0';

	dummy = strrchr(progname, '.');
	if (dummy)
		dummy[0] = '\0';

	/* make certain the name is 8 char long */
	while (strlen(progname) < 8)
		strcat(progname, " ");

	/* make certain the name is uppercase */
	strupr(progname);

	if ((i = appl_find(progname)) >= 0)
	{
    	strcpy(va_helpbuf, (char *)&cmdline[1]);

		send_extmessage(i, VA_START, 0, (int)(((long)va_helpbuf >> 16) & 0x0000ffff), (int)((long)va_helpbuf & 0x0000ffffL), 0, 0, 0);

		return TRUE;
	}

	return FALSE;
}

#endif
