#include <stdlib.h>
#include <stdio.h>

#ifdef __PUREC__
#include <tos.h>

#else /* LATTICE || __GNUC__ */
#include <mintbind.h>
#endif

#include <gemx.h>

#include "global.h"
#include "schedule.h"


static void highwire_ex(void);


VDI_Workstation dev;

#ifdef GEM_MENU
OBJECT   *about;
OBJECT	*menutree;
#endif

WORD planes;

static EVMULT_IN multi_in = {
	MU_MESAG|MU_BUTTON|MU_TIMER|MU_KEYBD|MU_M1,
	1, 1, 1,	                    /* MOUSE - 1 click,left button,left button */
	MO_LEAVE, { -1,-1, 1, 1 },   /* M1 */
	0,        {  0, 0, 0, 0 },   /* M2 */
	1, 0                       /* Timer */
};


int
main (int argc, char **argv)
{
	WORD u, x, y, w, h; /*, result, mx, my, key = 0;*/
	enum bool quit = false;
	WORD vwork_out[57]; /*, numSets , id; * unused */
	WORD AES_type;

#ifdef USE_LIBWWW
	char def_address[] = "http://wh58-508.st.uni-magdeburg.de/sparemint/index.html";
#else
	char def_address[]="html\\highwire.htm";
#endif

	char *address; /*, name[], name2[]="Dies ist ein langer Text";*/

	if (argc > 1)
		address = argv[1];
	else
		address = def_address;

	/* handle network layer startup */
	
	if (!init_netlayer())
		return(0);

	if ((vdi_handle = V_Opnvwk (&dev)) <= 0) {
		exit (1);
	}
	atexit (highwire_ex);
	
	if (appl_init() < 0) {
		exit (1);
	}

	vq_extnd(vdi_handle, 1, vwork_out);
	planes = vwork_out[4];
	
	if (planes < 2) /* monochrome ? */
	{
		/* set the scroller widget colors for monochrome */
		slider_bkg = 0;
		slider_col = 0;
		
		/* turn ignore_colours on so that we can read the text
		 * on a monochrome display
		 */
		 
		ignore_colours = 1;
	}

	/* identify the AES and issue appropriate initialization calls
	 */
	 	
	AES_type = identify_AES();

	/* This should fix single TOS but Geneva without MiNT will probably
	 * still fail
	 * baldrick Dec 21, 2001
	 */

	if( AES_type != AES_single ) 
	{
		shel_write(9,1,1,"","");
				
		(void)Pdomain(1);
	}
	
	if (can_mxalloc())
		va_helpbuf = (char *) Mxalloc(250,ALLOCMODE);
	else
		va_helpbuf = (char *) Malloc(250);

	Init_AV_Protocol();

#ifdef GEM_MENU
	if( rsrc_load( "highwire.rsc" ))               /* Resource laden */
	{
			rsrc_gaddr(R_TREE, MENUTREE, &menutree);
			rsrc_gaddr(R_TREE, ABOUT, &about);

			menu_bar(menutree, 1);
	}
#endif

	/* grab the screen colors for later use */
	save_colors();

	wind_get (DESK, WF_WORKXYWH, &x, &y, &w, &h);
	window_handle = wind_create (NAME + CLOSER + FULLER + MOVER + SMALLER + SIZER + INFO, x, y, w, h);

	wind_set_str (window_handle, WF_INFO, address);

/*	wind_set (window_handle, WF_BEVENT, 1, 0, 0, 0);
*/

	/* init paths and load config */
	init_paths();

/*	numSets= */ 
	vst_load_fonts (vdi_handle, 0);

	vst_scratch (vdi_handle, SCRATCH_BOTH);
	vst_kern (vdi_handle, TRACK_NORMAL, PAIR_ON, &u, &u);
	vswr_mode (vdi_handle, MD_TRANS);
	
	vst_font (vdi_handle, fonts[0][0][0]);
	vst_charmap (vdi_handle, 0); /* 0 = Bitstream mapping 1 = Atari Ascii mapping */

#if 0

/* I disabled this and left the old in place since this didn't really work yet */

    id = vqt_name(vdi_handle, 2, name );        /* 2. Zeichensatz  */
    vst_font( vdi_handle, id );                 /* ausw�hlen       */
    v_gtext( vdi_handle, 100, 100, name2 );      /* benutzen   */
    
#endif

	init_load(address);

	while (quit != true)
	{
		EVMULT_OUT out;
		short      event = evnt_multi_fast (&multi_in, event_messages, &out);
		
		if (event & MU_M1) {
			check_mouse_position (the_first_frame,
			                      out.emo_mouse.p_x, out.emo_mouse.p_y);
			/* set new mouse watch coordinates */
			*(PXY*)&multi_in.emi_m1 = out.emo_mouse;
		}
		if (event & MU_MESAG) {
			quit = process_messages (the_first_frame);
		}
		if (event & MU_BUTTON) {
			button_clicked (the_first_frame, out.emo_mouse.p_x, out.emo_mouse.p_y);
		}
		if (event & MU_KEYBD) {
			key_pressed (the_first_frame, out.emo_kreturn);
		}
		schedule (1);
	}

	return 0;
}

static void
highwire_ex (void) 
{
	if (gl_apid > 0) {
		
		Exit_AV_Protocol();
	
	#ifdef GEM_MENU
		menu_bar(menutree, 0);
		rsrc_free();
	#endif
		
		appl_exit ();
	}
	vst_unload_fonts (vdi_handle, 0);
	v_clsvwk         (vdi_handle);

	close_netlayer();
}

#ifdef GEM_MENU

void 
do_info_dialog(void)
{
    form_alert(1,"[1][Highwire HTML Browser|GEM Menu v. 0.1|Core v. 0.2|http://highwire.atari-users.net/][ok]");
}

void 
handle_menu(WORD item, WORD *msg)
{
	if (msg)
  		menu_tnormal(menutree,msg[3],1);      /* Kopfzeile normal */

	switch(item)
	{
		case M_ABOUT:
			do_info_dialog();
			break;
		case M_OPEN:
			(void)page_load();
			break;
		case M_QUIT:
			exit (0);
			break;

	}
}

#endif
