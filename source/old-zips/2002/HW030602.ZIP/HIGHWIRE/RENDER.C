#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h> /* just for printf for testing */

#include "token.h" /* must be included before gem/gemx.h */
#include <gemx.h>

#include "global.h"
#include "scanner.h"
#include "parser.h"
#include "Containr.h"
#include "Loader.h"
#ifndef LATTICE
# include "stptok.h"
#endif


char window_title[80];


WORD
convert_to_number (const char *text)
{
	char *next;
	long value;

	if (*text == '"')
		text++;
		
	value = strtol (text, &next, 0);

	/* XXX */
	if (next && *next == '%')
		value = -value;

	return value;
}

WORD
map (char symbol)
{
	if (symbol == ' ')
		return (Space_Code);
		
	return ((WORD) (symbol - 32));
}

WORD
list_indent (WORD type)
{
	switch (type)
	{
		case 0:
			return (POINT_SIZE * 2);
		case 1:
			return (POINT_SIZE * 3);
		case 2:
			return (POINT_SIZE * 4);
	}
	return (0);
}


/* set_pre_font()
 *
 * just a couple of lines that modify the current font to being 
 * the PRE font.
 * Used in numerous places
 *
 *  current_word is the current_word
 *  flag determines operation
 *     if 1 set to pre_font
 *     if not 1 turn off prefont
 */
 
static void
set_pre_font(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
		current_word->styles.font = pre_font;
	else
		current_word->styles.font = normal_font;

	current_word->changed.font = true;

}

/* set_font_bold
 * 
 * changes the value of the BOLD status of a word
 *
 * current_word  = current word
 * flag determines operation
 *    if 1 add to bold
 *    if not 1 subtract from bold
 */

static void
set_font_bold(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.bold++;
										
		if (current_word->styles.bold == 1)
			current_word->changed.font = true;
	}
	else
	{
		if (current_word->styles.bold > 0)
			current_word->styles.bold--;
				
		if(current_word->styles.bold == 0)
			current_word->changed.font = true;
	}
}

/* set_font_italic()
 * 
 * changes the value of the Italic status of a word
 *
 * current_word = current word
 * flag determines operation
 *    if 1 add to italic
 *    if not 1 subtract from italic
 */

static void
set_font_italic(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.italic++;
	
		if (current_word->styles.italic == 1)
			current_word->changed.font = true;
	}
	else
	{
		if (current_word->styles.italic > 0)
			current_word->styles.italic--;
											
		if (current_word->styles.italic == 0)
			current_word->changed.font = true;
	}
}

/* set_font_strike()
 *
 * changes the value of the Strike status of a word
 * 
 * current_word = current word
 * flag determines operation
 *    if 1 add to strike
 *    if not 1 subtract from strike
 */
 
static void
set_font_strike(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.strike++;
		current_word->changed.style = true;
	}
	else
	{
		if (current_word->styles.strike != 0)
			current_word->styles.strike--;

		current_word->changed.style = true;
	}
}

/* set_font_underline()
 *
 * changes the value of the underlined status of a word
 * 
 * current_word = current word
 * flag determines operation
 *    if 1 add to underline
 *    if not 1 subtract from underline
 */
 
static void
set_font_underline(struct word_item *current_word, WORD flag)
{
	if (flag == 1)
	{
		current_word->styles.underlined++;
		current_word->changed.style = true;
	}
	else
	{
		if (current_word->styles.underlined != 0)
			current_word->styles.underlined--;

		current_word->changed.style = true;
	}
}

/* set_center_text()
 *
 * changes the value of paragraphs alignment
 * 
 * flag determines operation
 *    if 1  center text
 *    if not 1 left justify text
 */
 
static void
set_center_text(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	if (flag == 1)
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	if (flag == 1)
		p_frame->current_paragraph->alignment = center;
	else
		p_frame->current_paragraph->alignment = 0;
}

/* set_blockquote_text()
 *
 * changes the value of paragraphs indentation
 * 
 * flag determines operation
 *    if 1  blockquote text
 *    if not 1  unindent text
 */
 
static void
set_blockquote_text(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	add_paragraph(p_frame,active_word_buffer);

	p_frame->active_word = active_word_buffer;

	if (flag == 1)
	{
		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->eop_space = 0;
		p_frame->current_paragraph->left_border += list_indent (2);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
	else
	{
		p_frame->current_paragraph->left_border -= list_indent(2);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
}


/* parse anchor
 * ideally you drop the input on this routine
 * and it parses and processes the body tag information
 * baldrick - December 3, 2001
 * 
 * flag determines operation
 *    if 1  start d tag
 *    if not 1 end d tag
 * baldrick - December 17, 2001
 */

static void
parse_anchor (struct frame_item *p_frame, WORD flag)
{
	if (flag == 1)
	{
		char * output = get_value_str (KEY_HREF);
		char   out2[100];

		if (output)
		{						
			p_frame->current_word->colour = p_frame->link_colour;
			p_frame->current_word->changed.colour = true;

			if (get_value (KEY_TARGET, out2, sizeof(out2)))
			{
				p_frame->current_word->link = new_url_link (output, lnk_href, out2);
			}
			else
			{
				p_frame->current_word->link = new_url_link (output, lnk_href, NULL);
			}
			free (output);
		}
		else if (get_value (KEY_NAME, out2, sizeof(out2)))
		{
			p_frame->current_word->link = new_url_link(out2, lnk_name, NULL);
		}	
	}
	else
	{
		p_frame->current_word->colour = p_frame->current_font_step->colour; /* p_frame->text_colour;*/
		p_frame->current_word->link = 0;
		p_frame->current_word->changed.colour = true;
	}
}

/* parse body tag
 * ideally you drop the input on this routine
 * and it parses and processes the body tag information
 *
 * baldrick - December 3, 2001
 *
 * modifications for new color routines
 * AltF4 - December 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 */

static void
parse_body (struct frame_item *p_frame)
{
	if (!ignore_colours)
	{
		WORD color;
		
		if ((color = get_value_color (KEY_TEXT)) >= 0)
		{
			p_frame->text_colour = color;
		}
		if ((color = get_value_color (KEY_BGCOLOR)) >= 0)
		{
			p_frame->background_colour = color;
		}
		if ((color = get_value_color (KEY_LINK)) >= 0)
		{
			p_frame->link_colour = color;
		}
	}
}

/* parse_d_tags()
 *
 * processes the d tags DL, DT, DD
 * 
 * type determines the type of d tag
 *    0 = DL tag
 *    1 = DT tag
 *    2 = DD tag
 *
 * flag determines operation
 *    if 1  start d tag
 *    if not 1 end d tag
 */
 
static void
parse_d_tags(struct frame_item *p_frame, WORD *active_word_buffer,
			 WORD type, WORD flag)
{
	add_paragraph(p_frame,active_word_buffer);

	p_frame->current_paragraph->alignment = left;

	if (flag == 1)
	{
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->eop_space = 0;


		if (type == 0)       /* dl tag start */
			p_frame->current_paragraph->left_border += list_indent (2);
		else if (type == 1)  /* dt tag start */
			p_frame->current_paragraph->left_border -= list_indent (2);
		else if (type == 2)  /* dd tag start */
			p_frame->current_paragraph->left_border = list_indent (2);

		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	}
	else
	{
		if (type == 0) /* dl tag end */
		{
			p_frame->current_paragraph->eop_space = p_frame->current_font_size;

			p_frame->current_paragraph->left_border -= list_indent(2);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse DIV tag
 * ideally you drop the input on this routine
 * and it parses and processes the DIV tag information
 *
 * DIV is only partially implemented from my understanding
 * baldrick - December 14, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_div_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	if (flag == 1)
	{
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->active_word = active_word_buffer;

		switch (toupper (get_value_char (KEY_ALIGN)))
		{
			case 'R':
				p_frame->current_paragraph->alignment = right;
				break;
			case 'C':
				p_frame->current_paragraph->alignment = center;
				break;
			case 'L':
				p_frame->current_paragraph->alignment = left;
				break;
		}
	}
	else
	{
		add_paragraph(p_frame, active_word_buffer);
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
	}
}

/* parse font tag
 * ideally you drop the input on this routine
 * and it parses and processes the font tag information
 *
 * baldrick - December 14, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 *
 * color handling modified to new routines
 * AltF4 - Dec 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 *
 * Baldrick - March 1, 2002: modifications to always store a font step
 *            so that we don't loose our size on complex sites
 */

static void
parse_font_tag(struct frame_item *p_frame, WORD fontstep, WORD flag)
{
	char output[100];
	struct font_step *old;

	if (flag == 1)
	{
		old = p_frame->current_font_step;

		p_frame->current_font_step = add_step (p_frame->current_font_step);
		
		if (get_value (KEY_SIZE, output, sizeof(output)))
		{
			if (*output == '+' || *output == '-')
			{
				p_frame->current_font_step->step += convert_to_number (output);
			}
			else
			{
				p_frame->current_font_step->step = convert_to_number (output);
			}
									
			/* added +1 to font_step in next calculation
			 * this is not perfect, but does fix some of the problems
			 * with font size when there is a size variable
			 * Basically the smallest size fonts are way too small
			 * baldrick July 20, 2001
			 */
									
			p_frame->current_font_size = p_frame->current_font_step->step * fontstep; /*(font_step + 1);*/
																	
			p_frame->current_word->styles.font_size = p_frame->current_font_size; 
			p_frame->current_word->changed.font = true;

	/*		printf("font size = %d\r\n",p_frame->current_word->styles.font_size);*/
		}
		else
		{
			/* no font size here, so copy last or we will lose it */
			
			p_frame->current_font_step->step = old->step;
		}
		
		if (!ignore_colours)
		{
			WORD color = get_value_color (KEY_COLOR);
			if (color >= 0)
			{
				p_frame->current_word->colour         = color;
				p_frame->current_font_step->colour 	  = color;
				p_frame->current_word->changed.colour = true;
			}
			else
				p_frame->current_font_step->colour 	  = p_frame->text_colour;				
		}
		else
			p_frame->current_font_step->colour 	  = p_frame->text_colour;				
	}
	else
	{
		p_frame->current_font_step = destroy_step(p_frame->current_font_step);
		p_frame->current_font_size = p_frame->current_font_step->step * fontstep;
		p_frame->current_word->styles.font_size = p_frame->current_font_size;
		p_frame->current_word->colour = p_frame->current_font_step->colour; /*p_frame->text_colour;*/
		p_frame->current_word->changed.colour = true;
		p_frame->current_word->changed.font = true;
	}
}


/* parse header tag
 * ideally you drop the input on this routine
 * and it parses and processes the header tag information
 *
 * baldrick - August 20, 2001
 * mj - added strupr and 'j' - 10-01-01
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_header_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	WORD size = 0;

	if (flag == 1)
	{
	    /* This next line I'm not 100% certain of.  If Headings don't
	     * have enough space then remove this line - baldrick Dec 14, 01 
	     *
	     * Ok there is an error here somewhere. On MagicPC this runs and
	     * modifies the height of the space around header tags
	     * on my TT under Magic it crashes - baldrick Dec 14, 01 (evening)
	     */
	/*	p_frame->current_word = p_frame->current_paragraph->item;
	*/

		p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

		add_paragraph(p_frame, active_word_buffer);

		switch (toupper (get_value_char (KEY_ALIGN)))
		{
			case 'R':
				p_frame->current_paragraph->alignment = right;
				break;
			case 'C':
				p_frame->current_paragraph->alignment = center;
				break;
			case 'J':
			case 'L':
				p_frame->current_paragraph->alignment = left;
		}
							
		p_frame->current_word->styles.font = header_font;
	
		switch (get_value_char (KEY_H_HEIGHT))
		{
			case '1':
				size = p_frame->current_font_size * 2;
				break;
			case '2':
				size = p_frame->current_font_size + (p_frame->current_font_size / 2);
				break;
			case '3':
				size = p_frame->current_font_size + (p_frame->current_font_size / 4);
				break;
			case '4':
				size = p_frame->current_font_size;
				break;
			case '5':
				size = p_frame->current_font_size - (p_frame->current_font_size / 5);
				break;
			case '6':
				size = p_frame->current_font_size - (p_frame->current_font_size / 3);
				break;
		}
		p_frame->current_word->styles.font_size = size;
		p_frame->current_word->styles.bold++;
		p_frame->current_word->changed.font = true;
	
		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		add_paragraph(p_frame,active_word_buffer);
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
		p_frame->current_word->styles.font = normal_font;
		p_frame->current_word->styles.font_size = p_frame->current_font_size;
		p_frame->current_word->styles.bold = 0;
		p_frame->current_word->changed.font = true;
	}
}

/* parse MENU tag
 * ideally you drop the input on this routine
 * and it parses and processes the MENU tag information
 *
 * I left symbol in this since we might need it, I'm not certain
 * it's also possible that we could map this onto parse_ul
 * baldrick - December 13, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_menu_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;
								
		add_paragraph(p_frame, active_word_buffer);
									
		p_frame->active_word = active_word_buffer;
		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent (0);
									
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
								
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item =	p_frame->current_list;

		if (p_frame->current_list != 0)
			temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;

		p_frame->current_list = temp_list_holder;
	}
	else
	{
		if (p_frame->current_list != 0)
		{
			if (p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space=-(p_frame->current_word->word_height);
												
			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);

			p_frame->active_word = active_word_buffer;
			p_frame->current_list = p_frame->current_list->next_stack_item;
			p_frame->current_paragraph->left_border -= list_indent(0);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse P tag
 * ideally you drop the input on this routine
 * and it parses and processes the P tag information
 *
 * baldrick - December 14, 2001
 */

static void
parse_p_tag(struct frame_item *p_frame, WORD *active_word_buffer)
{
	enum paragraph_alignment prev_alignment;

	prev_alignment = p_frame->current_paragraph->alignment;
	
	p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	switch (toupper (get_value_char (KEY_ALIGN)))
	{
		case 'R':
			p_frame->current_paragraph->alignment = right;
			break;
		case 'C':
			p_frame->current_paragraph->alignment = center;
			break;
		case 'L':
			p_frame->current_paragraph->alignment = left;
			break;
		default:
			p_frame->current_paragraph->alignment = prev_alignment; /*left;*/
	}
}

/* parse LI tag
 * ideally you drop the input on this routine
 * and it parses and processes the LI tag information
 *
 * baldrick - December 12, 2001
 */

static void
parse_li_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD fontstep)
{
	WORD value = get_value_unum (KEY_VALUE, -1);
	if  (value >= 0)
		p_frame->current_list->current_list_count = value;

	switch (get_value_char (KEY_TYPE))
	{
		case 'a':
			p_frame->current_list->bullet_style = alpha;
			break;
		case 'A':
			p_frame->current_list->bullet_style = Alpha;
			break;
		case 'i':
			p_frame->current_list->bullet_style = roman;
			break;
		case 'I':
			p_frame->current_list->bullet_style = Roman;
			break;
		case '1':
			p_frame->current_list->bullet_style = Number;
			break;
		case 'd':
		case 'D':
			p_frame->current_list->bullet_style = disc;
			break;
		case 'c':
		case 'C':
			p_frame->current_list->bullet_style = circle;
			break;
		case 's':
		case 'S':
			p_frame->current_list->bullet_style = square;
			break;
	}
	
	p_frame->current_word->word_code = br;
										
	p_frame->current_word->styles.font_size = 2 * fontstep;
	p_frame->current_word->changed.font = true;

	p_frame->current_word = list_marker(p_frame);
	p_frame->active_word = active_word_buffer;

	p_frame->current_word->styles.font_size = p_frame->current_font_step->step * fontstep;
	p_frame->current_word->changed.font = true;
}

/* parse OL tag
 * ideally you drop the input on this routine
 * and it parses and processes the OL tag information
 *
 * baldrick - December 12, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_ol_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->active_word = active_word_buffer;

		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent(1);
		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		temp_list_holder = new_stack_list_item ();
		temp_list_holder->next_stack_item = p_frame->current_list;
		p_frame->current_list = temp_list_holder;
								
		switch (get_value_char (KEY_TYPE))
		{
			case 'a':
				p_frame->current_list->bullet_style = alpha;
				break;
			case 'A':
				p_frame->current_list->bullet_style = Alpha;
				break;
			case 'i':
				p_frame->current_list->bullet_style = roman;
				break;
			case 'I':
				p_frame->current_list->bullet_style = Roman;
				break;
			default:
				p_frame->current_list->bullet_style = Number;
		}
							
		p_frame->current_list->current_list_count = get_value_unum (KEY_START, 1);

		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		if (p_frame->current_list != 0)
		{
			if(p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space = -(p_frame->current_word->word_height);

			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);
			p_frame->active_word = active_word_buffer;
			p_frame->current_list = remove_stack_item(p_frame->current_list);
			p_frame->current_paragraph->left_border -= list_indent(1);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}	
	}
}

/* parse UL tag
 * ideally you drop the input on this routine
 * and it parses and processes the UL tag information
 * baldrick - December 12, 2001
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 */

static void
parse_ul_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	struct list_stack_item *temp_list_holder;

	if (flag == 1)
	{	
		p_frame->current_paragraph->eop_space = -p_frame->current_word->word_height;

		add_paragraph(p_frame, active_word_buffer);

		p_frame->current_paragraph->alignment = left;
		p_frame->current_paragraph->left_border += list_indent (0);

		p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
	
		temp_list_holder = new_stack_list_item();
		temp_list_holder->next_stack_item = p_frame->current_list;

		switch (get_value_char (KEY_TYPE))
		{
			case 'S':
			case 's':
				temp_list_holder->bullet_style = square;
				break;
			case 'c':
			case 'C':
				temp_list_holder->bullet_style = circle;
				break;
			case 'd':
			case 'D':
				temp_list_holder->bullet_style = disc;
			default:
				if (p_frame->current_list != 0)
					temp_list_holder->bullet_style = (p_frame->current_list->bullet_style + 1) % 3;
		}
		p_frame->current_list = temp_list_holder;

		p_frame->current_word = p_frame->current_paragraph->item;
		p_frame->active_word = active_word_buffer;
	}
	else
	{
		if (p_frame->current_list != 0)
		{
			if (p_frame->current_list->next_stack_item != 0)
				p_frame->current_paragraph->eop_space =- (p_frame->current_word->word_height);
			p_frame->current_paragraph->eop_space += p_frame->current_font_size / 3;

			add_paragraph(p_frame, active_word_buffer);
			p_frame->active_word = active_word_buffer;
			p_frame->current_list = remove_stack_item(p_frame->current_list);
			p_frame->current_paragraph->left_border -= list_indent(0);
			p_frame->current_indent_distance = p_frame->current_paragraph->left_border;
		}
	}
}

/* parse table tag 
 * ideally you drop the input on this routine
 * and it parses and processes the table tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 *
 * Modifications for new color routines
 * AltF4 - December 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 *
 * baldrick - Jan. 31, 2002: table child walking on table close inserting place holders
 */

static void
parse_table_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];

	if (flag == 1)
	{
		add_paragraph(p_frame, active_word_buffer);

		/* link this paragraph into the list */
		p_frame->parent_table = add_table_step (p_frame->parent_table, p_frame->current_paragraph,p_frame->current_table);

		p_frame->active_word = active_word_buffer;
								
		p_frame->current_paragraph->paragraph_code = PAR_TABLE;

		p_frame->current_paragraph->table = new_table(p_frame);
		p_frame->current_table = p_frame->current_paragraph->table;

		switch (toupper (get_value_char (KEY_ALIGN)))
		{
			case 'R':
				p_frame->current_table->alignment = right;
				break;
			case 'C':
				p_frame->current_table->alignment = center;
				break;
			case 'L':
			default:
				p_frame->current_table->alignment = left;
		}
		
		if (get_value (KEY_WIDTH, output, sizeof(output)))
		{
			p_frame->current_table->table_width = convert_to_number(output);
		}

		if (!ignore_colours)
		{
			p_frame->current_table->bgcolor = get_value_color (KEY_BGCOLOR);
		}
		else
		{
			p_frame->current_table->bgcolor = -1;
		}
	
		p_frame->current_table->border       = get_value_unum (KEY_BORDER, 1);
		p_frame->current_table->cell_spacing = get_value_unum (KEY_CELLSPACING, 5);
		p_frame->current_table->cell_padding = get_value_unum (KEY_CELLPADDING, 0);

		if (p_frame->current_table->table_width > p_frame->frame_page_width)
			p_frame->frame_page_width = p_frame->current_table->table_width;

		p_frame->current_table->current_child = p_frame->current_table->children;
	}
	else
	{
		WORD temp_track,temp_loop;
		struct table_child *last;
		
		/* just a thought.  It's possible that we might want to create
		 * a flag for the existance of rowspan and colspan in a table.  
		 * If there are no rowspans and colspans there is no sense wasting
		 * time on searching for them
		 */

		/* sort children list inserting empty children where necessary
		 * to fill spaces
		 */


		/* reset current_child pointer to start of list */
		
		p_frame->current_table->current_child = p_frame->current_table->children;
		
		 /* walk table child list do rowspan first */
		while (p_frame->current_table->current_child != 0)
		{
			if (p_frame->current_table->current_child->colspan > 1)
			{
				temp_track = p_frame->current_table->current_child->colspan;
				
				while (temp_track > 1)
				{
					p_frame->current_table->current_child = insert_empty_child (p_frame->current_table->current_child);
					
					temp_track -= 1;
				}
			}

			p_frame->current_table->current_child = p_frame->current_table->current_child->next_child;	
		}
		
		/* reset current_child pointer to start of list */
		
		p_frame->current_table->current_child = p_frame->current_table->children;
		
		 /* walk table child list now do rowspan */
		while (p_frame->current_table->current_child != 0)
		{

			if (p_frame->current_table->current_child->rowspan > 1)
			{
				temp_track = p_frame->current_table->current_child->rowspan;
				
				last = p_frame->current_table->current_child;
				
				while (temp_track > 1)
				{
					for (temp_loop = 0; temp_loop < (p_frame->current_table->num_cols - 1); temp_loop++)
						last = last->next_child;	
						
					last = insert_empty_child (last);
					
					temp_track -= 1;
				}

			}

			p_frame->current_table->current_child = p_frame->current_table->current_child->next_child;	
		}

#if 0

/* I'm not certain if we will need to recalculate the rows or not
 * it's very possible that we will need to in some cases
 * baldrick
 */

		p_frame->current_table->current_child = p_frame->current_table->children;
		temp_track = 1; /* have to include first child */
		
		 /* recount the rows */
		while (p_frame->current_table->current_child != 0)
		{
			temp_track+=1;
				
			p_frame->current_table->current_child = p_frame->current_table->current_child->next_child;	
		}

printf("temp_track = %d     \r\n",temp_track);
	
#endif
			
	/* This needs to handle both Rowspan and Colspan */
	
/*struct table_child *insert_empty_child (struct table_child *prev);
*/

		/* set current paragraph to before the start of this table */

		p_frame->current_paragraph = p_frame->parent_table->entry;

		p_frame->current_table = p_frame->parent_table->parent;
				
/*printf("table num cols = %d  num rows = %d    \r\n",p_frame->current_table->num_cols,p_frame->current_table->num_rows);
*/
		/* walk back up list */
		
		p_frame->parent_table = destroy_table_step(p_frame->parent_table);

/*printf("p_frame->parent_table = %ld   \r\n",p_frame->parent_table);
*/		
	}
}


/* parse td tag (table data cell )
 * ideally you drop the input on this routine
 * and it parses and processes the td tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 *
 * Modifications for new color routines
 * AltF4 - December 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 */

static void
parse_td_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	char output[100];
	WORD temp = 0;

	if (flag == 1)
	{
		/* store any words floating around in the buffer */
								
		word_store (p_frame, active_word_buffer, p_frame->active_word);

		/* we need to create a new child */
								
		/* this first test will just supress the 
		 * creation of an extra child at the front of 
		 * the table's children list
		 */
								
		if (p_frame->current_table->num_children != 0)
		{
			p_frame->current_table->current_child->next_child = new_table_child(p_frame);
			p_frame->current_table->current_child = p_frame->current_table->current_child->next_child;
		}
								
		p_frame->current_table->num_children += 1;
								
		/* This might not be a good test
		 * we want to count the columns in the 
		 * first row. But if a Table has only
		 * one row it doesn't necessarily have a tr tag
		 *
		 * so we hope that we don't hit bad tables with
		 * multiple rows and no tr tag before first row
		 */
								 
		if (p_frame->current_table->num_rows == 1)
		{
			p_frame->current_table->num_cols += 1;
		}

		if (!ignore_colours)
		{
			p_frame->current_table->current_child->bgcolor = get_value_color (KEY_BGCOLOR);
		}
		else
		{
			p_frame->current_table->current_child->bgcolor = -1;
		}
		
		if (get_value (KEY_COLSPAN, output, sizeof(output)))
		{
			temp = convert_to_number(output);

			if (p_frame->current_table->num_rows == 1)
			{
				p_frame->current_table->num_cols += temp;
				
				/* adjust it by one to account for 1 previously added */
				
				p_frame->current_table->num_cols -= 1;
			}

			p_frame->current_table->current_child->colspan = temp;
		}
		else
		{
			p_frame->current_table->current_child->colspan = 1;
		}
		
		p_frame->current_table->current_child->rowspan = get_value_unum (KEY_ROWSPAN, 1);
		
		switch (toupper (get_value_char (KEY_ALIGN)))
		{
			case 'R':
				p_frame->current_table->current_child->alignment = right;
				break;
			case 'C':
				p_frame->current_table->current_child->alignment = center;
				break;
			case 'L':
			default:
				p_frame->current_table->current_child->alignment = left;
		}

		if (get_value (KEY_HEIGHT, output, sizeof(output)))
			p_frame->current_table->current_child->height = convert_to_number(output);

		if (get_value (KEY_WIDTH, output, sizeof(output)))
			p_frame->current_table->current_child->width = convert_to_number(output);

		p_frame->current_paragraph = p_frame->current_table->current_child->item;

		p_frame->current_word = p_frame->current_paragraph->item;

		p_frame->active_word = active_word_buffer;
	}
	else
	{
		/* Any special considerations for a closing td tag? */
		;
	}

}


/* parse th tag (table header cell )
 * ideally you drop the input on this routine
 * and it parses and processes the th tag information
 *
 * WORD flag controls operation 
 *      1 is start of tag
 *      !1 is close of tag
 * baldrick - December 17, 2001
 *
 * Modifications for new color routines
 * AltF4 - December 26, 2001
 *
 * AltF4 - Jan. 11, 2002:  modifications for yet another color routine
 */

static void
parse_th_tag(struct frame_item *p_frame, WORD *active_word_buffer, WORD flag)
{
	parse_td_tag (p_frame, active_word_buffer, flag);
	
	if (flag == 1)
	{
		set_font_bold(p_frame->current_word, 1);

		p_frame->current_paragraph->alignment = center;

	}
	else
	{
		/* Any special considerations for a closing th tag? */
		;
	}
}


/* parse hr tag
 * ideally you drop the input on this routine
 * and it parses and processes the hr tag information
 *
 * baldrick - December 5, 2001
 */

static void
parse_hr_tag(struct frame_item *p_frame, WORD *active_word_buffer)
{
	char output[100];

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;
	p_frame->current_paragraph->paragraph_code = PAR_HR;

	switch (toupper (get_value_char (KEY_ALIGN)))
	{
		case 'R':
			p_frame->current_paragraph->eop_space = 2;
			break;
		case 'C':
			p_frame->current_paragraph->eop_space = 1;
			break;
		default:
			p_frame->current_paragraph->eop_space = 0;
	}

	if (get_value (KEY_WIDTH, output, sizeof(output)))
		p_frame->current_word->word_width = convert_to_number(output);
	else
		p_frame->current_word->word_width = -100;

	if (get_value (KEY_SIZE, output, sizeof(output)))
		p_frame->current_word->word_height = convert_to_number(output);
	else
		p_frame->current_word->word_height = 2;

	if (get_value (KEY_NOSHADE, NULL,0))
		p_frame->current_word->word_height = -p_frame->current_word->word_height;

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;
	p_frame->current_word->changed.font = true;
}

/* parse img tag
 * ideally you drop the input on this routine
 * and it parses and processes the header tag information
 *
 * baldrick - Dec 4, 2001
 */

static void
parse_img_tag(struct frame_item *p_frame, WORD *active_word_buffer)
{
	char output[100];
	char img_file[100];

	add_paragraph(p_frame, active_word_buffer);

	p_frame->current_paragraph->paragraph_code = PAR_IMG;

	switch (toupper (get_value_char (KEY_ALIGN)))
	{
		case 'R':
			p_frame->current_paragraph->eop_space = 2;
			break;
		case 'L':
			p_frame->current_paragraph->eop_space = 0;
			break;
		case 'C':
		default: /* Assume center if not otherwise specifiec */
			p_frame->current_paragraph->eop_space = 1; /* should be left */
	}
	
	if (get_value (KEY_WIDTH, output, sizeof(output)))
		p_frame->current_word->word_width = convert_to_number(output);
	else
		p_frame->current_word->word_width = 10;

	if (p_frame->current_word->word_width > p_frame->frame_page_width)
		p_frame->frame_page_width = p_frame->current_word->word_width;

/*  might not need this

	if(p_frame->current_table)
		p_frame->current_table->current_child->min_width = p_frame->current_word->word_width;
*/
								
	if (get_value (KEY_HEIGHT, output, sizeof(output)))
		p_frame->current_word->word_height = convert_to_number(output);
	else
		p_frame->current_word->word_height = 10;

	p_frame->current_word->word_tail_drop = p_frame->current_word->word_height;

	if (get_value (KEY_SRC, img_file, sizeof(img_file)))
	{
		/*  This next line just shows the parsed IMG SRC
		    if you were going to process the message you 
		    would dispatch this off with a load_to_do message
		    with a new type for IMG's.
		    
		    You would also need to add a bit more information
		    for the IMG handling, mainly a MFDB should do the 
		    job.  This could possibly be linked to an already
		    existing item.
		    
		    You would then need to work in a message retrieval
		    from the external application to get the notification
		    of image decompression.  
		    
		    Modify the height and width of the paragraph to match
		    the height and width of the returned img and issue
		    a redraw for it's parent frame.
		    
		printf("img file = %s   \r\n",img_file);
		*/
	}

	add_paragraph(p_frame, active_word_buffer);

	p_frame->active_word = active_word_buffer;

	p_frame->current_word->changed.font = true;
}

/* parse_title
 *
 * parses a title tag from a file 
 * and sets the window's title to this value
 * also watches for ISO Latin entities in the Title string
 * Baldrick Dec. 6, 2001
 *
 * Modified to use new ISO scanning routines 
 * AltF4 Dec. 19, 2001
 */
 
static char *
parse_title (char *symbol, WORD *active_word)
{
	int ready = false;
	
	window_title[0] = '\0';

	while (!ready)
	{
		switch(*symbol)
		{
			case '\0':
				ready = true;
				break;
			case '\r':
			case '\n':
				symbol++;
				break;
			case '&': {
				/* the 'symbol' pointer will be set by the scanner function
				 * to the expression end, ';' or '\0'.
				 */
				char chr = (char)scan_namedchar (&symbol, ATASCI);
				strncat(window_title,&chr,1);
				symbol++;
			}	break;
			case '<':
				if (symbol[1] == '/')
				{
					char * sym = symbol +2;
					if (parse_tag (&sym) == TAG_TITLE)
					{
						symbol = sym;
						ready  = true;
						break;
					}
				}
			default:
				strncat(window_title,symbol,1);
				symbol++;
				break;
		}
	}									

	if (strlen(window_title) > 0)
		wind_set_str(window_handle, WF_NAME, window_title);

	return(symbol);
}


/* parse_embed()
 *
 * Processes embedded multi media objects.
 * Currently it simply fires up a new loader job and lets
 * the loader find out what to do.
 * 
 * AltF4 - Mar. 01, 2002
 */
static void
parse_embed (void)
{
	char snd_file[200];
	
	if (get_value (KEY_SRC, snd_file, sizeof(snd_file))) {
		new_loader_job (snd_file, NULL); 
	}
}


/* parse frameset()
 *
 * ideally you drop the input on this routine
 * and it parses and processes the frameset information
 * until done and then returns to the main parser with
 * a pointer to the end of the frameset
 * baldrick - August 8, 2001
 *
 * at the moment there is a hard coded limit of 10 frames.
 * Could or should be changed in the future.
 *
 * There are some printf's in this section that are rem'd out
 * they are useful checks on the frame parsing and I'm not
 * certain that it's 100% correct yet.  So I have left them
 * baldrick - August 14, 2001
 *
 * Major reworks by AltF4 in late January - early Feb 2002
 */
 
static char *
parse_frameset(char *symbol, CONTAINR container)
{
	HTMLTAG tag   = TAG_FRAMESET;
	BOOL    slash = FALSE;
	int     depth = 0;
	
	if (!container) {
		printf ("parse_frameset(): NO CONTAINER !!! \n");
		exit(1);
	} else if (container->Mode) {
		printf ("parse_frameset(): container not cleared! \n");
		exit(1);
	}
	
	do
	{
		if (!slash) {
			
			/* only work on an empty container.  if not empty there was either a
			 * forgotten </framset> or more tags than defined in the frameset.
			 */
			if (!container->Mode) {
				
				if (tag == TAG_FRAMESET) {
					
					char output[100];
					BOOL border = (container->Parent
					               ? container->Parent->Border : TRUE);
					container->Border = (get_value_unum (KEY_FRAMEBORDER, border) > 0);
					
					/* ok the first thing we do is look for ROWS or COLS
					 * since when we are dumped here we are looking at a
					 * beginning of a FRAMESET tag
					 */
					
					if (get_value (KEY_COLS, output, sizeof(output))) {
						containr_fillup (container, output, TRUE);
						container = container->u.Child;
						depth++;
					}
					
					else /* at the moment settings of either COLS _and_ ROWS aren't
					      * working yet, so we make it mutual exlusive for now   */
				
					if (get_value (KEY_ROWS, output, sizeof(output))) {
						containr_fillup (container, output, FALSE);
						container = container->u.Child;
						depth++;
					}
					
				} else if (tag == TAG_FRAME) {
					
					char  frame_file[200];
					
					container->Mode   = CNT_FRAME;
					container->Name   = get_value_str (KEY_NAME);
					container->Border = container->Parent->Border;
					
					if (get_value (KEY_SRC, frame_file, sizeof(frame_file))) {
						new_loader_job (frame_file, container); 
					}
					
					if (container->Sibling) {
						container = container->Sibling;
					}
				}
			} /* endif (!container->Mode) */
		
		} else if (tag == TAG_FRAMESET) { /* && slash */
			
			container = container->Parent;
			
			if (--depth <= 0) break;
			
			if (container->Sibling) {
				container = container->Sibling;
			}
		}
		
		/* skip junk until the next <...> */
		
		while (*symbol && *(symbol++) != '<');
		if (*symbol) {
			slash = (*symbol == '/');
			if (slash) symbol++;
			tag = parse_tag (&symbol);
			continue;
		}
	}
	while (*symbol);
	
	#if 0
	{
		extern void containr_debug (CONTAINR);
		containr_debug (container);
	}
	#endif
	
	return symbol;
}


struct word_item *
list_marker (struct frame_item *p_frame)
{
	WORD modulo = 0, count, word[5], *active_word, indent_type = 0;
	struct word_item *n_word;

	active_word = word;
	
	if (p_frame->current_list == 0)
		return (p_frame->current_word);

	count = p_frame->current_list->current_list_count;

	switch (p_frame->current_list->bullet_style)
	{
		case disc:
			*active_word = 342;
			active_word++;
			indent_type = 0;
			break;
		case square:
			*active_word = 507; /* baldrick - robert had 559;*/
			active_word++;
			indent_type = 0;
			break;
		case circle:
			*active_word = 353;
			active_word++;
			indent_type = 0;
			break;
		case Number:
			while (count > 9)
			{
				count -= 10;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 48);
				active_word++;
			}
			*active_word = map (count + 48);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case Alpha:
			while (count > 26)
			{
				count -= 26;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 64);
				active_word++;
			}
			*active_word = map (count + 64);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case alpha:
			while (count > 26)
			{
				count -= 26;
				modulo++;
			}
			if (modulo != 0)
			{
				*active_word = map (modulo + 96);
				active_word++;
			}
			*active_word = map (count + 96);
			active_word++;
			*active_word = 14;
			active_word++;
			p_frame->current_list->current_list_count++;
			indent_type = 1;
			break;
		case roman:
		case Roman:
			break;
	}

 /* This might fail with new add_word routine */
 
	n_word = add_word (p_frame,p_frame->current_word, word, active_word);

	p_frame->current_word->word_width = list_indent (indent_type);

	if (p_frame->current_word->word_width + p_frame->current_indent_distance > p_frame->frame_page_width)
		p_frame->frame_page_width = p_frame->current_word->word_width + p_frame->current_indent_distance;

	return (n_word);
}


/* skip everything until </STYLE> tag
 */
static void
skip_style (char ** pptr)
{
	char * line = *pptr;
	do {
		BOOL slash;
		while (*line && *(line++) != '<');
		slash = (*line == '/');
		if (slash) line++;
		if (parse_tag (&line) == TAG_STYLE && slash) {
			break;
		}
	} while (*line);
	
	*pptr = line;
}

/* skip everything until </SCRIPT> or <NOSCRIPT> tag
 */
static BOOL
skip_script (char ** pptr)
{
	char * line     = *pptr, * save = NULL;
	BOOL   noscript = FALSE;
	do {
		BOOL    slash;
		HTMLTAG tag;
		while (*line && *(line++) != '<');
		slash = (*line == '/');
		if (slash) line++;
		else       save = line +1;
		tag = parse_tag (&line);
		if (slash) {
			if (tag == TAG_SCRIPT) break;
		} else if (tag == TAG_NOSCRIPT) {
			noscript = TRUE;
			break;
		} else {
			line = save;
		}
	} while (*line);
	
	*pptr = line;
	
	return noscript;
}


/* calculate_frame
 * this is the main parsing routine
 *
 * AltF4 - Feb. 04, 2002: renamed to parse_html() because that matches more its
                          functionality, corresponding to parse_text().
 */
struct paragraph_item *
parse_html (char *symbol, struct frame_item *p_frame)
{
	struct paragraph_item *start;
	WORD u, fontstep;
	WORD prev_sm_size, prev_su_size; /* one for before small and one for before sub/p */
	enum bool space_found = false;
	char output[1024]; /* baldrick - this should be done dynamically somehow */
	WORD active_word_buffer[300]; /* this can be too small for run on lines */
	
	BOOL in_pre    = FALSE;
	BOOL in_script = FALSE; /* if this is TRUE we have to wait for a </noscript>
	                         * tag to reenter the skip_script() function   */
	
	WORD distances[5], effects[3];

	if (symbol == 0) return (p_frame->current_paragraph);

	start = p_frame->current_paragraph;
	p_frame->active_word = active_word_buffer;
	
	wind_update (BEG_UPDATE);
	graf_mouse (2, 0);
	wind_update (END_UPDATE);

	vst_font (vdi_handle, fonts[0][0][0]);
	prev_su_size = prev_sm_size = p_frame->current_font_size; /*= POINT_SIZE;*/
	p_frame->current_font_step = new_step(3);
	p_frame->current_font_step->colour 	  = p_frame->text_colour;
	fontstep = p_frame->current_font_size / p_frame->current_font_step->step;
	vst_arbpt (vdi_handle, p_frame->current_font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &p_frame->current_word->space_width, &u, &u, &u);

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	p_frame->current_word->word_height = distances[3];
	p_frame->current_word->word_tail_drop = distances[1];
	
	while (*symbol != '\0')
	{
		if (*symbol == '<')
		{
			int  flag = (*(++symbol) != '/');
			if (!flag) symbol++;
			
			p_frame->current_word = add_word (p_frame,p_frame->current_word, active_word_buffer,p_frame->active_word);
			p_frame->active_word = active_word_buffer;
			
			switch (parse_tag (&symbol))
			{
				case TAG_A:
					parse_anchor (p_frame, flag);
					break;
				case TAG_B: /* (bold text) */
					set_font_bold (p_frame->current_word, flag);
					break;
				case TAG_BASEFONT:
					if (flag && get_value (KEY_SIZE, output, sizeof(output)))
					{
						p_frame->current_font_step = add_step (p_frame->current_font_step);
						p_frame->current_font_step->step = convert_to_number (output);
						p_frame->current_font_size = p_frame->current_font_step->step * fontstep;
						p_frame->current_word->styles.font_size = p_frame->current_font_size;
						p_frame->current_word->changed.font = true;
					}
					break;
				case TAG_BGSOUND:
				case TAG_EMBED:
					if (flag) parse_embed();
					break;
				case TAG_BIG:
					if (flag)
					{
						p_frame->current_font_step = add_step (p_frame->current_font_step);
						p_frame->current_font_step->step = (p_frame->current_font_size * 3 / 2) / fontstep;
						p_frame->current_font_size = p_frame->current_font_step->step * fontstep;
						p_frame->current_word->styles.font_size = p_frame->current_font_size;
						p_frame->current_word->changed.font = true;
					}
					else
					{
						p_frame->current_font_step = destroy_step(p_frame->current_font_step);
						p_frame->current_font_size = p_frame->current_font_step->step * fontstep;
						p_frame->current_word->styles.font_size = p_frame->current_font_size;
						p_frame->current_word->changed.font = true;
					}

/*						p_frame->current_word->styles.font_size = p_frame->current_font_size * 3 / 2; 
					else
						p_frame->current_word->styles.font_size = p_frame->current_font_size;
*/
					p_frame->current_word->changed.font = true;
					break;
				case TAG_BR:
					if (flag)
					{
						p_frame->current_word->word_code = br;
						/* maybe need this? current_word->changed.font = true; */
					}
					break;
				case TAG_BLOCKQUOTE:
					set_blockquote_text (p_frame, active_word_buffer, flag);
					break;
				case TAG_BODY:
					if (flag)
						parse_body (p_frame);
					break;
				case TAG_C: case TAG_CENTER:
					set_center_text (p_frame, active_word_buffer, flag);
					break;
				case TAG_CITE:
					set_font_italic (p_frame->current_word, flag);
					break;
				case TAG_CODE:
					set_pre_font (p_frame->current_word,flag);
					break;
				case TAG_DFN: /* (instance definition) */
					set_font_italic (p_frame->current_word, flag);
					break;
				case TAG_DIR:
					parse_menu_tag (p_frame, active_word_buffer,flag);
					break;
				case TAG_DIV: /* (generic language style container) */
					parse_div_tag (p_frame, active_word_buffer, flag);
					break;
				case TAG_DL: /* (definition list) */
					parse_d_tags (p_frame, active_word_buffer, 0, flag);
					break;
				case TAG_DT: /* (definition term) */
					if (flag)
						parse_d_tags (p_frame, active_word_buffer, 1, 1);
					break;
				case TAG_DD: /* (definition description) */
					if (flag)
						parse_d_tags (p_frame, active_word_buffer, 2, 1);
					break;
				case TAG_EM: /* (emphasis tag) */
					set_font_italic (p_frame->current_word, flag);
					break;
				case TAG_FONT:
					parse_font_tag (p_frame, fontstep, flag);
					break;
				case TAG_FRAMESET: /* frame processing */
					if (flag) 
						symbol = parse_frameset (symbol, p_frame->Container);
					break;				
				case TAG_H: /* header tag <H1>..<H6> */
					parse_header_tag (p_frame, active_word_buffer, flag);
					break;
				case TAG_HR:
					if (flag)
						parse_hr_tag (p_frame, active_word_buffer);
					break;
				case TAG_HTML:
					if (!flag)
					{
						*symbol = '\0';
						p_frame->current_paragraph->eop_space = 20;
					}
					break;
				case TAG_I: /* (italic text style) tag */
					set_font_italic (p_frame->current_word, flag);
					break;
				case TAG_IMG:
					if (flag)
						parse_img_tag (p_frame, active_word_buffer);
					break;
				case TAG_KBD: /* KBD tag? */
					set_pre_font (p_frame->current_word,1);
					break;
				case TAG_LI: /* (list item) */
					if (flag)
					{
						parse_li_tag (p_frame, active_word_buffer, fontstep);
						space_found = true;
					}
					break;
				case TAG_MENU:
					parse_menu_tag (p_frame, active_word_buffer, flag);
					break;
				case TAG_OL:
					parse_ol_tag (p_frame, active_word_buffer, flag);
					break;
				case TAG_P: /* (paragraph) */
					if (flag)
						parse_p_tag (p_frame, active_word_buffer);
					break;
				case TAG_PRE:
					if (flag)
					{
						p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;
						add_paragraph (p_frame, active_word_buffer);
						p_frame->active_word = active_word_buffer;
						p_frame->current_paragraph->alignment = left;
						set_pre_font (p_frame->current_word,1);
						in_pre = true;
					}
					else
					{
						set_pre_font (p_frame->current_word,1);
						in_pre = false;
					}
					break;
				case TAG_S: case TAG_STRIKE: /* (strike through text style) */
					set_font_strike (p_frame->current_word,  flag);
					break;
				case TAG_SAMP: /* (sample code or script) */
					set_pre_font (p_frame->current_word, flag);
					break;
				case TAG_SCRIPT:
					if (flag) in_script = skip_script (&symbol);
					break;
				case TAG_NOSCRIPT:
					if (!flag && in_script) in_script = skip_script (&symbol);
					break;
				case TAG_SMALL:
					if (flag)
					{
						prev_sm_size = p_frame->current_word->styles.font_size;
						p_frame->current_word->styles.font_size = prev_sm_size * 2 / 3;
					}
					else
					{
						p_frame->current_word->styles.font_size = prev_sm_size;
					}
					p_frame->current_word->changed.font = true;
					break;
				case TAG_STRONG:
					set_font_bold (p_frame->current_word, flag);
					break;
				case TAG_STYLE:
					skip_style (&symbol);
					break;
				case TAG_SUB:
					if (flag)
					{
					/*	p_frame->current_word->styles.font_size = p_frame->current_font_size * 2 / 3;*/
						p_frame->current_word->styles.font_size = prev_su_size * 2 / 3;
						p_frame->current_word->vertical_align = below;
					}
					else
					{
						p_frame->current_word->styles.font_size = prev_su_size; /*p_frame->current_font_size; */
						p_frame->current_word->vertical_align = middle; /*bottom; baldrick - July 19, 2001 */
					}
					p_frame->current_word->changed.font = true;
					break;
				case TAG_SUP:
					if (flag)
					{
					/*	p_frame->current_word->styles.font_size = p_frame->current_font_size * 2 / 3;*/
						p_frame->current_word->styles.font_size = prev_su_size * 2 / 3;
						p_frame->current_word->vertical_align = above;
					}
					else
					{
						p_frame->current_word->styles.font_size = prev_su_size; /*p_frame->current_font_size; */
						p_frame->current_word->vertical_align = middle; /*bottom; baldrick - July 19, 2001 */
					}
					p_frame->current_word->changed.font = true;
					break;
				case TAG_TABLE:
					parse_table_tag (p_frame, active_word_buffer, flag);
					break;
				case TAG_TD: /* (table data cell) */
					if (flag)
						parse_td_tag (p_frame, active_word_buffer, 1);
					break;
				case TAG_TH: /* (table header cell) */
					if (flag)
						parse_th_tag (p_frame, active_word_buffer, 1);
					break;
				case TAG_TITLE:
					if (flag)
						symbol = parse_title (symbol, p_frame->active_word);
					break;
				case TAG_TR: /* (table row) */
					/* increment the number of rows */
					if (flag)
						if (p_frame->current_table->num_cols > 0)
							p_frame->current_table->num_rows += 1;
					break;
				case TAG_TT:
					set_pre_font (p_frame->current_word, flag);
					break;
				case TAG_U: /* (underlined text) */
					set_font_underline (p_frame->current_word, flag);
					break;
				case TAG_UL: /* (unordered list) */
					parse_ul_tag (p_frame, active_word_buffer, flag);
					break;
				case TAG_VAR: /* (variable tag) */
					set_font_italic (p_frame->current_word, flag);
					break;
				
				/* we don't set a 'default:' directive here because at least gcc
				 * can tell us if we have forgotten a TAG this way   */
				 
				 case TAG_FRAME:
				 case TAG_Unknown: ;
			}
			if (p_frame->current_word->changed.font == true)
			{
				vst_font (vdi_handle,
					  fonts[p_frame->current_word->styles.font]
					  [p_frame->current_word->styles.bold != 0]
					  [p_frame->current_word->styles.italic != 0]);
				vst_arbpt (vdi_handle, p_frame->current_word->styles.font_size, &u, &u, &u, &u);
				vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
				vqt_advance (vdi_handle, Space_Code,
					     &p_frame->current_word->space_width, &u, &u, &u);

				p_frame->current_word->word_height = distances[3];
				p_frame->current_word->word_tail_drop = distances[1];
			}
			
			continue;
		}
		
		switch (*symbol)
		{
			case 10: /* LF */
				if ((in_pre == true)&&(*(symbol - 1)==13))
				{
					*symbol = 32;
					symbol--;
					break;
				}			
			case 13: /* CR */
			case 12: /* FORM FEED ?????? */
				if ((in_pre == true))
				{
					p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

					add_paragraph(p_frame, active_word_buffer);
					p_frame->active_word = active_word_buffer;
				}
				else
				{
					*symbol = 32;
					symbol--;
				}
				break;
			case '&':
				/* the 'symbol' pointer will be set by the scanner function
				 * to the expression end, ';' or '\0'.
				 * AltF4 Dec 19, 2001
				 */

				*p_frame->active_word = scan_namedchar (&symbol, ISO1);
				p_frame->active_word++;
				space_found = false;
				break;
			case ' ':
				if (!in_pre)
				{
					if (space_found == true)
						break;
	
					p_frame->current_word = add_word (p_frame,p_frame->current_word, active_word_buffer,p_frame->active_word);
					p_frame->active_word = active_word_buffer;
					space_found = true;
				}
			default:
				if (*symbol < 32)
					break;
				if (*symbol > 126)
					break;
				if (*symbol != ' ')
					space_found = false;

				*p_frame->active_word = map (*symbol);
				p_frame->active_word++;
		}
		symbol++;

	}

	word_store (p_frame, active_word_buffer, p_frame->active_word);

	wind_update (BEG_UPDATE);
	graf_mouse (0, 0);
	wind_update (END_UPDATE);

	p_frame->frame_page_width += 5;
	
	return (start);
}

/* parse_text
 * this is the text parsing routine
 * for use with non formatted text files
 *
 * Nothing exciting just maps lines to paragraphs
 */
 
struct paragraph_item *
parse_text (char *symbol, struct frame_item *p_frame)
{
	struct paragraph_item *start;
	WORD u;
	WORD active_word_buffer[200];
	WORD distances[5], effects[3];
	WORD i;

	if (symbol == 0) 	return (p_frame->current_paragraph);

	start = p_frame->current_paragraph;
	p_frame->active_word = active_word_buffer;

	wind_update (BEG_UPDATE);
	graf_mouse (2, 0);
	wind_update (END_UPDATE);

	vst_font (vdi_handle, fonts[0][0][0]);
	vst_arbpt (vdi_handle, p_frame->current_font_size, &u, &u, &u, &u);
	vqt_advance (vdi_handle, Space_Code, &p_frame->current_word->space_width, &u, &u, &u);

	vqt_fontinfo (vdi_handle, &u, &u, distances, &u, effects);
	p_frame->current_word->word_height = distances[3];
	p_frame->current_word->word_tail_drop = distances[1];

	p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;
	p_frame->current_word->styles.font = pre_font;

	while (*symbol != '\0')
	{
		switch (*symbol)
		{
			case 9:  /* TAB */
				*symbol = 32;
				
				for (i = 0; i< 5;i++)
				{
					*p_frame->active_word = map (*symbol);
					p_frame->active_word++;
				}

				break;
			case 10: /* LF */
				if ((*(symbol - 1)==13))
				{
					*symbol = 32;
					symbol--;
					break;
				}			
			case 13: /* CR */
			case 12: /* FORM FEED ?????? */
				p_frame->current_paragraph->eop_space = p_frame->current_font_size / 2;

				add_paragraph(p_frame, active_word_buffer);

				p_frame->active_word = active_word_buffer;
				break;
			default:
				if (*symbol < 32)
					break;
/*				
				if (*symbol > 126)
					break;
*/
				*p_frame->active_word = map (*symbol);
				p_frame->active_word++;
		}

		symbol++;
	}

	word_store (p_frame, active_word_buffer, p_frame->active_word);

	wind_update (BEG_UPDATE);
	graf_mouse (0, 0);
	wind_update (END_UPDATE);

	p_frame->frame_page_width += 5;

	return (start);
}
