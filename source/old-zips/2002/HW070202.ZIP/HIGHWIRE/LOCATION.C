/* @(#)highwire/Location.c
 */
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h> /* printf */
#ifdef __PUREC__
# include <tos.h>
# include <stddef.h>
#endif
#ifdef LATTICE
# include <dos.h>
#endif
#ifdef __GNUC__
# include <osbind.h>
#endif

#include "defs.h"
#include "Location.h"
#include "Logging.h"
#include "inet.h"


static LOCATION __base = NULL;

#define LOCAL_WEB "E:\\WWW\\"


typedef struct s_host_entry {
	struct s_host_entry * Next;
	unsigned long         Ip;
	char                  Name[1];
} * HOST_ENT;
static HOST_ENT host_entry (const char ** name);
#define         host_addr(h)   (h ? h->Ip : 0uL)


/*----------------------------------------------------------------------------*/
static LOCATION
_alloc (size_t size, BOOL tos_path)
{
	LOCATION loc = malloc (sizeof (struct s_location) + size);
	loc->__reffs  = 0;
	loc->encoding = ENCODING_WINDOWS1252;
	loc->Proto    = 0;
	loc->Port     = 0;
	loc->Host     = NULL;
	loc->isTos    = tos_path;
	loc->Path     = loc->FullName + (tos_path ? 2 : 0);
	loc->Anchor   = NULL;
	
	return loc;
}

/*============================================================================*/
LOCATION
new_location (const char * src, LOCATION base)
{
	LOCATION loc;
	short    loc_proto = 0;
	HOST_ENT loc_host  = NULL;
	short    loc_port  = 0;
	
	char   * p;
	size_t   path_ln = 0, file_ln;
	BOOL     merge = FALSE;
	BOOL     is_tos;

#ifdef LOCAL_WEB
	static LOCATION __local_web = NULL;

	if (!__local_web) {
		char   path[] = LOCAL_WEB;
		size_t len    = sizeof(LOCAL_WEB) -1;

		len = strlen (path);
		__local_web = _alloc (len, TRUE);
		__local_web->File  = (char*)memcpy (__local_web->FullName, path, len) + len;
		__local_web->FullName[len] = '\0';
	}
#endif
	
	if (!__base) {
		char   path[HW_PATH_MAX];
		size_t len;
		path[0] = Dgetdrv();
		path[0] += (path[0] < 26)? 'A' : -26 + '1';
		path[1] = ':';
		Dgetpath (path +2, 0);
		len = strlen (path);
		if (path[len -1] != '\\') {
			path[len++] = '\\';
		}
		__base = _alloc (len, TRUE);
		__base->File  = (char*)memcpy (__base->FullName, path, len) + len;
		__base->FullName[len] = '\0';
	}
	
	if (!base) {
		base = __base;
	}
	
	if (!src || !src[0]) {
		loc = base;
		loc->__reffs++;
		
		return loc;
	}
	
/*	if (isalpha(src[0]) && src[1] == ':') { old line */

	if (src[1] == ':') {  /* TOS drive letter is A-Z[\]^_` or A-Z1-6 */
		is_tos  = TRUE;
	/*	path_ln = 0;*/
	
	} else if (src[0] == '/') {
		is_tos    = FALSE;
		loc_proto = base->Proto;
		loc_port  = base->Port;
		loc_host  = base->Host;
	
	} else { /* file, about, mailto, http, https, ftp */
		const char * s = src;
		char buf[8];
		short i = 0;
		
		while (isalpha(*s)) {
			if (i < sizeof(buf)) {
				buf[i++] = tolower(*(s++));
			} else {
				break;
			}
		}
		if (*s == ':') {
			buf[i] = '\0';
			if        (strcmp (buf, "file")   == 0) {
				loc_proto = 0;
			} else if (strcmp (buf, "about")  == 0) {
				loc_proto = 1;
			} else if (strcmp (buf, "mailto") == 0) {
				loc_proto = 2;
			} else if (strcmp (buf, "http")   == 0) {
				loc_proto = 3;
				loc_port  = 80;
			} else if (strcmp (buf, "https")  == 0) {
				loc_proto = 4;
				loc_port  = 443;
			} else if (strcmp (buf, "ftp")    == 0) {
				loc_proto = 5;
				loc_port  = 21;
			} else {
				loc_proto = -1;
			}
			src = (*(++s) == '/' && *(++s) == '/' ? ++s : s);
			if (loc_proto == 0 || loc_proto >= 3) {
				loc_host = host_entry (&s);
				if (loc_host && !loc_port) {
					loc_proto = 5;
					loc_port  = 21; /* ftp */
				}
			#ifdef LOCAL_WEB
				if (!loc_host || host_addr (loc_host))
			#endif
				src = (*s ? s : "/");
			}
			is_tos = FALSE;
		
		} else {
			merge  = TRUE;
			is_tos = base->isTos;
		}
	}
	
#ifdef LOCAL_WEB
	if (loc_proto >= 3 && !host_addr (loc_host)) {
		base      = __local_web;
		path_ln   = strlen(base->Path);
		is_tos    = TRUE;
		loc_proto = 0;
		loc_host  = NULL;
	}
#endif
	
	if (merge) {
		char * end = base->File -1;
		
		while (src[0] == '.') {
			if (src[1] == '/' || src[1] == '\\') {
				src += 2;
			} else if (src[1] == '.' && (src[2] == '/' || src[2] == '\\')) {
				while (end > base->Path && *(--end) != *base->Path);
				src += 3;
			} else {
				break;
			}
		}
		if (src[0] == '/' || src[0] == '\\') {
			src++;
		}
		path_ln = end - base->Path +1;
		
		loc_proto = base->Proto;
		loc_port  = base->Port;
		loc_host  = base->Host;
	}
	
	file_ln = strlen (src);
	loc     = _alloc (path_ln + file_ln, is_tos);
	if (is_tos) {
		if (path_ln) {
			if (base->isTos) {
				memcpy (loc->FullName, base->FullName, path_ln +2);
			} else {
				loc->FullName[0] = 'U';
				loc->FullName[1] = ':';
				memcpy (loc->Path, base->Path, path_ln);
			}
		} else {
			path_ln = -2;
		}
		memcpy (loc->Path + path_ln, src, file_ln +1);
		p = loc->Path;
		while ((p = strchr (p, '/')) != NULL) *(p++) = '\\';
		
	} else {
		if (path_ln) {
			memcpy (loc->Path, base->Path, path_ln);
		}
		memcpy (loc->Path + path_ln, src, file_ln +1);
		p = loc->Path;
		while ((p = strchr (p, '\\')) != NULL) *(p++) = '/';
	}
	
	if ((p = strchr (loc->Path, '#')) != NULL) {
		*(p++) = '\0';
		loc->Anchor = p;
	}
	loc->File  = (*loc->Path ? strrchr (loc->Path, loc->Path[0]) +1 : loc->Path);
	loc->Proto = loc_proto;
	loc->Port  = loc_port;
	loc->Host  = loc_host;

	loc->__reffs++;
	
	logprintf(LOG_BLACK, "new_location('%s', %hd '%s' returns %hd '%s')\n",
	          src, base->isTos, base->FullName, is_tos, loc->FullName);
	
	return loc;
}

/*============================================================================*/
void
free_location (LOCATION * _loc)
{
	LOCATION loc = *_loc;
	if (loc) {
		if ((!loc->__reffs || !--loc->__reffs) && loc != __base) {
			free (loc);
		}
		*_loc = NULL;
	}
}


/*============================================================================*/
LOCATION
location_share  (LOCATION loc)
{
	if (loc) {
		loc->__reffs++;
	}
	return loc;
}


/*============================================================================*/
int
location_open (LOCATION loc, const char ** host_name)
{
	HOST_ENT host = loc->Host;
	int      sock = -1;
	
	if (!host) {
		*host_name = "";
	
	} else {
		*host_name = host->Name;
		
#ifdef USE_INET
		if (host->Ip) {
			sock = inet_connect (host->Ip, loc->Port);
		}
#endif /* USE_INET */
	}
	return sock;
}


/*******************************************************************************
 *
 * Database Stuff
 *
 */

/*============================================================================*/
static HOST_ENT
host_entry (const char ** name)
{
	static HOST_ENT _base = NULL;
	
	HOST_ENT ent = _base;
	const char * n = *name;
	char buf[258], c;
	short len = 0;
	
	while ((c = *n) != '\0' && len < sizeof(buf) -1) {
		if (isalpha(c)) {
			buf[len++] = tolower(c);
			n++;
		} else if (isdigit(c) || c == '.' || c == '-') {
			buf[len++] = c;
			n++;
		} else {
			break;
		}
	}
	buf[len] = '\0';
	*name    = n;
	
	if (!len || strcmp (buf, "localhost") == 0) {
		return NULL;
	}
	
	while (ent) {
		if (strcmp (buf, ent->Name) == 0) {
			break;
		} else {
			ent = ent->Next;
		}
	}
	if (!ent) {
		ent = malloc (sizeof(struct s_host_entry) + len);
		memcpy (ent->Name, buf, len +1);
		ent->Ip   = 0uL;
		ent->Next = _base;
		_base     = ent;
	}
#ifdef USE_INET
	if (!ent->Ip) {
		inet_host_addr (ent->Name, &ent->Ip);
	}
#endif /* USE_INET */
	
/*	printf("%s -> %i.%i.%i.%i\n", ent->Name,
	       (int)((char*)&ent->Ip)[0], (int)((char*)&ent->Ip)[1],
	       (int)((char*)&ent->Ip)[2], (int)((char*)&ent->Ip)[3]);
*/	
	return ent;
}
