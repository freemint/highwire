#include <string.h>
#include <stdlib.h>


#include <gem.h>

#include	"global.h"
#include	"av_comm.h"


int	av_shell_id = -1,					/* Desktop's ID 										*/
		av_shell_status = 0;			/* What AV Commands can desktop do?	*/

char		*va_helpbuf = NULL;			/* GLOBAL memory buffer for AV */

short get_avserver(void)
{
	short ret;
	char *av_env;

	if ((av_env = getenv("AVSERVER")))
	{
		ret = appl_find(av_env);

		if (ret >= 0)
			return ret;
	}
	else if((ret = appl_find("AVSERVER")) >= 0)
		return ret;
	else if((ret = appl_find("JINNEE  ")) >= 0)
		return ret;
	else if((ret = appl_find("THING   ")) >= 0)
		return ret;
	else if((ret = appl_find("MAGXDESK")) >= 0)
		return ret;
	else if((ret = appl_find("GEMINI  ")) >= 0)
		return ret;
	else if((ret = appl_find("STRNGSRV")) >= 0)
		return ret;
	else if((ret = appl_find("DIRECT  ")) >= 0)
		return ret;
	else if((ret = appl_find("EASY    ")) >= 0)
		return ret;
	else if((ret = appl_find("KAOS    ")) >= 0)
		return ret;

	return -100;
}


int Send_AV(int to_ap_id, int message, char *data1, char *data2)
{
	short msg[8];
	
	/* - 100 to ap id would be no AV server */
	if (to_ap_id == -100)
		return(0);
		
	if(va_helpbuf!=NULL)
	{
		msg[0] = message;
		msg[1] = gl_apid;
		
		switch(message)
		{
			case PDF_AV_OPEN_FILE:
				strcpy(va_helpbuf,data1);
				
				to_ap_id = appl_find("MYPDF   ");
				msg[2] = 0;

				if(data1!=NULL)
					*(char **) (msg + 3) = va_helpbuf;	
/*
				{
					msg[3] = (short)(((long)va_helpbuf >> 16) & 0x0000ffff);
					msg[4] = (short)((long)va_helpbuf & 0x0000ffffL);
				}
*/				
				break;
			case AV_EXIT:
				msg[2] = 0;
				msg[3] = gl_apid;
				break;
			case AV_PROTOKOLL:
			    strcpy(va_helpbuf, "HIGHWIRE");
				msg[2] = 0;
				msg[3] = (2|16);		/* VA_START, Quoting */
				msg[4] = 0;
				msg[5] = 0;
				msg[6] = (short)(((long)va_helpbuf >> 16) & 0x0000ffff);
				msg[7] = (short)((long)va_helpbuf & 0x0000ffffL);
				break;
			default:
				msg[2] = 0;
				msg[3] = 0;
				break;
		}	

		if(appl_write(to_ap_id, 16, msg)!=0)
			return(1);
		else
			return(0);
	}
	
	return(0);
}


int
Receive_AV(void)
{
	return(0);
}

void Init_AV_Protocol(void)
{
	/* OK we need a better test on this.
	 * I know there is a way to determine if a system has
	 * Mxalloc.  I don't have the proper docs to say when that is
	 * baldrick Feb 15, 2002
	 */
	 
	va_helpbuf[0] = 0;

	av_shell_id = get_avserver();
			
	Send_AV(av_shell_id, AV_PROTOKOLL, NULL, NULL);
}

void Exit_AV_Protocol(void)
{
	if ((av_shell_id >= 0) && (av_shell_status & 1024))
		Send_AV(av_shell_id, AV_EXIT, NULL, NULL);
}

#if 0

int send_vastart(char *path, char *cmdline)
{
	int i;
	char progname[32];
	char *dummy;

	strncpy(progname,path,min((strlen(path)),32));

	dummy = strrchr(progname,'.');
	
	dummy[0] = '\0';

	/* make certain the name is 8 char long */
	
	if (strlen(progname)>8)
		progname[8]=0;
	else
		while (strlen(progname)<8) 
			strcat(progname," ");

	/* make certain the name is uppercase */

	for (i=0;i<8;i++)
		progname[i]=toupper(progname[i]);

	if ((i=appl_find(progname))>=0)
	{	
    	strcpy(va_helpbuf, (char *)&cmdline[1]);

		send_extmessage(i, VA_START, 0, (int)(((long)va_helpbuf >> 16) & 0x0000ffff), (int)((long)va_helpbuf & 0x0000ffffL), 0, 0, 0);

		return(1);
	}
	
	return(0);
		
}

#endif

