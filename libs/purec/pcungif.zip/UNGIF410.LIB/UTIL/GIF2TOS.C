/******************************************************************************   "Gif-Lib" - Yet another gif library.				     **									     ** Written by:  Gershon Elber				Ver 0.1, Jul. 1989   ******************************************************************************** Program to display GIF file under X11 window system.			     ** Options:								     ** -q : quiet printing mode.						     ** -p PosX PosY : defines the position where to put the image.		     ** -d Display : what display should go to.				     ** -f : force attempt to allocate the exact colors. This usually look bad...  ** -h : on-line help.							     ******************************************************************************** History:								     ** 28 Dec 89 - Version 1.0 by Gershon Elber, color allocation is based on the **		xgif program by John Bradley, bradley@cis.ipenn.edu.	     ******************************************************************************/#ifdef HAVE_CONFIG_H#include <config.h>#endif#ifdef __MSDOS__#include <graphics.h>#include <stdlib.h>#include <alloc.h>#include <io.h>#include <dos.h>#include <bios.h>#endif /* __MSDOS__ */#ifndef __MSDOS__#include <stdlib.h>#endif#include <stdio.h>#include <ctype.h>#include <string.h>
#ifdef __PUREC__#include <gemx.h>
#else
#include <fcntl.h>
#endif#include "gif_lib.h"#include "getarg.h"#define PROGRAM_NAME	"Gif2TOS"#define ICON_SIZE	60#define ABS(x)		((x) > 0 ? (x) : (-(x)))#ifdef __MSDOS__extern unsigned int    _stklen = 16384;			     /* Increase default stack size. */#endif /* __MSDOS__ */#ifdef SYSVstatic char *VersionStr =        "Gif toolkit module,\t\tGershon Elber\n\	(C) Copyright 1989 Gershon Elber.\n";static char    *CtrlStr = "Gif2X11 q%- p%-PosX|PosY!d!d d%-Display!s f%- h%- GifFile!*s";#elsestatic char    *VersionStr =	PROGRAM_NAME	GIF_LIB_VERSION	"	Gershon Elber,	"	__DATE__ ",   " __TIME__ "\n"	"(C) Copyright 1989 Gershon Elber.\n";static char    *CtrlStr =	PROGRAM_NAME	" q%- p%-PosX|PosY!d!d d%-Display!s f%- h%- GifFile!*s";#endif /* SYSV *//* Make some variables global, so we could access them faster: */static int    PosFlag = FALSE,    HelpFlag = FALSE,    DisplayFlag = FALSE,    ForceFlag = FALSE,    ColorMapSize = 0,    BackGround = 0,    XPosX = 0,    XPosY = 0,    InterlacedOffset[] = { 0, 4, 2, 1 }, /* The way Interlaced image should. */    InterlacedJumps[] = { 8, 8, 4, 2 };    /* be read - offsets and jumps... */static char    *DisplayName = NULL;static ColorMapObject    *ColorMap;RGB1000 image_colortab[256]; /* used to temp hold image pallette */
RGB1000 screen_colortab[256]; /* used to temp hold image pallette */
MFDB screen;
MFDB image;
int no_colors;
int img_handle;

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef min
#define min(a, b)             ((a) < (b) ? (a) : (b))
#endif

#ifndef max
#define max(a, b)             ((a) > (b) ? (a) : (b))
#endif
#if 0static void Screen2X(int argc, char **argv, GifRowType *ScreenBuffer,		     int ScreenWidth, int ScreenHeight);static void AllocateColors1(void);static void AllocateColors2(void);#endif
/******************************************************************************* Interpret the command line and scan the given GIF file.		      *******************************************************************************/int main(int argc, char **argv){    int	i, j, Error, NumFiles, ImageNum = 0, Row, Col, Width, Height,        ExtCode, Count;
    long Size;    GifRecordType RecordType;    GifByteType *Extension;    char **FileName = NULL;    GifRowType *ScreenBuffer;    GifFileType *GifFile;
#if 0    if ((Error = GAGetArgs(argc, argv, CtrlStr,		&GifQuietPrint, &PosFlag, &XPosX, &XPosY,	        &DisplayFlag, &DisplayName, &ForceFlag,		&HelpFlag, &NumFiles, &FileName)) != FALSE ||		(NumFiles > 1 && !HelpFlag)) {	if (Error)	    GAPrintErrMsg(Error);	else if (NumFiles > 1)	    GIF_MESSAGE("Error in command line parsing - one GIF file please.");	GAPrintHowTo(CtrlStr);	exit(EXIT_FAILURE);    }    if (HelpFlag) {	fprintf(stderr, VersionStr);	GAPrintHowTo(CtrlStr);	exit(EXIT_SUCCESS);    }#endif
NumFiles = 1;
/*strcpy(FileName,argv[1]);*/
*FileName = argv[1];
    if (NumFiles == 1) {	if ((GifFile = DGifOpenFileName(*FileName)) == NULL) {	    PrintGifError();	    exit(EXIT_FAILURE);	}    }    else {	/* Use the stdin instead: */#ifdef __MSDOS__	setmode(0, O_BINARY);#endif /* __MSDOS__ */	if ((GifFile = DGifOpenFileHandle(0)) == NULL) {	    PrintGifError();	    exit(EXIT_FAILURE);	}    }    /* Allocate the screen as vector of column of rows. We cannt allocate    */    /* the all screen at once, as this broken minded CPU can allocate up to  */    /* 64k at a time and our image can be bigger than that:		     */    /* Note this screen is device independent - its the screen as defined by */    /* the GIF file parameters itself.					     */    if ((ScreenBuffer = (GifRowType *)	malloc(GifFile->SHeight * sizeof(GifRowType *))) == NULL)	    GIF_EXIT("Failed to allocate memory required, aborted.");    Size = GifFile->SWidth * sizeof(GifPixelType);/* Size in bytes one row.*/    if ((ScreenBuffer[0] = (GifRowType) malloc(Size)) == NULL) /* First row. */	GIF_EXIT("Failed to allocate memory required, aborted.");    for (i = 0; i < GifFile->SWidth; i++)  /* Set its color to BackGround. */	ScreenBuffer[0][i] = GifFile->SBackGroundColor;    for (i = 1; i < GifFile->SHeight; i++) {	/* Allocate the other rows, and set their color to background too: */	if ((ScreenBuffer[i] = (GifRowType) malloc(Size)) == NULL)	    GIF_EXIT("Failed to allocate memory required, aborted.");	memcpy(ScreenBuffer[i], ScreenBuffer[0], Size);    }    /* Scan the content of the GIF file and load the image(s) in: */    do {	if (DGifGetRecordType(GifFile, &RecordType) == GIF_ERROR) {	    PrintGifError();	    exit(EXIT_FAILURE);	}	switch (RecordType) {	    case IMAGE_DESC_RECORD_TYPE:		if (DGifGetImageDesc(GifFile) == GIF_ERROR) {		    PrintGifError();		    exit(EXIT_FAILURE);		}		Row = GifFile->Image.Top; /* Image Position relative to Screen. */		Col = GifFile->Image.Left;		Width = GifFile->Image.Width;		Height = GifFile->Image.Height;		GifQprintf("\n%s: Image %d at (%d, %d) [%dx%d]:     ",		    PROGRAM_NAME, ++ImageNum, Col, Row, Width, Height);		if (GifFile->Image.Left + GifFile->Image.Width > GifFile->SWidth ||		   GifFile->Image.Top + GifFile->Image.Height > GifFile->SHeight) {		    fprintf(stderr, "Image %d is not confined to screen dimension, aborted.\n",ImageNum);		    exit(EXIT_FAILURE);		}		if (GifFile->Image.Interlace) {		    /* Need to perform 4 passes on the images: */		    for (Count = i = 0; i < 4; i++)			for (j = Row + InterlacedOffset[i]; j<Row + Height;						 j += InterlacedJumps[i]) {			    GifQprintf("\b\b\b\b%-4d", Count++);			    if (DGifGetLine(GifFile, &ScreenBuffer[j][Col],				Width) == GIF_ERROR) {				PrintGifError();				exit(EXIT_FAILURE);			    }			}		}		else {		    for (i = 0; i < Height; i++) {			GifQprintf("\b\b\b\b%-4d", i);			if (DGifGetLine(GifFile, &ScreenBuffer[Row++][Col],				Width) == GIF_ERROR) {			    PrintGifError();			    exit(EXIT_FAILURE);			}		    }		}		break;	    case EXTENSION_RECORD_TYPE:		/* Skip any extension blocks in file: */		if (DGifGetExtension(GifFile, &ExtCode, &Extension) == GIF_ERROR) {		    PrintGifError();		    exit(EXIT_FAILURE);		}		while (Extension != NULL) {		    if (DGifGetExtensionNext(GifFile, &Extension) == GIF_ERROR) {			PrintGifError();			exit(EXIT_FAILURE);		    }		}		break;	    case TERMINATE_RECORD_TYPE:		break;	    default:		    /* Should be traps by DGifGetRecordType. */		break;	}    }    while (RecordType != TERMINATE_RECORD_TYPE);    /* Lets display it - set the global variables required and do it: */    BackGround = GifFile->SBackGroundColor;    ColorMap = (GifFile->Image.ColorMap		? GifFile->Image.ColorMap		: GifFile->SColorMap);    ColorMapSize = ColorMap->ColorCount;
/*    Screen2X(argc, argv, ScreenBuffer, GifFile->SWidth, GifFile->SHeight);*/    for (i = GifFile->SHeight - 1 ; i >= 0 ; i--) {	free( ScreenBuffer[ i ] );    }    free( ScreenBuffer ); 
 /*
    if ( XImageBuffer != (XImage *) NULL )	XDestroyImage( XImageBuffer );*/    if (DGifCloseFile(GifFile) == GIF_ERROR) {	PrintGifError();	exit(EXIT_FAILURE);    }    GifQprintf("\n");	return 0 ;}

#if 0/******************************************************************************* The real display routine.						      *******************************************************************************/static void Screen2X(int argc, char **argv, GifRowType *ScreenBuffer,		     int ScreenWidth, int ScreenHeight){#define	WM_DELETE_WINDOW	"WM_DELETE_WINDOW"	Status	rc ;	Atom	atomKill ;    int i, j, c, Size, x, y,        MinIntensity, MaxIntensity, AvgIntensity, IconSizeX, IconSizeY;    char *XImageData, *XIconData, KeyBuffer[81];    double Aspect;    GifByteType *OutLine, Data;    unsigned long ValueMask;    GifPixelType *Line;    GifRowType *DitherBuffer;    GifColorType *ColorMapEntry = ColorMap->Colors;    XSetWindowAttributes SetWinAttr;    XSizeHints Hints;    XEvent Event;    XExposeEvent *EEvent;    XKeyEvent *KEvent;    XComposeStatus Stat;    KeySym KS;    /* Let find out what are the intensities in the color map: */    MaxIntensity = 0;    MinIntensity = 256 * 100;    for (i = 0; i < ColorMapSize; i++) {	c = ColorMapEntry[i].Red * 30 +	    ColorMapEntry[i].Green * 59 +	    ColorMapEntry[i].Blue * 11;	if (c > MaxIntensity) MaxIntensity = c;	if (c < MinIntensity) MinIntensity = c;    }    AvgIntensity = (MinIntensity + MaxIntensity) / 2;    /* The big trick here is to select the colors so lets do this first: */    if (ForceFlag)	AllocateColors2();    else	AllocateColors1();    SetWinAttr.background_pixel = BlackPixel( XDisplay, XScreen );    SetWinAttr.border_pixel = WhitePixel( XDisplay, XScreen );    ValueMask = CWBackPixel | CWBorderPixel;    Hints.flags = PSize | PMinSize | PMaxSize;    Hints.x = Hints.y = 1;    Hints.width = Hints.min_width = Hints.max_width = ScreenWidth;    Hints.height = Hints.min_height = Hints.max_height = ScreenHeight;    if (PosFlag) {	Hints.flags |= USPosition;	Hints.x = XPosX;	Hints.y = XPosY;    }    XImageWndw = XCreateWindow(XDisplay, Xroot, XPosX, XPosY,			       ScreenWidth, ScreenHeight,			       1, 0,			       CopyFromParent, CopyFromParent,			       ValueMask, &SetWinAttr);    /* Set up the icon bit map to be a shrinked BW version of the image: */    if (ScreenWidth > ScreenHeight) {	IconSizeX = (ICON_SIZE / 8) * 8;	IconSizeY = (ScreenHeight * ICON_SIZE) / ScreenWidth;    }    else {	IconSizeY = ICON_SIZE;	IconSizeX = (((ScreenWidth * ICON_SIZE) / ScreenHeight) / 8) * 8;    }    XIconData = (char *) malloc(IconSizeX * IconSizeY / 8);    memset(XIconData, 0, IconSizeX * IconSizeY / 8);    for (i = 0; i < IconSizeY; i++) {	y = (i * ScreenHeight / IconSizeY);	Size = i * IconSizeX / 8;	for (j = 0; j < IconSizeX; j++) {	    x = j * ScreenWidth / IconSizeX;	    c = ScreenBuffer[y][x];	    c = ColorMapEntry[c].Red * 30 +		ColorMapEntry[c].Green * 59 +		ColorMapEntry[c].Blue * 11 > AvgIntensity;	    XIconData[Size + j / 8] |= c << (j % 8);	}    }    XIcon = XCreateBitmapFromData(XDisplay, XImageWndw, XIconData,				  IconSizeX, IconSizeY);    XSetStandardProperties(XDisplay, XImageWndw,			   PROGRAM_NAME, PROGRAM_NAME, XIcon,			   argv, argc,			   &Hints);    free( XIconData );    atomKill = XInternAtom(XDisplay, WM_DELETE_WINDOW, False );    rc = XSetWMProtocols( XDisplay, XImageWndw , &atomKill , 1 );    if ( rc == 0 )	GIF_EXIT("Failed to trap WM_DELETE_WINDOW event" );    XSelectInput(XDisplay, XImageWndw, ExposureMask | KeyPressMask);    /* Set out own cursor: */    XCursor = XCreateFontCursor(XDisplay, XC_diamond_cross);    XDefineCursor(XDisplay, XImageWndw, XCursor);        XMapWindow(XDisplay, XImageWndw);    /* Create the image in X format: */    if ((XImageData = (char *) malloc(ScreenWidth * ScreenHeight)) == NULL)	GIF_EXIT("Failed to allocate memory required, aborted.");    for (i = 0; i < ScreenHeight; i++) {	y = i * ScreenWidth;	for (j = 0; j < ScreenWidth; j++)	    XImageData[y + j] = XPixelTable[ScreenBuffer[i][j]];    }    XImageBuffer = XCreateImage(XDisplay, XVisual, 8, ZPixmap, 0,				XImageData, ScreenWidth, ScreenHeight,				8, ScreenWidth);    while (TRUE) {	XNextEvent(XDisplay, &Event);	switch (Event.type) {	    case Expose:	        EEvent = (XExposeEvent *) &Event;		XPutImage(XDisplay, XImageWndw, XGraphContext, XImageBuffer,			  EEvent->x, EEvent->y,			  EEvent->x, EEvent->y,			  EEvent->width, EEvent->height);		break;	    case KeyPress:	        KEvent = (XKeyEvent *) &Event;		XLookupString(KEvent, KeyBuffer, 80, &KS, &Stat);		if (KeyBuffer[0] == 3) return;	/*	if (KeyBuffer[0] == 3) { free(XImageData ); return; }	made by XDestroyImage	*/		break;	    case ClientMessage :		if ( Event.xclient.data.l[0] == atomKill ) return ;		break ;	}    }}/******************************************************************************* Routine to allocate the requested colors from the X server.		      ** Colors are allocated until success by stripping off the least bits of the   ** colors.								      *******************************************************************************/static void AllocateColors1(void){    int Strip, Msk, i, j;    char Msg[80];    for (i = 0; i < 256; i++)	XPixelTable[i] = 0;	   /* Put reasonable color for out of range. */    for (Strip = 0, Msk = 0xff; Strip < 8; Strip++, Msk <<= 1) {	for (i = 0; i < ColorMapSize; i++) {	    /* Prepere color entry in X format. */	    XColorTable[i].red = (ColorMap->Colors[i].Red & Msk) << 8;	    XColorTable[i].green = (ColorMap->Colors[i].Green & Msk) << 8;	    XColorTable[i].blue = (ColorMap->Colors[i].Blue & Msk) << 8;	    XColorTable[i].flags = DoRed | DoGreen | DoBlue;	    if (XAllocColor(XDisplay, XColorMap, &XColorTable[i]))		XPixelTable[i] = XColorTable[i].pixel;	    else		break;	}	if (i < ColorMapSize)	    XFreeColors(XDisplay, XColorMap, XPixelTable, i, 0L);	else	    break;    }    if (Strip == 8)	GIF_EXIT("Can not display the image - not enough colors available.");    if (Strip != 0) {	sprintf(Msg, "%d bits were stripped off the color map.", Strip);	GIF_MESSAGE(Msg);    }}/******************************************************************************* Routine to allocate the requested colors from the X server.		      ** Two stages are performed:						      ** 1. Colors are requested directly.					      ** 2. If not enough colors can be allocated, the closest current color	      **    in current table is selected instead.				      ** This allocation is not optimal as when fail to allocate all colors one      ** should pick the right colors to do allocate in order to minimize the        ** closest distance from the unallocated ones under some norm (what is a good  ** norm for the RGB space?). Improve it if you are bored.		      *******************************************************************************/static void AllocateColors2(void){    int i, j, Index = 0, Count = 0, XNumOfColors;    char Msg[80];    unsigned long D, Distance, AvgDistance = 0, Red, Green, Blue;    GifBooleanType Failed = FALSE;    XColor *XOldColorTable;    for (i = 0; i < 256; i++) {	if (i < ColorMapSize) {          /* Prepere color entry in X format. */	    XColorTable[i].red = ColorMap->Colors[i].Red << 8;	    XColorTable[i].green = ColorMap->Colors[i].Green << 8;	    XColorTable[i].blue = ColorMap->Colors[i].Blue << 8;	    XColorTable[i].flags = DoRed | DoGreen | DoBlue;	    XPixelTable[i] = -1;		       /* Not allocated yet. */	}	else	    XPixelTable[i] = 0;    /* Put reasonable color for out of range. */    }    for (i = 0; i < ColorMapSize; i++)	      /* Allocate the colors from X: */	if (XAllocColor(XDisplay, XColorMap, &XColorTable[i]))	    XPixelTable[i] = XColorTable[i].pixel;	else	    Failed = TRUE;    if (Failed) {	XNumOfColors = DisplayCells(XDisplay, XScreen);	XOldColorTable = (XColor *) malloc(sizeof(XColor) * XNumOfColors);	for (i = 0; i < XNumOfColors; i++) XOldColorTable[i].pixel = i;	XQueryColors(XDisplay, XColorMap, XOldColorTable, XNumOfColors);		for (i = 0; i < ColorMapSize; i++) {	    /* Allocate closest colors from X: */	    if (XPixelTable[i] == -1) {      /* Failed to allocate this one. */		Distance = 0xffffffff;		Red = XColorTable[i].red;		Green = XColorTable[i].green;		Blue = XColorTable[i].blue;		for (j = 0; j < XNumOfColors; j++) {		    /* Find the closest color in 3D RGB space using L1 norm. */		    if ((D = ABS(Red - XOldColorTable[j].red) +			     ABS(Green - XOldColorTable[j].green) +			     ABS(Blue - XOldColorTable[j].blue)) < Distance) {			Distance = D;			Index = j;		    }		}	        XPixelTable[i] = Index;		AvgDistance += Distance;		Count++;	    }	}	free(XOldColorTable);	sprintf(Msg, "Colors will be approximated (average error = %d).\n",		AvgDistance / Count);	GIF_MESSAGE(Msg);    }}#endif

/* shows img on screen */
int show_img(GifRowType *ScreenBuffer, GifFileType *GifFile)
{
  int screen_planes, screen_w, screen_h, buttons = 0, key,
        i, x1 = 0, y1 = 0, x2 = 0, y2 = 0, mx, my, xx, yy, cen_x, cen_y,
        redraw = TRUE, work_in[11], work_out[57], pxyarray[8],
        wg_x, wg_y, wg_w, wg_h;
  MFDB image, tmpscreen;

  /* Screen and Image VDI Memory Form Definitions. */
  tmpscreen.fd_addr   = 0;
  image.fd_addr    = ScreenBuffer;                 /* address      */
  image.fd_w       = GifFile->SWidth;                /* width        */
  image.fd_wdwidth = (GifFile->SWidth + 15) >> 4;    /* (words)      */
  image.fd_h       = GifFile->SHeight;                /* height       */
  image.fd_stand   = 0;                         /* raster format = device */
  image.fd_nplanes = GifFile->SColorResolution;               /* bitplanes    */

  /*** This could be as well *your* window's work area. ***/
  /* Desktop work area. */
  wind_get ( 0, WF_WORKXYWH, &wg_x, &wg_y, &wg_w, &wg_h );

  /* pic size on screen */
  xx = min( wg_w, GifFile->SWidth );
  yy = min( wg_h, GifFile->SHeight );

  /* for centering pic on screen */
  cen_x = ((wg_w - xx) >> 1) + wg_x;
  cen_y = ((wg_h - yy) >> 1) + wg_y;

  /* open virtual screen workstation (screen) */
  work_in[0] = 1; work_in[10] = 2;

  if (vq_gdos() == 0)
	{
		work_in[0] = 2 + Getrez(); 
	}

  img_handle = graf_handle( &i, &i, &i, &i );

  v_opnvwk( work_in, &img_handle, work_out );
  screen_w = work_out[0];
  screen_h = work_out[1];

  no_colors = work_out[13];

  /* get the number of bitplanes on screen */

  vq_extnd(img_handle, 1, work_out);
  screen_planes = work_out[4];


  /* convert image to the current screen format if necessary */
  if( !(transform_img( &image, screen_planes, GifFile->SColorMap, img_handle)) )
  {
    v_clsvwk( img_handle );
    return( FALSE );
  }

  /* suspend other screen activity */
  /*wind_update( BEG_UPDATE );
  form_dial( FMD_START, wg_x, wg_y, wg_w, wg_h, wg_x, wg_y, wg_w, wg_h );

  graf_mouse( M_OFF, 0 );
*/


  do
  {
    /* get mouse position */
    graf_mkstate( &mx, &my, &buttons, &key );

    /* calculate new image place */
    x1 = (long) mx * (image.fd_w - xx) / screen_w;
    y1 = (long) my * (image.fd_h - yy) / screen_h;

    /* fit co-ordinates onto screen */
    x1 = min( x1, GifFile->SWidth - xx );
    y1 = min( y1, GifFile->SHeight - yy );
    x1 = max( 0, x1 );
    y1 = max( 0, y1 );

    /* draw image if necessary */
    if ( redraw || x1 != x2 || y1 != y2 )
    {
      /* put values into the co-ordinate array */
      pxyarray[0] = x1;
      pxyarray[1] = y1;
      pxyarray[2] = x1 + xx - 1;
      pxyarray[3] = y1 + yy - 1;
      pxyarray[4] = cen_x;
      pxyarray[5] = cen_y;
      pxyarray[6] = cen_x + xx - 1;
      pxyarray[7] = cen_y + yy - 1;

      /* throw onto screen */
      vro_cpyfm( img_handle, S_ONLY, pxyarray, &image, &tmpscreen); /* was source*/

      x2 = x1; y2 = y1;
      redraw = FALSE;
    }
  /* exit with right button */
  }
  while(buttons != 1);

  /*graf_mouse( M_ON, 0 );*/

  /* enable other screen activities */
  wind_update( END_UPDATE );

  /* redraw screen (really necessary with MTOS only) */
  form_dial( FMD_FINISH, wg_x, wg_y, wg_w, wg_h, wg_x, wg_y, wg_w, wg_h );

  /* close virtual... */
  v_clsvwk( img_handle );

  /* if image was converted to device format, free allcated memory */
  if( image.fd_addr != ScreenBuffer )
    free( image.fd_addr );

  return( TRUE );
}
