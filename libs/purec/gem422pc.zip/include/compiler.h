#ifndef _COMPILER_H
# define _COMPILER_H 1


#ifdef __PUREC__

# define __BEGIN_DECLS
# define __END_DECLS

# define inline

# define __CDECL cdecl

#endif /* __PUREC__ */


#endif /* _COMPILER_H */
