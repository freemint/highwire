/* This file should contain the keyboard handler
 * routines.  ie. Input to forms, URL address etc
 *
 * right now it just handles hot key for UNDO - back up a page 
 * baldrick July 10, 2001
 */


#include <stdlib.h>
#include <string.h>

#include <gemx.h>

#include "global.h"

/* added 10-04-01 mj. req'd for file selector */
#include <stdio.h>
#ifndef PATH_MAX
#define PATH_MAX 255
#endif
#define EOS                '\0'  /* End of string                  */
#define BACKSLASH          '\\'
char Path[PATH_MAX] = "D:\\*.HTM";
/* */

void
key_pressed (struct frame_item *first_frame, WORD key)
{
	struct frame_item *current_frame;
	struct frame_item *t_frame;
/*	char test; * unused */
	int i;

	extern char prev_location[128];
	
/*	printf("key = %d\r\n",key);
*/

	current_frame = first_frame;

/*
	Doesn't handle forms yet so just skip down to hotkeys

	while (current_frame != 0)
	{
		if (mx < current_frame->clip.x + current_frame->clip.w + scroll_bar_width
		    && mx > current_frame->clip.x
		    && my < current_frame->clip.y + current_frame->clip.h + scroll_bar_width
		    && my > current_frame->clip.y)
		{
			frame_clicked (first_frame, current_frame, mx, my);
			return;
		}
		current_frame = current_frame->next_frame;
	}
*/

	/* nothing else so process hotkeys */
	
	switch (key)
	{
		case 24832: /* UNDO */
			/* create temp frame */
			t_frame = temp_frame();
				
			/* set temp frame values to what we want for new frame*/
			t_frame->frame_left = 0;
			t_frame->frame_top = 0;
			t_frame->frame_width = -100;
			t_frame->frame_height = -100;
			t_frame->border = current_frame->border;
				
			add_load_item_to_to_do_list (0, prev_location, first_frame, t_frame);

			break;
#ifdef GEM_MENU
		/* change 12-22-01 mj. */
		case 4113:  handle_menu(M_QUIT, NULL); break;
		case 5897:  handle_menu(M_ABOUT, NULL); break;
		case 6159:  handle_menu(M_OPEN, NULL); break;
#else
		/* added 10-04-01 mj. */
		case 5897: /* CTL-I */
		    form_alert(1,"[1][Highwire HTML Browser v. 0.2|http://highwire.atari-users.net/][ok]");
		    break;
		case 6159: /* CTL-O */
			i=page_load();
			break;
		case 4113: /* CTL-Q */
			highwire_ex();
			break;
#endif
		/* */
		default:
			break;
	}
	
	key = 0;
}

/* page_load
 * 
 * calls the fileselector and loads the selected file
 *
 * added 10-04-01 mj. 
 * 
 * simplified AltF4 December 26, 2001
 */
int page_load(void )
{
	char n[80] = "",                  /* Buffer f�r Dateinamen         */
        x[312];    
	WORD butt;                             /* Enth�lt Code des Buttons der  */

	fsel_exinput( Path, n, &butt, "Open file..." );

	if ( butt != 0)
	{
		build_fname( x, Path, n );
		init_load(x);
   }
   return ( butt );

}

void build_fname( char *dest, char *s1, char *s2 )
{
   char *cptr;

   strcpy( dest, s1 );                 /* Pfad kopieren.                */
   cptr = strrchr( dest, (int) BACKSLASH);
   strcpy( ++cptr, s2);                /* Schlie�lich den Dateinamen    */
}                                      /* dranh�ngen.                   */
/* */

