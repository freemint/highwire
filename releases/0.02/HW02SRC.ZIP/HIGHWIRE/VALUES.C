#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

#define numberof(arr)   (sizeof(arr) / sizeof(*arr))

#include "token.h"


#ifndef NULL
# define NULL ((void*)0)
#endif


struct VARIABLE {
	HTMLKEY      Key :16;
	unsigned     Len :16;
	const char * Value;
};
static struct VARIABLE var_tab[16];
static int             var_num = 0;

int
Variable (HTMLKEY key, char * output, size_t max_len)
{
	int found = 0;
	int i;
	
	for (i = 0; i < var_num; i++) {
		if (key == var_tab[i].Key) {
			if (!output) {
				found = 1;
			} else if (var_tab[i].Len && var_tab[i].Len < max_len) {
				memcpy (output, var_tab[i].Value, var_tab[i].Len);
				output[var_tab[i].Len] = '\0';
				found = 1;
			}
			break;
		}
	}
	return found;
}

char *
Variable_str (HTMLKEY key)
{
	char * found = NULL;
	int i;
	
	for (i = 0; i < var_num; i++) {
		if (key == var_tab[i].Key) {
			found = malloc (var_tab[i].Len +1);
			memcpy (found, var_tab[i].Value, var_tab[i].Len);
			found[var_tab[i].Len] = '\0';
			break;
		}
	}
	return found;
}


struct TAG {
	const char * Name;
	HTMLTAG      Tag;
};
static struct TAG tag_table[] = {
	#define __TAG_ITEM(t) { #t, TAG_##t }
	#include "token.h"
};

struct KEY {
	const char * Name;
	HTMLKEY      Key;
};
static struct KEY key_table[] = {
	#define __KEY_ITEM(k) { #k, KEY_##k }
	#include "token.h"
};

HTMLTAG
parse (char ** _line)
{
	HTMLTAG tag  = TAG_Unknown;
	char  * line = *_line;
	char  * p    = line;
	size_t  len;
	
	
	/*** first find the tag, same way as in Scanner.c */
	
	int beg = 0;
	int end = (int)numberof(tag_table) -1;
	
	var_num = 0;
	
	while (isalpha(*p)) p++;
	len = p - line;
	do {
		int i = (end + beg) /2;
		int d = strnicmp (line, tag_table[i].Name, len);
		if (d > 0) {
			beg = i +1;
		} else if (d || tag_table[i].Name[len]) {
			end = i -1;
		} else {
			if ((tag = tag_table[i].Tag) == TAG_H) {
				if (line[len] < '1' || line[len] > '6') {
					tag = TAG_Unknown;
				} else {
					var_tab[0].Key   = KEY_H_HEIGHT;
					var_tab[0].Value = p++;
					var_tab[0].Len   = 1;
					var_num = 1;
				}
			}
			break;
		}
	} while (beg <= end);

/*printf("% 2i [%.*s]\n", tag, (int)len, line);*/
	
	/*** if the tag is known or not, in every case we have to go through the list
	 *   of variabls to avoid the parser to become confused   */
	
	while (isspace(*p)) p++;
	
	while (*p  &&  *p != '>') {
		char * val = NULL;
		
		line = p;
		while (isalpha(*p) || *p == '-') p++;
		len = p - line;
		
		while (isspace(*p)) p++;
		if (*p == '=' || !len) {
			while (isspace(*(++p)));
			val = p;
			p = (*val == '"' ? strchr (++val, '"') : strpbrk (val, " >\t\r\n"));
			if (!p) p = strchr (val, '\0');
		}
		
		if (tag != TAG_Unknown  &&  len) {
			beg = 0;
			end = (int)numberof(key_table) -1;
			do {
				int i = (end + beg) /2;
				int d = strnicmp (line, key_table[i].Name, len);
				if (d > 0) {
					beg = i +1;
				} else if (d || key_table[i].Name[len]) {
					end = i -1;
				} else {
					if (var_num < numberof(var_tab)) {
						var_tab[var_num].Key = key_table[i].Key;
						if (val  &&  val < p) {
							var_tab[var_num].Value = val;
							var_tab[var_num].Len   = (unsigned)(p - val);
						} else {
							var_tab[var_num].Value = NULL;
							var_tab[var_num].Len   = 0;
						}
						var_num++;
					}
/* printf("  |%.*s=%.*s|\n", (int)len, line, (int)(p - val), val);*/
					break;
				}
			} while (beg <= end);
		}
		while (isspace(*p)) p++;
		if (*p == '"') {
			while (isspace(*++(p)));
		}
	}
	
	if (*p == '>') {
		p++;
	}
	*_line = p;
	
	return tag;
}
