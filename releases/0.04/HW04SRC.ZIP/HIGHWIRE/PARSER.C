/* @(#)highwire/parser.c
 *
 * parser.c -- Parser functions for HTML expressions.
 *
 * AltF4 - Jan 14, 2002
 *
 */


#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

#include "global.h"
#include "token.h"
#include "scanner.h"
#include "parser.h"


/* Array to store KEY=VALUE pairs found while a parse() call.
 */
struct VALUE {
	HTMLKEY      Key :16;
	unsigned     Len :16;
	const char * Value;
};
static struct VALUE val_tab[16];
static int          val_num = 0;

/*==============================================================================
 * Finds the VALUE of 'key' that was read while the last parse() call.
 * If successful the VALUE will be copied to 'output' up to 'max_len' character
 * (including the trailing '\0') and a TRUE will be returned.
 * Else a FALSE will be returned.
 */
BOOL
get_value (HTMLKEY key, char * output, const size_t max_len)
{
	BOOL found = FALSE;
	int  i;

	for (i = 0; i < val_num; i++) {
		if (key == val_tab[i].Key) {
			if (!output) {
				found = TRUE;
			} else if (val_tab[i].Len && val_tab[i].Len < max_len) {
				memcpy (output, val_tab[i].Value, val_tab[i].Len);
				output[val_tab[i].Len] = '\0';
				found = TRUE;
			}
			break;
		}
	}
	return found;
}


/*==============================================================================
 * Returns the VALUE of 'key' that was read while the last parse() call as a
 * malloc'ed zero terminated character string.
 * If not successful the result is a NULL pointer.
 */
char *
get_value_str (HTMLKEY key)
{
	char * found = NULL;
	int i;

	for (i = 0; i < val_num; i++) {
		if (key == val_tab[i].Key) {
			found = malloc (val_tab[i].Len +1);
			memcpy (found, val_tab[i].Value, val_tab[i].Len);
			found[val_tab[i].Len] = '\0';
			break;
		}
	}
	return found;
}


/*==============================================================================
 * Returns the first character of the VALUE of 'key' that was read while the
 * last parse() call.
 * If not successful a '\0' will be returned.
 */
char
get_value_char (HTMLKEY key)
{
	char found = '\0';
	int i;

	for (i = 0; i < val_num; i++) {
		if (key == val_tab[i].Key) {
			if (val_tab[i].Len) {
				found = *val_tab[i].Value;
			}
			break;
		}
	}
	return found;
}


/*==============================================================================
 * Returns the VALUE of 'key' that was read while the last parse() call as a
 * unsigned short.
 * If not successful the value of 'dflt' will be returned instead, which may
 * also be negative.
 */
WORD
get_value_unum (HTMLKEY key, WORD dflt)
{
	int i;

	for (i = 0; i < val_num; i++) {
		if (key == val_tab[i].Key) {
			if (val_tab[i].Len) {
				char * tail;
				long   value = strtol (val_tab[i].Value, &tail, 10);
				if (value >= 0 && value <= 0x7FFF && tail != val_tab[i].Value) {
					dflt = (WORD)value;
				}
			}
			break;
		}
	}
	return dflt;
}


/*==============================================================================
 * Returns the VDI color VALUE of 'key' that was read while the last parse()
 * call.
 * If not successful a negative number will be returned.
 */
WORD
get_value_color (HTMLKEY key)
{
	WORD color = -1;
	int i;


	for (i = 0; i < val_num; i++) {
		if (key == val_tab[i].Key) {
			long value = scan_color (val_tab[i].Value, val_tab[i].Len);
			if (value >= 0) {
				color = remap_color (value);
			}
			break;
		}
	}

	return color;
}


/*==============================================================================
 * Parses a html TAG expression of the forms
 *    <TAG>  |  <TAG KEY ...>  |  <TAG KEY=VALUE ...>
 * The 'pptr' content must point to the first character after the leading '<'
 * and a possibly '/'.  After processing it is set to first character behind the
 * expression, either behind the closing '>' or to a trailing '\0'.
 * If successful the found known KEYs are stored with their VALUEs internally
 * and a TAG enum is returned.
 * Else the symbol TAG_Unknown is returned.
 */
HTMLTAG
parse_tag (const char ** pptr)
{
	const char * line = *pptr;
	HTMLTAG tag;
	BOOL    lookup;

	val_num = 0;

	/* first check for comment
	 */
	if (*line == '!') {
		line++;
		if (line[0] == '-' && line[1] == '-') {
			const char * end = strstr (line + 2, "--");

			if (end)
				line = end;
		}
		while (*line && *(line++) != '>')
			;
		*pptr = line;

		return TAG_Unknown;
	}

	if ((tag = scan_tag (&line)) == TAG_H) {
		if (*line < '1' || *line > '6') {
			tag = TAG_Unknown;
		} else {
			val_tab[0].Key   = KEY_H_HEIGHT;
			val_tab[0].Value = line++;
			val_tab[0].Len   = 1;
			val_num = 1;
		}
	}
	lookup = (tag != TAG_Unknown);

	/*** if the tag is known or not, in every case we have to go through the list
	 *   of variabls to avoid the parser to become confused   */

	while (isspace(*line)) line++;

	while (*line  &&  *line != '>') {
		const char  * val = line;
		HTMLKEY key = scan_key (&line, lookup);
		BOOL    rhs = (val == line);

		while (isspace(*line)) line++;
		if (*line == '=') {
			while (isspace(*(++line)));
			rhs = TRUE;
		}
		if (rhs) {
			val = line;
			line = (*val == '"' ? strchr (++val, '"') : strpbrk (val, " >\t\r\n"));
			if (!line) line = strchr (val, '\0');
		} else {
			val = NULL;
		}
		if (tag != TAG_Unknown  &&  val_num < numberof(val_tab)) {
			val_tab[val_num].Key = key;
			if (val  &&  val < line) {
				val_tab[val_num].Value = val;
				val_tab[val_num].Len   = (unsigned)(line - val);
			} else {
				val_tab[val_num].Value = NULL;
				val_tab[val_num].Len   = 0;
			}
			val_num++;
		}
		if (*line == '"') line++;
		while (isspace(*line)) line++;
	}

	*pptr = (*line ? ++line : line);

	return tag;
}
