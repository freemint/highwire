#define _HIGHWIRE_MAJOR_     0
#define _HIGHWIRE_MINOR_     3
#define _HIGHWIRE_REVISION_  2
#define _HIGHWIRE_BETATAG_   ""
#define _HIGHWIRE_VERSION_   "0.3.2"
