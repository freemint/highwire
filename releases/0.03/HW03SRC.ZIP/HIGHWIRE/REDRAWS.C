#include <stdlib.h>

#include <gemx.h>

#include "global.h"
#include "Table.h"


#ifdef __GNUC__

static inline int
max (int a, int b)
{
	return (a > b) ? a : b;
}

static inline int
min (int a, int b)
{
	return (a < b) ? a : b;
}

#endif



void frame_draw (FRAME, GRECT *);
void draw_hbar  (FRAME, BOOL complete);
void draw_vbar  (FRAME, BOOL complete);

void
frame_draw (FRAME frame, GRECT * clip)
{
	PXY  bgnd[2];
	bgnd[1].p_x = (bgnd[0].p_x = frame->clip.x) + frame->clip.w -1;
	bgnd[1].p_y = (bgnd[0].p_y = frame->clip.y) + frame->clip.h -1;
	
	if (frame->frame_named_location) {
		frame->vertical_scroll = search_for_named_location (frame->frame_named_location, frame->first_named_location);
		frame->frame_named_location = NULL;
	}
	
	if (clip->g_x < bgnd[0].p_x || clip->g_x + clip->g_w -1 > bgnd[1].p_x ||
	    clip->g_y < bgnd[0].p_y || clip->g_y + clip->g_h -1 > bgnd[1].p_y) {
		/*
		 * draw borders and/or slider
		*/
		PXY l[5];
		int corner = 0;
		
		vsl_color (vdi_handle, G_BLACK);
		vsf_color (vdi_handle, (ignore_colours ? G_WHITE : G_LWHITE));
		
		if (frame->border) {
			l[0].p_x = l[3].p_x = bgnd[0].p_x -1;
			l[0].p_y = l[1].p_y = bgnd[0].p_y -1;
			l[2].p_x = l[1].p_x = bgnd[1].p_x
			                    + (frame->v_scroll_on ? scroll_bar_width : 1);
			l[2].p_y = l[3].p_y = bgnd[1].p_y
			                    + (frame->h_scroll_on ? scroll_bar_width : 1);
			l[4] = l[0];
			v_pline (vdi_handle, 5, (short*)l);
		}
		
		if (frame->v_scroll_on && clip->g_x + clip->g_w -1 > bgnd[1].p_x) {
			draw_vbar (frame, TRUE);
			corner++;
		}
		
		if (frame->h_scroll_on && clip->g_y + clip->g_h -1 > bgnd[1].p_y) {
			draw_hbar (frame, TRUE);
			corner++;
		}
		
		if (corner == 2) {
			short b  = scroll_bar_width - (frame->border ? 3 : 2);
			l[1].p_x = (l[0].p_x = bgnd[1].p_x +2) + b;
			l[1].p_y = (l[0].p_y = bgnd[1].p_y +2) + b;
			v_bar (vdi_handle, (short*)l);
		}
		
		/* adjust the clipping rectangle to the contents extent
		*/
		if (rc_intersect ((GRECT*)&frame->clip, clip)) {
			l[1].p_x = (l[0].p_x = clip->g_x) + clip->g_w -1;
			l[1].p_y = (l[0].p_y = clip->g_y) + clip->g_h -1;
			vs_clip_pxy (vdi_handle, l);
		} else {
			return;
		}
	}
		
	vsf_color (vdi_handle, frame->background_colour);
	v_bar     (vdi_handle, (short*)bgnd);
		
	draw_contents (frame->item,
	               (long)frame->clip.x - frame->horizontal_scroll,
	               (long)frame->clip.y - frame->vertical_scroll,
	               frame->clip.w, clip);
}

void
draw_vbar (FRAME frame, BOOL complete)
{
	short lft = frame->clip.x + frame->clip.w +1;
	short rgt = lft + scroll_bar_width -3;
	short top = frame->clip.y
	          + scroll_bar_width - (frame->border ? 2 : 1);
	short bot = frame->clip.y + frame->clip.h
	          - scroll_bar_width + (frame->border || frame->v_scroll_on ? 1 : 0);
	long  bar = bot - top -1;
	PXY p[8];
	
	vsl_color (vdi_handle, G_BLACK);
	
	if (complete) {
		short n;
		p[0].p_x = p[1].p_x = lft -1;
		p[0].p_y            = frame->clip.y + frame->clip.h -1;
		p[1].p_y            = frame->clip.y;
		if (frame->border) {
			n = 2;
		} else {
			p[2].p_x = p[3].p_x = rgt +1;
			p[2].p_y = p[1].p_y;
			p[3].p_y = p[0].p_y;
			if (frame->v_scroll_on) {
				n = 4;
			} else {
				p[4] = p[0];
				n = 5;
			}
		}
		if (frame->v_scroll_on) {
			p[0].p_y += scroll_bar_width -1;
		}
		v_pline (vdi_handle, n, (short*)p);
		
		p[0].p_y = top - (scroll_bar_width -2);
		p[1].p_y = top - 1;
		p[2].p_y = bot + 1;
		p[3].p_y = bot + (scroll_bar_width -2);
		p[0].p_x = p[2].p_x = lft;
		p[1].p_x = p[3].p_x = rgt;
		v_bar (vdi_handle, (short*)(p +0));
		v_bar (vdi_handle, (short*)(p +2));
		p[0].p_y = ++p[1].p_y;
		p[3].p_y = --p[2].p_y;
		v_pline (vdi_handle, 2, (short*)(p +0));
		v_pline (vdi_handle, 2, (short*)(p +2));
		
		p[0].p_x = p[7].p_x = lft + (scroll_bar_width -2) /2;
		p[1].p_x = p[6].p_x = lft + 1;
		p[2].p_x = p[5].p_x = rgt - 1;
		p[0].p_y            = top - (scroll_bar_width -3);
		p[1].p_y = p[2].p_y = top - 3;
		p[3]     = p[0];
		p[7].p_y            = bot + (scroll_bar_width -3);
		p[6].p_y = p[5].p_y = bot + 3;
		p[4]     = p[7];
		if (ignore_colours) {
			v_pline (vdi_handle, 4, (short*)(p +0));
			v_pline (vdi_handle, 4, (short*)(p +4));
		} else {
			GRECT b;
			b.g_w = b.g_h = scroll_bar_width -2;
			b.g_x = lft;
			b.g_y = top - (scroll_bar_width -2);
			draw_border (&b, G_WHITE, G_LBLACK, 1);
			b.g_y = bot + 1;
			draw_border (&b, G_WHITE, G_LBLACK, 1);
			v_pline (vdi_handle, 2, (short*)(p +0));
			v_pline (vdi_handle, 3, (short*)(p +5));
			vsl_color (vdi_handle, G_WHITE);
			v_pline (vdi_handle, 3, (short*)(p +1));
			v_pline (vdi_handle, 2, (short*)(p +4));
		}
	} else {
		v_hide_c (vdi_handle);
	}
	
	p[0].p_x = p[2].p_x = lft;
	p[0].p_y = p[2].p_y = top +1;
	p[1].p_x = p[3].p_x = rgt;
	p[1].p_y =            bot -1;
	vswr_mode    (vdi_handle, MD_REPLACE);
	vsf_interior (vdi_handle, FIS_PATTERN);
	vsf_style    (vdi_handle, 4);
	vsf_color    (vdi_handle, G_LBLACK);
	v_bar        (vdi_handle, (short*)p);
	
	p[3].p_y = (bar * frame->clip.h) / frame->current_page_height;
	if (p[3].p_y < scroll_bar_width -2)
	    p[3].p_y = scroll_bar_width -2;
	p[2].p_y += ((bar - p[3].p_y) * frame->vertical_scroll)
	          / (frame->current_page_height - frame->clip.h);
	p[3].p_y += p[2].p_y -1;
	vsf_interior (vdi_handle, FIS_SOLID);
	vsf_color    (vdi_handle, (ignore_colours ? G_WHITE : G_LWHITE));
	v_bar        (vdi_handle, (short*)(p +2));
	
	if (!ignore_colours) {
		GRECT b;
		*(PXY*)&b = p[2];
		b.g_w = scroll_bar_width -2;
		b.g_h = p[3].p_y - p[2].p_y +1;
		draw_border (&b, G_WHITE, G_LBLACK, 1);
		vsl_color (vdi_handle, G_BLACK);
	}
	p[1].p_y = --p[2].p_y;
	p[4].p_y = ++p[3].p_y;
	p[4].p_x = lft;
	v_pline (vdi_handle, 2, (short*)(p +1));
	v_pline (vdi_handle, 2, (short*)(p +3));
	
	if (!complete) {
		v_show_c (vdi_handle, 1);
	}
	vswr_mode (vdi_handle, MD_TRANS);
}

void
draw_hbar (FRAME frame, BOOL complete)
{
	short top = frame->clip.y + frame->clip.h +1;
	short bot = top + scroll_bar_width -3;
	short lft = frame->clip.x
	          + scroll_bar_width - (frame->border ? 2 : 1);
	short rgt = frame->clip.x + frame->clip.w
	          - scroll_bar_width + (frame->border || frame->v_scroll_on ? 1 : 0);
	long  bar = rgt - lft -1;
	PXY p[8];
	
	vsl_color (vdi_handle, G_BLACK);
	
	if (complete) {
		short n;
		p[0].p_y = p[1].p_y = top -1;
		p[0].p_x            = frame->clip.x + frame->clip.w -1;
		p[1].p_x            = frame->clip.x;
		if (frame->border) {
			n = 2;
		} else {
			p[2].p_y = p[3].p_y = bot +1;
			p[2].p_x = p[1].p_x;
			p[3].p_x = p[0].p_x;
			if (frame->h_scroll_on) {
				n = 4;
			} else {
				p[4] = p[0];
				n = 5;
			}
		}
		if (frame->h_scroll_on) {
			p[0].p_x += scroll_bar_width -1;
		}
		v_pline (vdi_handle, n, (short*)p);
		
		p[0].p_x = lft - (scroll_bar_width -2);
		p[1].p_x = lft - 1;
		p[2].p_x = rgt + 1;
		p[3].p_x = rgt + (scroll_bar_width -2);
		p[0].p_y = p[2].p_y = top;
		p[1].p_y = p[3].p_y = bot;
		v_bar (vdi_handle, (short*)(p +0));
		v_bar (vdi_handle, (short*)(p +2));
		p[0].p_x = ++p[1].p_x;
		p[3].p_x = --p[2].p_x;
		v_pline (vdi_handle, 2, (short*)(p +0));
		v_pline (vdi_handle, 2, (short*)(p +2));
		
		p[0].p_y = p[7].p_y = top + (scroll_bar_width -2) /2;
		p[1].p_y = p[6].p_y = top + 1;
		p[2].p_y = p[5].p_y = bot - 1;
		p[0].p_x            = lft - (scroll_bar_width -3);
		p[1].p_x = p[2].p_x = lft - 3;
		p[3]     = p[0];
		p[7].p_x            = rgt + (scroll_bar_width -3);
		p[6].p_x = p[5].p_x = rgt + 3;
		p[4]     = p[7];
		if (ignore_colours) {
			v_pline (vdi_handle, 4, (short*)(p +0));
			v_pline (vdi_handle, 4, (short*)(p +4));
		} else {
			GRECT b;
			b.g_w = b.g_h = scroll_bar_width -2;
			b.g_y = top;
			b.g_x = lft - (scroll_bar_width -2);
			draw_border (&b, G_WHITE, G_LBLACK, 1);
			b.g_x = rgt + 1;
			draw_border (&b, G_WHITE, G_LBLACK, 1);
			v_pline (vdi_handle, 2, (short*)(p +0));
			v_pline (vdi_handle, 3, (short*)(p +5));
			vsl_color (vdi_handle, G_WHITE);
			v_pline (vdi_handle, 3, (short*)(p +1));
			v_pline (vdi_handle, 2, (short*)(p +4));
		}
	
	} else {
		v_hide_c (vdi_handle);
	}
	
	p[0].p_y = p[2].p_y = top;
	p[0].p_x = p[2].p_x = lft +1;
	p[1].p_y = p[3].p_y = bot;
	p[1].p_x =            rgt -1;
	vswr_mode    (vdi_handle, MD_REPLACE);
	vsf_interior (vdi_handle, FIS_PATTERN);
	vsf_style    (vdi_handle, 4);
	vsf_color    (vdi_handle, G_LBLACK);
	v_bar        (vdi_handle, (short*)p);
	
	p[3].p_x = (bar * frame->clip.w) / frame->frame.w;
	if (p[3].p_x < scroll_bar_width -2)
	    p[3].p_x = scroll_bar_width -2;
	p[2].p_x += ((bar - p[3].p_x) * frame->horizontal_scroll)
	          / (frame->frame.w - frame->clip.w);
	p[3].p_x += p[2].p_x -1;
	vsf_interior (vdi_handle, FIS_SOLID);
	vsf_color    (vdi_handle, (ignore_colours ? G_WHITE : G_LWHITE));
	v_bar        (vdi_handle, (short*)(p +2));
	
	if (!ignore_colours) {
		GRECT b;
		*(PXY*)&b = p[2];
		b.g_w     = p[3].p_x - p[2].p_x +1;
		b.g_h     = scroll_bar_width -2;
		draw_border (&b, G_WHITE, G_LBLACK, 1);
		vsl_color (vdi_handle, G_BLACK);
	}
	p[1].p_x = --p[2].p_x;
	p[4].p_x = ++p[3].p_x;
	p[4].p_y = top;
	v_pline (vdi_handle, 2, (short*)(p +1));
	v_pline (vdi_handle, 2, (short*)(p +3));
	
	if (!complete) {
		v_show_c (vdi_handle, 1);
	}
	vswr_mode (vdi_handle, MD_TRANS);
}



void
blit_block (struct frame_item *frame, WORD distance, enum direction direction_of_scroll)
{
	MFDB screen;
	WORD pts[8], x, y, w, h;
	long x_abs = (long)frame->clip.x - frame->horizontal_scroll;
	long y_abs = (long)frame->clip.y - frame->vertical_scroll;

/*	frame->frame.x = frame->clip.x - frame->horizontal_scroll;*/
/*	frame->frame.y = (WORD)((long)frame->clip.y - frame->vertical_scroll);*/
	vsf_color (vdi_handle, frame->background_colour);
	wind_get (window_handle, WF_FIRSTXYWH, &x, &y, &w, &h);
	do
	{
		if (x < frame->clip.x + frame->clip.w && y < frame->clip.y + frame->clip.h
		    && frame->clip.x < x + w && frame->clip.y < y + h)
		{
			GRECT clip;
			pts[4] = pts[0] = max (x, frame->clip.x);
			pts[5] = pts[1] = max (y, frame->clip.y);
			pts[6] = pts[2] = min (x + w, frame->clip.x + frame->clip.w) - 1;
			pts[7] = pts[3] = min (y + h, frame->clip.y + frame->clip.h) - 1;
			clip.g_w = pts[2] - (clip.g_x = pts[0]) +1;
			clip.g_h = pts[3] - (clip.g_y = pts[1]) +1;
			screen.fd_addr = 0;
			vs_clip (vdi_handle, 1, pts);
			frame->current.paragraph = frame->item;
			switch (direction_of_scroll)
			{
				case d_up:
					if (pts[3] - distance > pts[1])
					{
						pts[3] -= distance;
						pts[5] += distance;
						vro_cpyfm (vdi_handle, 3, pts, &screen, &screen);
						pts[3] = pts[5];
					}
					vr_recfl (vdi_handle, pts);

					/* turn off old clip for entire window */
					vs_clip (vdi_handle, 0, pts);
					
					/* turn on new clip for just redraw area */
					vs_clip (vdi_handle, 1, pts);
					
					draw_contents (frame->item, x_abs /*frame->frame.x*/,
							     y_abs, clip.g_w /*frame->frame.y, frame->frame.w*/,
							     /*pts[3], pts[1],*/ &clip);


/*							     pts[3] - pts[1], pts[1]);*/
					break;
				case d_down:
					if (pts[1] + distance < pts[3])
					{
						pts[1] += distance;
						pts[7] -= distance;
						vro_cpyfm (vdi_handle, 3, pts, &screen, &screen);
						pts[1] = pts[7];
					}
					vr_recfl (vdi_handle, pts);

					/* turn off old clip for entire window */
					vs_clip (vdi_handle, 0, pts);

					/* turn on new clip for just redraw area */
					vs_clip (vdi_handle, 1, pts);

					draw_contents (frame->item, x_abs /*frame->frame.x*/,
							     y_abs, clip.g_w /*frame->frame.y, frame->frame.w*/,
							     /*pts[3], pts[1],*/ &clip);
/*							     pts[3] - pts[1], pts[1]);*/
					break;
				case d_left:
					if (pts[2] - distance > pts[0])
					{
						pts[2] -= distance;
						pts[4] += distance;
						vro_cpyfm (vdi_handle, 3, pts, &screen, &screen);
						pts[2] = pts[4];
					}
					vr_recfl (vdi_handle, pts);

					/* turn off old clip for entire window */
					vs_clip (vdi_handle, 0, pts);
					
					/* turn on new clip for just redraw area */
					vs_clip (vdi_handle, 1, pts);

					draw_contents (frame->item, x_abs /*frame->frame.x*/,
							     y_abs, clip.g_w /*frame->frame.y, frame->frame.w*/,
							     /*pts[3], pts[1],*/ &clip);
/*							     pts[3] - pts[1], pts[1]);*/
					break;
				case d_right:
					if (pts[0] + distance < pts[2])
					{
						pts[0] += distance;
						pts[6] -= distance;
						vro_cpyfm (vdi_handle, 3, pts, &screen, &screen);
						pts[0] = pts[6];
					}
					vr_recfl (vdi_handle, pts);

					/* turn off old clip for entire window */
					vs_clip (vdi_handle, 0, pts);
					
					/* turn on new clip for just redraw area */
					vs_clip (vdi_handle, 1, pts);

					draw_contents (frame->item, x_abs /*frame->frame.x*/,
							     y_abs, clip.g_w /*frame->frame.y, frame->frame.w*/,
							     /*pts[3], pts[1],*/ &clip);
/*							     pts[3] - pts[1], pts[1]);*/
					break;
			}
			/* This had been a 0 instead of pts
			 * caused it to crash on my TT
			 * baldrick July 14, 2001
			 */
			vs_clip (vdi_handle, 0, pts);

		}
		wind_get (window_handle, WF_NEXTXYWH, &x, &y, &w, &h);
	}
	while (w + h > 0);
}

/*printf("current frame x = %d y = %d w = %d h = %d\r\n",current_frame->frame_left,
current_frame->frame_top,current_frame->frame_width,current_frame->frame_height);
*/

void
redraw (WORD handle, WORD rx, WORD ry, WORD rw, WORD rh, struct frame_item *current_frame)
{
	vsf_color (vdi_handle, 0);

	if (frames_recalculated == true)
		wind_get (window_handle, WF_WORKXYWH, &rx, &ry, &rw, &rh);

	while (current_frame != 0)
	{
		redraw_frame (handle, rx, ry, rw, rh, current_frame);

		draw_frame_borders (current_frame, 0);

		current_frame = frame_next (current_frame);
	}

	frames_recalculated = false;
}

void
redraw_frame (WORD handle, WORD rx, WORD ry, WORD rw, WORD rh,
	      struct frame_item *current_frame)
{
	WORD pts[4], x, y, w, h;
	long x_abs, y_abs;

	if (current_frame->frame_named_location)
	{
		current_frame->vertical_scroll = search_for_named_location (current_frame->frame_named_location, current_frame->first_named_location);
		current_frame->frame_named_location = NULL;

/* we are missing an assignment of frame->frame.h somewhere.  Without that this test is junk and causes
   problems elsewhere in the system.  So until it's fixed it's been rem'd out.  Baldrick Dec 17 2001)
		if (current_frame->vertical_scroll > current_frame->current_page_height - current_frame->frame.h)
			current_frame->vertical_scroll = current_frame->current_page_height - current_frame->frame.h;
*/
	}
	x_abs = (long)current_frame->clip.x - current_frame->horizontal_scroll;
	y_abs = (long)current_frame->clip.y - current_frame->vertical_scroll;

/*	current_frame->frame.x = current_frame->clip.x - current_frame->horizontal_scroll;*/
/*	current_frame->frame.y = (WORD)((long)current_frame->clip.y - current_frame->vertical_scroll);*/

	wind_get (window_handle, WF_FIRSTXYWH, &x, &y, &w, &h);

	if (current_frame->clip.x < rx + rw && current_frame->clip.y < ry + rh
	    && rx < current_frame->clip.x + current_frame->clip.w
	    && ry < current_frame->clip.y + current_frame->clip.h)
	{
		wind_get (window_handle, WF_FIRSTXYWH, &x, &y, &w, &h);
		graf_mouse (M_OFF, 0);
		wind_update (BEG_UPDATE);

		do
		{
			if (x < rx + rw && y < ry + rh && rx < x + w && ry < y + h
			    && x < current_frame->clip.x + current_frame->clip.w
			    && y < current_frame->clip.y + current_frame->clip.h
			    && current_frame->clip.x < x + w && current_frame->clip.y < ry + rh)
			{
				GRECT clip;
				pts[0] = max (current_frame->clip.x, max (x, rx));
				pts[1] = max (current_frame->clip.y, max (y, ry));
				pts[2] = min (current_frame->clip.x + current_frame->clip.w, min (x + w, rx + rw)) - 1;
				pts[3] = min (current_frame->clip.y + current_frame->clip.h, min (y + h, ry + rh)) - 1;

				vs_clip (vdi_handle, 1, pts); 

				vsf_color (vdi_handle, current_frame->background_colour);
				vr_recfl (vdi_handle, pts);

				clip.g_w = pts[2] - (clip.g_x = pts[0]) +1;
				clip.g_h = pts[3] - (clip.g_y = pts[1]) +1;
				current_frame->current.paragraph = current_frame->item;
				draw_contents (current_frame->item, x_abs /*current_frame->frame.x*/,
						     y_abs, clip.g_w /*current_frame->frame.y, current_frame->frame.w*/,
						     /*pts[3], pts[1],*/ &clip);

				/* this was a 0 instead of pts, this caused it
				 * to crash on my machine - Baldrick July 14, 2001
				 */
				vs_clip (vdi_handle, 0, pts);
			}
			wind_get (window_handle, WF_NEXTXYWH, &x, &y, &w, &h);
		}
		while (w + h > 0);

		wind_update (END_UPDATE);
		graf_mouse (M_ON, 0);
	}
}


static void
draw_sliders (struct frame_item *frame)
{
	WORD pts[4];
	long slider_length, slider_pos, scroll_length;

	if (frame->v_scroll_on == true)
	{
		scroll_length = frame->clip.h - 1 - scroll_bar_width * 2;
		slider_length = frame->clip.h * scroll_length / frame->current_page_height;
		if (slider_length < scroll_bar_width)
			slider_length = scroll_bar_width;
		slider_pos =
			((scroll_length - slider_length) * frame->vertical_scroll /
			 (frame->current_page_height - frame->clip.h)) + frame->clip.y +
			scroll_bar_width + 1;

		pts[2] = pts[0] = frame->clip.x + frame->clip.w + 1;
		pts[2] += scroll_bar_width - 3;
		pts[3] = pts[1] = (WORD)slider_pos + 1;
		pts[3] += (WORD)slider_length - 3;
		vsf_color (vdi_handle, slider_col);
		vr_recfl (vdi_handle, pts);
		vsf_color (vdi_handle, slider_bkg); 
		pts[1] = frame->clip.y + scroll_bar_width + 1;
		pts[3] = (WORD)slider_pos - 1;
		if (pts[1] < pts[3])
			vr_recfl (vdi_handle, pts);
		pts[1] = ++pts[3];
		v_pline (vdi_handle, 2, pts);
		pts[3] = pts[1] = (WORD)(slider_pos + slider_length - 1);
		v_pline (vdi_handle, 2, pts);
		pts[1]++;
		pts[3] = frame->clip.y + frame->clip.h - 1 - scroll_bar_width;
		if (pts[1] < pts[3])
			vr_recfl (vdi_handle, pts);
	}

	if (frame->h_scroll_on == true)
	{
		scroll_length = frame->clip.w - 1 - scroll_bar_width * 2;
		slider_length = frame->clip.w * scroll_length / frame->frame.w;
		if (slider_length < scroll_bar_width)
			slider_length = scroll_bar_width;
		slider_pos =
			((scroll_length - slider_length) * frame->horizontal_scroll /
			 (frame->frame.w - frame->clip.w)) + frame->clip.x + scroll_bar_width + 1;

		pts[3] = pts[1] = frame->clip.y + frame->clip.h + 1;
		pts[3] += scroll_bar_width - 3;
		pts[2] = pts[0] = (WORD)slider_pos + 1;
		pts[2] += (WORD)slider_length - 3;
		vsf_color (vdi_handle, slider_col);
		vr_recfl (vdi_handle, pts);
		vsf_color (vdi_handle, slider_bkg);
		pts[0] = frame->clip.x + scroll_bar_width + 1;
		pts[2] = (WORD)slider_pos - 1;
		if (pts[0] < pts[2])
			vr_recfl (vdi_handle, pts);
		pts[0] = ++pts[2];
		v_pline (vdi_handle, 2, pts);
		pts[2] = pts[0] = (WORD)(slider_pos + slider_length - 1);
		v_pline (vdi_handle, 2, pts);
		pts[0]++;
		pts[2] = frame->clip.x + frame->clip.w - 1 - scroll_bar_width;
		if (pts[0] < pts[2])
			vr_recfl (vdi_handle, pts);
	}
}

void
draw_frame_borders (struct frame_item *current_frame, WORD flag)
{
	WORD pts[8], clip[4], x, y, w, h;

	wind_get (window_handle, WF_FIRSTXYWH, &x, &y, &w, &h);
	graf_mouse (M_OFF, 0);
	wind_update (BEG_UPDATE);
	do
	{
		clip[0] = x;
		clip[1] = y;
		clip[2] = x + w - 1;
		clip[3] = y + h - 1;
		vs_clip (vdi_handle, 1, clip);

		draw_sliders (current_frame);

		if (flag == 1)
		{
			/* This next was a 0 instead of clip
			 * again it caused a crash on my TT
			 * baldrick July 14, 2001
			 */
			vs_clip (vdi_handle, 0, clip);
			wind_get (window_handle, WF_NEXTXYWH, &x, &y, &w, &h);
			continue;
		}

		if (current_frame->border == true)
		{
			pts[2] = pts[0] = current_frame->clip.x - 1;
			pts[3] = pts[1] = current_frame->clip.y - 1;
			pts[3] += current_frame->clip.h + 2;
			if (current_frame->h_scroll_on == true)
				pts[3] += scroll_bar_width - 1;
			v_pline (vdi_handle, 2, pts);
			pts[3] = pts[1];
			pts[2] += current_frame->clip.w + 2;
			if (current_frame->v_scroll_on == true)
				pts[2] += scroll_bar_width - 1;
			v_pline (vdi_handle, 2, pts);
		}

		if (current_frame->h_scroll_on == true || current_frame->border == true)
		{
			pts[2] = pts[0] = current_frame->clip.x;
			pts[2] += current_frame->clip.w - 1;
			pts[3] = pts[1] = current_frame->clip.y + current_frame->clip.h;
			v_pline (vdi_handle, 2, pts);
			if (current_frame->h_scroll_on == true)
			{
				pts[1] = pts[3] += scroll_bar_width - 1;
				v_pline (vdi_handle, 2, pts);

				pts[1] -= scroll_bar_width - 2;
				pts[3]--;
				pts[2] = pts[0];
				v_pline (vdi_handle, 2, pts);

				pts[0]++;
				pts[2] += scroll_bar_width - 1;
				vsf_color (vdi_handle, slider_col);
				vr_recfl (vdi_handle, pts);
				pts[0] = ++pts[2];
				v_pline (vdi_handle, 2, pts);

				pts[0] = pts[2] = current_frame->clip.x + current_frame->clip.w -	scroll_bar_width;
				v_pline (vdi_handle, 2, pts);

				pts[2] += scroll_bar_width - 1;
				pts[0]++;
				vr_recfl (vdi_handle, pts);
				pts[0] = ++pts[2];
				v_pline (vdi_handle, 2, pts);

				/*left arrow*/
				pts[5] = pts[3] = pts[1] = current_frame->clip.y + current_frame->clip.h;
				pts[6] = pts[2] = pts[0] = current_frame->clip.x + scroll_bar_width / 3;
				pts[7] = pts[1] += scroll_bar_width / 2;
				pts[3] += scroll_bar_width / 4;
				pts[5] += scroll_bar_width * 3 / 4;
				pts[4] = pts[2] += scroll_bar_width / 2;
				v_pline (vdi_handle, 4, pts);

				/* right arrow */
				pts[6] = pts[2] = pts[0] = current_frame->clip.x + current_frame->clip.w - scroll_bar_width / 3;
				pts[4] = pts[2] -= scroll_bar_width / 2;
				v_pline (vdi_handle, 4, pts);
			}
		}

		if (current_frame->v_scroll_on == true || current_frame->border == true)
		{
			pts[3] = pts[1] = current_frame->clip.y;
			pts[3] += current_frame->clip.h - 1;
			pts[2] = pts[0] = current_frame->clip.x + current_frame->clip.w;
			v_pline (vdi_handle, 2, pts);
			if (current_frame->v_scroll_on == true)
			{
				pts[0] = pts[2] += scroll_bar_width - 1;
				v_pline (vdi_handle, 2, pts);
				vsf_color (vdi_handle, slider_col);
				pts[0] -= scroll_bar_width - 2;
				pts[2]--;
				pts[3] = pts[1];
				v_pline (vdi_handle, 2, pts);
				pts[1]++;
				pts[3] += scroll_bar_width - 1;
				vr_recfl (vdi_handle, pts);
				pts[1] = ++pts[3];
				v_pline (vdi_handle, 2, pts);
				pts[1] = pts[3] = current_frame->clip.y + current_frame->clip.h - scroll_bar_width;
				v_pline (vdi_handle, 2, pts);
				pts[3] += scroll_bar_width - 1;
				pts[1]++;
				vsf_color (vdi_handle, slider_col);
				vr_recfl (vdi_handle, pts);
				pts[1] = ++pts[3];
				v_pline (vdi_handle, 2, pts);

				/* up arrow */
				pts[4] = pts[2] = pts[0] = current_frame->clip.x + current_frame->clip.w;
				pts[7] = pts[3] = pts[1] = current_frame->clip.y + scroll_bar_width / 3;
				pts[6] = pts[0] += scroll_bar_width / 2;
				pts[2] += scroll_bar_width / 4;
				pts[4] += scroll_bar_width * 3 / 4;
				pts[5] = pts[3] += scroll_bar_width / 2;
				v_pline (vdi_handle, 4, pts);

				/* down arrow */
				pts[7] = pts[3] = pts[1] = current_frame->clip.y + current_frame->clip.h -
					scroll_bar_width / 3;
				pts[5] = pts[3] -= scroll_bar_width / 2;
				v_pline (vdi_handle, 4, pts);
			}
		}

		if (current_frame->v_scroll_on == true && current_frame->h_scroll_on == true)
		{
			pts[2] = pts[0] = current_frame->clip.x + current_frame->clip.w + 1;
			pts[3] = pts[1] = current_frame->clip.y + current_frame->clip.h + 1;
			pts[2] += scroll_bar_width - 3;
			pts[3] += scroll_bar_width - 3;
			vr_recfl (vdi_handle, pts);
			pts[0] = ++pts[2];
			pts[3]++;
			v_pline (vdi_handle, 2, pts);
			pts[1] = pts[3];
			pts[0] -= scroll_bar_width - 2;
			v_pline (vdi_handle, 2, pts);
		}

		/* This next was a 0 instead of clip
		 * again it caused a crash on my TT
		 * baldrick July 14, 2001
		 */
		vs_clip (vdi_handle, 0, clip);

		wind_get (window_handle, WF_NEXTXYWH, &x, &y, &w, &h);
	}
	while (w + h > 0);
	wind_update (END_UPDATE);
	graf_mouse (M_ON, 0);
}

/* draw_box
 * 
 * draws a bounding box around an item
 * pts[4] is the object coordinates
 * border_color - is just that the border color
 */
static void
draw_box(WORD pts[4], WORD border_color)
{
	WORD pts2[4];
	
	vsl_color(vdi_handle, border_color);
	
	pts2[0] = pts2[2] = pts[0];
	pts2[1] = pts[1];
	pts2[3] = pts[3];
	v_pline (vdi_handle, 2, pts2);

	pts2[0] = pts2[2] = pts[2];
	pts2[1] = pts[1];
	pts2[3] = pts[3];
	v_pline (vdi_handle, 2, pts2);

	pts2[1] = pts2[3] = pts[1];
	pts2[0] = pts[0];
	pts2[2] = pts[2];
	v_pline (vdi_handle, 2, pts2);

	pts2[1] = pts2[3] = pts[3];
	pts2[0] = pts[0];
	pts2[2] = pts[2];
	v_pline (vdi_handle, 2, pts2);

	vsl_color(vdi_handle, 1);
}

/* draw_hr
 *
 * current_paragraph - our paragraph descriptor for the hr tag
 * x,y and w - the location and restraining width for the hr tag
 */
static void
draw_hr(struct paragraph_item *current_paragraph, WORD x, WORD y, WORD w)
{
	struct word_item *current_word;
	WORD current_line_width;
	WORD pts[4];
	
	current_word = current_paragraph->item;

	/* I changed the line below to frame_w, with
	 * the old code the horizontal rulers didn't not
	 * cover the frame as they are supposed to
	 * baldrick - July 13, 2001
	 *
	 * Alright I made another modification it now substracts
	 * 10 from the length and starts at 5 on a default
	 * This gives it that slight offset that you might be
	 * used to with other browsers
	 * baldrick - July 18, 2001
	 */

	if (current_word->word_width < 0)
		current_line_width = (WORD)((long)current_word->word_width * ((long)w / 10L) / -10L) - 10;
	else
		current_line_width = current_word->word_width;
				
	switch (current_paragraph->eop_space)
	{
		case center:
			pts[0] = (w - current_line_width) / 2;
			pts[2] = w - pts[0];
			break;
		case right:
			pts[0] = (w - current_line_width);
			pts[2] = w;
			break;
		default:
			pts[0] = 5;
			pts[2] = current_line_width;
	}

	pts[0] += x;
	pts[2] += (x - 1);
	pts[1] = pts[3] = y;/* + 10; what is 10 for ? baldrick*/
			
	if (current_word->word_height < 1)
	{
		pts[3] -= current_word->word_height;
		vsf_color (vdi_handle, 1);
		vr_recfl (vdi_handle, pts);
	}
	else
	{
		pts[3] += current_word->word_height - 1;
		vsf_color (vdi_handle, 9);
		vr_recfl (vdi_handle, pts);
		vsf_color (vdi_handle, 8);
		pts[0]++;
		pts[1]++;
		pts[2]++;
		pts[3]++;
		vr_recfl (vdi_handle, pts);
	}
}

/* draw_img
 *
 * current_paragraph - our paragraph descriptor for the IMG tag
 * x,y and w - the location and restraining width for the IMG tag
 */
static void
draw_img(struct paragraph_item *current_paragraph, WORD x, WORD y, WORD w)
{
	struct word_item *current_word;
	WORD current_line_width;
	WORD pts[4];
	
	current_word = current_paragraph->item;

	/* this section is for displaying an IMG
	 * 
	 * baldrick august 28, 2001
	 */

	current_line_width = current_word->word_width;

	switch (current_paragraph->eop_space)
	{
		case center:
			pts[0] = (w - current_line_width) / 2;
			pts[2] = w - pts[0];
			break;
		case right:
			pts[0] = (w - current_line_width) - 2;
			pts[2] = w - 2;
			break;
		case left:
			pts[0] = 3;
			pts[2] = current_line_width + 3;
			break;
		default: /* just assume it's left */
			pts[0] = 3;
			pts[2] = current_line_width + 3;
	}

	pts[0] += x;
	pts[2] += (x - 1);
	pts[1] = pts[3] = y;
			
	pts[3] += current_word->word_height - 1;

	vsf_color (vdi_handle, 9);
	v_bar(vdi_handle, pts);

	draw_box(pts,1);

}


/* draw_paragraph
 *
 * This handles any text sort of paragraph rendering
 *
 * current_paragraph - our paragraph descriptor
 * x,y,w and h - the location and restraining width
 * top_of_page ->start of drawing area
 * l_border, r_border and b_border are borders for the text to avoid
 * alignment any default alignment for the paragraph
 */
static void set_veffects(struct word_item *current_word);

static long
draw_paragraph (PARAGRPH paragraph, WORD x_off, long y_off, const GRECT * clip)
{
	WORDLINE line = paragraph->Line;
	long   clip_y = clip->g_y;
	
	while (line) {
		long y = y_off + line->Ascend + line->Descend;
		if (y > clip_y) break;
		y_off = y;
		line  = line->NextLine;
	}
	clip_y += clip->g_h -1;
	
	if (line) {
	 	
	 	if (!line->Word) {
	 		puts ("draw_paragraph(): empty line!");
	 		return 0;
	 	}
	 	
	 	set_veffects (line->Word);
	 }
	while (line && y_off < clip_y) {
		struct word_item * word = line->Word;
		WORD * text = word->item;
		short  n    = line->Count;
		y_off += line->Ascend;
	 	
	 	if (!word) {
	 		puts ("draw_paragraph(): empty line (2)!");
	 		break;
	 	} else if (!text) {
	 		puts ("draw_paragraph(): empty word!");
	 		break;
	 	}
		
		if (*text == Space_Code) {
			text++;
		}
		while(1) {
			short x = x_off + word->h_offset;
			short y = y_off;
		 	
		 	if (!word) {
		 		puts ("draw_paragraph(): empty line (3)!");
		 		break;
		 	} else if (!word->item) {
		 		puts ("draw_paragraph(): empty word (2)!");
		 		break;
		 	}
			
			switch (word->vertical_align) {
				case below: y += word->word_height /2; break;
				case above: y -= word->word_height /2; break;
				default: ;
			}
			if (word->changed.style) {
				vst_effects (vdi_handle, 8 * (word->styles.underlined != 0));
			}
			if (word->changed.font) {
				short u;
				vst_font (vdi_handle,
				          fonts[word->styles.font]
				               [(word->styles.bold != 0)]
				               [(word->styles.italic != 0)]);
					
				vst_arbpt (vdi_handle, word->styles.font_size, &u,&u,&u,&u);
			}
			if (word->changed.colour) {
				if (word->link && current_highlighted_link_area &&
				    word->link == current_highlighted_link_area->link) {
					vst_color (vdi_handle, highlighted_link_colour);
				} else {
					vst_color (vdi_handle, word->colour);
				}
			}
			v_ftext16 (vdi_handle, x, y, text);
			
			if (word->styles.strike) {
				PXY p[2];
				p[1].p_x = (p[0].p_x = x) + word->word_width  -1;
				p[1].p_y =  p[0].p_y = y  - word->word_height /2;
				if (n == line->Count && word->item[0] == Space_Code) {
					p[1].p_x -= word->space_width +1;
				}
				v_pline (vdi_handle, 2, (short*)p);
			}
			if (!--n) break;
			word = word->next_word;
			text = word->item;
		}
		
		y_off += line->Descend;
		line  =  line->NextLine;
	}
	return y_off;
}
#if 0 /***** REPLACED *****/
draw_paragraph(struct paragraph_item *current_paragraph, WORD x, long y_off, WORD w, WORD h, WORD top_of_page, WORD l_border, WORD r_border, WORD b_border, WORD alignment)
{
	struct word_item *current_word, *line_start, *line_end;
	WORD left_indent, right_indent, line_height, current_line_width, line_tail = 0;
	WORD u, alignment_spacer, height_spacer;
	WORD previous_word_height = 0, pts[4];

/*printf("start y_off = %ld                                 \r\n",y_off);
*/	
	current_word = current_paragraph->item;

	left_indent = current_paragraph->left_border + l_border; /* baldrick August 28, 2001 modified to offset for pics */
	right_indent = current_paragraph->right_border + r_border;

	while (current_word != 0)
	{
		current_line_width = 0;
		line_start = current_word;
		line_height = 0;
		line_tail = 0;

/*printf("1 y_off = %ld                             \r\n",y_off);
*/
		/* if past the object reset the borders */
		if (b_border)
		{
			if (y_off >= b_border)
			{
				left_indent = current_paragraph->left_border;
				right_indent = current_paragraph->right_border;	
				b_border = 0;
				l_border = 0;
			}
		}
/*printf("2 y_off = %ld                             \r\n",y_off);
*/
		/* if we have a border we have an object to work around */

		if (l_border)
		{
			if ((current_line_width + current_word->word_width)
				>= (w - left_indent - right_indent))
			{

				/* watch for b_border or else tables will not print
				 */
				 
				if (b_border > 0)
					y_off = b_border;
					
				left_indent = current_paragraph->left_border;
				l_border = 0;
				b_border = 0;
			}
		}
		
/*printf("3 y_off = %ld    right border = %d                         \r\n",y_off,r_border);
*/
		if (r_border)
		{
			if ((current_line_width + current_word->word_width)
				>= (w - left_indent - right_indent))
			{
				y_off = b_border;
				right_indent = current_paragraph->right_border;
				r_border = 0;
				b_border = 0;
			}
		}

/*printf("4 y_off = %ld                             \r\n",y_off);
*/

/* Under some circumstances 'w' get a too small value and this loop runs
 * infinite and causes a system freeze due to wind_update (BEG_UPDATE)
 * without an END_UPDATE.  The following workaround cures this symptome
 * even if I don't know the failure reason yet. -- AltF4 Jan 02, 2002
 *
		while (current_word != 0
	       && (current_line_width + current_word->word_width) <
	       (w - left_indent - right_indent))
		{
			if (current_word->line_brk && current_word != line_start)
				break;
*/
		while (current_word != 0)
		{
			short word_width = current_word->word_width;
			if (current_line_width == 0 && *current_word->item == Space_Code)
				word_width -= current_word->space_width +1;
			
			if (current_word != line_start  &&
			    (current_word->line_brk  ||
	           (current_line_width + word_width)
	            >= (w - left_indent - right_indent)))
				break;

			/* filter out single spaces, these are wrong -- AltF4 Mar. 07, 2002
			 */
			if (current_word->item[0] != Space_Code || current_word->item[1]) {
				current_line_width += word_width;
	
				if (line_height < current_word->word_height)
					line_height = current_word->word_height;
				if (line_tail < current_word->word_tail_drop)
					line_tail = current_word->word_tail_drop;
			}
			current_word = current_word->next_word;
		}

/*printf("y_off = %ld     line height = %d       \r\n",y_off,line_height);
*/
		y_off += (long)line_height;

/*
printf("y_off = %ld                             \r\n",y_off);
*/
		line_end = current_word;

		current_word = line_start;

		switch (current_paragraph->alignment)
		{
			case center:
				alignment_spacer = 	(w - current_line_width - left_indent - right_indent) / 2 + left_indent;
				break;
			case right:
				alignment_spacer = (w - current_line_width - left_indent);
				break;
			default:
				if (alignment != -1) /* check for default alignment */
				{
					switch(alignment)
					{
						case center:
							alignment_spacer = (w - current_line_width - left_indent - right_indent) / 2 + left_indent;
							break;
						case right:
							alignment_spacer = (w - current_line_width - left_indent);
							break;
						default:
							alignment_spacer = left_indent;
					}
				}			
				else
					alignment_spacer = left_indent;
		}

		current_line_width = 0;

		while (current_word != line_end)
		{
			WORD * word_item  = current_word->item;
			short  word_width = current_word->word_width;
			
			if (current_word->changed.style == true)
				vst_effects (vdi_handle, 8 * (current_word->styles.underlined != 0));

			if (current_word->changed.font == true)
			{
				vst_font (vdi_handle,
				fonts[current_word->styles.font]
					[(current_word->styles.bold != 0)]
					[(current_word->styles.italic != 0)]);
					
				vst_arbpt (vdi_handle, current_word->styles.font_size, &u,
						   &u, &u, &u);
			}

			if (current_word->changed.colour == true)
			{
				if (current_word->link && current_highlighted_link_area &&
				    current_word->link == current_highlighted_link_area->link)
				{
					vst_color (vdi_handle, highlighted_link_colour);
				}
				else
				{
					vst_color (vdi_handle, current_word->colour);
				}
			}
				
			switch (current_word->vertical_align)
			{
				case below:
					height_spacer = -(current_word->word_height / 2);
					break;
				case above:
					height_spacer = previous_word_height - current_word->word_height;
					break;
				case bottom:
					previous_word_height = current_word->word_height;
				default:
					height_spacer = line_tail; /* was 0; baldrick July 19, 2001*/
			}

			if (current_line_width == 0 && *word_item == Space_Code)
			{
		#if 1
				word_width -= current_word->space_width +1;
				word_item++;
		#else
				switch (current_paragraph->alignment)
				{
					case right:
						break;
					case center:
						alignment_spacer -= current_word->space_width /2 +1;
						break;
					default:
						alignment_spacer -= current_word->space_width    +1;
				}
		#endif
			}
/*printf("y_off = %ld  other = %ld           \r\n",y_off,(long)(top_of_page - line_tail - 2));
*/
			if (y_off > (long)(top_of_page - line_tail - 2))
			{
				if (current_word->link) vst_effects (vdi_handle, TXT_UNDERLINED);
				v_ftext16 (vdi_handle, x + current_line_width + alignment_spacer,
				           y_off - height_spacer, word_item);
				if (current_word->link) vst_effects (vdi_handle, TXT_NORMAL);

				if (current_word->styles.strike != 0)
				{
					pts[0] = x + current_line_width + alignment_spacer;
					pts[1] = pts[3] = y_off - (current_word->word_height / 2);
					pts[2] = pts[0] + word_width;
					v_pline (vdi_handle, 2, pts);
				}
			}

			current_line_width += word_width;
			current_word = current_word->next_word;
		}
			
		y_off += line_tail;
			
		if (y_off + (current_paragraph->eop_space < 0 ? current_paragraph->eop_space : 0) > (h + top_of_page))
			return(y_off);

	}

	return(y_off);
}
#endif /***** REPLACED *****/


/* set_veffects
 *
 * a number of vdi effects that are set in exactly the same
 * way in a large number of places in this module
 * baldrick January 29, 2002
 */
 
static void
set_veffects(struct word_item *current_word)
{
	WORD junk;
	
	vst_effects (vdi_handle, 8 * (current_word->styles.underlined != 0));
	vst_font (vdi_handle, fonts[current_word->styles.font][(current_word->styles.bold != 0)][(current_word->styles.italic != 0)]);
	vst_arbpt (vdi_handle, current_word->styles.font_size, &junk, &junk, &junk, &junk);
	vst_color (vdi_handle, current_word->colour);
}


/* draw_contents()
 *
 * current_paragraph -> start paragraph for the frame / table cell
 * current_height -> where is top of page in relation to the real top of the page
 *     so when we start it should equal the y offset of the frame as you scroll down
 *     the page, it moves up beyond the y offset of the frame, so it's not drawn
 *     (ex current_height = -120 ... first list would be printed at 120 pixels above the frame top)
 * frame_h -> should be the height of the frame
 * top_of_page -> this should be the y offset of the frame 
 *					but it can be a different value.  This is the top of where to draw.
 *                  When scrolling a page it is just a small value at the bottom etc.
 */
void
draw_contents (PARAGRPH paragraph,
               long x_abs, long y_abs, short width, const GRECT * clip)
{
	long clip_y = (long)clip->g_y - y_abs;
	
	while (paragraph && paragraph->Offset.Y + paragraph->Height <= clip_y) {
		paragraph = paragraph->next_paragraph;
	}
	clip_y = clip->g_y + clip->g_h -1;
	
	while (paragraph) {
		long x = x_abs + paragraph->Offset.X;
		long y = y_abs + paragraph->Offset.Y;
		
		if (y > clip_y) break;
		
		if (paragraph->paragraph_code == PAR_HR) {
			draw_hr (paragraph, x, y, width);
		
		} else if (paragraph->paragraph_code == PAR_IMG) {
			draw_img (paragraph, x, y, width);
		
		} else if (paragraph->paragraph_code == PAR_TABLE) {
			table_draw (paragraph->Table, x, y, clip);
		
		} else { /* normal text */
			draw_paragraph (paragraph, x, y, clip);
		}
		paragraph = paragraph->next_paragraph;
	}
}
#if 0 /***** REPLACED *****/
draw_contents (struct paragraph_item *current_paragraph,
               WORD frame_x, long current_height,
               WORD frame_w, WORD frame_h, WORD top_of_page)
{
	WORD left_border = 0, bottom_border = 0, right_border = 0;
	long old_height = current_height;

/*printf("normal current_height = %ld frame_h = %d\r\n",current_height,frame_h);

	if(current_height > (long)frame_h)
	{
printf("at top current_height = %ld frame_h = %d\r\n",current_height,frame_h);

		return;
	}
*/

	while (current_paragraph)
	{
		/* set current height to our start height plus the vertical
		 * offset of this paragraph
		 */
		 
		current_height = old_height + current_paragraph->area.y;

		/* check if the paragraph appears in the viewport
		 */

		if ((current_height + current_paragraph->area.h) > top_of_page)
		{
			struct word_item * current_word = current_paragraph->item;

			/* I put this here to avoid some strange formatting problems
			 * that were appearing
			 */

		 	set_veffects(current_word);

/*			current_height = old_height + current_paragraph->area.y;
*/
			if (current_paragraph->paragraph_code == PAR_HR)
			{
				draw_hr(current_paragraph, frame_x, (WORD)current_height, frame_w);

				current_height += abs (current_word->word_height) + 20; /* what was the + 20 for? baldrick*/
			}
			else if (current_paragraph->paragraph_code == PAR_IMG)
			{
				draw_img(current_paragraph, frame_x, (WORD)current_height, frame_w);

				/* we now need to look for the borders and location
				 * of following paragraphs.  At some point this code
				 * will be moved or disappear
				 */

				switch (current_paragraph->eop_space)
				{
					case center:
						current_height += abs (current_word->word_height);
						left_border = 0;
						right_border = 0;
						break;
					case right:
						left_border = 0;
						right_border = current_word->word_width + 2;
						break;
					case left:
						left_border = current_word->word_width + 2;
						right_border = 0;
						break;
					default: /* just assume it's left */
						left_border = current_word->word_width + 2;
						right_border = 0;
				}

				bottom_border = (WORD)current_height + abs(current_word->word_height);
			}
			else if (current_paragraph->paragraph_code == PAR_TABLE)
			{
#ifdef _NEW_TABLES
				current_height = table_draw (current_paragraph->Table,
				                             frame_x, current_height, frame_h, top_of_page);
#else
				current_height = draw_table (current_paragraph->table, frame_x,
				                             current_height, frame_w, frame_h,
				                             top_of_page);
/*				current_height += current_paragraph->table->table_height;*/
#endif
			}
			else
			{
				current_height = draw_paragraph(current_paragraph, frame_x, current_height, frame_w, frame_h, top_of_page, left_border, right_border, bottom_border, -1);

				current_height += current_paragraph->eop_space;
			}
		}
/*		else
			printf("failure of match\r\n");
*/
		/* are we past the end of the page?
		 * I put this here since it was previously going way
		 * past the area that it should have stopped at.
		 * possibly not the right location etc here
		 * baldrick September 19, 2001
		 */


		if(current_height > frame_h)
		{
			return;
		}
					
		current_paragraph = current_paragraph->next_paragraph;		
	}
}
#endif /***** REPLACED *****/


/*============================================================================*/
void
draw_border (const GRECT * rec, short lu, short rd, short width)
{
	PXY p[3];
	short b = width;
	p[2].p_x = (p[1].p_x = p[0].p_x = rec->g_x) + rec->g_w -1;
	p[0].p_y = (p[1].p_y = p[2].p_y = rec->g_y) + rec->g_h -1;
	vsl_color (vdi_handle, lu);
	while(1) {
		v_pline (vdi_handle, 3, (short*)p);
		if (!--b) break;
		p[1].p_x = ++p[0].p_x;
		p[1].p_y = ++p[2].p_y;
		p[2].p_x--;
		p[0].p_y--;
	}
	b = width;
	p[0].p_x++; p[1].p_x = p[2].p_x;
	p[2].p_y++; p[1].p_y = p[0].p_y;
	vsl_color (vdi_handle, rd);
	while(1) {
		v_pline (vdi_handle, 3, (short*)p);
		if (!--b) break;
		p[1].p_x = ++p[2].p_x;
		p[1].p_y = ++p[0].p_y;
		p[0].p_x--;
		p[2].p_y--;
	}
}
